// 코코포리아 선생님 — 자동 업데이트
//
// 크롬 확장은 자기 폴더에 파일을 쓸 수 없다. 그래서 사용자가 파일 시스템 접근 권한으로
// "설치 폴더"를 한 번 지정해 주면, 그 뒤로는 이 화면에서
//   새 버전 zip 내려받기 → 그 자리에서 풀기 → 폴더에 덮어쓰기 → chrome.runtime.reload()
// 까지 버튼 한 번으로 끝낸다. (폴더 핸들은 IndexedDB 에 담아 다음에도 쓴다)
//
// 공개 배포본 → 릴리즈 저장소의 version.json + zip

const RELEASE_RAW = 'https://raw.githubusercontent.com/HOTDOGGYDOGGY/CocofoTeacher-release/main/';
const UPDATE_INFO_URL = RELEASE_RAW + 'version.json';
// 배포 zip 서명 확인용 공개키 (ECDSA P-256 · SHA-256). 짝인 비밀키는 배포하는 사람 컴퓨터에만 있다.
// 저장소 계정을 빼앗겨 zip 이 바뀌어도, 이 키로 서명이 풀리지 않으면 폴더에 덮어쓰지 않는다.
const RELEASE_PUBKEY = 'MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEI3dNtbiAgxHk0ZeHf4yMcOvquhw2elYvfWAZFXjy+MFrZGHcnZD1zK79UXF6YI7/vZtqjZDrmy3WkGrbAl7IDg==';
const THEMES = ['dark', 'light', 'mono', 'retro'];

const $ = (id) => document.getElementById(id);
const getSync = (defs) => new Promise((r) => chrome.storage.sync.get(defs, (d) => r(chrome.runtime.lastError ? defs : d)));
const setLocal = (o) => new Promise((r) => chrome.storage.local.set(o, () => r(!chrome.runtime.lastError)));

let latest = null; // version.json 의 dist 정보
let latestCh = ''; // latest 를 어느 채널에서 읽었는가 (폴더 채널과 다르면 다시 읽는다)
let dirHandle = null;
let edVer = '';
let folderInfo = null; // 지정한 폴더의 { name, version } — 버전 비교의 기준

// ---------- 화면 ----------
function normalizeHex(v) {
  const s = String(v || '').trim();
  return /^#[0-9a-fA-F]{6}$/.test(s) ? s : '';
}

async function applyTheme() {
  const s = await getSync({ theme: 'dark', accentColor: '' });
  const theme = THEMES.includes(s.theme) ? s.theme : 'dark';
  for (const t of THEMES) document.body.classList.toggle('theme-' + t, theme === t && t !== 'dark');
  const a = normalizeHex(s.accentColor);
  if (a) document.body.style.setProperty('--accent', a);
}

// 기록 줄 — 받은 값(버전 · 이름 · 오류 문구)이 섞이므로 글자로만 넣는다
let logLines = [];
function renderLog() {
  const box = $('log');
  box.textContent = '';
  logLines.forEach((l, i) => {
    if (i) box.appendChild(document.createElement('br'));
    const span = document.createElement('span');
    if (l.cls) span.className = l.cls;
    span.textContent = l.text;
    box.appendChild(span);
  });
}
function log(text, cls) {
  logLines.push({ text: String(text), cls: cls || '' });
  renderLog();
}
function logClear() {
  logLines = [];
  renderLog();
}

// 버전 줄 — ['글자', { b: '굵게' }, { code: '코드' }] 조각을 이어 쓴다
function setLine(el, parts, append) {
  if (!append) el.textContent = '';
  for (const p of parts) {
    if (p && typeof p === 'object') {
      const n = document.createElement(p.b != null ? 'b' : 'code');
      n.textContent = String(p.b != null ? p.b : p.code);
      el.appendChild(n);
    } else el.appendChild(document.createTextNode(String(p)));
  }
}

// ---------- 서명 확인 ----------
// 배포 저장소 주소인가 — '../' 같은 것을 풀어 본 주소로 견준다 (앞부분만 같고 다른 저장소로 가는 주소를 거른다)
function isReleaseUrl(u) {
  try {
    return new URL(String(u)).href.startsWith(RELEASE_RAW);
  } catch (_) {
    return false;
  }
}

function b64Bytes(s) {
  const bin = atob(String(s));
  const u = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  return u;
}

async function verifyZip(buf, sigB64) {
  if (!sigB64) throw new Error('서명이 없는 zip 이라 받지 않았습니다');
  let sig;
  try {
    sig = b64Bytes(sigB64);
  } catch (_) {
    throw new Error('서명 형식이 잘못되어 받지 않았습니다');
  }
  const key = await crypto.subtle.importKey('spki', b64Bytes(RELEASE_PUBKEY), { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
  const ok = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, key, sig, buf);
  if (!ok) throw new Error('서명이 맞지 않습니다. 배포자가 올린 파일이 아닐 수 있어 받지 않았습니다');
}

// ---------- 버전 ----------
function verCmp(a, b) {
  const pa = String(a || '').split('.').map((n) => parseInt(n, 10) || 0);
  const pb = String(b || '').split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

let runningEdition = () => 'public';
// 지금 확장이 스스로 내세우는 버전
let editionVersion = async () => chrome.runtime.getManifest().version;
let installedEdition = () => 'public';

function currentChannel() {
  if (folderInfo && folderInfo.channel) return folderInfo.channel;
  return runningEdition();
}


async function loadLatest() {
  $('verLine').textContent = '확인 중…';
  $('notes').classList.add('hidden');
  if (!edVer) edVer = await editionVersion();
  const ch = currentChannel();
  const base = (folderInfo && folderInfo.version) || edVer;
  const where = folderInfo ? '설치' : '지금 확장';
  let what = '배포본';
  try {
    latest = null;
    if (!latest) {
      const res = await fetch(UPDATE_INFO_URL, { cache: 'no-store' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const j = await res.json();
      latest = j && j.dist ? { ...j.dist, changelog: j.changelog || [] } : null;
      if (!latest) throw new Error('version.json 을 읽지 못했습니다');
    }
    latestCh = ch;
  } catch (e) {
    latest = null;
    latestCh = '';
    setLine($('verLine'), [`${where} `, { b: `v${base}` }, ` · ${what} 최신 버전을 확인하지 못했습니다 (${e.message})`]);
    refreshGo();
    return;
  }
  const newer = verCmp(latest.version, base) > 0;
  setLine(
    $('verLine'),
    newer
      ? [`${where} v${base} → ${what} 새 버전 `, { b: `v${latest.version}` }, latest.branch ? ` (${latest.branch})` : '']
      : [`${where} `, { b: `v${base}` }, ` · 최신입니다 (${what} v${latest.version})`]
  );
  if (!folderInfo) setLine($('verLine'), [' — 폴더를 지정하면 그 폴더 기준으로 다시 봅니다.'], true);
  const entry = (latest.changelog || []).find((c) => c.v === latest.version) || {};
  // groups [{title, items}] 가 있으면 제목 줄을 끼워 묶어 보여 준다
  const sections =
    Array.isArray(entry.groups) && entry.groups.length
      ? entry.groups.map((g) => ({ title: String((g && g.title) || ''), items: (g && g.items) || [] }))
      : [{ title: '', items: entry.items || [] }];
  const ul = $('notes');
  ul.innerHTML = '';
  if (newer && sections.some((s) => s.items.length)) {
    for (const sec of sections) {
      if (!sec.items.length) continue;
      if (sec.title) {
        const t = document.createElement('li');
        t.className = 'upd-notes-group';
        t.textContent = sec.title;
        ul.appendChild(t);
      }
      for (const it of sec.items) {
        const li = document.createElement('li');
        li.textContent = it;
        ul.appendChild(li);
      }
    }
    ul.classList.remove('hidden');
  } else {
    ul.classList.add('hidden');
  }
  refreshGo();
}

// ---------- 설치 폴더 (IndexedDB 에 핸들 보관) ----------
function idb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open('cst-update', 1);
    req.onupgradeneeded = () => req.result.createObjectStore('handles');
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function idbGet(key) {
  const db = await idb();
  return new Promise((resolve) => {
    const tx = db.transaction('handles', 'readonly').objectStore('handles').get(key);
    tx.onsuccess = () => resolve(tx.result || null);
    tx.onerror = () => resolve(null);
  });
}

async function idbPut(key, val) {
  const db = await idb();
  return new Promise((resolve) => {
    const tx = db.transaction('handles', 'readwrite').objectStore('handles').put(val, key);
    tx.onsuccess = () => resolve(true);
    tx.onerror = () => resolve(false);
  });
}

//   public   : manifest name 이 정확히 '코코포리아 선생님' → 릴리즈 zip
// 반환: { ok, name, version, channel } 또는 { ok:false, why }
const PUBLIC_NAME = '코코포리아 선생님';

function channelOf(name) {
  const n = String(name || '').trim();
  return n === PUBLIC_NAME ? 'public' : '';
}

async function hasEntry(dir, name, kind) {
  try {
    if (kind === 'dir') await dir.getDirectoryHandle(name);
    else await dir.getFileHandle(name);
    return true;
  } catch (_) {
    return false;
  }
}

async function inspectFolder(dir) {
  let manifest = null;
  try {
    const fh = await dir.getFileHandle('manifest.json');
    manifest = JSON.parse(await (await fh.getFile()).text());
  } catch (_) {
    return { ok: false, why: '이 폴더에는 manifest.json 이 없습니다. 크롬에 로드한 확장 폴더를 골라 주세요.' };
  }
  const name = String(manifest.name || '');
  const channel = channelOf(name);
  if (!/코코포리아 선생님/.test(name) || !channel) {
    return { ok: false, why: `이 확장의 설치 폴더가 아닙니다 (${name || '이름 없음'}).` };
  }
  return { ok: true, name, version: manifest.version, channel };
}

function showFolder(info) {
  if (!info) {
    $('folderLine').textContent = '아직 지정하지 않았습니다.';
    $('forgetBtn').classList.add('hidden');
    return;
  }
  $('folderLine').textContent = `${info.dirName} · ${info.name} v${info.version}`;
  $('forgetBtn').classList.remove('hidden');
}

async function loadSavedFolder() {
  const h = await idbGet('extDir');
  if (!h) return showFolder(null);
  dirHandle = h;
  // 권한은 브라우저를 다시 켜면 'prompt' 로 돌아간다 — 업데이트를 누를 때 다시 묻는다
  let name = '';
  let version = '';
  try {
    const perm = await h.queryPermission({ mode: 'readwrite' });
    if (perm === 'granted') {
      const got = await inspectFolder(h);
      name = got.name || '';
      version = got.version || '';
      folderInfo = got.ok ? { name, version, channel: got.channel } : null;
    }
  } catch (_) {}
  showFolder({ dirName: h.name, name: name || '(허가 필요)', version: version || '?' });
  refreshGo();
}

function refreshGo() {
  const ch = currentChannel();
  const base = (folderInfo && folderInfo.version) || edVer;
  const newer = !!latest && verCmp(latest.version, base) > 0;
  // 받아올 곳이 준비돼 있는가 — 공개는 zip 주소
  let source = !!(latest && latest.zip);
  // 새 버전일 때만 덮어쓴다 — 안 그러면 앞선 빌드를 옛 공개판으로 되돌리는 사고가 난다
  $('goBtn').disabled = !(dirHandle && latest && source && newer);
  $('goBtn').textContent = newer
    ? `v${base} → v${latest.version} 로 업데이트`
    : latest
      ? `받을 새 버전이 없습니다 (${folderInfo ? '설치' : '지금'} v${base} · 최신 v${latest.version})`
      : '최신 버전을 확인하지 못했습니다';
}

// ---------- 덮어쓰기 ----------
async function ensurePermission(dir) {
  if ((await dir.queryPermission({ mode: 'readwrite' })) === 'granted') return true;
  return (await dir.requestPermission({ mode: 'readwrite' })) === 'granted';
}

// zip 안 경로대로 폴더를 만들어 가며 쓴다
async function writeEntry(dir, path, bytes) {
  const parts = path.split('/').filter((p) => p && p !== '.' && p !== '..');
  const fileName = parts.pop();
  let cur = dir;
  for (const p of parts) cur = await cur.getDirectoryHandle(p, { create: true });
  const fh = await cur.getFileHandle(fileName, { create: true });
  const w = await fh.createWritable();
  await w.write(bytes);
  await w.close();
}

// ---------- 공개 배포본: zip 하나를 풀어 통째로 덮어쓴다 ----------
async function applyPublicZip(before) {
  if (!latest || !latest.zip) throw new Error('배포본 zip 주소를 찾지 못했습니다');
  if (!isReleaseUrl(latest.zip)) throw new Error('배포 저장소 밖의 zip 주소라 받지 않았습니다');
  log('새 버전 내려받는 중…');
  const res = await fetch(latest.zip, { cache: 'no-store' });
  if (!res.ok) throw new Error('내려받기 실패 (HTTP ' + res.status + ')');
  const buf = await res.arrayBuffer();
  log(`받음 — ${Math.round(buf.byteLength / 1024).toLocaleString()}KB`);
  // 풀기 전에 서명부터 본다 — 맞지 않으면 폴더에는 아무것도 쓰지 않는다
  await verifyZip(buf, latest.sig);
  log('서명 확인: 배포자가 올린 파일입니다');

  const entries = await window.CSTUnzip.unzip(buf);
  const mf = entries.find((e) => e.name === 'manifest.json');
  if (!mf) throw new Error('zip 안에 manifest.json 이 없습니다');
  const newManifest = JSON.parse(new TextDecoder('utf-8').decode(mf.bytes));
  checkSwap(before, newManifest);
  log(`풀었습니다 — 파일 ${entries.length}개 · ${newManifest.name} v${newManifest.version}`);

  // manifest.json 은 맨 마지막에 쓴다. 중간에 끊겼을 때 폴더가 새 버전을 내세우면
  // 다시 시도해도 버전 검사(checkSwap)에 막혀 반쯤 덮인 채로 남는다
  const order = [...entries.filter((e) => e !== mf), mf];
  let done = 0;
  for (const e of order) {
    await writeEntry(dirHandle, e.name, e.bytes);
    done++;
    if (done % 10 === 0 || done === order.length) log(`덮어쓰는 중… ${done}/${order.length}`);
  }
  dropProgressLines();
  log(`덮어쓰기 완료 — 파일 ${entries.length}개`, 'upd-strong');
  return newManifest.version;
}

// 다른 확장으로 바뀌거나 버전이 내려가는 것을 막는다
function checkSwap(before, newManifest) {
  if (String(newManifest.name || '').trim() !== String(before.name || '').trim()) {
    throw new Error(`다른 확장입니다 — 폴더는 "${before.name}", 받은 것은 "${newManifest.name}"`);
  }
  if (verCmp(newManifest.version, before.version) <= 0) {
    throw new Error(`설치된 v${before.version} 이 받은 v${newManifest.version} 보다 최신이거나 같습니다`);
  }
}

function dropProgressLines() {
  logLines = logLines.filter((l) => !/(덮어쓰는 중…|맞추는 중…)/.test(l.text));
}

async function doUpdate() {
  logClear();
  $('goBtn').disabled = true;
  try {
    if (!(await ensurePermission(dirHandle))) {
      log('폴더 사용 허가가 없어 멈췄습니다. [지금 업데이트]를 다시 눌러 허가해 주세요.', 'upd-bad');
      return;
    }
    const before = await inspectFolder(dirHandle);
    if (!before.ok) {
      log(before.why, 'upd-bad');
      return;
    }
    log(`설치 폴더 확인 — ${before.name} v${before.version}`);
    // 폴더 채널과 다르면 그 채널로 다시 읽는다 (공개 zip 주소가 없는 정보로 받으려 하지 않게)
    if (latestCh !== before.channel) {
      folderInfo = { name: before.name, version: before.version, channel: before.channel };
      showFolder({ dirName: dirHandle.name, name: before.name, version: before.version });
      await loadLatest();
      $('goBtn').disabled = true; // loadLatest 가 버튼을 다시 켰을 수 있다
      if (!latest || latestCh !== before.channel) throw new Error('설치 폴더 채널의 최신 버전을 확인하지 못했습니다');
      if (verCmp(latest.version, before.version) <= 0) {
        log(`설치 폴더가 이미 최신입니다 (v${before.version})`);
        return;
      }
    }
    let version = '';
    if (!version) version = await applyPublicZip(before);
    folderInfo = { name: before.name, version, channel: before.channel };
    showFolder({ dirName: dirHandle.name, name: before.name, version });
    await setLocal({ updSelfApplied: { version, at: Date.now() } });
    log('[확장 새로고침]을 누르면 새 버전으로 다시 시작합니다. 확장이 다시 뜨면서 이 탭은 닫힙니다.');
    $('reloadBtn').classList.remove('hidden');
  } catch (e) {
    log('실패: ' + e.message, 'upd-bad');
    log('그래도 안 되면 파일을 직접 받아 폴더에 덮어써 주세요.', 'upd-warn');
  } finally {
    refreshGo();
  }
}

// ---------- 버튼 ----------
$('recheckBtn').addEventListener('click', loadLatest);

$('pickBtn').addEventListener('click', async () => {
  if (!window.showDirectoryPicker) {
    log('이 브라우저는 폴더 지정을 지원하지 않습니다. zip 을 직접 받아 덮어써 주세요.', 'upd-bad');
    return;
  }
  let dir;
  try {
    dir = await window.showDirectoryPicker({ mode: 'readwrite', id: 'cst-ext-dir' });
  } catch (_) {
    return; // 사용자가 취소
  }
  const got = await inspectFolder(dir);
  if (!got.ok) {
    logClear();
    log(got.why, 'upd-bad');
    return;
  }
  dirHandle = dir;
  folderInfo = { name: got.name, version: got.version, channel: got.channel };
  await idbPut('extDir', dir);
  showFolder({ dirName: dir.name, name: got.name, version: got.version });
  logClear();
  let kindTxt = '공개 배포본';
  log(`설치 폴더를 기억했습니다 — ${dir.name} (${kindTxt})`);
  await loadLatest(); // 채널이 바뀌었으니 최신 정보도 그 채널로 다시
});

$('forgetBtn').addEventListener('click', async () => {
  dirHandle = null;
  folderInfo = null;
  await idbPut('extDir', null);
  showFolder(null);
  refreshGo();
});

// 설치 폴더 열기 — 확장은 자기 폴더 경로를 알 수 없어 탐색기를 바로 열지 못한다.
// 대신 크롬 확장 관리 화면에서 이 확장의 세부정보를 연다. 거기 '소스' 아래 폴더 경로를 누르면 탐색기에서 열린다.
$('openDirBtn').addEventListener('click', () => {
  const self = !folderInfo || folderInfo.channel === installedEdition();
  chrome.tabs.create({ url: self ? `chrome://extensions/?id=${chrome.runtime.id}` : 'chrome://extensions/' });
  logClear();
  log(
    self
      ? '확장 관리 화면에서 소스 아래 폴더 경로를 누르면 탐색기에서 설치 폴더가 열립니다.'
      : `지정한 폴더는 다른 확장(${folderInfo.name})입니다. 확장 관리 화면에서 그 확장의 [세부정보] → 소스 아래 폴더 경로를 누르세요.`
  );
});

$('goBtn').addEventListener('click', doUpdate);
$('reloadBtn').addEventListener('click', () => chrome.runtime.reload());

(async () => {
  await applyTheme();
  edVer = await editionVersion();
  // 방금 자기 자신을 덮어쓰고 다시 시작한 경우 결과를 알려 준다
  chrome.storage.local.get({ updSelfApplied: null }, (d) => {
    const a = d && d.updSelfApplied;
    if (a && a.version === edVer) {
      log(`v${a.version} 로 업데이트되었습니다.`, 'upd-strong');
      chrome.storage.local.set({ updSelfApplied: null });
    }
  });
  await loadSavedFolder();
  await loadLatest();
})();
