// 코코포리아 선생님 — 세션 관리자
const $ = (id) => document.getElementById(id);
const EXT = typeof chrome !== 'undefined' && chrome.storage && chrome.runtime;

const THEMES = ['dark', 'light', 'mono', 'retro'];

const getLocal = (defs) => new Promise((r) => (EXT ? chrome.storage.local.get(defs, r) : r(defs)));
const setLocal = (obj) => new Promise((r) => (EXT ? chrome.storage.local.set(obj, r) : r()));
const getSync = (defs) => new Promise((r) => (EXT ? chrome.storage.sync.get(defs, r) : r(defs)));

let selectedRoom = null; // roomId | '__colors__'

function normalizeHex(v) {
  let s = String(v || '').trim();
  if (!s) return '';
  if (!s.startsWith('#')) s = '#' + s;
  return /^#[0-9a-fA-F]{6}$/.test(s) ? s.toLowerCase() : '';
}

function darkenHex(hex, amt = 0.15) {
  const h = normalizeHex(hex);
  if (!h) return hex;
  const n = parseInt(h.slice(1), 16);
  const f = (v) => Math.max(0, Math.round(v * (1 - amt)));
  return (
    '#' +
    [f((n >> 16) & 255), f((n >> 8) & 255), f(n & 255)]
      .map((v) => v.toString(16).padStart(2, '0'))
      .join('')
  );
}

async function applyTheme() {
  const s = await getSync({ theme: 'dark', accentColor: '' });
  const theme = THEMES.includes(s.theme) ? s.theme : 'dark';
  for (const t of THEMES) document.body.classList.toggle('theme-' + t, theme === t && t !== 'dark');
  const a = normalizeHex(s.accentColor);
  if (a) {
    document.body.style.setProperty('--accent', a);
    document.body.style.setProperty('--accent-dark', darkenHex(a));
  }
}

function fmtDate(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}.${p(d.getMonth() + 1)}.${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}

// ---------- 방 목록 ----------
async function renderRoomList() {
  const all = EXT ? await getAll('local') : {};
  const rooms = all.rooms || {};
  const list = $('roomList');
  list.innerHTML = '';
  const entries = Object.entries(rooms || {}).sort(
    (a, b) => (b[1].lastVisit || 0) - (a[1].lastVisit || 0)
  );
  if (!entries.length) {
    list.appendChild(el('div', 'mgr-empty', '저장된 방이 없습니다.'));
    return;
  }
  for (const [roomId, room] of entries) {
    const btn = el('button', 'mgr-room-item' + (selectedRoom === roomId ? ' on' : ''));
    if (room.favorite && typeof faIcon === 'function') {
      const ic = el('span', 'mgr-bk-ic');
      ic.innerHTML = faIcon('bookmark');
      btn.appendChild(ic);
    }
    const size = roomBytes(all, roomId);
    btn.append(
      document.createTextNode(room.name || '이름 없는 방'),
      el('span', 'mgr-room-date', fmtDate(room.lastVisit) + (size > 200 * 1024 ? ` · ${fmtBytes(size)}` : ''))
    );
    btn.addEventListener('click', () => {
      selectedRoom = roomId;
      renderRoomList();
      renderDetail();
    });
    list.appendChild(btn);
  }
}

// ---------- 상세 ----------
// 그리기 차례. 읽어 오는 동안(await) 다시 불리면(빠르게 두 번 누르기 등) 앞의 것은 붙이지 않는다 —
// 둘 다 비운 뒤 둘 다 붙이면 카드가 두 벌 생긴다
let detailTurn = 0;

async function renderDetail() {
  const turn = ++detailTurn;
  const stale = () => turn !== detailTurn;
  const detail = $('detail');
  detail.innerHTML = '';

  if (selectedRoom === '__colors__') {
    renderGlobalColors(detail, stale);
    return;
  }

  if (selectedRoom === '__storage__') {
    await renderStorage(detail, stale);
    return;
  }

  const room = await CSTRoomStore.loadRoom(selectedRoom);
  if (stale()) return;
  if (!room) {
    detail.appendChild(el('div', 'mgr-empty', '왼쪽에서 방을 선택하세요.'));
    return;
  }
  const roomId = selectedRoom;

  // ----- 방 정보 -----
  const top = el('div', 'mgr-card');
  const topRow = el('div', 'mgr-room-top');
  const thumb = el('div', 'mgr-room-thumb');
  if (room.thumb) {
    const img = document.createElement('img');
    img.src = room.thumb;
    img.addEventListener('error', () => {
      img.remove();
      thumb.innerHTML = typeof faIcon === 'function' ? faIcon('dice') : '?';
    });
    thumb.appendChild(img);
  } else {
    thumb.innerHTML = typeof faIcon === 'function' ? faIcon('dice') : '?';
  }
  const info = el('div', 'mgr-room-info');
  info.appendChild(el('div', 'mgr-room-name', room.name || '이름 없는 방'));
  info.appendChild(
    el('div', 'mgr-room-meta', `마지막 방문: ${fmtDate(room.lastVisit)}${room.favorite ? ' · 저장된 방' : ''}`)
  );
  const openBtn = el('button', 'mgr-btn', '방 열기');
  openBtn.addEventListener('click', () => {
    const url = CSTRoomStore.roomUrl(room, roomId);
    if (EXT && chrome.tabs) chrome.tabs.create({ url });
    else window.open(url);
  });
  const delRoomBtn = el('button', 'mgr-btn danger', '이 방 데이터 전체 삭제');
  delRoomBtn.style.marginLeft = '8px';
  delRoomBtn.addEventListener('click', async () => {
    if (!confirm(`"${room.name || roomId}"의 모든 데이터(메모·스탠딩·색상·방문 기록)를 삭제할까요?`)) return;
    const { savedRoomOrder } = await getLocal({ savedRoomOrder: [] });
    await CSTRoomStore.removeRoom(roomId, { savedRoomOrder: (savedRoomOrder || []).filter((id) => id !== roomId) });
    selectedRoom = null;
    renderRoomList();
    renderDetail();
  });
  info.append(openBtn, delRoomBtn);
  topRow.append(thumb, info);
  top.appendChild(topRow);
  detail.appendChild(top);

  // ----- 메모 (방 공지 + 세션 메모) -----
  const memoCard = el('div', 'mgr-card');
  const memoTitle = el('div', 'mgr-card-title');
  memoTitle.innerHTML = titleIcon('pen') + '방 공지';
  memoTitle.appendChild(el('span', 'count', '방 화면 상단에 고정'));
  memoCard.appendChild(memoTitle);
  const memo = el('textarea', 'mgr-memo');
  memo.placeholder = '방 공지 (자동 저장 — 방 화면 상단·홈 호버뷰에 표시)';
  memo.value = room.memo || '';
  const saved = el('div', 'mgr-memo-saved', '');
  let t = 0;
  memo.addEventListener('input', () => {
    clearTimeout(t);
    saved.textContent = '입력 중…';
    t = setTimeout(async () => {
      const { rooms: cur } = await getLocal({ rooms: {} });
      if (cur[roomId]) {
        cur[roomId].memo = memo.value;
        await setLocal({ rooms: cur });
      }
      saved.textContent = '저장됨 ✓';
    }, 500);
  });
  memoCard.append(memo, saved);
  detail.appendChild(memoCard);

  // ----- 세션 메모 (패널에서 추가한 것들) -----
  const memosCard = el('div', 'mgr-card');
  const memosTitle = el('div', 'mgr-card-title');
  memosTitle.innerHTML = titleIcon('pen') + '세션 메모';
  const memosList = Array.isArray(room.memos) ? room.memos : [];
  memosTitle.appendChild(el('span', 'count', `${memosList.length}개`));
  memosCard.appendChild(memosTitle);
  if (!memosList.length) {
    memosCard.appendChild(el('div', 'mgr-empty', '세션 메모가 없습니다. 방 패널의 메모 탭에서 추가할 수 있어요.'));
  }
  for (const mo of memosList) {
    const box = el('div', 'mgr-memo-box');
    const head = el('div', 'mgr-row');
    const md = new Date(mo.at || Date.now());
    const mpad = (n) => String(n).padStart(2, '0');
    head.appendChild(
      el('span', 'sub', `${md.getFullYear()}.${mpad(md.getMonth() + 1)}.${mpad(md.getDate())} ${mpad(md.getHours())}:${mpad(md.getMinutes())}`)
    );
    const delBtn = el('button', 'del', '✕');
    delBtn.title = '이 메모 삭제';
    delBtn.addEventListener('click', async () => {
      const { rooms: cur } = await getLocal({ rooms: {} });
      if (cur[roomId]) {
        cur[roomId].memos = (cur[roomId].memos || []).filter((x) => x.id !== mo.id);
        await setLocal({ rooms: cur });
      }
      renderDetail();
    });
    head.appendChild(delBtn);
    const ta = el('textarea', 'mgr-memo mgr-memo-mini');
    ta.value = mo.text || '';
    ta.placeholder = '메모 내용 (자동 저장)';
    const sv = el('div', 'mgr-memo-saved', '');
    let t2 = 0;
    ta.addEventListener('input', () => {
      clearTimeout(t2);
      sv.textContent = '입력 중…';
      t2 = setTimeout(async () => {
        const { rooms: cur } = await getLocal({ rooms: {} });
        const hit = cur[roomId] && (cur[roomId].memos || []).find((x) => x.id === mo.id);
        if (hit) {
          hit.text = ta.value;
          await setLocal({ rooms: cur });
        }
        sv.textContent = '저장됨 ✓';
      }, 500);
    });
    box.append(head, ta, sv);
    memosCard.appendChild(box);
  }
  const addMemoBtn = el('button', 'mgr-btn', '+ 새 세션 메모');
  addMemoBtn.addEventListener('click', async () => {
    const { rooms: cur } = await getLocal({ rooms: {} });
    if (cur[roomId]) {
      cur[roomId].memos = cur[roomId].memos || [];
      cur[roomId].memos.unshift({ id: Date.now() + '_' + Math.random().toString(36).slice(2, 7), text: '', at: Date.now() });
      await setLocal({ rooms: cur });
    }
    renderDetail();
  });
  memosCard.appendChild(addMemoBtn);
  detail.appendChild(memosCard);

  // ----- 스탠딩 -----
  const standCard = el('div', 'mgr-card');
  const standings = room.standings || {};
  const charNames = Object.keys(standings);
  const title = el('div', 'mgr-card-title');
  title.innerHTML = titleIcon('image') + '저장된 스탠딩';
  title.appendChild(el('span', 'count', `캐릭터 ${charNames.length}명`));
  standCard.appendChild(title);
  if (!charNames.length) {
    standCard.appendChild(el('div', 'mgr-empty', '저장된 스탠딩이 없습니다.'));
  }
  for (const name of charNames) {
    const row = el('div', 'mgr-row');
    const nm = el('span', 'name', name);
    const sub = el('span', 'sub', `${standings[name].length}개`);
    const del = el('button', 'del', '✕');
    del.title = '이 캐릭터의 스탠딩 삭제';
    del.addEventListener('click', async () => {
      if (!confirm(`"${name}"의 스탠딩 ${standings[name].length}개를 삭제할까요?`)) return;
      const cur = await CSTRoomStore.loadRoom(roomId);
      if (cur) {
        for (const k of ['standings', 'standingOrder', 'hiddenStandings', 'wardrobe', 'wardrobeOutfits', 'standingThumbs']) {
          if (cur[k]) delete cur[k][name];
        }
        await CSTRoomStore.saveRoom(roomId, cur);
      }
      renderDetail();
    });
    row.append(nm, sub, del);
    standCard.appendChild(row);
    const thumbs = el('div', 'mgr-standing-thumbs');
    for (const s of standings[name].slice(0, 14)) {
      if (!s.img) continue;
      const im = document.createElement('img');
      im.src = s.img;
      im.title = s.label;
      im.addEventListener('error', () => im.remove());
      thumbs.appendChild(im);
    }
    if (thumbs.children.length) standCard.appendChild(thumbs);
  }
  detail.appendChild(standCard);

  // ----- 이 방 전용 색상 -----
  const colorCard = el('div', 'mgr-card');
  const roomColors = room.charColors || {};
  const colorNames = Object.keys(roomColors);
  const ctitle = el('div', 'mgr-card-title');
  ctitle.innerHTML = titleIcon('palette') + '이 방 전용 색상';
  ctitle.appendChild(el('span', 'count', `${colorNames.length}개`));
  colorCard.appendChild(ctitle);
  if (!colorNames.length) {
    colorCard.appendChild(el('div', 'mgr-empty', '이 방 전용으로 저장된 색상이 없습니다.'));
  }
  for (const name of colorNames) {
    const row = el('div', 'mgr-row');
    const chip = el('span', 'mgr-chip');
    chip.style.background = roomColors[name];
    const nm = el('span', 'name', name);
    const sub = el('span', 'sub', roomColors[name]);
    const del = el('button', 'del', '✕');
    del.addEventListener('click', async () => {
      const { rooms: cur } = await getLocal({ rooms: {} });
      if (cur[roomId] && cur[roomId].charColors) {
        delete cur[roomId].charColors[name];
        await setLocal({ rooms: cur });
      }
      renderDetail();
    });
    row.append(chip, nm, sub, del);
    colorCard.appendChild(row);
  }
  detail.appendChild(colorCard);
}

// ---------- 전역 색상 ----------
async function renderGlobalColors(detail, stale) {
  const { charColors } = await getLocal({ charColors: {} });
  if (stale && stale()) return;
  const card = el('div', 'mgr-card');
  const names = Object.keys(charColors || {});
  const title = el('div', 'mgr-card-title');
  title.innerHTML = titleIcon('palette') + '캐릭터 색상 (모든 방 공통)';
  title.appendChild(el('span', 'count', `${names.length}개`));
  card.appendChild(title);
  if (!names.length) {
    card.appendChild(el('div', 'mgr-empty', '저장된 색상이 없습니다.'));
  }
  for (const name of names) {
    const row = el('div', 'mgr-row');
    const chip = el('span', 'mgr-chip');
    chip.style.background = charColors[name];
    const nm = el('span', 'name', name);
    const sub = el('span', 'sub', charColors[name]);
    const del = el('button', 'del', '✕');
    del.addEventListener('click', async () => {
      const { charColors: cc } = await getLocal({ charColors: {} });
      delete cc[name];
      await setLocal({ charColors: cc });
      renderDetail();
    });
    row.append(chip, nm, sub, del);
    card.appendChild(row);
  }
  detail.appendChild(card);
}

function getAll(areaName) {
  return new Promise((r) => {
    if (!EXT) return r({});
    try {
      chrome.storage[areaName].get(null, (d) => r(chrome.runtime.lastError ? {} : d || {}));
    } catch (_) {
      r({});
    }
  });
}

function setMany(areaName, obj) {
  return new Promise((r) => {
    if (!EXT) return r();
    try {
      chrome.storage[areaName].set(obj, () => r());
    } catch (_) {
      r();
    }
  });
}

function fmtBytes(n) {
  if (n < 1024) return n + 'B';
  if (n < 1024 * 1024) return (n / 1024).toFixed(1) + 'KB';
  return (n / 1048576).toFixed(1) + 'MB';
}

// ---------- 저장 공간 · 정리 ----------
// 방마다 차지하는 크기 = 목록 줄 + 캐릭터 기록(roomChars:<id>: 스탠딩 주소 · 옷장 · 확대/위치 · 시트)
function roomBytes(all, id) {
  return CSTRoomStore.sizeOf((all.rooms || {})[id]) + CSTRoomStore.sizeOf(all[CSTRoomStore.keyOf(id)]);
}

async function renderStorage(detail, stale) {
  const all = await getAll('local');
  const rooms = all.rooms || {};
  let used = 0;
  try {
    used = await new Promise((r) => chrome.storage.local.getBytesInUse(null, (n) => r(n || 0)));
  } catch (_) {}
  if (stale && stale()) return;

  const card = el('div', 'mgr-card');
  const title = el('div', 'mgr-card-title');
  title.innerHTML = titleIcon('grid') + '저장 공간';
  title.appendChild(el('span', 'count', `전체 ${fmtBytes(used || Object.keys(all).reduce((a, k) => a + CSTRoomStore.sizeOf(all[k]), 0))}`));
  card.appendChild(title);
  card.appendChild(
    el('div', 'mgr-room-meta', '방마다 이 확장이 저장한 크기입니다 (메모 · 스탠딩 목록 · 옷장 · 시트 백업). 코코포리아의 캐릭터 · 이미지는 여기서 지워도 그대로입니다.')
  );

  // 오래 안 간 방 고르기
  const pickRow = el('div', 'mgr-row');
  const daysSel = document.createElement('select');
  daysSel.className = 'mgr-select';
  for (const [d, t] of [[30, '30일'], [90, '90일'], [180, '180일'], [365, '1년']]) {
    const o = document.createElement('option');
    o.value = String(d);
    o.textContent = t;
    daysSel.appendChild(o);
  }
  daysSel.value = '90';
  const pickOld = el('button', 'mgr-btn ghost', '넘게 안 간 방 고르기');
  const delPicked = el('button', 'mgr-btn danger', '고른 방 기록 지우기');
  pickRow.append(daysSel, pickOld, delPicked);
  card.appendChild(pickRow);

  const entries = Object.entries(rooms)
    .map(([id, r]) => ({ id, r, size: roomBytes(all, id) }))
    .sort((a, b) => b.size - a.size);
  const picked = new Set();
  const table = el('div', 'mgr-storage-list');
  const boxes = new Map();
  const paint = () => {
    delPicked.disabled = !picked.size;
    delPicked.textContent = picked.size ? `고른 방 ${picked.size}개 기록 지우기` : '고른 방 기록 지우기';
  };
  for (const e of entries) {
    const row = el('label', 'mgr-row mgr-storage-row');
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.addEventListener('change', () => {
      if (cb.checked) picked.add(e.id);
      else picked.delete(e.id);
      paint();
    });
    boxes.set(e.id, cb);
    const days = e.r.lastVisit ? Math.floor((Date.now() - e.r.lastVisit) / 86400000) : null;
    row.append(
      cb,
      el('span', 'name', e.r.name || '이름 없는 방'),
      el('span', 'sub', `${fmtBytes(e.size)} · ${days == null ? '방문 기록 없음' : days === 0 ? '오늘' : `${days}일 전`}`)
    );
    table.appendChild(row);
  }
  if (!entries.length) table.appendChild(el('div', 'mgr-empty', '저장된 방이 없습니다.'));
  card.appendChild(table);
  pickOld.addEventListener('click', () => {
    const limit = Date.now() - Number(daysSel.value) * 86400000;
    for (const e of entries) {
      const on = !e.r.favorite && (e.r.lastVisit || 0) < limit;
      boxes.get(e.id).checked = on;
      if (on) picked.add(e.id);
      else picked.delete(e.id);
    }
    paint();
  });
  delPicked.addEventListener('click', async () => {
    if (!picked.size) return;
    if (!confirm(`고른 방 ${picked.size}개의 기록(메모 · 스탠딩 · 시트 · 방문 기록)을 지울까요?\n되돌릴 수 없습니다.`)) return;
    const { savedRoomOrder } = await getLocal({ savedRoomOrder: [] });
    for (const id of picked) await CSTRoomStore.removeRoom(id);
    await setLocal({ savedRoomOrder: (savedRoomOrder || []).filter((id) => !picked.has(id)) });
    renderRoomList();
    renderDetail();
  });
  paint();

  const other = Object.keys(all)
    .filter((k) => k !== 'rooms' && !CSTRoomStore.isCharsKey(k))
    .map((k) => ({ k, size: CSTRoomStore.sizeOf(all[k]) }))
    .filter((x) => x.size > 100 * 1024)
    .sort((a, b) => b.size - a.size);
  if (other.length) {
    const oc = el('div', 'mgr-card');
    const ot = el('div', 'mgr-card-title');
    ot.innerHTML = titleIcon('folder') + '방 밖의 큰 항목';
    oc.appendChild(ot);
    const NAMES = {
      logBgImage: '스튜디오 배경 이미지',
      logHeaderImage: '스튜디오 세션 카드 이미지',
      logPresets: '저장한 스타일',
      history: '맞춤법 검사 기록',
    };
    let keyLabel = (k) => k;
    for (const x of other) {
      const row = el('div', 'mgr-row');
      row.append(el('span', 'name', NAMES[x.k] || keyLabel(x.k)), el('span', 'sub', fmtBytes(x.size)));
      oc.appendChild(row);
    }
    oc.appendChild(el('div', 'mgr-room-meta', '이 항목은 각 기능 화면(로그 스튜디오 데이터 초기화 등)에서 지울 수 있어요.'));
    detail.append(card, oc);
    return;
  }
  detail.appendChild(card);
}

$('storageBtn').addEventListener('click', () => {
  selectedRoom = '__storage__';
  renderRoomList();
  renderDetail();
});

$('globalColorsBtn').addEventListener('click', () => {
  selectedRoom = '__colors__';
  renderRoomList();
  renderDetail();
});

// 이모지 → SVG 아이콘 치환
(function initIcons() {
  if (typeof faIcon !== 'function') return;
  document.querySelectorAll('.ic[data-ic]').forEach((sp) => (sp.innerHTML = faIcon(sp.dataset.ic)));
})();

function titleIcon(name) {
  return typeof faIcon === 'function' ? faIcon(name) + ' ' : '';
}


applyTheme();
renderRoomList();
renderDetail();
