import { spellCheck, ENGINES } from './lib/spellcheck.js';
import './lib/ignore.js'; // globalThis.CSTIgnore — 검사 제외 단어 판정 (팝업과 같은 규칙)
import './lib/room-store.js'; // globalThis.CSTRoomStore — 방 기록 저장소 (목록 · 캐릭터 기록 나누기)

const DEFAULTS = {
  engine: 'daum',
  liveCheck: false,
  debounceMs: 1500,
  contextMenu: true,
  excluded: '',
  userDict: [], // [{ from, to }]
  userDictOn: true,
  ignoreWords: [], // 검사 제외 단어 (팝업 '매번 원문 유지' 로 쌓인다)
  liveEngine: '', // 실시간 검사 전용 엔진 ('' = engine 과 동일)
};

// 설정 정본은 popup/spell.js와 동일하게 "sync 로드 → local로 덮어쓰기" 병합.
// (예전엔 sync만 읽어서, sync 쓰기가 한도로 조용히 실패하면 팝업·밑줄은 새 설정,
//  우클릭 교정·실시간 검사는 옛 설정으로 갈라지는 버그가 있었다)
// 매 검사마다 storage 왕복하지 않게 캐시하고, onChanged에서 무효화한다.
let settingsCache = null;

async function getSettings() {
  if (settingsCache) return settingsCache;
  const sv = await chrome.storage.sync.get(DEFAULTS);
  const lc = await chrome.storage.local.get(Object.keys(DEFAULTS));
  const s = { ...DEFAULTS, ...sv };
  for (const k of Object.keys(DEFAULTS)) if (lc[k] !== undefined) s[k] = lc[k];
  settingsCache = s;
  return s;
}

// ---- 결과 캐시 (동일 텍스트 반복 요청 방지) ----
const CACHE_TTL = 30 * 1000;
const CACHE_MAX = 20;
const cache = new Map(); // key -> { at, result }

function cacheGet(key) {
  const hit = cache.get(key);
  if (!hit) return null;
  if (Date.now() - hit.at > CACHE_TTL) {
    cache.delete(key);
    return null;
  }
  return hit.result;
}

function cachePut(key, result) {
  cache.set(key, { at: Date.now(), result });
  if (cache.size > CACHE_MAX) {
    cache.delete(cache.keys().next().value);
  }
}

// 교정어 안에 원문이 들어 있는 항목("갈께" → "갈께요")은 이미 고친 자리도 원문과 맞는다.
// 그런 자리만 있으면 잡지 않는다 (고칠 자리가 하나라도 있어야 true)
function hasUncorrected(text, from, to) {
  const k = to.indexOf(from);
  for (let i = text.indexOf(from); i !== -1; i = text.indexOf(from, i + from.length)) {
    if (k === -1 || i < k || !text.startsWith(to, i - k)) return true;
  }
  return false;
}

// 개인 사전 교정을 엔진 결과 앞에 병합 (같은 토큰은 개인 사전이 우선)
function mergeUserDict(corrections, text, userDict) {
  const userCorr = [];
  for (const entry of userDict) {
    const from = (entry.from || '').trim();
    const to = (entry.to || '').trim();
    if (!from || !to || from === to || !hasUncorrected(text, from, to)) continue;
    userCorr.push({
      errType: 'user',
      token: from,
      suggestion: to,
      cands: [to],
      context: '',
      info: '개인 사전에 등록된 교정입니다.',
    });
  }
  if (!userCorr.length) return corrections;
  const userTokens = new Set(userCorr.map((c) => c.token));
  return [...userCorr, ...corrections.filter((c) => !userTokens.has(c.token))];
}

// 비교 모드: 모든 엔진을 동시에 돌려 토큰 기준으로 결과 통합
const ENGINE_LABEL = { daum: '다음', naver: '네이버', saramin: '사람인', incruit: '인크루트' };

async function compareCheck(text) {
  // 사람인·인크루트는 같은 부산대 엔진 → 비교에는 사람인만 사용
  const keys = ['daum', 'naver', 'saramin'];
  const settled = await Promise.allSettled(keys.map((k) => spellCheck(text, k)));

  const byToken = new Map();
  const okEngines = [];
  settled.forEach((r, i) => {
    if (r.status !== 'fulfilled') return;
    okEngines.push(ENGINE_LABEL[keys[i]]);
    for (const c of r.value.corrections) {
      const item = byToken.get(c.token);
      if (!item) {
        byToken.set(c.token, {
          ...c,
          cands: [...(c.cands && c.cands.length ? c.cands : [c.suggestion])],
          engines: [ENGINE_LABEL[keys[i]]],
        });
      } else {
        item.engines.push(ENGINE_LABEL[keys[i]]);
        for (const cd of c.cands && c.cands.length ? c.cands : [c.suggestion]) {
          if (!item.cands.includes(cd)) item.cands.push(cd);
        }
        if (!item.info && c.info) item.info = c.info;
      }
    }
  });

  if (!okEngines.length) throw new Error('ALL_ENGINES_FAILED');

  // 정렬 비교자 안에서 매번 원문 전체를 스캔하지 않게 위치를 미리 계산해 둔다
  const posOf = new Map();
  for (const tk of byToken.keys()) posOf.set(tk, text.indexOf(tk));
  const corrections = [...byToken.values()]
    .sort((a, b) => posOf.get(a.token) - posOf.get(b.token))
    .map((c) => ({
      ...c,
      info: `발견한 엔진: ${c.engines.join(' · ')}` + (c.info ? '\n\n' + c.info : ''),
    }));

  return { corrections, compared: okEngines };
}

async function doCheck(text, source) {
  const settings = await getSettings();
  // 고른 엔진은 팝업·우클릭 어디서나 그대로 쓴다. 실시간 검사만 따로 지정할 수 있다
  // (빠른 엔진으로 두거나, 반대로 비교 모드로 꼼꼼히 보고 싶을 때).
  // (비교 모드는 세 엔진을 동시에 던지므로 가장 느린 하나만큼만 걸린다)
  let engine = source === 'live' && settings.liveEngine ? settings.liveEngine : settings.engine;
  if (engine !== 'compare' && !ENGINES[engine]) engine = 'daum';

  const key = `${engine}\n${text}`;
  let result = cacheGet(key);
  if (!result) {
    result = engine === 'compare' ? await compareCheck(text) : await spellCheck(text, engine);
    cachePut(key, result);
  }
  const out = { ...result, engine };
  if (settings.userDictOn && Array.isArray(settings.userDict) && settings.userDict.length) {
    out.corrections = mergeUserDict(result.corrections, text, settings.userDict);
  }
  // 검사 제외 단어는 마지막에 걸러낸다 — 캐시된 결과에도 최신 목록이 바로 적용되고,
  // 같은 단어가 본문에 몇 번 나오든 한 번에 전부 빠진다 (개인 사전 교정은 사용자가
  // 직접 넣은 것이므로 제외 목록보다 우선).
  const ignore = Array.isArray(settings.ignoreWords) ? settings.ignoreWords : [];
  if (ignore.length && globalThis.CSTIgnore) {
    const isIgnored = globalThis.CSTIgnore.matcher(ignore);
    out.corrections = out.corrections.filter((c) => c.errType === 'user' || !isIgnored(c.token));
  }
  return out;
}

function errorMessage(err) {
  const msg = String((err && err.message) || err);
  if (msg.includes('FORMAT_CHANGED')) {
    return '검사 서비스의 응답 형식이 바뀌어 결과를 읽지 못했습니다. 설정에서 다른 엔진으로 바꿔보세요.';
  }
  if (msg.includes('NAVER_KEY_FAILED')) {
    return '네이버 검사 키를 가져오지 못했습니다. 설정에서 다음 엔진으로 바꿔보세요.';
  }
  if (msg.includes('TIMEOUT')) {
    return '검사 서비스가 20초 넘게 응답하지 않습니다. 잠시 뒤 다시 하거나 설정에서 다른 엔진으로 바꿔 보세요.';
  }
  if (msg.includes('ALL_ENGINES_FAILED')) {
    return '모든 엔진 검사에 실패했습니다. 네트워크를 확인해 주세요.';
  }
  if (msg.includes('HTTP_403') || msg.includes('HTTP_429')) {
    return '요청이 너무 많습니다. 잠시 후 다시 시도해 주세요.';
  }
  if (msg.includes('HTTP_')) {
    return `검사 서버 오류가 발생했습니다. (${msg.replace('HTTP_', 'HTTP ')})`;
  }
  return '검사 서버에 연결하지 못했습니다. 네트워크를 확인해 주세요.';
}

// 엔진 점검 — 네 엔진에 같은 문장(오류 네 군데)을 보내 응답을 확인한다 (팝업 설정의 [엔진 점검]).
// 엔진이 안 될 때 어느 엔진이 어떤 이유로 안 되는지 그 자리에서 보려는 것.
async function engineSelfTest() {
  const text = '않돼요 왠지 몇일동안 됬다.';
  return Promise.all(
    Object.keys(ENGINES).map(async (k) => {
      const t = Date.now();
      try {
        const r = await spellCheck(text, k);
        return { engine: k, name: ENGINES[k].name, ok: true, ms: Date.now() - t, count: r.corrections.length };
      } catch (err) {
        return { engine: k, name: ENGINES[k].name, ok: false, ms: Date.now() - t, code: String((err && err.message) || err).slice(0, 80), error: errorMessage(err) };
      }
    })
  );
}

// ---- 메시지 라우터 ----
// 알림 중복 막기용 (키 → 마지막으로 통과시킨 시각)
const notifyClaims = new Map();

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'CHECK') {
    doCheck(msg.text, msg.source)
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((err) => sendResponse({ ok: false, error: errorMessage(err) }));
    return true; // async
  }
  if (msg && msg.type === 'ENGINE_SELFTEST') {
    engineSelfTest()
      .then((list) => sendResponse({ ok: true, list }))
      .catch((err) => sendResponse({ ok: false, error: String(err && err.message) }));
    return true;
  }
  if (msg && msg.type === 'DESKTOP_NOTIFY') {
    // 채팅 알림을 데스크톱(OS 알림 센터)으로. notifications는 optional 권한 — 팝업에서 켤 때 요청한다.
    const tabId = sender && sender.tab && sender.tab.id;
    const windowId = sender && sender.tab && sender.tab.windowId;
    if (!chrome.notifications || !chrome.notifications.create) {
      sendResponse({ ok: false, error: 'notifications API 없음 (권한을 켠 뒤 확장을 다시 불러오세요)' });
      return false;
    }
    // 탭 · 창 번호를 id 에 같이 싣는다. 서비스 워커가 잠들었다 깨면 notifTargets 가 비어 있어서
    // 알림을 눌러도 갈 곳을 몰랐다 (클릭 때 id 를 풀어 쓴다)
    const id =
      'cst-chat-t' + (tabId != null ? tabId : '') + '-w' + (windowId != null ? windowId : '') +
      '-' + Date.now() + '-' + Math.floor(Math.random() * 1e6);
    notifTargets.set(id, { tabId, windowId });
    if (notifTargets.size > 50) notifTargets.delete(notifTargets.keys().next().value);
    try {
      // 인장(스탠딩) 이미지를 콘텐트 스크립트가 data URL 로 바꿔 보내면 그것을 아이콘으로 쓴다.
      // 못 받았거나 형식이 다르면 확장 아이콘으로 (알림 자체는 뜨게 한다)
      const icon = /^data:image\//.test(String(msg.iconUrl || ''))
        ? msg.iconUrl
        : chrome.runtime.getURL('icons/icon128.png');
      const opts = {
        type: 'basic',
        iconUrl: icon,
        title: String(msg.title || '코코포리아').slice(0, 80),
        message: String(msg.message || '새 채팅이 도착했습니다').slice(0, 300),
        silent: msg.silent !== false,
        priority: 0,
      };
      if (msg.contextMessage) opts.contextMessage = String(msg.contextMessage).slice(0, 80);
      chrome.notifications.create(
        id,
        opts,
        () => {
          const err = chrome.runtime.lastError;
          sendResponse(err ? { ok: false, error: err.message } : { ok: true });
        }
      );
    } catch (err) {
      sendResponse({ ok: false, error: String((err && err.message) || err) });
      return false;
    }
    return true; // async
  }
  if (msg && msg.type === 'OPEN_STUDIO') {
    chrome.tabs.create({ url: chrome.runtime.getURL('studio/studio.html') });
    sendResponse({ ok: true });
    return false;
  }
  if (msg && msg.type === 'OPEN_MANAGER') {
    // 콘텐트 스크립트(웹페이지)에서는 chrome-extension:// 페이지를 직접 열 수 없어 백그라운드가 대신 연다
    chrome.tabs.create({ url: chrome.runtime.getURL('manager/manager.html') });
    sendResponse({ ok: true });
    return false;
  }
  return false;
});

// ---- 데스크톱 알림 클릭 → 그 방 탭으로 이동 ----
const notifTargets = new Map(); // notificationId → { tabId, windowId } (빠른 길. 워커가 깨어 있을 때만 남아 있다)

// 알림 id('cst-chat-t<탭>-w<창>-<시각>-<난수>')에서 갈 곳을 푼다
function notifTargetOf(id) {
  const t = notifTargets.get(id);
  if (t) return t;
  const m = /^cst-chat-t(\d*)-w(\d*)-/.exec(String(id));
  if (!m) return null;
  return { tabId: m[1] ? Number(m[1]) : null, windowId: m[2] ? Number(m[2]) : null };
}

function bindNotificationClick() {
  if (!chrome.notifications || !chrome.notifications.onClicked) return;
  try {
    chrome.notifications.onClicked.addListener((id) => {
      const t = notifTargetOf(id);
      notifTargets.delete(id);
      try {
        chrome.notifications.clear(id, () => void chrome.runtime.lastError);
      } catch (_) {}
      if (!t) return;
      if (t.windowId != null) chrome.windows.update(t.windowId, { focused: true }).catch(() => {});
      if (t.tabId != null) chrome.tabs.update(t.tabId, { active: true }).catch(() => {});
    });
    chrome.notifications.onClosed.addListener((id) => notifTargets.delete(id));
  } catch (_) {}
}
bindNotificationClick();
// 권한을 나중에 켜면 API가 그때 생긴다 — 그 시점에 다시 묶는다
if (chrome.permissions && chrome.permissions.onAdded) {
  chrome.permissions.onAdded.addListener((p) => {
    if (p && p.permissions && p.permissions.includes('notifications')) bindNotificationClick();
  });
}


// ---- 허용 사이트 (v12.0: optional_host_permissions) ----
// 맞춤법 실시간 검사·텍스트 대치는 코코포리아에는 항상, 그 밖에는 사용자가 팝업에서 허용한 사이트에만 들어간다.
// 허용된 origin 목록을 읽어 동적 콘텐트 스크립트 하나로 등록한다.
const STATIC_ORIGINS = [
  'https://ccfolia.com/*',
  'https://*.ccfolia.com/*',
  'https://dic.daum.net/*',
  'https://m.search.naver.com/*',
  'https://search.naver.com/*',
  'https://www.saramin.co.kr/*',
  'https://m.incruit.com/*',
];
const SITE_SCRIPT_ID = 'cst-user-sites';

async function grantedSiteOrigins() {
  try {
    const all = await chrome.permissions.getAll();
    return (all.origins || []).filter((o) => !STATIC_ORIGINS.includes(o));
  } catch (_) {
    return [];
  }
}

async function syncSiteScripts() {
  if (!chrome.scripting || !chrome.scripting.registerContentScripts) return;
  const origins = await grantedSiteOrigins();
  let existing = [];
  try {
    existing = await chrome.scripting.getRegisteredContentScripts({ ids: [SITE_SCRIPT_ID] });
  } catch (_) {}
  if (!origins.length) {
    if (existing.length) await chrome.scripting.unregisterContentScripts({ ids: [SITE_SCRIPT_ID] }).catch(() => {});
    return;
  }
  const def = {
    id: SITE_SCRIPT_ID,
    matches: origins,
    js: ['lib/ignore.js', 'content/spell.js', 'content/replace.js'],
    css: ['content/spell.css'],
    runAt: 'document_idle',
    allFrames: true,
    persistAcrossSessions: true,
  };
  try {
    if (existing.length) await chrome.scripting.updateContentScripts([def]);
    else await chrome.scripting.registerContentScripts([def]);
  } catch (err) {
    // 일부 origin이 유효하지 않으면 통째로 실패한다 — 하나씩 걸러 다시 시도
    const ok = [];
    for (const o of origins) {
      try {
        await chrome.scripting.registerContentScripts([{ ...def, id: SITE_SCRIPT_ID + '-probe', matches: [o] }]);
        await chrome.scripting.unregisterContentScripts({ ids: [SITE_SCRIPT_ID + '-probe'] });
        ok.push(o);
      } catch (_) {}
    }
    if (ok.length) {
      try {
        if (existing.length) await chrome.scripting.updateContentScripts([{ ...def, matches: ok }]);
        else await chrome.scripting.registerContentScripts([{ ...def, matches: ok }]);
      } catch (_) {}
    }
  }
}

if (chrome.permissions) {
  if (chrome.permissions.onAdded) chrome.permissions.onAdded.addListener(() => syncSiteScripts());
  if (chrome.permissions.onRemoved) chrome.permissions.onRemoved.addListener(() => syncSiteScripts());
}
chrome.runtime.onStartup.addListener(() => syncSiteScripts());
// 예전 모양의 방 기록(rooms 안에 스탠딩 등)을 방마다 따로 옮긴다 — 설치 · 업데이트 · 브라우저 시작 때
const migrateRooms = () => globalThis.CSTRoomStore && globalThis.CSTRoomStore.migrate().catch(() => {});
chrome.runtime.onStartup.addListener(migrateRooms);
chrome.runtime.onInstalled.addListener(migrateRooms);
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // 알림 한 번만 — 같은 방을 여러 창 · 여러 탭으로 띄워 두면 창마다 울린다.
  // 먼저 온 창만 통과시키고 3초 안에 같은 알림(키)은 막는다.
  if (msg && msg.type === 'NOTIFY_CLAIM') {
    const now = Date.now();
    for (const [k, t] of notifyClaims) if (now - t > 15000) notifyClaims.delete(k);
    const key = String(msg.key || '');
    const ok = now - (notifyClaims.get(key) || 0) > 3000;
    if (ok) notifyClaims.set(key, now);
    sendResponse({ ok });
    return false;
  }
  if (msg && msg.type === 'SYNC_SITE_SCRIPTS') {
    syncSiteScripts().then(() => sendResponse({ ok: true })).catch((err) => sendResponse({ ok: false, error: String(err && err.message) }));
    return true;
  }
  // 코코포리아 페이지 쪽(MAIN) 도구 — lib/ccf-page.js 를 넣고 그 함수를 부른다
  const pageCall = CCF_PAGE_CALLS[msg && msg.type];
  if (pageCall) {
    const tabId = sender && sender.tab && sender.tab.id;
    if (!tabId) {
      sendResponse({ ok: false, why: 'no-tab' });
      return false;
    }
    // 코코포리아 방 화면(맨 위 프레임)의 우리 스크립트가 보낸 것만 — 맞춤법 검사가 도는 다른 사이트 · 프레임에서는 받지 않는다
    if (sender.frameId !== 0 || !/^https:\/\/([a-z0-9-]+\.)*ccfolia\.com\//i.test(String(sender.url || ''))) {
      sendResponse({ ok: false, why: 'not-ccfolia' });
      return false;
    }
    const [fn, args] = pageCall(msg);
    runInCcfPage(tabId, fn, args).then(sendResponse);
    return true;
  }
  return false;
});

// ---- 코코포리아 페이지(MAIN 월드) 도구 ----
// 코코포리아 redux store · 캐릭터 액션을 만지는 코드는 전부 lib/ccf-page.js 한 곳에 있다
// (코코포리아 구조가 바뀌면 그 파일만 고친다). 부를 때마다 파일을 넣어 확장 업데이트 뒤에도 새 코드로 돈다.
//   CCF_CHARACTER_OP  { name, op }  편집창 없이 캐릭터 고치기 (기본 스탠딩 · 표정 지우기/이름 바꾸기 · 표정 더하기 · 되돌리기)
//   CCF_OPEN_CHARACTER { name }     캐릭터 편집창 열기
//   CCF_CHAT_CHARACTER { op }       발화 캐릭터 읽기 · 바꾸기
//   CCF_WATCH_CHARACTERS { all }    캐릭터가 바뀌면 페이지가 postMessage 로 알림 (편집창 없이 스탠딩 · 시트 저장)
//   CCF_ROOM_INFO     {}            방 이름 · 썸네일(전경 → 배경, 코코포리아 방 목록과 같은 그림)
//   CCF_WATCH_ROOM    {}            방 이름 · 썸네일이 바뀌면 postMessage 로 알림
const CCF_PAGE_CALLS = {
  CCF_CHARACTER_OP: (msg) => ['characterOp', [String(msg.name || ''), msg.op || {}]],
  CCF_OPEN_CHARACTER: (msg) => ['openEditor', [String(msg.name || '')]],
  CCF_CHAT_CHARACTER: (msg) => ['chatCharacter', [msg.op || {}]],
  CCF_WATCH_CHARACTERS: (msg) => ['watchCharacters', [{ all: !!msg.all }]],
  CCF_ROOM_INFO: () => ['roomInfo', []],
  CCF_WATCH_ROOM: () => ['watchRoom', []],
  CCF_DIAGNOSE: () => ['diagnose', []],
};

async function runInCcfPage(tabId, fn, args) {
  try {
    const target = { tabId };
    await chrome.scripting.executeScript({ target, world: 'MAIN', files: ['lib/ccf-page.js'] });
    const res = await chrome.scripting.executeScript({
      target,
      world: 'MAIN',
      func: (name, list) => {
        const api = window.__cstCcfPage;
        if (!api || typeof api[name] !== 'function') return { ok: false, why: 'no-page-api' };
        return api[name](...list);
      },
      args: [fn, args],
    });
    return (res && res[0] && res[0].result) || { ok: false, why: 'no-result' };
  } catch (err) {
    return { ok: false, why: 'inject', error: String(err && err.message) };
  }
}

// ---- 콘텐트 스크립트 주입 (설치/업데이트 직후 이미 열려 있던 탭 대응) ----
async function injectIntoTab(tabId, frameId) {
  const target =
    frameId != null ? { tabId, frameIds: [frameId] } : { tabId, allFrames: true };
  await chrome.scripting.insertCSS({ target, files: ['content/spell.css'] });
  await chrome.scripting.executeScript({
    target,
    files: ['lib/ignore.js', 'content/spell.js', 'content/replace.js'],
  });
}

chrome.runtime.onInstalled.addListener(async () => {
  await refreshContextMenu();
  await syncSiteScripts();
  // 이미 열려 있는 탭에도 주입 (권한 없는 사이트·chrome:// 등 불가한 탭은 조용히 무시)
  let tabs = [];
  try {
    tabs = await chrome.tabs.query({});
  } catch (_) {}
  for (const tab of tabs) {
    if (tab.id == null) continue;
    injectIntoTab(tab.id).catch(() => {});
  }
});

// ---- 우클릭 메뉴: 선택 영역 즉시 교정 ----
const MENU_ID = 'textdoctor-correct-selection';

function refreshContextMenu() {
  return new Promise((resolve) => {
    chrome.contextMenus.removeAll(async () => {
      const { contextMenu } = await getSettings();
      if (contextMenu) {
        chrome.contextMenus.create(
          {
            id: MENU_ID,
            title: '맞춤법 검사 후 자동 교정',
            contexts: ['selection'],
          },
          () => void chrome.runtime.lastError
        );
      }
      resolve();
    });
  });
}

chrome.storage.onChanged.addListener((changes, area) => {
  // 맞춤법 설정 캐시 무효화 (sync·local 어느 쪽이 바뀌어도)
  if (Object.keys(DEFAULTS).some((k) => k in changes)) settingsCache = null;
  // 팝업은 local(정본)에 먼저 쓰고 sync 는 덤으로 따라 쓴다. sync 쓰기가 한도로 실패해도 메뉴가 바뀌게 양쪽 다 본다
  if (changes.contextMenu) refreshContextMenu();
});

function sendToTab(tabId, frameId, message) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, { frameId: frameId || 0 }, (res) => {
      if (chrome.runtime.lastError) resolve({ delivered: false });
      else resolve({ delivered: true, res });
    });
  });
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== MENU_ID || !tab || tab.id == null) return;
  const msg = { type: 'CONTEXT_CORRECT' };
  let r = await sendToTab(tab.id, info.frameId, msg);
  if (!r.delivered) {
    // 콘텐트 스크립트가 없는 탭(설치 전에 연 탭 등) → 주입 후 재시도
    try {
      await injectIntoTab(tab.id, info.frameId);
      await sendToTab(tab.id, info.frameId, msg);
    } catch (_) {
      // chrome:// 웹스토어 등 주입 불가 페이지
    }
  }
});
