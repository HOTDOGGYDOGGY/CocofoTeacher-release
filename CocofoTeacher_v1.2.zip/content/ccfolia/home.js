// 코코포리아 선생님 — 홈 화면 방 기록 (페이지 상단, 최근 방문/저장된 방)
(() => {
  if (window.__cstHomeLoaded) return;
  window.__cstHomeLoaded = true;

  const EXT = typeof chrome !== 'undefined' && chrome.storage && chrome.runtime;
  if (!EXT) return;

  const THEMES = ['dark', 'light', 'mono', 'retro'];
  let box = null;
  let theme = 'dark';
  let accent = '';
  let subTab = 'recent'; // 'recent' | 'saved'
  let viewMode = 'thumb'; // 'thumb' | 'list'
  let memoEditing = false; // 메모 입력 중에는 재렌더링 금지 (입력창이 닫히는 버그 방지)
  // 카드 밖(body)에 띄운 메모들 — 다시 그릴 때 같이 치운다
  let memoViews = [];


  // 확장을 새로고침하면 남아 있던 이 스크립트의 chrome.* 연결이 끊긴다
  // ("Extension context invalidated"). 호출 전에 살아 있는지 확인한다.
  function extAlive() {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (_) {
      return false;
    }
  }

  const getLocal = (defs) =>
    new Promise((r) => {
      if (!extAlive()) return r(defs);
      try {
        chrome.storage.local.get(defs, (d) => r(chrome.runtime.lastError ? defs : d));
      } catch (_) {
        r(defs);
      }
    });
  const setLocal = (obj) =>
    new Promise((r) => {
      if (!extAlive()) return r();
      try {
        chrome.storage.local.set(obj, () => {
          void chrome.runtime.lastError;
          r();
        });
      } catch (_) {
        r();
      }
    });
  const setSync = (obj) =>
    new Promise((r) => {
      if (!extAlive()) return r();
      try {
        chrome.storage.sync.set(obj, () => {
          void chrome.runtime.lastError;
          r();
        });
      } catch (_) {
        r();
      }
    });

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }

  function normalizeHex(v) {
    let s = String(v || '').trim();
    if (!s) return '';
    if (!s.startsWith('#')) s = '#' + s;
    return /^#[0-9a-fA-F]{6}$/.test(s) ? s.toLowerCase() : '';
  }

  function darken(hex, amt = 0.15) {
    const h = normalizeHex(hex);
    if (!h) return hex;
    const n = parseInt(h.slice(1), 16);
    const f = (v) => Math.max(0, Math.round(v * (1 - amt)));
    return (
      '#' +
      [f((n >> 16) & 255), f((n >> 8) & 255), f(n & 255)]
        .map((v) => v.toString(16).padStart(2, '0'))
        .join('')
    );
  }

  // 테마 클래스·포인트색을 한 요소에 입힌다.
  // 메모 호버 뷰는 카드 밖 body에 따로 띄우므로 상자(#cst-home)와 별개로 입혀야 한다.
  function themeEl(target) {
    if (!target) return;
    for (const t of THEMES) target.classList.remove('cst-theme-' + t);
    if (theme !== 'dark') target.classList.add('cst-theme-' + theme);
    const a = normalizeHex(accent);
    if (a) {
      target.style.setProperty('--cst-accent', a);
      target.style.setProperty('--cst-accent-dark', darken(a));
    } else {
      target.style.removeProperty('--cst-accent');
      target.style.removeProperty('--cst-accent-dark');
    }
  }

  function applyTheme() {
    themeEl(box);
    for (const v of memoViews) themeEl(v);
  }

  // 메모 뷰는 position: fixed라 페이지가 스크롤되면 카드와 떨어져 화면에 박힌다.
  // 스크롤(안쪽 스크롤 영역 포함)·창 크기 변경 때 떠 있는 것들을 카드 자리로 되돌린다.
  function replaceOpenMemos() {
    for (const v of memoViews) {
      if (v.style.display !== 'none' && typeof v.__place === 'function') v.__place();
    }
  }
  addEventListener('scroll', replaceOpenMemos, { capture: true, passive: true });
  addEventListener('resize', replaceOpenMemos);

  function fmtDate(ts) {
    if (!ts) return '';
    const d = new Date(ts);
    const day0 = new Date();
    day0.setHours(0, 0, 0, 0);
    if (ts >= day0.getTime()) return '오늘';
    if (ts >= day0.getTime() - 86400000) return '어제';
    const p = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}.${p(d.getMonth() + 1)}.${p(d.getDate())}`;
  }

  async function toggleBookmark(roomId) {
    const { rooms, savedRoomOrder } = await getLocal({ rooms: {}, savedRoomOrder: [] });
    if (!rooms[roomId]) return;
    const on = !rooms[roomId].favorite;
    rooms[roomId].favorite = on;
    let order = savedRoomOrder.filter((id) => id !== roomId);
    if (on) order.push(roomId); // 저장한 순서대로 뒤에 추가
    await setLocal({ rooms, savedRoomOrder: order });
    render();
  }

  async function saveMemo(roomId, memo) {
    const { rooms } = await getLocal({ rooms: {} });
    if (!rooms[roomId]) return;
    rooms[roomId].memo = memo;
    await setLocal({ rooms });
  }

  // ---------- 렌더 ----------
  async function render() {
    for (const v of memoViews) v.remove();
    memoViews = [];
    if (!box) return;
    const { rooms, savedRoomOrder } = await getLocal({ rooms: {}, savedRoomOrder: [] });
    const bodyEl = box.querySelector('.cst-home-body');
    const countEl = box.querySelector('.cst-home-count');
    bodyEl.innerHTML = '';

    // 서브탭 UI 상태
    box.querySelectorAll('.cst-subtab').forEach((b) => b.classList.toggle('on', b.dataset.sub === subTab));
    const vt = box.querySelector('.cst-viewtoggle');
    if (vt) vt.innerHTML = (viewMode === 'thumb' ? (window.faIcon ? window.faIcon('list') : '') + ' 리스트로' : (window.faIcon ? window.faIcon('grid') : '') + ' 썸네일로');

    let entries;
    if (subTab === 'recent') {
      entries = Object.entries(rooms || {}).sort((a, b) => (b[1].lastVisit || 0) - (a[1].lastVisit || 0));
    } else {
      const ordered = savedRoomOrder.filter((id) => rooms[id] && rooms[id].favorite);
      for (const [id, r] of Object.entries(rooms || {})) {
        if (r.favorite && !ordered.includes(id)) ordered.push(id);
      }
      entries = ordered.map((id) => [id, rooms[id]]);
    }
    countEl.textContent = entries.length ? `${entries.length}개` : '';

    if (!entries.length) {
      bodyEl.appendChild(
        el(
          'div',
          'cst-hint',
          subTab === 'recent'
            ? '아직 방문한 방이 없습니다. 코코포리아 방에 들어가면 자동으로 기록돼요.'
            : '저장된 방이 없습니다. 방 카드의 책갈피 버튼을 누르면 여기 저장돼요.'
        )
      );
      return;
    }

    const wrap = el('div', viewMode === 'thumb' ? 'cst-room-grid' : 'cst-room-list');
    entries.forEach(([roomId, room], idx) => {
      wrap.appendChild(roomItem(roomId, room, idx, entries));
    });
    bodyEl.appendChild(wrap);
  }

  function roomItem(roomId, room, idx, entries) {
    const isList = viewMode === 'list';
    const card = el('div', isList ? 'cst-room-row' : 'cst-room-card');
    card.title = room.name || roomId;

    // 썸네일
    const thumb = el('div', isList ? 'cst-room-row-thumb' : 'cst-room-thumb');
    if (room.thumb) {
      const img = document.createElement('img');
      img.src = room.thumb;
      img.loading = 'lazy';
      img.addEventListener('error', () => {
        img.remove();
        thumb.innerHTML = window.faIcon ? window.faIcon('dice') : '?';
      });
      thumb.appendChild(img);
    } else {
      thumb.innerHTML = window.faIcon ? window.faIcon('dice') : '?';
    }

    const name = el('span', 'cst-room-name', room.name || '이름 없는 방');
    const date = el('span', 'cst-room-date', fmtDate(room.lastVisit));

    const bk = el('button', (isList ? 'cst-room-row-btn' : 'cst-room-fav') + (room.favorite ? ' on' : ''));
    bk.innerHTML = window.faIcon ? window.faIcon('bookmark') : 'B';
    bk.title = room.favorite ? '저장 해제' : '저장된 방에 추가 (책갈피)';
    bk.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleBookmark(roomId);
    });

    const del = el('button', isList ? 'cst-room-row-btn' : 'cst-room-del');
    del.innerHTML = window.faIcon ? window.faIcon('xmark') : 'x';
    del.title = '기록 삭제';
    del.addEventListener('click', async (e) => {
      e.stopPropagation();
      if (!confirm(`"${room.name || roomId}" 방문 기록을 삭제할까요?\n(저장된 스탠딩·메모도 함께 삭제됩니다)`)) return;
      const { savedRoomOrder } = await getLocal({ savedRoomOrder: [] });
      // 목록 줄과 그 방 캐릭터 기록(roomChars:<id>)을 같이 지운다
      await globalThis.CSTRoomStore.removeRoom(roomId, { savedRoomOrder: savedRoomOrder.filter((id) => id !== roomId) });
      render();
    });

    // 메모: 호버하면 읽기용으로 자동 펼침, 클릭(또는 연필 버튼)하면 편집 모드
    const memoBtn = el('button', isList ? 'cst-room-row-btn' : 'cst-room-memo-btn');
    memoBtn.innerHTML = window.faIcon ? window.faIcon('pen') : 'M';
    memoBtn.title = '방 메모 편집';
    if (room.memo) memoBtn.classList.add('has-memo');

    const memoView = el('div', 'cst-room-memoview');
    const memoText = el('div', 'cst-room-memotext', room.memo || '');
    memoView.appendChild(memoText);
    if (!room.memo) memoView.classList.add('cst-memo-none');

    function openEditor() {
      if (card.classList.contains('cst-memo-editing')) return;
      memoView.style.display = 'block';
      card.classList.add('cst-memo-editing');
      memoEditing = true;
      memoView.innerHTML = '';
      const ta = el('textarea', 'cst-memo');
      ta.style.minHeight = '70px';
      ta.placeholder = '이 방 메모 (자동 저장)';
      ta.value = room.memo || '';
      const saved = el('div', 'cst-memo-saved', '');
      let t = 0;
      ta.addEventListener('input', () => {
        clearTimeout(t);
        saved.textContent = '입력 중…';
        t = setTimeout(async () => {
          await saveMemo(roomId, ta.value);
          room.memo = ta.value;
          memoBtn.classList.toggle('has-memo', !!ta.value);
          saved.textContent = '저장됨 ✓';
        }, 500);
      });
      ta.addEventListener('blur', () => {
        // 편집 종료 → 읽기용으로 복귀
        setTimeout(() => {
          memoEditing = false;
          card.classList.remove('cst-memo-editing');
          memoView.innerHTML = '';
          memoText.textContent = room.memo || '';
          memoView.appendChild(memoText);
          memoView.classList.toggle('cst-memo-none', !room.memo);
        }, 150);
      });
      ta.addEventListener('click', (ev) => ev.stopPropagation());
      memoView.append(ta, saved);
      ta.focus();
    }

    memoView.addEventListener('click', (ev) => {
      ev.stopPropagation();
      openEditor();
    });
    memoBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      showMemo(true);
      openEditor();
    });

    // 메모는 카드 안이 아니라 body에 띄운다.
    // 카드 안에 두면 코코포리아 본문이 위로 덮어 그려서 아래쪽이 잘렸다.
    memoView.classList.add('cst-root', 'cst-memo-float');
    memoView.style.display = 'none';
    themeEl(memoView);
    document.body.appendChild(memoView);
    memoViews.push(memoView);
    memoView.__place = () => placeMemo(); // 스크롤·창 크기 변경 때 카드 자리를 다시 따라간다

    function placeMemo() {
      const r = card.getBoundingClientRect();
      // 카드가 화면 밖으로 나가면 호버 메모는 접는다 (fixed라 그냥 두면 화면에 박혀 따라온다).
      // 편집 중인 메모는 접지 않고 카드를 계속 따라가게 둔다.
      if ((r.bottom < 0 || r.top > innerHeight) && !card.classList.contains('cst-memo-editing')) {
        memoView.style.display = 'none';
        return;
      }
      memoView.style.left = Math.round(r.left) + 'px';
      memoView.style.width = Math.round(r.width) + 'px';
      // 아래 공간이 부족하면 카드 위쪽으로 띄운다
      const need = memoView.offsetHeight || 90;
      const below = innerHeight - r.bottom;
      if (below < need + 12 && r.top > need + 12) {
        memoView.style.top = Math.round(r.top - need - 4) + 'px';
      } else {
        memoView.style.top = Math.round(r.bottom + 2) + 'px';
      }
    }

    function showMemo(force) {
      if (!force && !room.memo) return; // 메모가 없으면 호버로는 안 뜬다
      memoView.style.display = 'block';
      placeMemo();
    }

    function hideMemo() {
      if (card.classList.contains('cst-memo-editing')) return;
      memoView.style.display = 'none';
    }

    card.addEventListener('mouseenter', () => showMemo(false));
    card.addEventListener('mouseleave', () => setTimeout(() => {
      if (!memoView.matches(':hover')) hideMemo();
    }, 80));
    memoView.addEventListener('mouseleave', () => setTimeout(() => {
      if (!card.matches(':hover')) hideMemo();
    }, 80));

    if (isList) {
      card.append(thumb, name, date, memoBtn, bk, del);
    } else {
      card.append(thumb, name, date, bk, del, memoBtn);
    }

    card.addEventListener('click', () => {
      location.href = room.url || location.origin + '/rooms/' + roomId;
    });

    // 저장된 방 탭: 드래그로 순서 변경
    if (subTab === 'saved') {
      card.draggable = true;
      card.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('text/plain', String(idx));
        card.classList.add('cst-dragging');
      });
      card.addEventListener('dragend', () => card.classList.remove('cst-dragging'));
      card.addEventListener('dragover', (e) => {
        e.preventDefault();
        card.classList.add('cst-dragover');
      });
      card.addEventListener('dragleave', () => card.classList.remove('cst-dragover'));
      card.addEventListener('drop', async (e) => {
        e.preventDefault();
        card.classList.remove('cst-dragover');
        const fromIdx = Number(e.dataTransfer.getData('text/plain'));
        if (Number.isNaN(fromIdx) || fromIdx === idx) return;
        const order = entries.map(([id]) => id);
        const [moved] = order.splice(fromIdx, 1);
        order.splice(idx, 0, moved);
        await setLocal({ savedRoomOrder: order });
        render();
      });
    }

    return card;
  }

  // ---------- 구성 ----------
  function build() {
    if (box) return;
    box = el('div', 'cst-root');
    box.id = 'cst-home';

    const head = el('div', 'cst-home-head');
    const title = el('span', 'cst-home-title');
    const icon = document.createElement('img');
    icon.src = chrome.runtime.getURL('icons/icon16.png');
    icon.className = 'cst-title-icon';
    icon.alt = '';
    title.append(icon, document.createTextNode('방 기록'));

    const subtabs = el('span', 'cst-subtabs');
    for (const [key, label] of [
      ['recent', '최근 방문한 방'],
      ['saved', '저장된 방'],
    ]) {
      const b = el('button', 'cst-subtab' + (key === subTab ? ' on' : ''), label);
      b.dataset.sub = key;
      b.addEventListener('click', () => {
        subTab = key;
        render();
      });
      subtabs.appendChild(b);
    }

    const count = el('span', 'cst-home-count', '');

    const managerBtn = el('button', 'cst-btn ghost cst-sm', '세션 관리자');
    managerBtn.addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'OPEN_MANAGER' });
    });

    const viewBtn = el('button', 'cst-btn ghost cst-sm cst-viewtoggle');
    viewBtn.innerHTML = (window.faIcon ? window.faIcon('list') : '') + ' 리스트로';
    viewBtn.title = '보기 방식 전환';
    viewBtn.addEventListener('click', () => {
      viewMode = viewMode === 'thumb' ? 'list' : 'thumb';
      setSync({ roomView: viewMode });
      render();
    });

    const minBtn = el('button', 'cst-iconbtn', '－');
    minBtn.title = '접기/펼치기';

    head.append(title, subtabs, count, managerBtn, viewBtn, minBtn);

    const bodyEl = el('div', 'cst-home-body');
    box.append(head, bodyEl);

    document.body.insertBefore(box, document.body.firstChild);

    function setMin(min) {
      box.classList.toggle('cst-min', min);
    }
    getLocal({ homeMin: false }).then(({ homeMin }) => setMin(homeMin));
    minBtn.addEventListener('click', () => {
      const min = box.classList.toggle('cst-min');
      setLocal({ homeMin: min });
    });

    applyTheme();
    render();

    const guard = new MutationObserver(() => {
      if (!document.body.contains(box)) {
        document.body.insertBefore(box, document.body.firstChild);
      }
    });
    guard.observe(document.body, { childList: true });
  }

  // ---- 코코포리아 방 목록 카드의 그림을 그대로 쓴다 ----
  // 카드는 <a href="/rooms/id"> 안의 MuiCardMedia 배경 그림 (전경 → 배경). 우리 목록에 이미 있는 방만 갱신한다.
  function readRoomCards() {
    const out = {};
    for (const a of document.querySelectorAll('a[href^="/rooms/"]')) {
      if (a.closest('.cst-root')) continue; // 우리가 그린 카드는 건너뛴다
      const m = (a.getAttribute('href') || '').match(/^\/rooms\/([^/?#]+)/);
      if (!m) continue;
      let url = '';
      for (const node of [a, ...a.querySelectorAll('*')]) {
        const bg = getComputedStyle(node).backgroundImage;
        const hit = bg && bg.match(/url\(["']?(.+?)["']?\)/);
        if (hit && /^https?:\/\//i.test(hit[1])) {
          url = hit[1];
          break;
        }
        if (node.tagName === 'IMG' && /^https?:\/\//i.test(node.src)) {
          url = node.src;
          break;
        }
      }
      if (!url) continue;
      out[m[1]] = { thumb: url, name: (a.getAttribute('aria-label') || '').trim() };
    }
    return out;
  }
  async function syncRoomCards() {
    if (!extAlive()) return;
    const cards = readRoomCards();
    if (!Object.keys(cards).length) return;
    const { rooms } = await getLocal({ rooms: {} });
    let changed = false;
    for (const [id, card] of Object.entries(cards)) {
      const cur = rooms[id];
      if (!cur) continue; // 들어가 본 적 없는 방은 목록에 새로 만들지 않는다
      if (card.thumb && cur.thumb !== card.thumb) {
        cur.thumb = card.thumb;
        cur.thumbFrom = 'room';
        changed = true;
      }
      if (card.name && cur.name !== card.name) {
        cur.name = card.name;
        changed = true;
      }
    }
    if (changed) await setLocal({ rooms });
  }
  for (const ms of [1500, 4000, 10000]) setTimeout(syncRoomCards, ms);

  if (!extAlive()) return;
  chrome.storage.sync.get({ theme: 'dark', accentColor: '', ccfHome: true, roomView: 'thumb' }, (s) => {
    theme = THEMES.includes(s.theme) ? s.theme : 'dark';
    accent = s.accentColor || '';
    viewMode = s.roomView === 'list' ? 'list' : 'thumb';
    if (s.ccfHome === false) return;
    if (document.readyState === 'loading') {
      window.addEventListener('DOMContentLoaded', build);
    } else {
      build();
    }
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync' && (changes.theme || changes.accentColor)) {
      if (changes.theme) theme = THEMES.includes(changes.theme.newValue) ? changes.theme.newValue : 'dark';
      if (changes.accentColor) accent = changes.accentColor.newValue || '';
      applyTheme();
    }
    if (area === 'sync' && changes.roomView && box) {
      viewMode = changes.roomView.newValue === 'list' ? 'list' : 'thumb';
      render();
    }
    if (area === 'sync' && changes.ccfHome) {
      const on = changes.ccfHome.newValue !== false;
      if (on && !box) build();
      else if (box) box.style.display = on ? 'block' : 'none';
    }
    if (area === 'local' && changes.rooms && box && !memoEditing) render();
  });
})();
