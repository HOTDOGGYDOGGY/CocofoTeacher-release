// 코코포리아 선생님 — 방 정보(이름·썸네일) 수집·저장
(() => {
  if (window.__cstRoomInfoLoaded) return;
  window.__cstRoomInfoLoaded = true;

  const EXT = typeof chrome !== 'undefined' && chrome.storage && chrome.runtime;
  if (!EXT) return;

  // roomId = /rooms/XXXX 부분 (쿼리스트링 무시)
  const m = location.pathname.match(/^\/rooms\/([^/]+)/);
  if (!m) return;
  const roomId = m[1];
  const roomUrl = location.origin + '/rooms/' + roomId;

  // 공통 헬퍼: rooms 스토리지 갱신

  // 확장을 새로고침하면 남아 있던 이 스크립트의 chrome.* 연결이 끊긴다
  // ("Extension context invalidated"). 호출 전에 살아 있는지 확인한다.
  function extAlive() {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (_) {
      return false;
    }
  }

  function updateRoom(patch) {
    if (!extAlive()) return;
    chrome.storage.local.get({ rooms: {} }, (data) => {
      if (chrome.runtime.lastError) return;
      const rooms = data.rooms || {};
      const cur = rooms[roomId] || {};
      rooms[roomId] = {
        name: '이름 없는 방',
        url: roomUrl,
        thumb: '',
        favorite: false,
        memo: '',
        ...cur,
        ...patch,
        lastVisit: Date.now(),
      };
      try {
        chrome.storage.local.set({ rooms }, () => void chrome.runtime.lastError);
      } catch (_) {}
    });
  }

  // panel.js 등에서 재사용할 수 있게 노출
  window.__cstRoom = { roomId, roomUrl, updateRoom };

  updateRoom({}); // 방문 시각 즉시 기록

  // ---- 방 이름 · 썸네일: 코코포리아가 방 목록에 쓰는 그림 그대로 ----
  // 페이지 쪽(lib/ccf-page.js watchRoom)이 코코포리아 상태에서 방 문서를 읽어, 이름과
  // 전경(없으면 배경) 주소가 바뀔 때만 알려 준다 (장면을 바꾸면 전경도 바뀐다). 서버 요청은 없다.
  let gotRoomThumb = false;
  window.addEventListener('message', (e) => {
    const d = e.data;
    if (e.source !== window || !d || d.source !== 'cst-ccf-page' || d.type !== 'room') return;
    if (d.roomId && d.roomId !== roomId) return;
    const patch = {};
    if (d.name) {
      patch.name = d.name;
      clearInterval(nameTimer); // 화면에서 이름을 찾을 필요가 없다
    }
    if (d.thumb) {
      patch.thumb = d.thumb;
      patch.thumbFrom = 'room';
      gotRoomThumb = true;
    }
    if (Object.keys(patch).length) updateRoom(patch);
  });
  if (extAlive()) {
    try {
      chrome.runtime.sendMessage({ type: 'CCF_WATCH_ROOM' }, () => void chrome.runtime.lastError);
    } catch (_) {}
  }

  // ---- 방 이름: MUI 서브타이틀 폴링 (코코포리아 상태를 못 읽을 때의 길) ----
  let nameTries = 0;
  const nameTimer = setInterval(() => {
    if (document.hidden) return; // 숨김 탭에서는 쉰다 (시도 횟수도 소모하지 않음)
    nameTries++;
    const el = document.querySelector('h6[class*="MuiTypography-subtitle2"]');
    if (el) {
      const textNode = Array.from(el.childNodes).find(
        (c) => c.nodeType === Node.TEXT_NODE && c.textContent.trim() !== ''
      );
      const name = (textNode ? textNode.textContent : el.textContent || '').trim();
      if (name) {
        updateRoom({ name });
        clearInterval(nameTimer);
        return;
      }
    }
    if (nameTries > 60) clearInterval(nameTimer);
  }, 1000);

  // ---- 썸네일 백업: 화면에서 가장 크게 렌더된 이미지 (코코포리아 상태를 못 읽을 때만) ----
  function captureThumb() {
    if (gotRoomThumb || !extAlive()) return;
    chrome.storage.local.get({ rooms: {} }, (d) => {
      if (chrome.runtime.lastError) return;
      const cur = (d.rooms || {})[roomId];
      if (cur && cur.thumbFrom === 'room' && cur.thumb) return; // 방 목록과 같은 그림이 이미 있다
      shotThumb();
    });
  }
  function shotThumb() {
    let best = null;
    let bestArea = 0;
    for (const img of document.querySelectorAll('img')) {
      if (!img.src || img.src.startsWith('data:')) continue;
      // 30초 시점엔 채팅 인장이 수백 개 쌓여 있다 — rect(강제 레이아웃) 전에
      // 로드된 표시 크기(width/height 속성)로 아바타·아이콘을 먼저 거른다
      if ((img.width && img.width < 200) || (img.height && img.height < 150)) continue;
      const r = img.getBoundingClientRect();
      const area = r.width * r.height;
      // 아바타·아이콘 크기는 제외
      if (r.width < 200 || r.height < 150) continue;
      if (area > bestArea) {
        bestArea = area;
        best = img.src;
      }
    }
    if (best) updateRoom({ thumb: best, thumbFrom: 'shot' });
  }

  // 로드 직후 + 배경이 늦게 뜨는 경우 대비해 몇 번 재시도
  setTimeout(captureThumb, 4000);
  setTimeout(captureThumb, 12000);
  setTimeout(captureThumb, 30000);
})();
