// 코코포리아 선생님 — 통합 헬퍼 패널 (스탠딩 / 색상 / 메모 / 문자 / 사이즈)
(() => {
  if (window.__cstPanelLoaded) return;
  window.__cstPanelLoaded = true;

  const EXT = typeof chrome !== 'undefined' && chrome.storage && chrome.runtime;
  if (!EXT) return;

  const m = location.pathname.match(/^\/rooms\/([^/]+)/);
  if (!m) return;
  const roomId = m[1];

  const DEFAULT_CHARS = [
    '「', '」', '『', '』', '【', '】', '〈', '〉', '《', '》', '〔', '〕',
    '…', '‥', '―', '─', '·', '、', '。', '♥', '♡', '☆', '★',
    '※', '○', '●', '◎', '◇', '◆', '□', '■', '△', '▲', '▽', '▼',
    '→', '←', '↑', '↓', '↔', '♪', '♬', '♩', '〓', '§', '¶', '†', '‡',
  ];

  const THEMES = ['dark', 'light', 'mono', 'retro'];
  // 배포본: 캡처 탭·로그 수집(원클릭·자동 백업) 없음 (lib/edition.js).
  // 개인용에서 '배포용 미리보기'로 두면 init() 에서 storage 를 읽어 여기에 맞춘다 (탭 새로고침 필요)
  let LITE = !!window.CST_LITE;

  // 켜기/끄기 스위치 — 팝업 설정의 토글과 같은 모양. 패널의 모든 켜기/끄기는 이걸 쓴다.
  // 반환: { wrap, input }  (wrap 을 줄에 붙이고, input 으로 checked 를 읽는다)
  // 글자 라벨은 <label for=input.id> 로 연결한다 — 줄 자체를 label 로 감싸 중첩시키면
  // 글자를 눌렀을 때 토글이 안 된다 (안쪽 label 이 상호작용 요소라 바깥 label 이 비켜감).
  let swSeq = 0;
  function mkSwitch(checked, onChange) {
    // <label> 이어야 손잡이를 눌렀을 때 안쪽 숨은 체크박스가 토글된다 (div 줄 안에 놓여도 동작)
    const wrap = document.createElement('label');
    wrap.className = 'cst-switch';
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.id = 'cst-sw-' + ++swSeq;
    input.checked = !!checked;
    if (onChange) input.addEventListener('change', () => onChange(input.checked));
    const knob = document.createElement('span');
    knob.className = 'cst-switch-knob';
    wrap.append(input, knob);
    return { wrap, input };
  }

  const state = {
    theme: 'dark',
    accent: '',
    panelOn: true,
    specialChars: DEFAULT_CHARS,
    thumb: { zoom: 100, posX: 50, posY: 15 },
    cols: 3,
    standingCss: {},
    noticePos: 'top', // 고정 메모 바 위치: top | bottom(좌하단)
    noticeFont: 12, // 고정 메모 글자 크기(px)
    activeTab: 'standing',
    currentChar: '',
    lastStanding: '',
    atPrefix: true, // 스탠딩 클릭 시 맨 앞에 @ 추가
    adjustMode: false, // 썸네일을 마우스로 직접 조정하는 중
    detected: null, // { name, standings, sheet }
    sheetChar: '', // 시트 백업에서 보고 있는 캐릭터
    wardrobeLayout: 'tabs', // 옷장 보기: tabs | toc(목차) | fold(접기)
    wardrobeTab: {}, // 캐릭터별로 보고 있던 옷 (탭)
    wardrobeFold: {}, // 캐릭터·옷별 접힘 상태
    hideOutfit: true, // 옷장으로 나눠 볼 때 이름표에서 옷 이름 빼기 (보내는 이름은 그대로)
    standingSort: 'manual', // 스탠딩 정렬: manual | name | added
    followSpeaker: true, // 발화 캐릭터를 바꾸면 스탠딩 보기도 따라가기
    thumbPerOutfit: true, // 확대 · 위치를 옷장별로 따로
    thumbSet: { base: { zoom: 100, posX: 50, posY: 15 }, outfits: {} }, // 지금 캐릭터의 확대 · 위치 (공통 + 옷장별)
    thumbSplit: false, // 지금 캐릭터가 옷장으로 나뉘는지
    thumbTarget: null, // 조절하는 옷장 (null = 캐릭터 공통)
    saveAllChars: false, // 코코포리아 상태에서 읽을 때 다른 사람 캐릭터도 저장 (GM 용)
    panelUi: { fold: {} }, // 캐릭터 탭 접은 구역
    standingQuery: '', // 스탠딩 검색어
    myCharsDirect: null, // 코코포리아 상태에서 내 캐릭터를 읽을 수 있는지 (false 면 [내 캐릭터 새로고침])
    colsFixed: true, // 열 수 고정 (끄면 패널 너비에 맞춤)
    colsMore: false, // 4~6열 버튼 펼침
    sharpen: true, // 확대돼 보이는 스탠딩 선명하게
  };

  // 스탠딩 썸네일 확대 · 위치는 캐릭터마다 따로 — room.standingThumbs[캐릭터] = { zoom, posX, posY }
  // 처음 보는 캐릭터는 기본값(확대 · 위치 조정 안 한 상태)으로 시작한다
  const THUMB_DEFAULT = { zoom: 100, posX: 50, posY: 15 };
  let suppressColsEcho = false;
  let standingDragFrom = null; // 끌고 있는 스탠딩 카드 { char, label } — 다른 곳에서 끌어온 것(파일 등)은 순서에 안 넣는다
  let standingEditorBack = null; // 열려 있는 [고치기] 창 (두 개 열지 않게)
  let suppressCssEcho = false;

  // ---------------- 스토리지 ----------------
  // 확장을 새로고침하면 페이지에 남아 있던 이 스크립트의 chrome.* 연결이 끊긴다
  // ("Extension context invalidated"). 그 상태에서 호출하면 예외가 나므로,
  // 매번 살아 있는지 확인하고 죽었으면 조용히 기본값으로 넘어간 뒤 UI를 정리한다.
  let extDead = false;

  function extAlive() {
    if (extDead) return false;
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (_) {
      return false;
    }
  }

  function handleContextLost() {
    if (extDead) return;
    extDead = true;
    try {
      clearInterval(fabGuardTimer);
      clearTimeout(detectTimer);
      if (domObserver) domObserver.disconnect();
      if (panel) panel.remove();
      if (fab) fab.remove();
      if (noticeBar) noticeBar.remove();
      if (healthBanner) healthBanner.remove();
      if (toastEl) toastEl.remove();
    } catch (_) {}
    // 확장이 업데이트/재로드된 상황 — 새로고침하면 다시 붙는다.
    // 설정 [업데이트되면 방 새로고침]이 켜져 있으면 알아서 새로고침한다.
    // 다만 보내지 않은 글이 있거나 편집창을 열어 둔 중이면 날아가니, 그게 끝날 때까지 기다린다.
    if (reloadOnUpdate) {
      if (safeToReload()) {
        location.reload();
        return;
      }
      const wait = setInterval(() => {
        if (!safeToReload()) return;
        clearInterval(wait);
        location.reload();
      }, 2000);
    }
    // 업데이트는 보통 다른 탭(업데이트 화면)에서 하므로, 이 탭이 숨어 있으면 돌아왔을 때 띄운다
    // (숨은 동안 떴다가 사라져 못 보는 일이 없게).
    const show = () => {
      try {
        const note = document.createElement('div');
        note.style.cssText =
          'position:fixed;left:50%;bottom:22px;transform:translateX(-50%);z-index:2147483600;' +
          'background:#2a2a2f;color:#ececef;border:1px solid #46464f;border-radius:10px;' +
          'padding:8px 14px;font:12px/1.5 sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.4);cursor:pointer;';
        note.textContent = reloadOnUpdate
          ? '코코포리아 선생님이 업데이트됐어요. 입력 중인 글을 보내거나 창을 닫으면 알아서 새로고침합니다. (클릭하면 지금 새로고침)'
          : '코코포리아 선생님이 업데이트됐어요. 새로고침하면 다시 켜집니다. (클릭하면 새로고침)';
        note.addEventListener('click', () => location.reload());
        document.body.appendChild(note);
        setTimeout(() => note.remove(), 20000);
      } catch (_) {}
    };
    if (document.hidden) {
      const onVisible = () => {
        if (document.hidden) return;
        document.removeEventListener('visibilitychange', onVisible);
        show();
      };
      document.addEventListener('visibilitychange', onVisible);
    } else {
      show();
    }
  }

  // [업데이트되면 방 새로고침] 설정 — 확장이 끊긴 뒤에는 저장소를 못 읽으니 미리 읽어 둔다 (init · onChanged)
  let reloadOnUpdate = true;

  // 새로고침해도 잃을 게 없는가: 채팅 입력칸이 비었고, 편집창 같은 창이 안 열려 있고,
  // 지금 글을 쓰는 칸(내용 있는 입력칸)에 커서가 있지 않을 때
  function safeToReload() {
    try {
      const chat = findChatInput();
      if (chat && chat.value.trim()) return false;
      const dlg = [...document.querySelectorAll('.MuiDialog-root, [role="dialog"]')].some((n) => !n.closest('.cst-root'));
      if (dlg) return false;
      const a = document.activeElement;
      if (a && (a.tagName === 'TEXTAREA' || a.tagName === 'INPUT' || a.isContentEditable) && String(a.value || a.textContent || '').trim()) return false;
      return true;
    } catch (_) {
      return false;
    }
  }

  // 패널을 가만히 두어도 확장이 새로고침된 것을 알아챈다.
  // 예전엔 저장소를 읽을 때(패널에서 뭔가 누를 때)만 알아채서, 그냥 두면 안내가 뜨지 않았다.
  const liveTimer = setInterval(() => {
    if (extAlive()) return;
    clearInterval(liveTimer);
    handleContextLost();
  }, 2000);

  // chrome.storage 호출을 감싼다 — 컨텍스트가 죽었으면 예외 대신 기본값 반환
  function safeStorage(area, method, arg, defs) {
    return new Promise((resolve) => {
      if (!extAlive()) {
        handleContextLost();
        return resolve(defs);
      }
      try {
        chrome.storage[area][method](arg, (d) => {
          if (chrome.runtime.lastError) return resolve(defs);
          resolve(method === 'get' ? d : undefined);
        });
      } catch (_) {
        handleContextLost();
        resolve(defs);
      }
    });
  }

  function extUrl(path) {
    try {
      return extAlive() ? chrome.runtime.getURL(path) : '';
    } catch (_) {
      return '';
    }
  }

  function sendMsg(payload) {
    if (!extAlive()) {
      handleContextLost();
      return;
    }
    try {
      chrome.runtime.sendMessage(payload, () => void chrome.runtime.lastError);
    } catch (_) {
      handleContextLost();
    }
  }

  const getLocal = (defs) => safeStorage('local', 'get', defs, defs);
  const setLocal = (obj) => safeStorage('local', 'set', obj, undefined);
  const getSync = (defs) => safeStorage('sync', 'get', defs, defs);
  const setSync = (obj) => safeStorage('sync', 'set', obj, undefined);

  // 방 기록은 lib/room-store.js 가 목록(rooms)과 캐릭터 기록(roomChars:<id>)으로 나눠 둔다
  const RoomStore = globalThis.CSTRoomStore;
  const newRoom = () => ({
    name: '이름 없는 방',
    url: location.origin + '/rooms/' + roomId,
    thumb: '',
    favorite: false,
    memo: '',
    standings: {},
    standingOrder: {},
    lastVisit: Date.now(),
  });
  async function getRoom() {
    if (!extAlive()) return newRoom();
    return (await RoomStore.loadRoom(roomId)) || newRoom();
  }

  // 방 기록 고치기 — 읽기 · 고치기 · 쓰기를 한 줄로 세워 차례로 한다.
  // 동시에 두 개가 돌면 둘 다 옛 값을 읽고 나중에 쓴 쪽이 앞의 변경을 덮는다
  // (편집창 자동 감지가 옛 표정 목록을 쓰는 사이에 '코코포리아에서도 지우기'가 지운 것이 되살아나던 문제).
  let roomWriteChain = Promise.resolve();
  // 다른 방 기록 고치기 (캐릭터 방 복사) — 같은 쓰기 줄에 세워 이 방 쓰기와 엇갈리지 않게
  function patchRoomById(id, patchFn) {
    if (id === roomId) return patchRoom(patchFn);
    const run = roomWriteChain.then(async () => {
      const cur = await RoomStore.loadRoom(id);
      if (!cur) throw new Error('no-room');
      patchFn(cur);
      await RoomStore.saveRoom(id, cur);
    });
    roomWriteChain = run.catch(() => {});
    return run;
  }
  function patchRoom(patchFn) {
    const run = roomWriteChain.then(async () => {
      if (!extAlive()) return;
      const cur = (await RoomStore.loadRoom(roomId)) || newRoom();
      patchFn(cur);
      // 캐릭터 기록은 이 방 것만, 목록 줄은 바뀌었을 때만 쓴다 (다른 방 스탠딩까지 다시 쓰지 않는다)
      await RoomStore.saveRoom(roomId, cur);
    });
    roomWriteChain = run.catch(() => {});
    return run;
  }

  // ---------------- 색상 유틸 ----------------
  function normalizeHex(v) {
    let s = String(v || '').trim();
    if (!s) return '';
    if (!s.startsWith('#')) s = '#' + s;
    if (/^#[0-9a-fA-F]{3}$/.test(s)) s = '#' + [...s.slice(1)].map((c) => c + c).join('');
    return /^#[0-9a-fA-F]{6}$/.test(s) ? s.toLowerCase() : '';
  }

  function darken(hex, amt = 0.15) {
    const h = normalizeHex(hex);
    if (!h) return hex;
    const n = parseInt(h.slice(1), 16);
    const f = (v) => Math.max(0, Math.round(v * (1 - amt)));
    return (
      '#' +
      [f((n >> 16) & 255), f((n >> 8) & 255), f(n & 255)]
        .map((v) => v.toString(16).padStart(2, '0'))
        .join('')
    );
  }

  function hexToSoft(hex, alpha = 0.15) {
    const h = normalizeHex(hex);
    if (!h) return '';
    const n = parseInt(h.slice(1), 16);
    return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${alpha})`;
  }

  // ---------------- 코코포리아 DOM 헬퍼 ----------------
  function findChatInput() {
    return document.querySelector('div[class*="MuiInputBase-root"] textarea');
  }

  function setNativeValue(el, text) {
    const proto =
      el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(el, text);
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }

  function insertAtCursor(text) {
    const input = findChatInput();
    if (!input) return;
    const start = input.selectionStart ?? input.value.length;
    const end = input.selectionEnd ?? input.value.length;
    const val = input.value;
    setNativeValue(input, val.slice(0, start) + text + val.slice(end));
    const pos = start + text.length;
    input.focus();
    input.setSelectionRange(pos, pos);
  }

  // ---- 발화 캐릭터 메뉴 (v12.0 강화) ----
  // 예전에는 "입력창 근처에서 글자가 있는 첫 버튼"을 눌렀는데, 코코포리아 개편 뒤 엉뚱한 버튼이 잡혀
  // NPC 한 명만 보이거나 목록을 못 읽는 일이 있었다. 이제 후보를 여러 개 모아 순서대로 눌러 보고,
  // 열린 메뉴에 "지금 발화 중인 이름"이 들어 있어야 진짜 캐릭터 메뉴로 인정한다.
  const MENU_ITEM_SEL =
    '[role="menu"] [role="menuitem"], [role="listbox"] [role="option"], .MuiMenu-list li, .MuiPopover-root li, .MuiMenu-list [role="button"]';

  // 채팅 입력칸 위의 발화 이름칸 (input[name="name"]) — 캐릭터 편집창 같은 창 안의 것은 뺀다
  function chatNameInput() {
    for (const i of document.querySelectorAll('input[name="name"]')) {
      if (i.closest('.MuiDialog-root, .MuiModal-root, .MuiPopover-root, .cst-root')) continue;
      return i;
    }
    return null;
  }
  const currentChatName = () => {
    const i = chatNameInput();
    return i ? i.value.trim() : '';
  };

  // 코코포리아(2026-09): [캐릭터 선택] 버튼은 이름 글자 없이 아바타만 있고 툴팁(aria-label)이 붙는다.
  // 이름칸(input[name="name"])과 같은 줄에 있다. 글자가 없어도 아바타 버튼이면 후보로 넣는다.
  const CHAR_SELECT_LABEL = /キャラクター選択|캐릭터\s*선택|select\s*character|character/i;
  function charOpenerCandidates(myNames) {
    const input = findChatInput();
    if (!input) return [];
    const out = [];
    const seen = new Set();
    const nameBox = chatNameInput();
    const nameRow = nameBox && nameBox.closest('.MuiInputBase-root') ? nameBox.closest('.MuiInputBase-root').parentElement : null;
    const current = currentChatName();
    let p = input.parentElement;
    for (let i = 0; i < 8 && p; i++) {
      for (const b of p.querySelectorAll('button, [role="button"], [aria-haspopup]')) {
        if (seen.has(b) || (b.closest && b.closest('.cst-root'))) continue;
        if (b.getAttribute('role') === 'tab') continue;
        const t = (b.textContent || '').trim();
        const avatar = !!b.querySelector('img, .MuiAvatar-root, svg');
        if (!t && !avatar) continue;
        if (t.length > 40 || /^[0-9]+$/.test(t)) continue;
        if (/^(전송|送信|send|보내기)$/i.test(t)) continue;
        const r = b.getBoundingClientRect();
        if (!r.width || !r.height) continue;
        seen.add(b);
        let score = 0;
        if (CHAR_SELECT_LABEL.test(b.getAttribute('aria-label') || b.getAttribute('title') || '')) score += 8;
        if (nameRow && nameRow.contains(b)) score += 6;
        if (b.getAttribute('aria-haspopup')) score += 4;
        if (b.getAttribute('aria-controls') || b.getAttribute('aria-expanded') != null) score += 2;
        if (b.querySelector('img, .MuiAvatar-root')) score += 2;
        if (t && myNames && myNames.some((n) => n === t || t.includes(n))) score += 5;
        score -= i * 0.1; // 입력창에 가까운 것 우선
        // 버튼에 이름이 없으면 이름칸의 지금 발화 이름으로 메뉴를 확인한다
        out.push({ el: b, text: t || current, score });
      }
      p = p.parentElement;
    }
    return out.sort((a, b) => b.score - a.score).slice(0, 4);
  }

  // 메뉴 줄의 이름 — 코코포리아 메뉴 줄에는 '활성 상태' 같은 보조 글이 붙어 있어 첫 줄(primary)만 쓴다
  const menuItemName = (it) => {
    const prim = it.querySelector && it.querySelector('.MuiListItemText-primary');
    return ((prim ? prim.textContent : it.textContent) || '').trim();
  };

  function menuItemsNow() {
    return [...document.querySelectorAll(MENU_ITEM_SEL)].filter((it) => {
      if (it.closest && it.closest('.cst-root')) return false;
      const r = it.getBoundingClientRect();
      return r.width > 0 && r.height > 0 && (it.textContent || '').trim();
    });
  }

  async function closeMenus() {
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    await new Promise((r) => setTimeout(r, 120));
    if (menuItemsNow().length) {
      document.body.click();
      await new Promise((r) => setTimeout(r, 120));
    }
  }

  // 캐릭터 메뉴를 연다. 성공하면 { opener, items } — 실패하면 null (메뉴는 닫아 둔다)
  async function openCharMenu(myNames) {
    const cands = charOpenerCandidates(myNames);
    for (const c of cands) {
      const before = menuItemsNow().length;
      c.el.click();
      let items = [];
      for (let w = 0; w < 10; w++) {
        await new Promise((r) => setTimeout(r, 120));
        items = menuItemsNow();
        if (items.length > before) break;
      }
      if (items.length <= before) continue;
      const names = items.map(menuItemName);
      // 지금 발화 중인 이름(버튼 글자 · 이름칸)이 목록에 있어야 캐릭터 메뉴다
      const looksRight = !!c.text && names.some((n) => n === c.text || n.includes(c.text) || c.text.includes(n));
      if (looksRight) return { opener: c.el, items };
      await closeMenus();
    }
    // 검증에 걸리는 후보가 없으면, 메뉴가 열리기라도 한 첫 후보를 그대로 쓴다 (예전 동작)
    for (const c of cands) {
      c.el.click();
      await new Promise((r) => setTimeout(r, 400));
      const items = menuItemsNow();
      if (items.length) return { opener: c.el, items, unverified: true };
      await closeMenus();
    }
    return null;
  }

  // 발화 캐릭터 전환
  // 1) 페이지 쪽에서 코코포리아 상태를 직접 바꾼다 (메뉴에서 고른 것과 같은 값) — 화면이 바뀌어도 잘 안 깨진다
  // 2) 안 되면 예전처럼 캐릭터 선택 메뉴를 열어 이름을 누른다
  async function switchCharacter(name) {
    const direct = await msg('CCF_CHAT_CHARACTER', { op: { kind: 'set', name } });
    if (direct && direct.ok) {
      if (Array.isArray(direct.names) && direct.names.length) saveMyNames(direct.names);
      toast(direct.mine ? `"${name}"(으)로 전환` : `"${name}"(으)로 이름을 바꿨어요 (내 캐릭터 목록에 없어 이름만)`);
      onSpeakerSwitched(name);
      return;
    }
    const input = findChatInput();
    if (!input) {
      toast('채팅 입력창을 찾을 수 없어요.');
      return;
    }
    const room = await getRoom();
    const opened = await openCharMenu(Array.isArray(room.myChars) ? room.myChars : null);
    if (!opened) {
      toast('캐릭터 선택 메뉴를 열지 못했어요. 코코포리아 화면 구조가 바뀌었을 수 있어요 (패널 [로그] 탭 → 화면 구조 진단).');
      return;
    }
    if (!opened.unverified) saveMyCharsFromMenu(opened.items); // 메뉴에 뜬 목록 = 내가 발화 권한 있는 캐릭터
    let hit = null;
    for (const it of opened.items) {
      const t = menuItemName(it);
      if (t === name) {
        hit = it;
        break;
      }
      if (!hit && t.includes(name)) hit = it;
    }
    if (hit) {
      hit.click();
      toast(`"${name}"(으)로 전환`);
      onSpeakerSwitched(name);
    } else {
      await closeMenus();
      toast(`메뉴에서 "${name}"을(를) 찾지 못했어요. 캐릭터가 방에 등록돼 있어야 해요.`);
    }
  }

  // 캐릭터 선택 메뉴에 뜨는 이름들 = 내 권한 캐릭터 → room.myChars 저장
  // (백업용으로 편집창만 연 캐릭터는 여기 안 뜨므로 NPC 픽커에서 걸러진다)
  // 캐릭터 메뉴에 섞여 있는 조작 항목 (캐릭터가 아니다)
  const MENU_JUNK =
    /^(없음|なし|なし\(自分\)|자신|본인|추가|만들기|새|새로\s*만들기|캐릭터\s*(추가|만들기|생성)|편집|수정|삭제|설정|닫기|취소|확인|전체|모두|新規|作成|追加|編集|削除|設定|閉じる|キャンセル|add|new|create|edit|delete|settings?|close|cancel)$/i;

  // 내 캐릭터 이름 목록 저장 (바뀌었을 때만)
  function saveMyNames(names) {
    return patchRoom((r) => {
      if (JSON.stringify(r.myChars || []) !== JSON.stringify(names)) r.myChars = names;
    }).catch(() => {});
  }

  // 발화 캐릭터를 바꾼 뒤: [스탠딩도 같이 바꾸기]가 켜져 있으면 스탠딩 보기도 그 캐릭터로
  async function onSpeakerSwitched(name) {
    lastSpeaker = name;
    if (state.followSpeaker) {
      const room = await getRoom();
      if (knownChars(room).includes(name)) state.currentChar = name;
    }
    if (state.activeTab === 'standing') renderBody();
  }

  function saveMyCharsFromMenu(items) {
    const names = [];
    for (const it of items) {
      const t = menuItemName(it);
      if (!t || t.length > 40) continue;
      if (MENU_JUNK.test(t)) continue; // '없음'·'캐릭터 추가' 같은 조작 항목 제외
      if (/^[\s\d+＋・·-]+$/.test(t)) continue; // 기호·숫자만 있는 줄 제외
      if (!names.includes(t)) names.push(t);
    }
    if (names.length) {
      patchRoom((r) => {
        r.myChars = names;
      }).catch(() => {});
    }
    return names;
  }

  // 메뉴를 잠깐 열었다 닫으며 내 캐릭터 목록만 갱신
  async function scanMyChars() {
    const direct = await msg('CCF_CHAT_CHARACTER', { op: { kind: 'list' } });
    if (direct && direct.ok && Array.isArray(direct.names)) {
      await saveMyNames(direct.names);
      return direct.names;
    }
    const input = findChatInput();
    if (!input) {
      toast('채팅 입력창을 찾을 수 없어요.');
      return [];
    }
    const room = await getRoom();
    const opened = await openCharMenu(Array.isArray(room.myChars) ? room.myChars : null);
    if (!opened) {
      toast('캐릭터 선택 메뉴를 열지 못했어요. 코코포리아 화면 구조가 바뀌었을 수 있어요.');
      return [];
    }
    const names = opened.unverified ? [] : saveMyCharsFromMenu(opened.items);
    if (opened.unverified) {
      toast('메뉴가 열리긴 했지만 캐릭터 목록인지 확실하지 않아 저장하지 않았어요. [저장된 캐릭터 전부 표시]를 켜 주세요.');
    }
    await closeMenus();
    return names;
  }

  function appendStandingTag(label) {
    const input = findChatInput();
    if (!input) return;
    // @ 추가 토글: 켜져 있으면 정확히 하나의 @만 붙인다 (라벨에 이미 @가 있으면 중복 방지)
    const tag = state.atPrefix ? '@' + String(label).replace(/^@+/, '') : String(label);
    const stripped = input.value.replace(/\s*@[^@\s]*$/, '');
    setNativeValue(input, stripped + tag);
    input.focus();
  }

  // ---------------- 캐릭터 편집창 감지 (스탠딩 자동 저장용) ----------------
  // 편집창 안의 이름 입력칸. name="name"이 기본이지만, 폼 이름이 바뀐 경우를 대비해
  // "이름/名前/Name" 라벨이 붙은 첫 텍스트 입력칸도 후보로 본다.
  function findNameInput(dialog) {
    const direct = dialog.querySelector(
      'input[name="name"], textarea[name="name"], input[name$=".name"], input[name="characterName"]'
    );
    if (direct) return direct;
    for (const inp of dialog.querySelectorAll('input[type="text"], input:not([type]), textarea')) {
      const lab = inp.labels && inp.labels[0] ? inp.labels[0].textContent : '';
      const ph = inp.getAttribute('placeholder') || '';
      const aria = inp.getAttribute('aria-label') || '';
      if (/(^|\s)(이름|캐릭터\s*이름|캐릭터명|名前|キャラクター名|name|character\s*name)(\s|$)/i.test(lab + ' ' + ph + ' ' + aria))
        return inp;
    }
    return null;
  }

  // "faces.0.label" / "faces[0].label" / "faces.0.image" 처럼 표기가 조금 달라도 읽어낸다
  const FACE_LABEL_RE = /faces\W*(\d+)\W*label$/;
  const FACE_IMAGE_RE = /faces\W*(\d+)\W*(image|iconUrl|url|src)$/i;
  const EDITOR_SEL = '.MuiDialog-root, .MuiModal-root, [role="dialog"], .MuiDrawer-paper';

  // 편집창 후보 하나를 읽는다. 이름이 없으면 null
  function readEditor(dialog) {
    const nameInput = findNameInput(dialog);
    if (!nameInput) return null;
    const name = (nameInput.value || '').trim();
    if (!name) return null;

    const standings = [];
    const imgByIdx = new Map();
    for (const inp of dialog.querySelectorAll('input[name]')) {
      const im = (inp.getAttribute('name') || '').match(FACE_IMAGE_RE);
      if (im && inp.value) imgByIdx.set(im[1], inp.value);
    }
    const labelInputs = [...dialog.querySelectorAll('input[name]')].filter((inp) =>
      FACE_LABEL_RE.test(inp.getAttribute('name') || '')
    );
    for (const li of labelInputs) {
      const label = (li.value || '').trim();
      if (!label) continue;
      const idx = ((li.getAttribute('name') || '').match(FACE_LABEL_RE) || [])[1];
      let img = idx !== undefined ? imgByIdx.get(idx) || '' : '';
      if (!img) {
        // 줄 안의 <img>, 없으면 배경 이미지로 그린 칸
        let p = li.parentElement;
        while (p && p !== dialog) {
          const el2 = p.querySelector('img');
          if (el2 && el2.src) {
            img = el2.src;
            break;
          }
          const bg = p.querySelector('[style*="background-image"]');
          const m = bg && /url\(["']?([^"')]+)["']?\)/.exec(bg.style.backgroundImage || '');
          if (m) {
            img = m[1];
            break;
          }
          p = p.parentElement;
        }
      }
      const mainBtn = ccfFaceRowButtons(li).main;
      if (mainBtn && mainBtn.getAttribute('aria-current') === 'true') standings.push({ label, img, main: true });
      else standings.push({ label, img });
    }

    // 스탠딩만이 아니라 시트 내용도 함께 담아둔다 (능력치·파라미터·채팅 팔레트·메모)
    const sheet = readSheet(dialog);
    // 캐릭터 편집창인지 — 방 설정처럼 이름칸만 있는 창과 가른다.
    // 새로 만든 캐릭터는 스탠딩·시트가 비어 있어도 이 칸들은 있다.
    const isChar =
      labelInputs.length > 0 ||
      !!dialog.querySelector(
        'textarea[name="commands"], input[name="initiative"], input[name="externalUrl"], [name^="status"], [name^="params"], [name^="faces"]'
      );
    // 이름을 치는 중이면 아직 저장하지 않는다 ('바' → '바보' 처럼 중간 이름이 캐릭터로 남지 않게)
    const typingName = document.activeElement === nameInput;
    return { name, standings, sheet, isChar, typingName };
  }

  // 열려 있는 창 중 캐릭터 편집창을 찾는다.
  // 처음 이름칸이 보이는 창에서 바로 멈추면, 이름칸만 있는 다른 창을 잘못 집을 수 있다.
  // 그래서 후보를 모두 읽고 스탠딩이 가장 많이 읽힌 쪽을 고른다.
  function detectDialog() {
    const boxes = [...document.querySelectorAll(EDITOR_SEL)].filter((b) => !b.closest('.cst-root'));
    // 창 틀 없이 붙은 편집 폼 대비: 표정 칸에서 위로 올라가 이름칸이 있는 곳까지
    const face = [...document.querySelectorAll('input[name]')].find(
      (i) => FACE_LABEL_RE.test(i.getAttribute('name') || '') && !i.closest('.cst-root')
    );
    if (face) {
      let p = face.parentElement;
      while (p && p !== document.body && !findNameInput(p)) p = p.parentElement;
      if (p && p !== document.body) boxes.push(p);
    }
    let best = null;
    for (const box of boxes) {
      const d = readEditor(box);
      if (!d) continue;
      const score = d.standings.length * 10 + (sheetHasContent(d.sheet) ? 2 : 0) + (d.isChar ? 1 : 0);
      if (!best || score > best.score) best = { d, score, box };
    }
    if (!best) return null;
    // 어느 창에서 읽었는지 (저장용 JSON 에는 안 들어가게 숨김 속성)
    Object.defineProperty(best.d, 'box', { value: best.box, enumerable: false });
    return best.d;
  }

  // 캐릭터 편집창에서 시트 값을 읽어온다.
  // 코코포리아 폼은 status.0.label / status.0.value / status.0.max, params.0.label / params.0.value 꼴이다.
  function readSheet(dialog) {
    // "status.0.label" 이 기본이지만 "status[0].label" 처럼 바뀌어도 읽는다
    const rows = (prefix, keys) => {
      const byIdx = new Map();
      const re = new RegExp('^' + prefix + '\\W*(\\d+)\\W*(' + keys.join('|') + ')$');
      for (const inp of dialog.querySelectorAll('input[name], textarea[name]')) {
        const mm = (inp.getAttribute('name') || '').match(re);
        if (!mm) continue;
        if (!byIdx.has(mm[1])) byIdx.set(mm[1], {});
        byIdx.get(mm[1])[mm[2]] = (inp.value || '').trim();
      }
      const out = [];
      for (const idx of [...byIdx.keys()].sort((a, b) => Number(a) - Number(b))) {
        const rec = {};
        for (const k of keys) rec[k] = byIdx.get(idx)[k] || '';
        if (rec.label) out.push(rec);
      }
      return out;
    };

    const text = (sel) => {
      const e = dialog.querySelector(sel);
      return e ? e.value || '' : '';
    };

    return {
      status: rows('status', ['label', 'value', 'max']),
      params: rows('params', ['label', 'value']),
      commands: text('textarea[name="commands"]'),
      memo: text('textarea[name="memo"]'),
      initiative: text('input[name="initiative"]'),
      externalUrl: text('input[name="externalUrl"]'),
    };
  }

  // 시트에 담을 내용이 하나라도 있는지
  function sheetHasContent(sh) {
    if (!sh) return false;
    return !!(
      (sh.status && sh.status.length) ||
      (sh.params && sh.params.length) ||
      (sh.commands || '').trim() ||
      (sh.memo || '').trim()
    );
  }

  let detectTimer = 0;
  let detectSince = 0;
  let lastDetectSig = '';
  let lastNameTypeAt = 0; // 편집창 이름칸에 마지막으로 친 시각
  let autoCreated = null; // { box, name, sheet } 이 편집창 때문에 빈 채로 만든 캐릭터
  let syncThumbSliders = () => {};
  // 화면이 바뀔 때마다 조금 기다렸다 읽는다. 다만 계속 바뀌는 요소(애니메이션 등)가 있으면
  // 기다림이 끝없이 밀려 영영 못 읽으므로, 처음 바뀐 뒤 1.2초 안에는 반드시 한 번 읽는다.
  function scheduleDetect() {
    const now = Date.now();
    if (!detectTimer) detectSince = now;
    clearTimeout(detectTimer);
    detectTimer = setTimeout(runDetect, Math.max(0, Math.min(400, detectSince + 1200 - now)));
  }

  // 읽은 캐릭터 하나를 방 기록에 넣는다 — 편집창 읽기(runDetect) · 코코포리아 상태 읽기(onStoreCharacters) 공용.
  // d: { name, standings[{label, img, main?}], sheet }
  // fromStore: 코코포리아 상태에서 읽은 것 (그대로 믿는다 — 편집창은 덜 그려져 빈 칸으로 읽힐 수 있어 빈 값이면 예전 것을 둔다)
  // 반환: 스탠딩 없이 새로 만든 캐릭터인지
  function mergeCharacterRead(room, d, fromStore) {
    room.standings = room.standings || {};
    room.standingOrder = room.standingOrder || {};
    const isNew = !room.standings[d.name];
    if (sheetHasContent(d.sheet) || (fromStore && room.sheets && room.sheets[d.name])) {
      room.sheets = room.sheets || {};
      const prev = room.sheets[d.name] || {};
      const keep = (a, b) => (fromStore ? a : a && (Array.isArray(a) ? a.length : String(a).trim()) ? a : b);
      const next = {
        status: keep(d.sheet.status, prev.status) || [],
        params: keep(d.sheet.params, prev.params) || [],
        commands: keep(d.sheet.commands, prev.commands) || '',
        memo: keep(d.sheet.memo, prev.memo) || '',
        initiative: keep(d.sheet.initiative, prev.initiative) || '',
        externalUrl: keep(d.sheet.externalUrl, prev.externalUrl) || '',
      };
      const { at, ...prevBody } = prev;
      if (JSON.stringify(prevBody) !== JSON.stringify(next)) room.sheets[d.name] = { ...next, at: Date.now() };
    }
    if (!d.standings.length && !(fromStore && !isNew)) {
      // 새로 만든 캐릭터처럼 스탠딩이 없어도 캐릭터는 기록한다 (발화 캐릭터 고르기 · 가져오기에 뜨게)
      if (isNew) room.standings[d.name] = [];
      return isNew;
    }
    // 스탠딩 = 코코포리아 캐릭터 표정 그대로 (패널에만 있는 스탠딩은 두지 않는다).
    // 패널에서 숨긴 것은 빼고, 숨김 목록의 이미지는 코코포리아 최신 것으로 맞춰 둔다
    const hiddenList = (room.hiddenStandings && room.hiddenStandings[d.name]) || [];
    const hidden = new Set(hiddenList.map((x) => x.label));
    if (hiddenList.length) {
      const fresh = new Map(d.standings.map((x) => [x.label, x]));
      room.hiddenStandings[d.name] = hiddenList.map((x) => (fresh.has(x.label) ? { ...x, img: fresh.get(x.label).img } : x));
    }
    room.standings[d.name] = d.standings.filter((x) => !hidden.has(x.label));
    const known = room.standings[d.name].map((s) => s.label);
    // 숨긴 것도 순서에 남겨 둔다 (다시 보이게 하면 제자리)
    const order = (room.standingOrder[d.name] || []).filter((l) => known.includes(l) || hidden.has(l));
    for (const l of known) if (!order.includes(l)) order.push(l);
    room.standingOrder[d.name] = order;
    return false;
  }

  // ----- 코코포리아 상태에서 캐릭터 읽기 (편집창을 안 열어도 스탠딩 · 시트 저장) -----
  // 페이지 쪽(lib/ccf-page.js watchCharacters)이 캐릭터가 바뀔 때만 postMessage 로 보내 준다. 서버 요청은 없다.
  let storeCharsSig = '';
  function startCharacterWatch() {
    msg('CCF_WATCH_CHARACTERS', { all: state.saveAllChars }).then((res) => {
      state.storeWatch = !!(res && res.ok);
    });
  }
  window.addEventListener('message', (e) => {
    const data = e.data;
    if (e.source !== window || !data || data.source !== 'cst-ccf-page' || data.type !== 'characters') return;
    if (data.roomId && data.roomId !== roomId) return; // 방을 옮기는 중에 온 다른 방 것
    onStoreCharacters(Array.isArray(data.chars) ? data.chars : []);
  });
  async function onStoreCharacters(chars) {
    if (!extAlive()) return;
    const sig = JSON.stringify(chars);
    if (sig === storeCharsSig) return;
    storeCharsSig = sig;
    const reads = chars
      .filter((c) => c && c.name)
      .map((c) => {
        let mainSeen = false;
        const standings = [];
        for (const f of c.faces || []) {
          if (!f.label) continue;
          const isMain = !mainSeen && !!c.iconUrl && f.iconUrl === c.iconUrl;
          if (isMain) mainSeen = true;
          standings.push(isMain ? { label: f.label, img: f.iconUrl, main: true } : { label: f.label, img: f.iconUrl });
        }
        return {
          name: c.name,
          standings,
          sheet: {
            status: (c.status || []).filter((x) => x.label),
            params: (c.params || []).filter((x) => x.label),
            commands: c.commands || '',
            memo: c.memo || '',
            initiative: c.initiative || '',
            externalUrl: c.externalUrl || '',
          },
        };
      });
    if (!reads.length) return;
    let viewChanged = false;
    const viewSig = (room) => JSON.stringify([((room.standings || {})[state.currentChar]) || null, room.charIcons || null]);
    await patchRoom((room) => {
      const before = viewSig(room);
      for (const d of reads) mergeCharacterRead(room, d, true);
      // 말 이미지 주소 — 발화 캐릭터 칩의 작은 얼굴
      const icons = { ...(room.charIcons || {}) };
      for (const c of chars) {
        if (!c || !c.name) continue;
        if (c.iconUrl) icons[c.name] = c.iconUrl;
        else delete icons[c.name];
      }
      if (JSON.stringify(icons) !== JSON.stringify(room.charIcons || {})) room.charIcons = icons;
      viewChanged = before !== viewSig(room);
    });
    if (!state.currentChar) {
      state.currentChar = reads[0].name;
      viewChanged = true;
    }
    if (viewChanged && panel && panel.style.display !== 'none' && state.activeTab === 'standing') renderBody();
  }

  async function runDetect() {
    clearTimeout(detectTimer);
    detectTimer = 0;
    const d = detectDialog();
    if (!d) {
      state.detected = null;
      lastDetectSig = '';
      autoCreated = null;
      return;
    }
    // 이름을 치는 중이면 손을 멈출 때까지 기다린다 (칸을 벗어나면 바로 다시 읽는다)
    if (d.typingName) {
      const wait = 1500 - (Date.now() - lastNameTypeAt);
      if (wait > 0) {
        detectTimer = setTimeout(runDetect, wait);
        return;
      }
    }
    // 읽은 내용이 그대로면 다시 저장하지 않는다 (편집창이 열려 있는 동안 계속 쓰지 않게)
    const sig = JSON.stringify(d);
    if (sig === lastDetectSig) return;
    lastDetectSig = sig;
    const changed =
      !state.detected ||
      state.detected.name !== d.name ||
      JSON.stringify(state.detected.standings) !== JSON.stringify(d.standings);
    state.detected = d;

    if (d.standings.length || sheetHasContent(d.sheet) || d.isChar) {
      const prevAuto = autoCreated;
      let createdNow = null;
      await patchRoom((room) => {
        room.standings = room.standings || {};
        room.standingOrder = room.standingOrder || {};
        // 같은 편집창에서 이름만 바뀌었으면, 방금 이 창 때문에 빈 채로 만든 옛 이름은 지운다
        if (prevAuto && prevAuto.box === d.box && prevAuto.name !== d.name) {
          const old = room.standings[prevAuto.name];
          if (old && !old.length) {
            delete room.standings[prevAuto.name];
            delete room.standingOrder[prevAuto.name];
            if (prevAuto.sheet && room.sheets) delete room.sheets[prevAuto.name];
          }
        }
        const hadSheet = !!(room.sheets && room.sheets[d.name]);
        if (mergeCharacterRead(room, d, false)) createdNow = { box: d.box, name: d.name, sheet: !hadSheet && sheetHasContent(d.sheet) };
      });
      // 이 창에서 빈 캐릭터를 새로 만들었으면 기억 (이름을 더 고치면 옛 이름을 지우려고)
      if (createdNow) autoCreated = createdNow;
      else if (prevAuto && prevAuto.box === d.box && prevAuto.name !== d.name) autoCreated = null;
      if (!state.currentChar) state.currentChar = d.name;
    }
    if (changed && state.activeTab === 'standing') renderBody();
  }

  const domObserver = new MutationObserver(scheduleDetect);
  domObserver.observe(document.body, { childList: true, subtree: true });
  // 편집창 안의 요소면 그 창을, 아니면 null
  const inEditor = (t) => (t && t.closest && !t.closest('.cst-root') && t.closest(EDITOR_SEL)) || null;
  document.addEventListener('input', (e) => {
    const box = inEditor(e.target);
    if (!box) return;
    if (findNameInput(box) === e.target) lastNameTypeAt = Date.now();
    scheduleDetect();
  });
  // 편집창 칸을 벗어나면 바로 읽는다 (이름을 다 치고 창을 닫는 순간을 놓치지 않게)
  document.addEventListener('focusout', (e) => {
    if (!inEditor(e.target)) return;
    lastNameTypeAt = 0;
    runDetect();
  });

  // ---------------- 디자인 (기본 / 디자인 2 = 왼쪽 세로 레일) ----------------
  // 확장 팝업 설정에서 고른 값을 그대로 따라간다.
  let uiDesign = 'basic';

  function applyDesign() {
    if (panel) panel.classList.toggle('cst-rail', uiDesign === 'rail');
  }

  getSync({ uiDesign: 'basic' }).then((d) => {
    uiDesign = d.uiDesign === 'rail' ? 'rail' : 'basic';
    applyDesign();
  });

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'sync' || !changes.uiDesign) return;
      uiDesign = changes.uiDesign.newValue === 'rail' ? 'rail' : 'basic';
      applyDesign();
    });
  } catch (_) {}

  // ---------------- 패널 UI ----------------
  let panel = null;
  let fab = null;
  let body = null;
  let tabsEl = null; // 탭 줄 — 에디션 보기를 바꾸면 다시 그린다
  let sizeSaveTimer = 0;

  // 코코포리아 채팅 헤더의 톱니(설정) 버튼을 찾아 그 왼쪽에 토글 버튼을 넣는다.
  // MUI SettingsIcon의 path("M19.14…")로 톱니 아이콘을 정확히 식별하고,
  // 여러 개(하단 HO 탭 등)면 화면에서 가장 위에 있는 것(채팅 헤더)을 고른다.
  function findCcfoliaSettingsButton() {
    let best = null;
    let bestTop = Infinity;
    for (const path of document.querySelectorAll('button svg path, [role="button"] svg path')) {
      const d = path.getAttribute('d') || '';
      if (!/^M19[.,]14/.test(d)) continue;
      const btn = path.closest('button, [role="button"]');
      if (!btn) continue;
      const r = btn.getBoundingClientRect();
      if (!r.width || !r.height) continue;
      if (r.top < bestTop) {
        bestTop = r.top;
        best = btn;
      }
    }
    if (best) return best;
    // 백업: aria-label/title 텍스트
    const LABELS = /設定|설정|settings/i;
    for (const b of document.querySelectorAll('button[aria-label], [role="button"][aria-label]')) {
      if (LABELS.test(b.getAttribute('aria-label') || '')) return b;
    }
    for (const b of document.querySelectorAll('button[title]')) {
      if (LABELS.test(b.getAttribute('title') || '')) return b;
    }
    return null;
  }

  let fabPlaced = false;

  function placeFab() {
    if (!fab) return;
    const target = findCcfoliaSettingsButton();
    if (target && target.parentElement) {
      fab.classList.add('cst-fab-inline');
      fab.classList.remove('cst-fab-float');
      target.parentElement.insertBefore(fab, target);
      fabPlaced = true;
      fab.classList.remove('cst-fab-hidden');
    } else {
      fab.classList.add('cst-fab-float');
      fab.classList.remove('cst-fab-inline');
      document.body.appendChild(fab);
      // 코코포리아 UI가 아직 안 그려졌을 수 있다 — 잠깐 숨겨 두고 기다린다.
      // (예전에는 좌하단에 잠깐 떴다가 제자리로 튀어 거슬렸다)
      if (!fabPlaced) fab.classList.add('cst-fab-hidden');
    }
  }

  // 방 화면이 준비될 때까지 짧게 재시도하다가, 끝내 못 찾으면 폴백 위치로 보여준다
  function settleFab() {
    const t0 = Date.now();
    const tick = () => {
      if (!fab || fabPlaced) return;
      placeFab();
      if (fabPlaced) return;
      if (Date.now() - t0 > 4000) {
        fab.classList.remove('cst-fab-hidden'); // 폴백 위치로 확정
        return;
      }
      setTimeout(tick, 200);
    };
    tick();
  }

  // 코코포리아가 툴바를 다시 그려 버튼이 사라지면 재삽입
  let fabGuardTimer = 0;
  function startFabGuard() {
    clearInterval(fabGuardTimer);
    // 폴백(플로팅) 상태의 설정 버튼 재탐색은 문서 전체 svg 스캔이라 비싸다 —
    // 백오프(2s→4s→…→30s)로 점점 뜸하게 재시도하고, 숨김 탭에서는 쉰다.
    let floatRetryGap = 1; // fabGuard 틱(2초) 단위
    let floatWait = 0;
    fabGuardTimer = setInterval(() => {
      if (document.hidden) return;
      if (fab && !document.contains(fab)) {
        placeFab();
        floatRetryGap = 1;
      } else if (fab && fab.classList.contains('cst-fab-float')) {
        if (++floatWait < floatRetryGap) return;
        floatWait = 0;
        floatRetryGap = Math.min(floatRetryGap * 2, 15);
        const t = findCcfoliaSettingsButton();
        if (t) {
          placeFab();
          floatRetryGap = 1;
        }
      } else {
        floatRetryGap = 1;
      }
    }, 2000);
  }

  // 코코포리아 창(MUI Dialog)이 열려 있으면 그 창이 포커스를 붙잡아(focus trap), 바깥에 있는 우리 입력칸에
  // 글자를 치면 곧바로 포커스를 빼앗아 간다 (편집창을 연 채로 가져오기 이름을 못 고치던 원인).
  // MUI 는 document 에 올라온 focusin 을 보고 되돌리므로, 우리 UI 안의 focusin 은 document 까지 안 올라가게 막는다.
  function shieldFocus(root) {
    root.addEventListener('focusin', (e) => e.stopPropagation());
  }

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }


  function titleWithIcon(text) {
    const wrap = el('span', 'cst-title');
    const icon = document.createElement('img');
    icon.src = extUrl('icons/icon16.png');
    icon.className = 'cst-title-icon';
    icon.alt = '';
    wrap.append(icon, document.createTextNode(text));
    return wrap;
  }

  // 탭 줄 그리기 — 배포본(LITE)에는 [캡처] 탭이 없다
  function drawTabs() {
    if (!tabsEl) return;
    const TABS = [
      ['standing', '캐릭터'],
      ['color', '색상'],
      ['memo', '메모'],
      ['chars', '문자'],
      ['size', '사이즈'],
      ['capture', '캡처'],
      ['log', '로그'],
    ].filter(([key]) => !(LITE && key === 'capture'));
    if (!TABS.some(([key]) => key === state.activeTab)) state.activeTab = TABS[0][0];
    tabsEl.innerHTML = '';
    for (const [key, label] of TABS) {
      const b = el('button', 'cst-tab' + (key === state.activeTab ? ' on' : ''), label);
      b.dataset.tab = key;
      b.addEventListener('click', () => {
        state.activeTab = key;
        for (const t of tabsEl.children) t.classList.toggle('on', t.dataset.tab === key);
        renderBody();
      });
      tabsEl.appendChild(b);
    }
  }

  // 개인용에서 팝업 [에디션 보기]를 바꾸면 방 안 패널도 새로고침 없이 그 에디션 화면으로 바꾼다
  function applyEditionPreview(pv) {
    if (window.CST_LITE) return; // 진짜 배포본은 늘 배포본
    const next = pv === 'dist' || pv === 'distdev';
    if (next === LITE) return;
    LITE = next;
    if (!panel) return;
    drawTabs();
    renderBody();
    // 배포본에서 빠지는 검사 항목이 달라지므로 진단 결과도 다시
    try {
      lastHealth = runHealthCheck();
      showHealthBanner(lastHealth);
    } catch (_) {}
  }

  function buildUI() {
    if (panel) return;

    fab = el('button', 'cst-root');
    fab.id = 'cst-fab';
    const fabIcon = document.createElement('img');
    fabIcon.src = extUrl('icons/icon32.png');
    fabIcon.alt = '코코포리아 선생님';
    fab.appendChild(fabIcon);
    fab.title = '코코포리아 선생님 패널 열기/닫기';
    fab.classList.add('cst-fab-hidden');
    placeFab();
    settleFab();

    panel = el('div', 'cst-root');
    panel.id = 'cst-panel';
    shieldFocus(panel);
    panel.style.display = 'none';

    const head = el('div', 'cst-head');
    const title = titleWithIcon('코코포리아 선생님');
    const minBtn = el('button', 'cst-iconbtn', '－');
    minBtn.title = '최소화';
    const closeBtn = el('button', 'cst-iconbtn', '✕');
    closeBtn.title = '닫기';
    head.append(title, minBtn, closeBtn);

    const tabs = el('div', 'cst-tabs');
    tabsEl = tabs;
    drawTabs();

    body = el('div', 'cst-body');

    // 기본은 탭이 위, '디자인 2'에서는 왼쪽 세로 레일이 되는 껍데기
    const shell = el('div', 'cst-shell');
    shell.append(tabs, body);
    panel.append(head, shell);

    // 이미지 파일을 패널에 끌어다 놓으면 스탠딩 가져오기 (어느 탭에서든 — 캐릭터 탭으로 옮겨 연다)
    let dropDepth = 0;
    const hasFiles = (e) => [...((e.dataTransfer && e.dataTransfer.types) || [])].includes('Files');
    const dropOff = () => {
      dropDepth = 0;
      panel.classList.remove('cst-drop-on');
    };
    panel.addEventListener('dragenter', (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      dropDepth++;
      panel.dataset.drop = state.currentChar ? `놓으면 "${state.currentChar}" 스탠딩으로 가져오기` : '놓으면 스탠딩으로 가져오기';
      panel.classList.add('cst-drop-on');
    });
    panel.addEventListener('dragover', (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      e.stopPropagation();
      e.dataTransfer.dropEffect = 'copy';
    });
    panel.addEventListener('dragleave', (e) => {
      if (!hasFiles(e)) return;
      dropDepth = Math.max(0, dropDepth - 1);
      if (!dropDepth) dropOff();
    });
    panel.addEventListener('drop', (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      e.stopPropagation(); // 코코포리아 판에 이미지가 올라가지 않게
      dropOff();
      const all = [...e.dataTransfer.files];
      if (state.activeTab !== 'standing') {
        state.activeTab = 'standing';
        drawTabs();
        renderBody();
      }
      importFiles(all);
    });
    document.body.appendChild(panel);
    applyDesign();

    // 위치·크기 복원
    getLocal({ panelPos: null, panelSize: null }).then(({ panelPos, panelSize }) => {
      if (panelPos && panelPos.left != null) {
        panel.style.left = panelPos.left + 'px';
        panel.style.top = panelPos.top + 'px';
        clampIntoView();
      } else {
        panel.style.right = '14px';
        panel.style.bottom = '124px';
      }
      if (panelSize && panelSize.w) {
        panel.style.width = panelSize.w + 'px';
        panel.style.height = panelSize.h + 'px';
      }
    });

    // 크기 조절(우하단 그립): 크기 저장 + 썸네일 확대 상태 재계산 (칸이 커져도 잘라둔 위치 유지)
    const ro = new ResizeObserver(() => {
      if (panel.style.display === 'none') return;
      refreshThumbStyles();
      clearTimeout(sizeSaveTimer);
      sizeSaveTimer = setTimeout(() => {
        const r = panel.getBoundingClientRect();
        if (r.width > 100 && r.height > 100) setLocal({ panelSize: { w: Math.round(r.width), h: Math.round(r.height) } });
      }, 400);
    });
    ro.observe(panel);

    let drag = null;
    head.addEventListener('pointerdown', (e) => {
      if (e.target.closest('.cst-iconbtn')) return;
      const r = panel.getBoundingClientRect();
      drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
      head.setPointerCapture(e.pointerId);
    });
    head.addEventListener('pointermove', (e) => {
      if (!drag) return;
      panel.style.right = 'auto';
      panel.style.bottom = 'auto';
      panel.style.left = Math.max(0, e.clientX - drag.dx) + 'px';
      panel.style.top = Math.max(0, e.clientY - drag.dy) + 'px';
    });
    head.addEventListener('pointerup', () => {
      if (!drag) return;
      drag = null;
      clampIntoView();
      const r = panel.getBoundingClientRect();
      setLocal({ panelPos: { left: r.left, top: r.top } });
    });

    minBtn.addEventListener('click', () => {
      panel.classList.toggle('cst-min');
      // 접었다 펴도 크기 저장이 꼬이지 않게 현재 가로폭을 유지한다
      if (panel.classList.contains('cst-min')) {
        const r = panel.getBoundingClientRect();
        panel.dataset.openH = String(Math.round(r.height));
      }
    });
    closeBtn.addEventListener('click', () => (panel.style.display = 'none'));
    fab.addEventListener('click', () => {
      const show = panel.style.display === 'none';
      panel.style.display = show ? 'flex' : 'none';
      if (show) {
        clampIntoView();
        renderBody();
      }
    });

    startFabGuard();
    applyTheme();
  }

  function clampIntoView() {
    if (!panel) return;
    const r = panel.getBoundingClientRect();
    let left = r.left;
    let top = r.top;
    if (left + 60 > innerWidth) left = innerWidth - 80;
    if (top + 40 > innerHeight) top = innerHeight - 60;
    if (left < 0) left = 8;
    if (top < 0) top = 8;
    if (panel.style.left !== 'auto' && panel.style.left !== '') {
      panel.style.left = left + 'px';
      panel.style.top = top + 'px';
    }
  }

  function applyTheme() {
    for (const root of [panel, fab, toastEl, healthBanner]) {
      if (!root) continue;
      root.classList.toggle('cst-help-off', state.helpOn === false); // '설명 표시' 꺼짐 → 설명문 숨김
      for (const t of THEMES) root.classList.remove('cst-theme-' + t);
      if (state.theme !== 'dark') root.classList.add('cst-theme-' + state.theme);
      const accent = normalizeHex(state.accent);
      if (accent) {
        root.style.setProperty('--cst-accent', accent);
        root.style.setProperty('--cst-accent-dark', darken(accent));
        root.style.setProperty('--cst-accent-soft', hexToSoft(accent));
      } else {
        root.style.removeProperty('--cst-accent');
        root.style.removeProperty('--cst-accent-dark');
        root.style.removeProperty('--cst-accent-soft');
      }
    }
  }

  // ---------------- 탭 렌더링 ----------------
  let lastRenderedTab = '';
  // 패널 본문 안에서 그 요소가 위에 오게 스크롤 (페이지는 건드리지 않는다) + 잠깐 표시
  function scrollBodyTo(target) {
    if (!body || !target || !body.contains(target)) return;
    const top = target.getBoundingClientRect().top - body.getBoundingClientRect().top + body.scrollTop - 6;
    body.scrollTo({ top: Math.max(0, top), behavior: 'smooth' });
    target.classList.remove('cst-flash');
    void target.offsetWidth;
    target.classList.add('cst-flash');
    setTimeout(() => target.classList.remove('cst-flash'), 1000);
  }

  function renderBody() {
    if (!body || panel.style.display === 'none') return;
    // 같은 탭을 다시 그릴 때는 보던 스크롤 위치를 지킨다
    // ([마우스로 조정] 같은 버튼 하나 눌렀다고 맨 위로 튀지 않게)
    const keep = lastRenderedTab === state.activeTab ? body.scrollTop : 0;
    lastRenderedTab = state.activeTab;
    body.innerHTML = '';
    let done;
    if (state.activeTab === 'standing') done = renderStanding();
    else if (state.activeTab === 'color') done = renderColor();
    else if (state.activeTab === 'memo') done = renderMemo();
    else if (state.activeTab === 'chars') done = renderChars();
    else if (state.activeTab === 'size') done = renderSize();
    else if (state.activeTab === 'capture') done = renderCapture();
    else done = renderLog();
    if (!keep) return;
    Promise.resolve(done)
      .catch(() => {})
      .then(() => {
        body.scrollTop = keep;
        requestAnimationFrame(() => {
          body.scrollTop = keep;
        });
      });
  }

  // ----- 로그 (수집 · 스튜디오) -----
  // 배포본에는 수집이 없고 로그 스튜디오로 가는 길만 남는다.
  let logBusy = false;
  let lastMessages = null;

  let abStatHandler = null;

  async function renderLog() {
    body.innerHTML = '';
    // 배포본에는 수집 모듈(CSTLog)이 아예 없다 — 스튜디오 쪽만 그린다
    if (!LITE && !window.CSTLog) {
      body.appendChild(el('div', 'cst-hint', '로그 모듈을 불러오지 못했습니다. 페이지를 새로고침해 주세요.'));
      return;
    }
    // 로그 설정은 local이 정본 (sync는 다른 기기용 미러)
    const lc = await getLocal({ logSettings: null });
    const logSettings = lc.logSettings || (await getSync({ logSettings: null })).logSettings;
    const s = window.CSTLogBuild
      ? window.CSTLogBuild.normalizeSettings(logSettings)
      : { ...((window.CSTLog && window.CSTLog.DEFAULT_SETTINGS) || {}), ...(logSettings || {}) };

    if (LITE) {
      body.appendChild(
        el(
          'div',
          'cst-hint cst-hint-help',
          '코코포리아의 로그 내보내기로 받은 파일(HTML·JSON·ZIP)을\n로그 스튜디오에서 꾸며 저장합니다.'
        )
      );
    }

    // 로그 스튜디오 (미리보기 + 상세 설정)
    const studioRow = el('div', 'cst-row');
    const studioBtn = el('button', 'cst-btn ghost', '로그 스튜디오 열기 (미리보기·상세 설정)');
    studioBtn.style.flex = '1';
    studioBtn.addEventListener('click', () => {
      sendMsg({ type: 'OPEN_STUDIO' });
    });
    studioRow.appendChild(studioBtn);
    body.appendChild(studioRow);



    // ---- 설정 요약 (스타일 설정은 로그 스튜디오가 원본 — 여기서는 읽기 전용) ----
    const FONT_LABEL = {
      noto: 'Noto Sans KR', myeongjo: '나눔명조', gothic: '나눔고딕',
      pretendard: 'Pretendard', kopub: 'KoPub돋움',
    };
    const THEME_LABEL = { dark: '다크', gray: '그레이', white: '화이트', custom: '직접 지정' };
    const SHAPE_LABEL = { square: '네모', rounded: '둥근 네모', circle: '원형' };
    const MODE_LABEL = { merged: '합본', perTab: '탭별', both: '합본+탭별' };

    const sumWrap = el('div', 'cst-sliders');
    sumWrap.appendChild(el('div', 'cst-slider-row', '현재 저장 설정 (로그 스튜디오에서 변경)'));
    const rf = s.rowFilters || {};
    const RF_LABEL = { hide: '비표시', del: '삭제' };
    const filters = [];
    if (RF_LABEL[rf.empty]) filters.push('빈 대사 ' + RF_LABEL[rf.empty]);
    if (RF_LABEL[rf.dice]) filters.push('주사위 ' + RF_LABEL[rf.dice]);
    if (RF_LABEL[rf.cmd]) filters.push('명령어 ' + RF_LABEL[rf.cmd]);
    if (RF_LABEL[rf.edited]) filters.push('[편집 완료] ' + RF_LABEL[rf.edited]);
    if (s.groupSame) filters.push('연속 대사 묶기');
    const tabStyleCount = Object.values(s.tabStyles || {}).filter((t) => t.mode && t.mode !== 'normal').length;
    const lines = [
      `${FONT_LABEL[s.font] || s.font} ${s.fontSize}px · 행간 ${s.lineHeight} · 이미지 ${s.imgSize}px ${SHAPE_LABEL[s.imgShape] || ''}`,
      `테마 ${THEME_LABEL[s.theme] || s.theme}${s.theme === 'custom' ? ' (' + (s.customBg || '') + ')' : ''} · 저장 ${MODE_LABEL[s.saveMode] || s.saveMode}${s.split > 0 ? ' · ' + s.split + '개씩 분할' : ''}`,
      `필터: ${filters.length ? filters.join(', ') : '없음'}`,
      `탭 스타일 지정 ${tabStyleCount}개` + (LITE ? '' : ` · 변환기용 파일 ${s.ccfoliaCompat ? 'O' : 'X'}`),
    ];
    const sumBox = el('div', 'cst-log-summary');
    for (const line of lines) sumBox.appendChild(el('div', 'cst-log-summary-line', line));
    sumWrap.appendChild(sumBox);
    body.appendChild(sumWrap);

    body.appendChild(healthSection());

  }


  // 탭 안이 여러 덩어리로 나뉘는 곳에서 쓰는 구역 머리.
  // 붙어 있으면 뭐가 뭔지 알기 어려워서 번호·제목·설명을 붙여 갈라 놓는다.
  function secBlock(no, title, desc) {
    const wrap = el('div', 'cst-sec');
    const head = el('div', 'cst-sec-head');
    head.append(el('span', 'cst-sec-no', no), el('span', 'cst-sec-title', title));
    wrap.appendChild(head);
    if (desc) wrap.appendChild(el('div', 'cst-sec-desc cst-hint-help', desc)); // 섹션 설명도 '설명 표시'를 따른다
    return wrap;
  }

  // 패널 화면 상태 (캐릭터 탭 접은 구역) — chrome.storage.local panelUi
  function savePanelUi() {
    setLocal({ panelUi: state.panelUi }).catch(() => {});
  }
  // 머리줄을 눌러 접고 펴는 구역. 접은 상태는 key 로 기억한다
  function foldBlock(key, no, title, desc) {
    const wrap = secBlock(no, title, desc);
    wrap.classList.add('cst-sec-fold');
    wrap.dataset.fold = key;
    const head = wrap.querySelector('.cst-sec-head');
    const caret = el('span', 'cst-sec-caret', '');
    head.appendChild(caret);
    const paint = () => {
      const folded = !!(state.panelUi.fold || {})[key];
      wrap.classList.toggle('folded', folded);
      caret.textContent = folded ? '▸' : '▾';
      head.title = folded ? '펼치기' : '접기';
    };
    head.addEventListener('click', (e) => {
      if (e.target.closest('button, input, select, label')) return;
      setFold(key, !(state.panelUi.fold || {})[key]);
      paint();
      if (key === 'standing' && !(state.panelUi.fold || {})[key]) requestAnimationFrame(refreshThumbStyles);
    });
    wrap._paintFold = paint;
    paint();
    return wrap;
  }
  function setFold(key, folded) {
    state.panelUi.fold = { ...(state.panelUi.fold || {}), [key]: folded };
    savePanelUi();
  }
  // 접혀 있으면 펴기 (바로 가기 버튼 등)
  function openFold(sec) {
    if (!sec || !sec.dataset || !sec.dataset.fold) return;
    if ((state.panelUi.fold || {})[sec.dataset.fold]) {
      setFold(sec.dataset.fold, false);
      if (sec._paintFold) sec._paintFold();
    }
  }

  // ----- 캐릭터 (NPC 픽커 · 스탠딩 · 시트 백업) -----
  // 확대/이동: 원본 비율 기준으로 이미지를 통째로 배치 → 그림의 모든 부분을 훑을 수 있음
  //  base = cover 배율 (zoom 100% = 꽉 채움)
  //  disp = 원본비율 × base × zoom
  //  left/top = (박스 - disp) × pos%  → pos 0%=이미지 왼쪽/위 끝, 100%=오른쪽/아래 끝
  // 확대 보정 필터 — 가장자리를 살리는 샤프닝(합이 1인 3×3 커널). 많이 늘어난 것은 조금 더 세게.
  // 없는 해상도를 만들어 내지는 못하지만, 늘어나며 뭉개진 윤곽은 또렷해진다.
  function ensureSharpenFilter() {
    if (document.getElementById('cst-sharpen-defs')) return;
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    svg.id = 'cst-sharpen-defs';
    svg.setAttribute('width', '0');
    svg.setAttribute('height', '0');
    svg.setAttribute('aria-hidden', 'true');
    svg.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden;pointer-events:none';
    const mk = (id, k) => {
      const f = document.createElementNS(ns, 'filter');
      f.id = id;
      f.setAttribute('color-interpolation-filters', 'sRGB');
      const m = document.createElementNS(ns, 'feConvolveMatrix');
      m.setAttribute('order', '3');
      m.setAttribute('preserveAlpha', 'true');
      m.setAttribute('kernelMatrix', `0 ${-k} 0 ${-k} ${1 + 4 * k} ${-k} 0 ${-k} 0`);
      f.appendChild(m);
      svg.appendChild(f);
    };
    mk('cst-sharpen', 0.35);
    mk('cst-sharpen-strong', 0.6);
    document.body.appendChild(svg);
  }

  function applyThumbStyle(img) {
    const box = img.parentElement;
    if (!box) return;
    const doLayout = () => {
      const bw = box.clientWidth;
      const bh = box.clientHeight;
      const nw = img.naturalWidth;
      const nh = img.naturalHeight;
      if (!bw || !bh || !nw || !nh) return;
      const t = thumbForOutfit(img.dataset.outfit);
      const zoom = Math.max(100, Number(t.zoom) || 100) / 100;
      const posX = Math.min(100, Math.max(0, Number(t.posX) || 0)) / 100;
      const posY = Math.min(100, Math.max(0, Number(t.posY) || 0)) / 100;
      const base = Math.max(bw / nw, bh / nh);
      const dw = nw * base * zoom;
      const dh = nh * base * zoom;
      img.style.width = dw + 'px';
      img.style.height = dh + 'px';
      img.style.left = (bw - dw) * posX + 'px';
      img.style.top = (bh - dh) * posY + 'px';
      // 원본보다 크게(화면 픽셀 기준 1.15배 넘게) 그려지면 흐려 보이니 선명하게 보정한다
      const scaleUp = (dw * (window.devicePixelRatio || 1)) / nw;
      const sharp = state.sharpen && scaleUp > 1.15;
      if (sharp) ensureSharpenFilter();
      img.classList.toggle('cst-sharp', sharp);
      img.classList.toggle('cst-sharp-strong', sharp && scaleUp > 2.2);
    };
    if (img.complete && img.naturalWidth) {
      // 박스가 아직 레이아웃 전이면 다음 프레임에
      if (!box.clientWidth) requestAnimationFrame(doLayout);
      else doLayout();
    } else {
      img.addEventListener('load', doLayout, { once: true });
    }
  }

  // 스탠딩 썸네일 <img> 재사용 — 카드를 다시 그려도 같은 이미지를 새로 불러오거나 디코딩하지 않게.
  // 화면에 보이는 것만 불러온다(loading=lazy). 한 이미지가 두 카드에 동시에 쓰이면 두 번째는 새로 만든다.
  const thumbImgCache = new Map(); // src → img
  function thumbImg(src) {
    let img = thumbImgCache.get(src);
    if (!img || img.isConnected) {
      img = document.createElement('img');
      img.loading = 'lazy';
      img.decoding = 'async';
      img.src = src;
      if (!thumbImgCache.has(src)) thumbImgCache.set(src, img);
    }
    if (thumbImgCache.size > 400) {
      for (const [k, v] of thumbImgCache) {
        if (thumbImgCache.size <= 300) break;
        if (!v.isConnected) thumbImgCache.delete(k);
      }
    }
    return img;
  }

  function refreshThumbStyles() {
    if (!body) return;
    for (const img of body.querySelectorAll('.cst-thumb img')) applyThumbStyle(img);
  }

  // names 를 order 순서대로 (order 에 없는 이름은 원래 순서로 뒤에)
  function orderByList(names, order) {
    const rank = new Map(order.map((n, k) => [n, k]));
    return names
      .map((n, k) => ({ n, k }))
      .sort((a, b) => (rank.has(a.n) ? rank.get(a.n) : 1e6 + a.k) - (rank.has(b.n) ? rank.get(b.n) : 1e6 + b.k))
      .map((x) => x.n);
  }

  // ----- 스탠딩 열 수 -----
  // 고정: 고른 열 수(1~6). 고정 끔: 칸 하나가 약 96px 이 되게 패널 너비로 계산 (1~8열)
  let colsDescUpdater = () => {};
  function effectiveCols() {
    if (state.colsFixed) return state.cols;
    const grid = body && body.querySelector('.cst-standing-grid');
    const w = (grid && grid.clientWidth) || (body ? body.clientWidth - 28 : 0);
    if (!w) return state.cols;
    return Math.max(1, Math.min(8, Math.floor((w + 8) / (96 + 8))));
  }
  function applyStandingCols() {
    if (!body) return;
    const n = effectiveCols();
    let changed = false;
    for (const g of body.querySelectorAll('.cst-standing-grid')) {
      if (g.style.getPropertyValue('--cst-cols') !== String(n)) {
        g.style.setProperty('--cst-cols', n);
        changed = true;
      }
    }
    colsDescUpdater();
    if (changed) requestAnimationFrame(refreshThumbStyles); // 칸 크기가 바뀌므로 재계산
  }
  // 패널 크기가 바뀌면 (열 수 고정을 껐을 때만) 다시 맞춘다
  let colsObserver = null;
  function watchPanelWidth() {
    if (colsObserver || !body || typeof ResizeObserver === 'undefined') return;
    let raf = 0;
    colsObserver = new ResizeObserver(() => {
      if (state.colsFixed || state.activeTab !== 'standing') return;
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(applyStandingCols);
    });
    colsObserver.observe(body);
  }

  // 이 방에서 아는 캐릭터 — 스탠딩을 저장한 캐릭터 + 캐릭터 메뉴에서 읽은 내 캐릭터.
  // 스탠딩이 하나도 없는 새 캐릭터도 발화 캐릭터 고르기 · 가져오기에 떠야 한다.
  function knownChars(room) {
    const out = Object.keys(room.standings || {});
    for (const n of Array.isArray(room.myChars) ? room.myChars : []) if (n && !out.includes(n)) out.push(n);
    return out;
  }

  // 발화 캐릭터 칩의 작은 얼굴 — 코코포리아 말 이미지(없으면 기본 스탠딩 · 첫 스탠딩).
  // 스탠딩 카드와 같은 확대 · 위치로 잘라 보여 준다 (카드 칸도 정사각형이라 카드 모습이 작게 보인다)
  function charFace(room, name) {
    const box = el('span', 'cst-npc-face');
    const blank = () => {
      box.innerHTML = window.faIcon ? window.faIcon('avatar') : '';
      box.classList.add('empty');
    };
    const list = ((room.standings || {})[name]) || [];
    const main = list.find((s) => s.main);
    const url = ((room.charIcons || {})[name]) || (main && main.img) || (list[0] && list[0].img) || '';
    if (!url) {
      blank();
      return box;
    }
    const { outfits, ...flat } = ((room.standingThumbs || {})[name]) || {};
    let t = { ...THUMB_DEFAULT, ...flat };
    // 옷장별 확대 · 위치를 켰고 옷장이 둘 이상이면, 그 이미지가 든 옷장의 값
    if (state.thumbPerOutfit && outfits && list.length) {
      const map = wardrobeOf(room, name, list.map((x) => x.label));
      const s = list.find((x) => x.img === url);
      const o = s ? map.get(s.label) || '' : '';
      if (new Set(map.values()).size >= 2 && outfits[o]) t = { ...THUMB_DEFAULT, ...outfits[o] };
    }
    const zoom = Math.max(100, Number(t.zoom) || 100) / 100;
    const px = Math.min(100, Math.max(0, Number(t.posX) || 0));
    const py = Math.min(100, Math.max(0, Number(t.posY) || 0));
    const img = document.createElement('img');
    img.alt = '';
    img.decoding = 'async';
    img.draggable = false;
    img.style.objectPosition = `${px}% ${py}%`;
    if (zoom > 1) {
      img.style.transform = `scale(${zoom})`;
      img.style.transformOrigin = `${px}% ${py}%`;
    }
    img.addEventListener('error', blank, { once: true });
    img.src = url;
    box.appendChild(img);
    return box;
  }

  // 내 캐릭터 목록을 코코포리아 상태에서 조용히 읽어 저장 (바뀌었으면 다시 그림). 1.5초에 한 번까지만
  let myCharsReadAt = 0;
  async function refreshMyCharsQuiet(room) {
    if (Date.now() - myCharsReadAt < 1500) return;
    myCharsReadAt = Date.now();
    const res = await msg('CCF_CHAT_CHARACTER', { op: { kind: 'list' } });
    if (!res || !res.ok || !Array.isArray(res.names)) {
      if (state.myCharsDirect !== false) {
        state.myCharsDirect = false;
        if (state.activeTab === 'standing') renderBody();
      }
      return;
    }
    state.myCharsDirect = true;
    const same = JSON.stringify(room.myChars || []) === JSON.stringify(res.names) && room.myCharsFrom === 'store';
    if (same) return;
    await patchRoom((r) => {
      r.myChars = res.names;
      r.myCharsFrom = 'store';
    });
    if (state.activeTab === 'standing') renderBody();
  }

  // 코코포리아에서 발화 캐릭터를 바꿔도 스탠딩 보기가 따라가게 — 이름칸을 1초마다 본다
  let lastSpeaker = '';
  async function followTick(force) {
    if (!extAlive() || !panel) return;
    const name = currentChatName();
    if (!name || (!force && name === lastSpeaker)) return;
    const changed = name !== lastSpeaker;
    lastSpeaker = name;
    if (!state.followSpeaker) {
      if (changed && state.activeTab === 'standing' && panel.style.display !== 'none') renderBody(); // 칩 표시만 갱신
      return;
    }
    const room = await getRoom();
    const moveTo = knownChars(room).includes(name) && state.currentChar !== name;
    if (moveTo) state.currentChar = name;
    if ((moveTo || changed) && state.activeTab === 'standing' && panel.style.display !== 'none') renderBody();
  }
  setInterval(() => {
    if (document.hidden) return;
    followTick(false);
  }, 1000);

  // 이 캐릭터의 확대 · 위치를 state.thumb 로 읽는다.
  // 예전(v14.9 까지)에는 모든 캐릭터가 한 값(standingThumb)을 같이 썼다 — 방마다 처음 한 번,
  // 그때 있던 캐릭터들에 그 값을 나눠 준다(보던 모습 그대로). 그 뒤에 새로 생긴 캐릭터는 기본값.
  // 확대 · 위치는 캐릭터마다, 그리고 [옷장별로 따로 지정]을 켜면(기본) 옷장마다 따로.
  //   room.standingThumbs[캐릭터] = { zoom, posX, posY(캐릭터 공통), outfits: { 옷장: { zoom, posX, posY } } }
  //   옷장에 따로 정한 값이 없으면 캐릭터 공통 값을 쓴다. 끄면 그 뒤부터는 옷장과 상관없이 공통 값 하나로 같이 움직인다
  //   (끌 때 지금 조절하던 옷장 값을 공통 값으로 가져가 보던 모습을 지킨다. 옷장별 값은 지우지 않아 다시 켜면 돌아온다).
  const pickThumb = (t) => ({ zoom: Number(t.zoom) || 100, posX: Number(t.posX) || 0, posY: Number(t.posY) || 0 });
  const perOutfitOn = () => state.thumbPerOutfit && state.thumbSplit;
  function thumbForOutfit(outfit) {
    if (perOutfitOn() && outfit != null && state.thumbSet.outfits[outfit]) return state.thumbSet.outfits[outfit];
    return state.thumbSet.base;
  }
  // 슬라이더 · 마우스로 조절할 대상 (옷장별이면 그 옷장, 아니면 캐릭터 공통)
  let thumbTargetUpdater = () => {};
  function setThumbTarget(outfit) {
    if (!perOutfitOn() || outfit == null) {
      state.thumbTarget = null;
      state.thumb = state.thumbSet.base;
    } else {
      state.thumbTarget = outfit;
      state.thumb = state.thumbSet.outfits[outfit] || { ...state.thumbSet.base };
    }
    thumbTargetUpdater();
  }
  // 값을 바꾸기 직전 — 그 옷장에 따로 정한 값이 없으면 이때 만든다
  function touchThumb() {
    const o = state.thumbTarget;
    if (o != null && perOutfitOn() && !state.thumbSet.outfits[o]) state.thumbSet.outfits[o] = state.thumb;
  }

  async function useThumbOf(room, char) {
    if (room.standingThumbs === undefined) {
      const legacy = state.legacyThumb;
      const changed = legacy && ['zoom', 'posX', 'posY'].some((k) => Number(legacy[k]) !== THUMB_DEFAULT[k]);
      const map = {};
      if (changed) for (const c of knownChars(room)) map[c] = { ...THUMB_DEFAULT, ...legacy };
      room.standingThumbs = map;
      await patchRoom((r) => {
        if (r.standingThumbs === undefined) r.standingThumbs = map;
      });
    }
    // 마우스로 조정하는 중인 같은 캐릭터면 저장 전 값을 지킨다
    if (state.adjustMode && state.thumbChar === char) return;
    if (state.adjustMode && state.thumbChar && state.thumbChar !== char) await saveThumb(state.thumbChar);
    const saved = ((room.standingThumbs || {})[char]) || {};
    const { outfits, ...flat } = saved;
    const outs = {};
    for (const [k, v] of Object.entries(outfits || {})) outs[k] = { ...THUMB_DEFAULT, ...pickThumb(v || {}) };
    state.thumbSet = { base: { ...THUMB_DEFAULT, ...flat }, outfits: outs };
    state.thumbTarget = null;
    state.thumb = state.thumbSet.base;
    state.thumbChar = char;
  }

  function saveThumb(char = state.thumbChar) {
    if (!char) return Promise.resolve();
    const t = pickThumb(state.thumbSet.base);
    const outs = {};
    for (const [k, v] of Object.entries(state.thumbSet.outfits)) outs[k] = pickThumb(v);
    if (Object.keys(outs).length) t.outfits = outs;
    return patchRoom((r) => {
      r.standingThumbs = r.standingThumbs || {};
      r.standingThumbs[char] = t;
    });
  }

  async function renderStanding() {
    const room = await getRoom();
    // 내 캐릭터 목록은 코코포리아 상태에서 조용히 새로 읽는다 (바뀌었으면 다시 그림) — 편집창을 안 연 새 방에서도 발화 캐릭터 칩이 뜨게
    refreshMyCharsQuiet(room);
    const chars = knownChars(room);
    body.innerHTML = '';

    if (!chars.length) {
      body.appendChild(
        el('div', 'cst-hint', '저장된 캐릭터가 없습니다.\n캐릭터 편집창을 열면 캐릭터와 스탠딩이 자동으로 저장됩니다.')
      );
      // JSON 가져오기는 캐릭터를 새로 만드는 것이라 캐릭터가 없어도 둔다
      const jsonImport = el('button', 'cst-btn ghost', '캐릭터 JSON 가져오기');
      jsonImport.style.width = '100%';
      jsonImport.title = '코코포리아 캐릭터 JSON 붙여넣기나 시트 파일로 시트 · 스탠딩을 담습니다';
      jsonImport.addEventListener('click', openCharacterImport);
      body.appendChild(jsonImport);
      return;
    }

    if (!state.currentChar || !chars.includes(state.currentChar)) state.currentChar = chars[0];
    await useThumbOf(room, state.currentChar);

    // NPC 픽커: 칩 클릭 한 번으로 발화 캐릭터 전환 (GM용)
    // 내 권한 캐릭터(myChars)가 파악돼 있으면 그것만 표시 — 백업용으로 편집창만 연 캐릭터는 제외
    const myChars = Array.isArray(room.myChars) ? room.myChars : null;
    const pickWrap = el('div', 'cst-npc-picker');
    // 페이지 쪽을 못 읽을 때만 [내 캐릭터 새로고침](메뉴를 잠깐 열어 읽기)을 보여 준다.
    if (state.myCharsDirect === false) {
      const pickHead = el('div', 'cst-slider-row', '');
      const refreshBtn = el('button', 'cst-btn ghost cst-mini-btn', '내 캐릭터 새로고침');
      refreshBtn.title = '캐릭터 선택 메뉴를 잠깐 열어 내 권한 캐릭터 목록을 갱신합니다';
      refreshBtn.addEventListener('click', async () => {
        refreshBtn.disabled = true;
        refreshBtn.textContent = '확인 중';
        const names = await scanMyChars();
        toast(names.length ? `내 캐릭터 ${names.length}명 확인` : '캐릭터 메뉴를 읽지 못했어요.');
        renderBody();
      });
      pickHead.appendChild(refreshBtn);
      pickWrap.appendChild(pickHead);
    }
    // 메뉴를 잘못 읽어 한 명만 남는 일이 있었다 (GM 방에서 엉뚱한 NPC 하나만 보이던 제보).
    // 메뉴로 읽은 목록인데 저장된 캐릭터가 여럿이고 '내 캐릭터'가 한 명뿐이면 못 믿고 전부 보여준다.
    const tooFew = room.myCharsFrom !== 'store' && !!myChars && myChars.length <= 1 && chars.length > 1;
    // 직접 정한 순서(room.pickerOrder)가 있으면 그 순서로, 없는 이름은 뒤에
    const pickOrder = Array.isArray(room.pickerOrder) ? room.pickerOrder : [];
    const pickNames = orderByList(!tooFew && myChars && myChars.length ? myChars : chars, pickOrder);
    // 발화 캐릭터를 바꾸면 스탠딩 보기도 그 캐릭터로
    const followRow = el('div', 'cst-slider-row cst-follow-row');
    const followSw = mkSwitch(state.followSpeaker, (on) => {
      state.followSpeaker = on;
      setSync({ standingFollowSpeaker: on });
      if (on) followTick(true);
    });
    const followLab = el('label', 'cst-at-lab', '발화 캐릭터를 바꾸면 스탠딩 보기도 같이 바꾸기');
    followLab.htmlFor = followSw.input.id;
    followLab.style.cursor = 'pointer';
    followLab.title = '칩으로 바꾸든 코코포리아에서 바꾸든, 스탠딩이 저장된 캐릭터면 아래 스탠딩 보기가 따라갑니다';
    followRow.append(followSw.wrap, followLab);
    pickWrap.appendChild(followRow);
    const speaking = currentChatName();
    const chipRow = el('div', 'cst-npc-chips');
    const visibleNames = pickNames;
    // 칩에 마우스를 올리면 왼쪽에 끌기 손잡이가 나온다 — 손잡이를 끌어 순서를 바꾼다 (칩을 누르면 전환)
    let dragName = null;
    const clearMarks = () => chipRow.querySelectorAll('.cst-npc-item').forEach((x) => x.classList.remove('drop-before', 'drop-after', 'dragging'));
    for (const c of visibleNames) {
      const item = el('span', 'cst-npc-item');
      item.dataset.name = c;
      const grip = el('span', 'cst-npc-grip', '⋮⋮');
      grip.title = '끌어서 순서 바꾸기';
      grip.draggable = true;
      grip.addEventListener('dragstart', (e) => {
        dragName = c;
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', c);
        try {
          e.dataTransfer.setDragImage(item, 8, 10);
        } catch (_) {}
        item.classList.add('dragging');
      });
      grip.addEventListener('dragend', () => {
        dragName = null;
        clearMarks();
      });
      item.addEventListener('dragover', (e) => {
        if (!dragName || dragName === c) return;
        e.preventDefault();
        const r = item.getBoundingClientRect();
        const after = e.clientX > r.left + r.width / 2;
        item.classList.toggle('drop-after', after);
        item.classList.toggle('drop-before', !after);
      });
      item.addEventListener('dragleave', () => item.classList.remove('drop-before', 'drop-after'));
      item.addEventListener('drop', async (e) => {
        if (!dragName || dragName === c) return;
        e.preventDefault();
        const after = item.classList.contains('drop-after');
        const from = dragName;
        clearMarks();
        // 지금 보이는 전체 순서(접혀 있으면 안 보이는 것 포함)에서 옮긴다
        const list = pickNames.filter((n) => n !== from);
        const at = list.indexOf(c) + (after ? 1 : 0);
        list.splice(at, 0, from);
        await patchRoom((r) => {
          const prev = Array.isArray(r.pickerOrder) ? r.pickerOrder : [];
          // 지금 목록에 없는 이름(예전 캐릭터 등)의 자리도 잃지 않게 뒤에 붙여 둔다
          r.pickerOrder = [...list, ...prev.filter((n) => !list.includes(n))];
        });
        renderBody();
      });
      const chip = el('button', 'cst-npc-chip' + (c === speaking ? ' on' : ''), '');
      chip.append(charFace(room, c), el('span', 'cst-npc-name', c));
      chip.title = c === speaking ? `지금 "${c}"(으)로 발화 중` : `"${c}"(으)로 발화 캐릭터 전환`;
      chip.addEventListener('click', () => switchCharacter(c));
      item.append(grip, chip);
      chipRow.appendChild(item);
    }
    if (!pickNames.length) chipRow.appendChild(el('div', 'cst-hint', '내 권한 캐릭터가 없습니다.'));
    pickWrap.appendChild(chipRow);
    const sec1 = foldBlock('speaker', '1', '발화 캐릭터 고르기', '');
    sec1.appendChild(pickWrap);
    body.appendChild(sec1);

    const row = el('div', 'cst-row');
    const sel = el('select', 'cst-select');
    for (const c of chars) {
      const isMine = !myChars || myChars.some((n) => n === c || n.includes(c) || c.includes(n));
      const o = el('option', '', isMine ? c : c + ' (백업)');
      o.value = c;
      if (c === state.currentChar) o.selected = true;
      sel.appendChild(o);
    }
    sel.addEventListener('change', () => {
      state.currentChar = sel.value;
      renderBody();
    });
    // [⋯] 캐릭터 메뉴: 다른 방에 복사 · zip 받기 · zip 넣기 · 기록 지우기
    const moreBtn = el('button', 'cst-btn ghost cst-char-more', '⋯');
    moreBtn.title = '다른 방에 복사 · zip 으로 받기 · zip 넣기 · 이 캐릭터 기록 지우기';
    moreBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const r = moreBtn.getBoundingClientRect();
      const char = state.currentChar;
      const hasStandings = !!((room.standings || {})[char] || []).length;
      openPanelMenu(r.left, r.bottom + 4, char, [
        { text: '다른 방에 복사', run: () => openCopyCharacter(char) },
        { text: '스탠딩 zip 으로 받기', run: () => exportStandingZip(char), disabled: !hasStandings },
        { text: 'zip 넣기', title: '받아 둔 스탠딩 zip 을 가져오기 창으로 엽니다', run: () => pickStandingZip() },
        { sep: true },
        {
          text: '이 캐릭터 기록 지우기',
          danger: true,
          disabled: !(room.standings && room.standings[char]),
          title: '패널에 저장된 스탠딩 · 옷장 · 숨김 기록을 지웁니다 (코코포리아 캐릭터는 그대로)',
          run: async () => {
            const snap = await snapshotChar(char);
            await patchRoom((r2) => {
              // 숨김 · 옷장도 같이 지운다 (남겨 두면 다시 읽을 때 예전 숨김 · 옷장이 되살아난다)
              for (const k of CHAR_KEYS) if (r2[k]) delete r2[k][char];
            });
            state.currentChar = '';
            renderBody();
            undoToast(`"${char}" 기록을 지웠어요.`, char, snap);
          },
        },
      ]);
    });
    row.append(sel, moreBtn);
    const sec2 = foldBlock('standing', '2', '스탠딩', '카드를 누르면 채팅창에 표정 이름이 들어갑니다 · 드래그로 순서 변경 · 이미지 파일을 끌어다 놓으면 가져오기');
    sec2.appendChild(row);
    body.appendChild(sec2);

    const list = (room.standings || {})[state.currentChar] || [];
    const char = state.currentChar;
    // 검색어는 캐릭터마다 (캐릭터를 바꾸면 비운다)
    if (state.queryChar !== char) {
      state.standingQuery = '';
      state.queryChar = char;
    }
    // 옷장 — 옷이 두 가지 이상이면 옷별로 나눠 보여 준다 (옷 추측은 검색 · 정렬과 상관없이 전체 이름으로)
    const outfitMap = wardrobeOf(room, char, list.map((s) => s.label));
    const outfitOrder = outfitOrderOf(room, char, outfitMap);
    const outfitList = groupByOutfit(list, outfitMap, outfitOrder).map((g) => g.outfit);
    const splitOutfits = outfitList.length >= 2;
    state.thumbSplit = splitOutfits;
    // 조절할 옷장: 탭 보기면 보고 있는 탭, 아니면 전에 고른 옷장 (없으면 첫 옷장)
    const activeOutfit = () => {
      if (!splitOutfits) return null;
      if (state.wardrobeLayout === 'tabs' || !WARDROBE_LAYOUTS.includes(state.wardrobeLayout)) {
        const want = state.wardrobeTab[char];
        return outfitList.includes(want) ? want : outfitList[0];
      }
      return outfitList.includes(state.thumbTarget) ? state.thumbTarget : outfitList[0];
    };
    if (!state.adjustMode) setThumbTarget(activeOutfit());
    // 이름표에서 옷 이름 빼기 — 패널에 보이는 이름만. 채팅에는 코코포리아 표정 이름 그대로(@사복_웃음) 보낸다
    const SNames = window.CSTStandingNames;
    const shownName = (s) =>
      splitOutfits && state.hideOutfit && SNames ? SNames.stripOutfit(s.label, outfitMap.get(s.label)) : s.label;

    // 도구 줄: [+ 여러 장 가져오기] [고치기] ··········· [탭|목차|접기] [정렬 ▾] [↓ 설정]
    const tools = el('div', 'cst-st-tools');
    const importBtn = el('button', 'cst-st-tool primary', '');
    importBtn.innerHTML = (window.faIcon ? window.faIcon('plus') : '') + '<span>여러 장 가져오기</span>';
    importBtn.title = '이미지를 한꺼번에 골라 파일 이름에서 캐릭터 · 옷 · 표정을 나눠 넣습니다';
    importBtn.addEventListener('click', pickStandingFiles);
    const editBtn = el('button', 'cst-st-tool', '');
    editBtn.innerHTML = (window.faIcon ? window.faIcon('pen') : '') + '<span>고치기</span>';
    editBtn.title = '옷장 나누기 · 옷장 이름 · 보낼 이름 고치기 · 지우기';
    editBtn.addEventListener('click', openStandingEditor);
    const sortWrap = el('div', 'cst-st-sort');
    const sortSel = el('select', 'cst-st-sortsel');
    for (const [k, v] of Object.entries(STANDING_SORTS)) {
      const o = el('option', '', v);
      o.value = k;
      sortSel.appendChild(o);
    }
    sortSel.value = state.standingSort;
    sortSel.title = '정렬 · 직접순은 카드를 끌어 바꿉니다 · 추가순은 최근에 추가한 것부터, 오래된순은 먼저 추가한 것부터';
    sortSel.addEventListener('change', () => {
      state.standingSort = sortSel.value;
      setSync({ standingSort: sortSel.value });
      drawCards();
    });
    sortWrap.appendChild(sortSel);
    // 스탠딩이 많으면 아래 설정까지 스크롤하기 귀찮다 → 바로 가기
    const jumpBtn = el('button', 'cst-st-tool cst-st-jump', '');
    jumpBtn.innerHTML = (window.faIcon ? window.faIcon('down') : '') + '<span>설정</span>';
    jumpBtn.title = '아래 썸네일 표시 조절(열 수 · 확대 · 위치)로 바로 가기';
    jumpBtn.addEventListener('click', (e) => {
      e.preventDefault();
      openFold(setSec);
      scrollBodyTo(setSec);
    });
    sortWrap.appendChild(jumpBtn);
    // 옷장 보기(탭 · 목차 · 접기) — 옷장이 두 개 이상일 때만, 정렬 목록 왼쪽에 작게
    if (splitOutfits) {
      const seg = el('div', 'cst-st-seg');
      const LAYOUT_TIPS = {
        tabs: '옷장 보기: 탭 (옷장 하나씩)',
        toc: '옷장 보기: 목차 (전부 펼치고 위에 옷장 목록)',
        fold: '옷장 보기: 접기 (옷장마다 접고 펼치기)',
      };
      for (const [k, t] of [['tabs', '탭'], ['toc', '목차'], ['fold', '접기']]) {
        const b = el('button', 'cst-st-segbtn' + (state.wardrobeLayout === k ? ' on' : ''), t);
        b.dataset.layout = k;
        b.title = LAYOUT_TIPS[k];
        b.setAttribute('aria-pressed', String(state.wardrobeLayout === k));
        b.addEventListener('click', (e) => {
          e.preventDefault();
          if (state.wardrobeLayout === k) return;
          state.wardrobeLayout = k;
          setSync({ wardrobeLayout: k });
          for (const x of seg.children) {
            x.classList.toggle('on', x.dataset.layout === k);
            x.setAttribute('aria-pressed', String(x.dataset.layout === k));
          }
          drawCards();
        });
        seg.appendChild(b);
      }
      sortWrap.insertBefore(seg, sortSel);
    }
    tools.append(importBtn, editBtn, sortWrap);
    // 스탠딩이 하나도 없으면 도구 줄 · 검색 대신 큰 가져오기 자리를 보여 준다
    const searchCount = el('span', 'cst-st-searchcount', '');
    if (list.length) {
      sec2.appendChild(tools);
      const searchRow = el('div', 'cst-st-search');
      const searchInp = el('input', 'cst-input cst-st-searchinp');
      searchInp.type = 'search';
      searchInp.placeholder = `표정 이름 검색 (${list.length}장)`;
      searchInp.value = state.standingQuery || '';
      let searchT = 0;
      // 검색은 카드 칸만 다시 그린다 (입력칸은 그대로라 포커스가 안 풀린다)
      searchInp.addEventListener('input', () => {
        clearTimeout(searchT);
        searchT = setTimeout(() => {
          state.standingQuery = searchInp.value;
          drawCards();
        }, 140);
      });
      searchInp.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && searchInp.value) {
          e.stopPropagation();
          clearTimeout(searchT);
          searchInp.value = '';
          state.standingQuery = '';
          drawCards();
        }
      });
      searchRow.append(searchInp, searchCount);
      sec2.appendChild(searchRow);
    }

    // 카드 칸 — 검색 · 정렬 · 옷장 보기 · 옷장 탭을 바꾸면 여기만 다시 그린다
    const cardsBox = el('div', 'cst-st-cards');
    sec2.appendChild(cardsBox);
    function drawCards() {
      const keepScroll = body.scrollTop;
      cardsBox.innerHTML = '';
      const allOrdered = viewStandings(room, char);
      const query = String(state.standingQuery || '').trim().toLowerCase();
      const ordered = query ? allOrdered.filter((s) => String(s.label).toLowerCase().includes(query)) : allOrdered;
      searchCount.textContent = query ? `${ordered.length}장` : '';
      const groups = groupByOutfit(ordered, outfitMap, outfitOrder);

      const mkGrid = () => {
        const g = el('div', 'cst-standing-grid');
        g.style.setProperty('--cst-cols', effectiveCols());
        return g;
      };
      // i 는 전체 순서(ordered) 안의 위치 — 옷장으로 나눠 그려도 순서 바꾸기는 전체 기준으로 한다
      const makeCard = (s, i) => {
        const card = el('div', 'cst-standing');
        card.draggable = state.standingSort === 'manual' && !query; // 검색 중에는 순서 바꾸기 끔
        card.dataset.label = s.label;
        if (s.label === state.lastStanding) card.classList.add('cst-standing-last');

        const thumb = el('div', 'cst-thumb');
        if (s.img) {
          const img = thumbImg(s.img);
          img.dataset.outfit = outfitMap.get(s.label) || '';
          applyThumbStyle(img);
          thumb.appendChild(img);
        } else {
          const noimg = el('span', 'cst-noimg');
          noimg.innerHTML = window.faIcon ? window.faIcon('avatar') : '?'; // 인장 자리 — 사람 실루엣
          thumb.appendChild(noimg);
        }
        if (s.main) {
          const badge = el('span', 'cst-standing-main', '기본');
          badge.title = '코코포리아 말(맵시트)에 쓰이는 기본 스탠딩';
          thumb.appendChild(badge);
        }
        const label = el('span', 'cst-standing-label', shownName(s));
        card.title = `채팅에 ${state.atPrefix ? '@' : ''}${s.label} · 오른쪽 클릭으로 메뉴` +
          (state.standingSort === 'manual' && !query ? ' · 끌어서 순서 바꾸기' : '');
        card.append(thumb, label);
        card.addEventListener('contextmenu', (e) => {
          if (state.adjustMode) return;
          e.preventDefault();
          openStandingMenu(e.clientX, e.clientY, s);
        });

        card.addEventListener('click', () => {
          if (state.adjustMode) return; // 조정 중에는 전송하지 않는다
          appendStandingTag(s.label);
          state.lastStanding = s.label;
          for (const c of body.querySelectorAll('.cst-standing')) c.classList.remove('cst-standing-last');
          card.classList.add('cst-standing-last');
        });

        if (state.adjustMode) {
          card.classList.add('cst-standing-adjust');
          card.draggable = false;
          card.addEventListener(
            'wheel',
            (e) => {
              e.preventDefault();
              if (perOutfitOn() && state.thumbTarget !== (outfitMap.get(s.label) || '')) setThumbTarget(outfitMap.get(s.label) || '');
              touchThumb();
              const next = Math.round(Math.min(400, Math.max(100, state.thumb.zoom - Math.sign(e.deltaY) * 8)));
              state.thumb.zoom = next;
              refreshThumbStyles();
              syncThumbSliders();
            },
            { passive: false }
          );
          let drag = null;
          card.addEventListener('pointerdown', (e) => {
            if (perOutfitOn() && state.thumbTarget !== (outfitMap.get(s.label) || '')) setThumbTarget(outfitMap.get(s.label) || '');
            touchThumb();
            drag = { x: e.clientX, y: e.clientY, px: state.thumb.posX, py: state.thumb.posY };
            card.setPointerCapture(e.pointerId);
          });
          card.addEventListener('pointermove', (e) => {
            if (!drag) return;
            const box = card.querySelector('.cst-thumb');
            const w = (box && box.clientWidth) || 100;
            const h = (box && box.clientHeight) || 100;
            // 이미지를 잡아끄는 방향으로 움직이게 (드래그 반대편으로 잘린 곳이 보인다)
            state.thumb.posX = Math.round(Math.min(100, Math.max(0, drag.px - ((e.clientX - drag.x) / w) * 100)));
            state.thumb.posY = Math.round(Math.min(100, Math.max(0, drag.py - ((e.clientY - drag.y) / h) * 100)));
            refreshThumbStyles();
            syncThumbSliders();
          });
          const endDrag = () => (drag = null);
          card.addEventListener('pointerup', endDrag);
          card.addEventListener('pointercancel', endDrag);
        }

        card.addEventListener('dragstart', (e) => {
          if (state.adjustMode) {
            e.preventDefault();
            return;
          }
          e.dataTransfer.setData('text/plain', s.label);
          standingDragFrom = { char: state.currentChar, label: s.label };
          card.classList.add('cst-dragging');
        });
        card.addEventListener('dragend', () => {
          card.classList.remove('cst-dragging');
          standingDragFrom = null;
        });
        card.addEventListener('dragover', (e) => {
          if (!standingDragFrom) return; // 파일 등 다른 것을 끌어오면 받지 않는다
          e.preventDefault();
          card.classList.add('cst-dragover');
        });
        card.addEventListener('dragleave', () => card.classList.remove('cst-dragover'));
        card.addEventListener('drop', async (e) => {
          card.classList.remove('cst-dragover');
          const from = standingDragFrom;
          standingDragFrom = null;
          if (!from) return;
          e.preventDefault();
          if (from.char !== state.currentChar || from.label === s.label) return;
          if (state.standingSort !== 'manual' || query) return;
          const visible = ordered.map((x) => x.label);
          const fromIdx = visible.indexOf(from.label);
          if (fromIdx < 0) return;
          const [moved] = visible.splice(fromIdx, 1);
          visible.splice(i, 0, moved);
          const char = state.currentChar;
          await patchRoom((r) => {
            r.standingOrder = r.standingOrder || {};
            // 숨긴 스탠딩은 예전 자리에 남긴다 (다시 보이게 하면 제자리)
            const hiddenSet = new Set((((r.hiddenStandings || {})[char]) || []).map((x) => x.label));
            const next = visible.slice();
            (r.standingOrder[char] || []).forEach((l, k) => {
              if (hiddenSet.has(l) && !next.includes(l)) next.splice(Math.min(k, next.length), 0, l);
            });
            r.standingOrder[char] = next;
          });
          renderBody();
        });

        return card;
      };

      if (!allOrdered.length) {
        // 스탠딩이 없는 캐릭터: 끌어다 놓기 자리 + 큰 [여러 장 가져오기]
        const hiddenN = (((room.hiddenStandings || {})[char]) || []).length;
        const zone = el('div', 'cst-st-empty');
        zone.appendChild(el('div', 'cst-st-empty-icon', ''));
        zone.firstChild.innerHTML = window.faIcon ? window.faIcon('image') : '';
        zone.appendChild(el('div', 'cst-st-empty-title', `"${char}" 스탠딩 이미지를 여기로 끌어다 놓으세요`));
        zone.appendChild(el('div', 'cst-st-empty-sub', '여러 장을 한꺼번에 놓으면 파일 이름에서 옷 · 표정을 나눠 넣어요'));
        const big = el('button', 'cst-btn cst-st-empty-btn', '');
        big.innerHTML = (window.faIcon ? window.faIcon('plus') : '') + '<span>여러 장 가져오기</span>';
        big.addEventListener('click', pickStandingFiles);
        zone.appendChild(big);
        if (hiddenN) {
          const back = el('button', 'cst-btn ghost cst-mini-btn', `숨긴 스탠딩 ${hiddenN}장 다시 보기`);
          back.addEventListener('click', openStandingEditor);
          zone.appendChild(back);
        }
        cardsBox.appendChild(zone);
      } else if (!ordered.length) {
        cardsBox.appendChild(el('div', 'cst-hint', `"${state.standingQuery.trim()}" 이(가) 들어간 표정이 없어요.`));
      } else if (splitOutfits) {
        renderWardrobe(cardsBox, groups, makeCard, mkGrid, { char, outfitMap, outfitOrder, redraw: drawCards });
      } else {
        const grid = mkGrid();
        ordered.forEach((s, i) => grid.appendChild(makeCard(s, i)));
        cardsBox.appendChild(grid);
      }
      if (body.scrollTop !== keepScroll) body.scrollTop = keepScroll;
      if (!state.adjustMode && splitOutfits && perOutfitOn()) {
        const a = activeOutfit();
        if (a !== state.thumbTarget) setThumbTarget(a);
      }
      // 격자가 레이아웃된 뒤 썸네일 크기 계산
      requestAnimationFrame(refreshThumbStyles);
      if (!state.colsFixed) requestAnimationFrame(applyStandingCols);
    }
    drawCards();

    const sliders = el('div', 'cst-sliders');

    // 직접 조정 모드: 켜면 클릭 전송·순서 변경 대신 휠(확대)·드래그(위치)만 먹는다
    const adjRow = el('div', 'cst-slider-row');
    adjRow.append(el('label', '', '직접 조정'));
    const adjBtn = el('button', 'cst-btn ghost cst-mini-btn', state.adjustMode ? '조정 끝내기 (저장)' : '마우스로 조정');
    adjBtn.title = '휠로 확대, 드래그로 위치. 켜는 동안에는 클릭 전송·순서 변경이 잠깁니다.';
    adjBtn.addEventListener('click', async () => {
      state.adjustMode = !state.adjustMode;
      if (!state.adjustMode) {
        await saveThumb(); // 끝낼 때 이 캐릭터 것으로 저장
        toast(`"${state.thumbChar}" 스탠딩 확대 · 위치를 저장했어요.`);
      } else {
        toast('휠=확대, 드래그=위치. 끝나면 [조정 끝내기]를 눌러 주세요.');
      }
      renderBody();
    });
    adjRow.appendChild(adjBtn);

    // 열 수: 1~3열은 늘 보이고 4~6열은 접어 둔다 ([더 보기]로 펼침, 4열 이상을 쓰는 중이면 펼친 채로)
    // [열 수 고정]을 끄면 패널 크기에 맞춰 열 수가 알아서 바뀐다
    const colRow = el('div', 'cst-slider-row');
    colRow.append(el('label', '', '열 수'));
    const colBtns = el('div', 'cst-colbtns');
    const MAX_COLS = 6;
    let colsOpen = state.colsMore || state.cols >= 4;
    const paintCols = () => {
      colBtns.innerHTML = '';
      const shown = colsOpen ? MAX_COLS : 3;
      for (let n = 1; n <= shown; n++) {
        const b = el('button', 'cst-colbtn' + (state.colsFixed && n === state.cols ? ' on' : ''), n + '열');
        b.disabled = !state.colsFixed;
        b.addEventListener('click', () => {
          state.cols = n;
          applyStandingCols();
          paintCols();
          suppressColsEcho = true;
          setSync({ standingCols: n });
        });
        colBtns.appendChild(b);
      }
      const more = el('button', 'cst-colbtn cst-colmore', colsOpen ? '접기' : '더 보기');
      more.title = colsOpen ? '4~6열 접기' : '4 · 5 · 6열 펼치기';
      more.disabled = !state.colsFixed;
      more.addEventListener('click', () => {
        colsOpen = !colsOpen;
        state.colsMore = colsOpen;
        paintCols();
      });
      colBtns.appendChild(more);
    };
    paintCols();
    colRow.appendChild(colBtns);
    const fixRow = el('div', 'cst-slider-row');
    const fixSw = mkSwitch(state.colsFixed, (on) => {
      state.colsFixed = on;
      setSync({ standingColsFixed: on });
      applyStandingCols();
      paintCols();
      drawFixDesc();
    });
    const fixLab = el('label', '', '열 수 고정');
    fixLab.htmlFor = fixSw.input.id;
    fixLab.title = '끄면 패널을 늘리고 줄일 때 열 수가 알아서 바뀝니다';
    const fixDesc = el('span', 'cst-slider-note');
    const drawFixDesc = () => {
      fixDesc.textContent = state.colsFixed ? '' : `패널 크기에 맞춤 · 지금 ${effectiveCols()}열`;
    };
    drawFixDesc();
    colsDescUpdater = drawFixDesc;
    fixRow.append(fixLab, fixSw.wrap, fixDesc);

    const thumbInputs = [];
    // 마우스로 조정한 값을 슬라이더에도 즉시 반영 (서로 덮어써서 튀지 않게)
    syncThumbSliders = () => {
      for (const [key, range, out, unit] of thumbInputs) {
        range.value = state.thumb[key];
        out.textContent = Math.round(state.thumb[key]) + unit;
      }
    };

    const mk = (labelText, key, min, max, unit) => {
      const r = el('div', 'cst-slider-row');
      const lab = el('label', '', labelText);
      const range = document.createElement('input');
      range.type = 'range';
      range.min = min;
      range.max = max;
      range.value = state.thumb[key];
      const out = el('output', '', state.thumb[key] + unit);
      thumbInputs.push([key, range, out, unit]);
      range.addEventListener('input', () => {
        touchThumb();
        state.thumb[key] = Number(range.value);
        out.textContent = range.value + unit;
        refreshThumbStyles();
      });
      range.addEventListener('change', () => saveThumb());
      r.append(lab, range, out);
      return r;
    };

    // 스위치 줄 (바꾸면 바로 적용 — 새로고침 없이)
    const mkToggleRow = (on, text, tip, onChange) => {
      const row = el('div', 'cst-slider-row');
      const sw = mkSwitch(on, onChange);
      const lab = el('label', 'cst-at-lab', text);
      lab.htmlFor = sw.input.id;
      lab.style.cursor = 'pointer';
      if (tip) lab.title = tip;
      row.append(sw.wrap, lab);
      return row;
    };
    const hideRow = mkToggleRow(
      state.hideOutfit,
      '이름표에서 옷 이름 빼기',
      '옷장으로 나눠 볼 때 카드 이름표에서 옷 이름을 뺍니다 (사복_웃음 → 웃음). 채팅에는 @사복_웃음 그대로 보냅니다.',
      (on) => {
        state.hideOutfit = on;
        setSync({ standingHideOutfit: on });
        renderBody();
      }
    );
    const sharpRow = mkToggleRow(
      state.sharpen,
      '확대한 스탠딩 선명하게',
      '원본보다 크게 보일 때 흐려지지 않게 자동으로 보정합니다',
      (on) => {
        state.sharpen = on;
        setSync({ standingSharpen: on });
        refreshThumbStyles();
      }
    );
    // 맨 앞에 @ 추가 토글
    const allCharsRow = mkToggleRow(
      state.saveAllChars,
      '다른 사람 캐릭터도 자동 저장 (GM용)',
      '끄면 방에 들어왔을 때 내 캐릭터만 스탠딩 · 시트를 저장합니다. 켜면 방의 모든 캐릭터를 저장합니다.',
      (on) => {
        state.saveAllChars = on;
        setSync({ standingSaveAllChars: on });
        storeCharsSig = '';
        startCharacterWatch();
      }
    );
    const atRow = mkToggleRow(
      state.atPrefix,
      '클릭 시 맨 앞에 @ 추가',
      '라벨에 @가 이미 있으면 중복으로 붙지 않아요',
      (on) => {
        state.atPrefix = on;
        setSync({ standingAtPrefix: state.atPrefix });
      }
    );

    // 제목 줄 오른쪽 [↑ 스탠딩] — 설정을 만진 뒤 스탠딩 목록으로 돌아가기
    const thumbHead = el('div', 'cst-slider-row cst-slider-head');
    const backBtn = el('button', 'cst-btn ghost cst-mini-btn cst-st-back', '');
    backBtn.innerHTML = (window.faIcon ? window.faIcon('up') : '') + '<span>스탠딩</span>';
    backBtn.title = '위쪽 스탠딩 목록으로';
    backBtn.addEventListener('click', () => {
      openFold(sec2);
      scrollBodyTo(sec2);
    });
    thumbHead.append(el('span', 'cst-slider-title', '썸네일 표시 조절'), backBtn);
    // 확대 · 위치 대상: "캐릭터" [옷장 ▾] ··· [기본값으로]  /  (옷장이 둘 이상이면) [옷장별로 따로 지정] 스위치
    const charThumbRow = el('div', 'cst-slider-row cst-slider-sub');
    const thumbNote = el('span', 'cst-slider-note', '');
    const targetSel = el('select', 'cst-select cst-thumb-target');
    targetSel.title = '확대 · 위치를 조절할 옷장';
    for (const o of outfitList) {
      const op = el('option', '', o || NO_OUTFIT);
      op.value = o;
      targetSel.appendChild(op);
    }
    targetSel.addEventListener('change', () => {
      const v = targetSel.value;
      if (state.wardrobeLayout === 'tabs' || !WARDROBE_LAYOUTS.includes(state.wardrobeLayout)) {
        // 탭 보기면 그 옷장 탭을 보여 준다 (탭을 따라 조절 대상도 바뀐다)
        state.wardrobeTab[char] = v;
        drawCards();
      }
      setThumbTarget(v);
    });
    const resetThumb = el('button', 'cst-btn ghost cst-mini-btn', '기본값으로');
    resetThumb.addEventListener('click', async () => {
      touchThumb();
      Object.assign(state.thumb, THUMB_DEFAULT);
      await saveThumb();
      refreshThumbStyles();
      syncThumbSliders();
    });
    charThumbRow.append(thumbNote, targetSel, resetThumb);
    const perOutfitRow = mkToggleRow(
      state.thumbPerOutfit,
      '옷장별로 따로 지정',
      '켜면 옷장마다 확대 · 위치를 따로 기억합니다. 끄면 그 뒤부터는 옷장과 상관없이 모든 스탠딩이 같이 움직입니다 (옷장별 값은 지우지 않아 다시 켜면 돌아와요).',
      async (on) => {
        // 끌 때: 지금 조절하던 옷장 값을 공통 값으로 가져가 보던 모습을 지킨다
        if (!on && state.thumbTarget != null) Object.assign(state.thumbSet.base, pickThumb(thumbForOutfit(state.thumbTarget)));
        state.thumbPerOutfit = on;
        setSync({ standingThumbPerOutfit: on });
        setThumbTarget(on ? activeOutfit() : null);
        await saveThumb();
        refreshThumbStyles();
      }
    );
    perOutfitRow.hidden = !splitOutfits;
    thumbTargetUpdater = () => {
      const per = perOutfitOn();
      targetSel.hidden = !per;
      if (per && state.thumbTarget != null) targetSel.value = state.thumbTarget;
      thumbNote.textContent = per
        ? `확대 · 위치: "${state.currentChar}" 옷장`
        : splitOutfits
          ? `확대 · 위치: "${state.currentChar}" (모든 옷장 같이)`
          : `확대 · 위치: "${state.currentChar}" 전용`;
      resetThumb.title = per ? '고른 옷장의 확대 · 위치를 조정 안 한 상태로 되돌립니다' : '이 캐릭터의 확대 · 위치를 조정 안 한 상태로 되돌립니다';
      syncThumbSliders();
    };
    // 순서: 제목 → 직접 조정 → 열 수 고정 → 열 수 ─ 확대 · 가로 · 세로 ─ 옷 이름 빼기 · 선명하게 · @ 추가
    sliders.append(
      thumbHead,
      adjRow,
      fixRow,
      colRow,
      el('div', 'cst-slider-sep'),
      charThumbRow,
      perOutfitRow,
      mk('확대', 'zoom', 100, 400, '%'),
      mk('가로 위치', 'posX', 0, 100, '%'),
      mk('세로 위치', 'posY', 0, 100, '%'),
      el('div', 'cst-slider-sep'),
      hideRow,
      sharpRow,
      atRow,
      allCharsRow
    );
    thumbTargetUpdater();
    const setSec = foldBlock('settings', '3', '스탠딩 설정', '');
    setSec.appendChild(sliders);
    body.appendChild(setSec);

    // 캐릭터 시트 백업은 맨 아래 (접는 구역)
    renderSheetBackup(room);
    watchPanelWidth();
    if (!state.colsFixed) requestAnimationFrame(applyStandingCols);
  }

  // ----- 옷장 (스탠딩을 옷별로 나눠 보기) -----
  // 옷 정보는 room.wardrobe[캐릭터][스탠딩 이름] 에 따로 둔다.
  // (편집창을 열면 room.standings 는 코코포리아 것으로 통째로 갈리므로 거기에 넣으면 지워진다)
  // 직접 정한 옷이 없으면 이름('기본_웃음')에서 옷을 추측한다.
  const WARDROBE_LAYOUTS = ['tabs', 'toc', 'fold'];
  const NO_OUTFIT = '기타';

  function wardrobeOf(room, char, labels) {
    const set = ((room.wardrobe || {})[char]) || {};
    // 추측은 옷이 정해지지 않은 이름들끼리만 한다.
    // 가져오기로 넣은 '웃음' 같은 이름과 예전 '기본_웃음' 을 한데 섞어 분석하면 칸을 잘못 짚는다
    const unset = labels.filter((l) => set[l] == null);
    const guess = window.CSTStandingNames && unset.length ? window.CSTStandingNames.outfitsFromLabels(unset) : null;
    const map = new Map();
    for (const l of labels) map.set(l, set[l] != null ? set[l] : (guess && guess.get(l)) || '');
    return map;
  }

  // [{ outfit, items: [{ s, i }] }] — 옷이 한 가지뿐이면 나누지 않는다
  // outfitOrder: [옷장 · 보낼 이름 고치기]에서 정한 옷장 순서. 없는 옷은 처음 나온 순서, 옷 없는 것은 맨 뒤
  function groupByOutfit(ordered, outfitOf, outfitOrder = []) {
    const groups = new Map();
    ordered.forEach((s, i) => {
      const o = outfitOf.get(s.label) || '';
      if (!groups.has(o)) groups.set(o, []);
      groups.get(o).push({ s, i });
    });
    const list = [...groups.entries()].map(([outfit, items], n) => ({ outfit, items, n }));
    const rank = (g) => {
      if (g.outfit === '') return 1e9;
      const k = outfitOrder.indexOf(g.outfit);
      return k >= 0 ? k : 1e6 + g.n;
    };
    list.sort((a, b) => rank(a) - rank(b));
    return list;
  }

  // 옷장 탭 순서 — 고치기에서 정한 순서, 그다음 직접 순서에서 처음 나온 순서 (정렬을 바꿔도 탭 순서는 그대로)
  function outfitOrderOf(room, char, outfitMap) {
    const out = [...(((room.wardrobeOutfits || {})[char]) || [])];
    for (const s of sortStandings(room, char, 'manual')) {
      const o = outfitMap.get(s.label) || '';
      if (o && !out.includes(o)) out.push(o);
    }
    return out;
  }

  // 패널에 보이는 순서
  function viewStandings(room, char) {
    return sortStandings(room, char, state.standingSort);
  }

  // 스탠딩 정렬
  //   manual    직접순 (끌어서 바꾼 순서)
  //   name      이름 A-Z순 / name_desc 이름 Z-A순
  //   recent    추가순 (최근에 추가한 것부터) / added 오래된순 (먼저 추가한 것부터)
  //   추가한 순서 = 코코포리아 표정 순서
  const STANDING_SORTS = { manual: '직접순', name: '이름 A-Z순', name_desc: '이름 Z-A순', recent: '추가순', added: '오래된순' };
  const SORT_KEYS = Object.keys(STANDING_SORTS);
  function sortStandings(room, char, how) {
    const list = ((room.standings || {})[char] || []).slice();
    const byName = (a, b) => String(a.label).localeCompare(String(b.label), 'ko', { numeric: true });
    if (how === 'added') return list;
    if (how === 'recent') return list.reverse();
    if (how === 'name') return list.sort(byName);
    if (how === 'name_desc') return list.sort((a, b) => byName(b, a));
    const order = (room.standingOrder && room.standingOrder[char]) || list.map((x) => x.label);
    const byLabel = new Map(list.map((x) => [x.label, x]));
    const out = order.map((l) => byLabel.get(l)).filter(Boolean);
    for (const x of list) if (!order.includes(x.label)) out.push(x);
    return out;
  }

  // 옷장별로 나눠 그리기 — 탭 · 목차 · 접기
  // 옷장 이름표(탭 · 목차 칩 · 접기 머리줄): 끌어서 옷장 순서 바꾸기 · 두 번 눌러 이름 바꾸기 (고치기 창을 안 열어도)
  let outfitDragFrom = null;
  function outfitHandle(elm, g, ctx, vertical) {
    if (!g.outfit || !ctx) return; // 옷 없음(기타)은 이름 · 순서를 바꾸지 않는다 (늘 맨 뒤)
    elm.draggable = true;
    elm.title = '끌어서 옷장 순서 바꾸기 · 두 번 눌러 이름 바꾸기';
    const clear = () => elm.classList.remove('cst-od-before', 'cst-od-after');
    const isAfter = (e) => {
      const r = elm.getBoundingClientRect();
      return vertical ? e.clientY > r.top + r.height / 2 : e.clientX > r.left + r.width / 2;
    };
    elm.addEventListener('dragstart', (e) => {
      outfitDragFrom = { char: ctx.char, outfit: g.outfit };
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', g.outfit);
      elm.classList.add('cst-od-drag');
    });
    elm.addEventListener('dragend', () => {
      outfitDragFrom = null;
      elm.classList.remove('cst-od-drag');
    });
    elm.addEventListener('dragover', (e) => {
      if (!outfitDragFrom || outfitDragFrom.char !== ctx.char || outfitDragFrom.outfit === g.outfit) return;
      e.preventDefault();
      const after = isAfter(e);
      elm.classList.toggle('cst-od-after', after);
      elm.classList.toggle('cst-od-before', !after);
    });
    elm.addEventListener('dragleave', clear);
    elm.addEventListener('drop', async (e) => {
      const from = outfitDragFrom;
      outfitDragFrom = null;
      clear();
      if (!from || from.char !== ctx.char || from.outfit === g.outfit) return;
      e.preventDefault();
      e.stopPropagation();
      const order = ctx.outfitOrder.filter((o) => o !== from.outfit);
      order.splice(order.indexOf(g.outfit) + (isAfter(e) ? 1 : 0), 0, from.outfit);
      await patchRoom((r) => {
        r.wardrobeOutfits = r.wardrobeOutfits || {};
        r.wardrobeOutfits[ctx.char] = order;
      });
      renderBody();
    });
    elm.addEventListener('dblclick', (e) => {
      e.preventDefault();
      e.stopPropagation();
      renameOutfitInline(elm, g, ctx);
    });
  }

  function renameOutfitInline(elm, g, ctx) {
    const holder = el('span', 'cst-od-edit');
    const inp = el('input', 'cst-input cst-od-input');
    inp.value = g.outfit;
    inp.style.width = Math.max(70, Math.round(elm.getBoundingClientRect().width)) + 'px';
    holder.appendChild(inp);
    elm.replaceWith(holder);
    inp.focus();
    inp.select();
    let done = false;
    const finish = async (ok) => {
      if (done) return;
      done = true;
      const next = inp.value.trim();
      if (!ok || !next || next === g.outfit) return ctx.redraw();
      const snap = await snapshotChar(ctx.char);
      await patchRoom((r) => {
        r.wardrobe = r.wardrobe || {};
        const w = { ...(r.wardrobe[ctx.char] || {}) };
        // 이름에서 추측한 옷도 정한 값으로 넣고, 숨긴 스탠딩에 정해 둔 옷도 같이 바꾼다
        for (const [label, o] of ctx.outfitMap) if (o === g.outfit) w[label] = next;
        for (const k of Object.keys(w)) if (w[k] === g.outfit) w[k] = next;
        r.wardrobe[ctx.char] = w;
        r.wardrobeOutfits = r.wardrobeOutfits || {};
        const order = [...(r.wardrobeOutfits[ctx.char] || ctx.outfitOrder)];
        const at = order.indexOf(g.outfit);
        const rest = order.filter((o) => o !== g.outfit && o !== next);
        rest.splice(at >= 0 ? Math.min(at, rest.length) : rest.length, 0, next); // 같은 이름이 있으면 합친다
        r.wardrobeOutfits[ctx.char] = rest;
      });
      if (state.wardrobeTab[ctx.char] === g.outfit) state.wardrobeTab[ctx.char] = next;
      renderBody();
      undoToast(`옷장 이름을 "${g.outfit}" 에서 "${next}" 로 바꿨어요.`, ctx.char, snap);
    };
    inp.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        finish(true);
      } else if (e.key === 'Escape') {
        e.stopPropagation();
        finish(false);
      }
    });
    inp.addEventListener('blur', () => finish(true));
    inp.addEventListener('click', (e) => e.stopPropagation());
  }

  // ctx: { char, outfitMap, outfitOrder, redraw } — redraw 는 카드 칸만 다시 그린다
  function renderWardrobe(container, groups, makeCard, mkGrid, ctx) {
    const key = state.currentChar;
    const layout = WARDROBE_LAYOUTS.includes(state.wardrobeLayout) ? state.wardrobeLayout : 'tabs';
    const nameOf = (g) => g.outfit || NO_OUTFIT;
    const redraw = (ctx && ctx.redraw) || renderBody;

    if (layout === 'tabs') {
      const tabs = el('div', 'cst-wardrobe-tabs');
      const want = state.wardrobeTab[key];
      const active = groups.find((g) => g.outfit === want) || groups[0];
      for (const g of groups) {
        const b = el('button', 'cst-wardrobe-tab' + (g === active ? ' on' : ''), '');
        b.append(el('span', '', nameOf(g)), el('span', 'cst-wardrobe-count', String(g.items.length)));
        b.addEventListener('click', () => {
          if (g === active) return; // 이미 보고 있는 탭 (두 번 눌러 이름 바꾸기와 겹치지 않게)
          state.wardrobeTab[key] = g.outfit;
          redraw();
        });
        outfitHandle(b, g, ctx, false);
        tabs.appendChild(b);
      }
      const grid = mkGrid();
      for (const { s, i } of active.items) grid.appendChild(makeCard(s, i));
      container.append(tabs, grid);
      return;
    }

    if (layout === 'toc') {
      const toc = el('div', 'cst-wardrobe-toc');
      const heads = [];
      for (const g of groups) {
        const chip = el('button', 'cst-wardrobe-chip', '');
        chip.append(el('span', '', nameOf(g)), el('span', 'cst-wardrobe-count', String(g.items.length)));
        chip.addEventListener('click', () => {
          const h = heads[groups.indexOf(g)];
          if (h) scrollBodyTo(h);
        });
        outfitHandle(chip, g, ctx, false);
        toc.appendChild(chip);
      }
      container.appendChild(toc);
      for (const g of groups) {
        const head = el('div', 'cst-wardrobe-head', nameOf(g));
        head.appendChild(el('span', 'cst-wardrobe-count', String(g.items.length)));
        heads.push(head);
        const grid = mkGrid();
        for (const { s, i } of g.items) grid.appendChild(makeCard(s, i));
        container.append(head, grid);
      }
      return;
    }

    // fold — 옷마다 접었다 펴기 (처음엔 모두 펼침, 상태는 기억)
    for (const g of groups) {
      const foldKey = key + '\u0000' + g.outfit;
      const closed = !!state.wardrobeFold[foldKey];
      const head = el('button', 'cst-wardrobe-head cst-wardrobe-fold' + (closed ? ' closed' : ''), '');
      head.append(el('span', 'cst-wardrobe-caret', closed ? '▸' : '▾'), el('span', '', nameOf(g)), el('span', 'cst-wardrobe-count', String(g.items.length)));
      const grid = mkGrid();
      grid.classList.toggle('cst-hide', closed);
      for (const { s, i } of g.items) grid.appendChild(makeCard(s, i));
      head.addEventListener('click', () => {
        state.wardrobeFold[foldKey] = !state.wardrobeFold[foldKey];
        const now = !!state.wardrobeFold[foldKey];
        grid.classList.toggle('cst-hide', now);
        head.classList.toggle('closed', now);
        head.firstChild.textContent = now ? '▸' : '▾';
        if (!now) requestAnimationFrame(refreshThumbStyles);
      });
      outfitHandle(head, g, ctx, true);
      container.append(head, grid);
    }
  }

  // ----- 코코포리아 캐릭터 편집창 조작 (스탠딩 넣기 · 이름 바꾸기 · 지우기) -----
  // 코코포리아 번들(2026-09 확인) 구조:
  //   편집창 = MUI Dialog 안 <form>. form 의 자식 div 가 섹션: [기본 정보] [표정(立ち絵・差分)] [능력치] [파라미터] ...
  //   표정 섹션: Toolbar(제목 + 추가 버튼 하나) · 줄마다 [아바타 버튼][faces.N.label 입력칸][삭제 버튼][대표 이미지로 버튼]
  //   추가 / 아바타 버튼 → 이미지 고르기 창 (react-dropzone: 숨은 input[type=file], [role=group] 격자,
  //   타일은 img[alt=파일 이름][data-src=주소], 올리는 중이면 타일 안에 덮개가 하나 더 있다)
  //   타일을 누르면 표정 줄이 붙고(또는 그 줄 이미지가 바뀌고) 창이 닫힌다. 편집창은 바뀐 게 있으면 닫을 때 저장된다.
  const sleepMs = (ms) => new Promise((r) => setTimeout(r, ms));

  async function waitFor(fn, timeout = 8000, step = 100, stopped) {
    const end = Date.now() + timeout;
    for (;;) {
      if (stopped && stopped()) return null;
      let v = null;
      try {
        v = fn();
      } catch (_) {}
      if (v) return v;
      if (Date.now() > end) return null;
      await sleepMs(step);
    }
  }

  // 열려 있는 코코포리아 캐릭터 편집창 form (이름을 주면 그 캐릭터 것만)
  function findCcfEditor(name) {
    for (const f of document.querySelectorAll('.MuiDialog-root form')) {
      if (f.closest('.cst-root')) continue;
      const n = f.querySelector('input[name="name"]');
      if (!n) continue;
      if (name && n.value.trim() !== String(name).trim()) continue;
      return f;
    }
    return null;
  }

  function ccfFaceInputs(form) {
    return [...form.querySelectorAll('input[name^="faces."]')]
      .filter((i) => /^faces\.\d+\.label$/.test(i.getAttribute('name') || ''))
      .sort((a, b) => Number(a.name.split('.')[1]) - Number(b.name.split('.')[1]));
  }

  // 표정 섹션의 [추가] 버튼 — 표정 줄이 있으면 그 섹션, 없으면 버튼이 하나뿐인 툴바를 가진 두 번째 섹션
  function ccfFaceAddButton(form) {
    let sec = null;
    const faces = ccfFaceInputs(form);
    if (faces.length) {
      sec = faces[0];
      while (sec.parentElement && sec.parentElement !== form) sec = sec.parentElement;
    } else {
      const secs = [...form.children];
      const oneBtnBar = (c) => {
        const tb = c.querySelector('.MuiToolbar-root');
        return tb && tb.querySelectorAll('button').length === 1 && !c.querySelector('input[name="name"]');
      };
      sec = (secs[1] && oneBtnBar(secs[1]) && secs[1]) || secs.find((c, k) => k > 0 && oneBtnBar(c)) || null;
    }
    if (!sec) return null;
    const tb = sec.querySelector('.MuiToolbar-root');
    const btns = tb ? [...tb.querySelectorAll('button')] : [];
    return btns[btns.length - 1] || null;
  }

  // 표정 줄 안의 버튼들: [아바타, (입력칸), 삭제, 대표 이미지로]
  function ccfFaceRowButtons(input) {
    const tf = input.closest('.MuiTextField-root, .MuiFormControl-root');
    const row = tf && tf.parentElement;
    if (!row) return {};
    const kids = [...row.children];
    const at = kids.indexOf(tf);
    const btnAt = (k) => {
      const c = kids[k];
      return c && (c.tagName === 'BUTTON' ? c : c.querySelector('button'));
    };
    // main: '대표 이미지로' 버튼 — 지금 대표(말 이미지)인 줄은 aria-current="true" 이고 눌리지 않는다
    return { avatar: btnAt(at - 1), remove: btnAt(at + 1), main: btnAt(at + 2) };
  }

  function ccfImageDialog() {
    return (
      [...document.querySelectorAll('.MuiDialog-root')].find(
        (d) => !d.closest('.cst-root') && d.querySelector('input[type="file"]') && !d.querySelector('input[name="name"]')
      ) || null
    );
  }

  async function ccfCloseImageDialog(dlg) {
    if (!dlg || !document.contains(dlg)) return;
    const btn = dlg.querySelector('.MuiDialogActions-root button');
    if (btn) btn.click();
    else dlg.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    await waitFor(() => !document.contains(dlg), 3000);
  }

  // 늘 ROOM 보기로 — Unsplash 는 격자가 없고, ALL 은 코코포리아가 누를 때마다 내 파일 목록 전체를 서버에서 읽는다.
  // (지난번에 ALL 로 두고 닫았으면 그대로 열리므로 ROOM 을 눌러 둔다. 이미 ROOM 이면 아무 일도 없다)
  async function ccfEnsureGrid(dlg) {
    const room = [...dlg.querySelectorAll('button')].find((b) => b.textContent.trim() === 'ROOM');
    if (room) room.click();
    return !!(await waitFor(() => dlg.querySelector('[role="group"]'), 3000));
  }

  // 코코포리아는 5MB 가 넘는 파일을 올릴 때 압축할지 묻고, 거절하거나 압축해도 크면 올리지 않는다
  const CCF_UPLOAD_LIMIT = 5242880;
  const ccfTiles = (dlg, name) => [...dlg.querySelectorAll('[role="group"] img')].filter((img) => img.alt === name);
  const ccfTileReady = (img) =>
    img.parentElement && img.parentElement.children.length === 1 && /^https?:/i.test(img.getAttribute('data-src') || '');

  // 파일들을 코코포리아에 올리고 표정 줄로 넣는다. 반환: [{ file, label, outfit, status: added|replaced|fail, why }]
  async function insertIntoCcfolia(form, files, rows, say, stopped) {
    const results = [];
    const failAll = (from, why) => {
      for (let n = from; n < files.length; n++) results.push({ file: files[n].name, label: rows[n].label, status: 'fail', why });
      return results;
    };
    const addBtn = ccfFaceAddButton(form);
    if (!addBtn) return failAll(0, '코코포리아 편집창에서 표정 추가 버튼을 찾지 못했습니다');

    // 1) 이미지 고르기 창을 열어 한 번에 올린다 (올리기는 창을 닫아도 계속된다)
    // 멈춘 사이에 늦게 열린 이미지 창은 닫는다
    const closeLatePicker = async () => {
      const late = await waitFor(ccfImageDialog, 1500);
      if (late) await ccfCloseImageDialog(late);
    };
    say('코코포리아 이미지 창 여는 중');
    addBtn.click();
    let dlg = await waitFor(ccfImageDialog, 8000, 100, stopped);
    if (!dlg) {
      if (stopped()) {
        await closeLatePicker();
        return failAll(0, '멈춤');
      }
      return failAll(0, '코코포리아 이미지 고르기 창이 열리지 않았습니다');
    }
    await ccfEnsureGrid(dlg);
    // 올리기 전에 있던 같은 이름 타일을 기억한다 (ROOM 보기만 — 방에서 올린 파일은 ROOM 에 뜬다).
    // ALL 보기는 누를 때마다 코코포리아가 내 파일 목록을 최대 3000개까지 서버에서 새로 읽어 오므로 쓰지 않는다.
    const before = new Map(files.map((f) => [f.name, new Set(ccfTiles(dlg, f.name).map((i) => i.getAttribute('data-src')))]));
    const input = dlg.querySelector('input[type="file"]');
    try {
      const dt = new DataTransfer();
      for (const f of files) dt.items.add(f);
      input.files = dt.files;
      input.dispatchEvent(new Event('change', { bubbles: true }));
    } catch (e) {
      await ccfCloseImageDialog(dlg);
      return failAll(0, '코코포리아에 파일을 넘기지 못했습니다');
    }
    say(`코코포리아에 ${files.length}장 올리는 중`);

    // 2) 한 장씩: 창 열기 → 올라가길 기다렸다가 타일 누르기 → 이름 적기
    for (let n = 0; n < files.length; n++) {
      const f = files[n];
      const row = rows[n];
      if (stopped()) {
        results.push({ file: f.name, label: row.label, status: 'fail', why: '멈춤' });
        continue;
      }
      say(`코코포리아에 넣는 중 ${n + 1}/${files.length} · ${row.label}`);
      const existing = ccfFaceInputs(form).find((i) => i.value.trim() === row.label);
      const opener = existing ? ccfFaceRowButtons(existing).avatar : ccfFaceAddButton(form);
      if (!opener) {
        results.push({ file: f.name, label: row.label, status: 'fail', why: '표정 버튼을 찾지 못했습니다' });
        continue;
      }
      // 처음 연 창은 '추가'로 연 것이라, 같은 이름 줄을 바꿀 때는 닫고 그 줄에서 다시 연다
      if (dlg && document.contains(dlg) && existing) {
        await ccfCloseImageDialog(dlg);
        dlg = null;
      }
      if (!dlg || !document.contains(dlg)) {
        opener.click();
        dlg = await waitFor(ccfImageDialog, 8000, 100, stopped);
        if (!dlg) {
          if (stopped()) await closeLatePicker();
          results.push({ file: f.name, label: row.label, status: 'fail', why: stopped() ? '멈춤' : '코코포리아 이미지 고르기 창이 열리지 않았습니다' });
          continue;
        }
        await ccfEnsureGrid(dlg);
      }
      // 올라갈 때까지 기다린다 (ROOM 보기에서만 찾는다)
      const old = before.get(f.name) || new Set();
      const started = Date.now();
      const big = f.size > CCF_UPLOAD_LIMIT;
      let reused = false;
      const img = await waitFor(
        () => {
          const tiles = ccfTiles(dlg, f.name);
          const fresh = tiles.find((i) => ccfTileReady(i) && !old.has(i.getAttribute('data-src')));
          if (fresh) return fresh;
          // 5MB 넘는 파일: 올리는 중인 새 타일도 없이 30초가 지나면 코코포리아가 올리지 않은 것
          if (big) {
            const pending = tiles.some((i) => !old.has(i.getAttribute('data-src')));
            return !pending && Date.now() - started > 30000 ? 'none' : null;
          }
          // 새 타일이 안 생기는 경우(같은 이미지가 이미 있어 코코포리아가 새로 만들지 않음): 같은 이름의 예전 타일을 쓴다
          if (Date.now() - started > 15000) {
            if (!tiles.length) return 'none';
            if (tiles.every((i) => ccfTileReady(i))) {
              reused = true;
              return tiles[0];
            }
          }
          return null;
        },
        90000,
        250,
        stopped
      );
      if (!img || img === 'none') {
        results.push({
          file: f.name,
          label: row.label,
          status: 'fail',
          why: stopped()
            ? '멈춤'
            : big
              ? '5MB 가 넘어 코코포리아가 올리지 않았습니다 (압축을 거절했거나 압축해도 5MB 넘음)'
              : '코코포리아 이미지 목록에 나타나지 않았습니다 (용량 한도 · 네트워크 · 같은 이미지가 이미 있음)',
        });
        await ccfCloseImageDialog(dlg);
        dlg = null;
        continue;
      }
      const prevCount = ccfFaceInputs(form).length;
      const existingIdx = existing ? ccfFaceInputs(form).indexOf(existing) : -1;
      img.parentElement.click();
      await waitFor(() => !document.contains(dlg), 5000);
      dlg = null;
      if (existing) {
        // 코코포리아는 줄 이미지를 바꿀 때 그 줄 이름을 예전 값(마지막으로 줄을 더하거나 뺀 때)으로 되돌린다 → 다시 적는다
        await sleepMs(150);
        const again = ccfFaceInputs(form)[existingIdx];
        if (again && again.value.trim() !== row.label) setNativeValue(again, row.label);
        results.push({ file: f.name, label: row.label, outfit: row.outfit, status: 'replaced', reused });
        continue;
      }
      const newInput = await waitFor(() => {
        const list = ccfFaceInputs(form);
        return list.length > prevCount ? list[list.length - 1] : null;
      }, 5000);
      if (!newInput) {
        results.push({ file: f.name, label: row.label, status: 'fail', why: '코코포리아에 표정 줄이 생기지 않았습니다' });
        continue;
      }
      setNativeValue(newInput, row.label);
      results.push({ file: f.name, label: row.label, outfit: row.outfit, status: 'added', reused });
    }
    if (dlg) await ccfCloseImageDialog(dlg);
    return results;
  }

  // ----- 스탠딩 카드 오른쪽 클릭 메뉴 -----
  // 채팅에 넣기 · 옷/보낼 이름 고치기 · 패널에서 지우기 · (편집창이 열려 있으면) 코코포리아에서도 지우기
  // 지우기는 실수 방지로 두 번 누른다 (첫 번째는 "한 번 더 누르면 지웁니다").
  let standingMenu = null;
  function closeStandingMenu() {
    if (!standingMenu) return;
    standingMenu.remove();
    standingMenu = null;
    document.removeEventListener('mousedown', onMenuOutside, true);
    document.removeEventListener('keydown', onMenuKey, true);
    window.removeEventListener('blur', closeStandingMenu);
  }
  function onMenuOutside(e) {
    if (standingMenu && !standingMenu.contains(e.target)) closeStandingMenu();
  }
  function onMenuKey(e) {
    if (e.key === 'Escape') {
      e.stopPropagation();
      closeStandingMenu();
    }
  }

  // 작은 메뉴 — items: [{ text, run, danger?, disabled?, title?, sep? }]
  function openPanelMenu(x, y, title, items) {
    closeStandingMenu();
    const menu = el('div', 'cst-root cst-ctx');
    shieldFocus(menu);
    for (const t of THEMES) if (panel.classList.contains('cst-theme-' + t)) menu.classList.add('cst-theme-' + t);
    for (const v of ['--cst-accent', '--cst-accent-dark', '--cst-accent-soft']) {
      const val = panel.style.getPropertyValue(v);
      if (val) menu.style.setProperty(v, val);
    }
    if (title) menu.appendChild(el('div', 'cst-ctx-title', title));
    for (const it of items) {
      if (it.sep) {
        menu.appendChild(el('div', 'cst-ctx-sep'));
        continue;
      }
      const b = el('button', 'cst-ctx-item' + (it.danger ? ' danger' : ''), it.text);
      if (it.title) b.title = it.title;
      b.disabled = !!it.disabled;
      b.addEventListener('click', (e) => {
        e.stopPropagation();
        closeStandingMenu();
        it.run();
      });
      menu.appendChild(b);
    }
    document.body.appendChild(menu);
    const r = menu.getBoundingClientRect();
    menu.style.left = Math.max(4, Math.min(x, innerWidth - r.width - 4)) + 'px';
    menu.style.top = Math.max(4, Math.min(y, innerHeight - r.height - 4)) + 'px';
    standingMenu = menu;
    document.addEventListener('mousedown', onMenuOutside, true);
    document.addEventListener('keydown', onMenuKey, true);
    window.addEventListener('blur', closeStandingMenu);
  }

  function openStandingMenu(x, y, s) {
    closeStandingMenu();
    const char = state.currentChar;
    const menu = el('div', 'cst-root cst-ctx');
    shieldFocus(menu);
    for (const t of THEMES) if (panel.classList.contains('cst-theme-' + t)) menu.classList.add('cst-theme-' + t);
    for (const v of ['--cst-accent', '--cst-accent-dark', '--cst-accent-soft']) {
      const val = panel.style.getPropertyValue(v);
      if (val) menu.style.setProperty(v, val);
    }
    const tag = (state.atPrefix ? '@' : '') + s.label;
    menu.appendChild(el('div', 'cst-ctx-title', `${char} · 채팅에 ${tag}`));
    const item = (text, fn, cls) => {
      const b = el('button', 'cst-ctx-item' + (cls ? ' ' + cls : ''), text);
      b.addEventListener('click', fn);
      menu.appendChild(b);
      return b;
    };
    item('채팅에 넣기', () => {
      closeStandingMenu();
      appendStandingTag(s.label);
      state.lastStanding = s.label;
    });
    const mainItem = item(s.main ? '기본 스탠딩 (지금)' : '기본 스탠딩으로 지정', () => {
      closeStandingMenu();
      setAsMainStanding(char, s);
    });
    if (s.main) mainItem.disabled = true;
    else mainItem.title = '코코포리아 말(맵시트)의 이미지를 이 스탠딩으로 바꿉니다';
    item('옷장 · 보낼 이름 고치기', () => {
      closeStandingMenu();
      openStandingEditor();
    });
    menu.appendChild(el('div', 'cst-ctx-sep'));
    // 코코포리아 편집창이 열려 있어 되돌리기를 못 하는 경우만 두 번 눌러야 지운다
    const armed = (btn, first, run) => {
      let ready = false;
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        if (!ready) {
          ready = true;
          btn.classList.add('armed');
          btn.textContent = first;
          return;
        }
        closeStandingMenu();
        await run();
      });
    };
    const delPanel = el('button', 'cst-ctx-item danger', '패널에서 숨기기');
    delPanel.title = '패널에서만 숨깁니다. 코코포리아 표정은 그대로이고, [고치기]에서 다시 보이게 할 수 있어요.';
    menu.appendChild(delPanel);
    delPanel.addEventListener('click', async (e) => {
      e.stopPropagation();
      closeStandingMenu();
      const snap = await snapshotChar(char);
      await removeFromPanel(char, [s.label]);
      renderBody();
      undoToast(`"${s.label}" 을 패널에서 숨겼어요.`, char, snap);
    });
    {
      const delCcf = el('button', 'cst-ctx-item danger', '코코포리아에서 지우기');
      delCcf.title = '코코포리아 캐릭터의 이 표정 자체를 지웁니다. 패널에서도 빠집니다.';
      menu.appendChild(delCcf);
      const runCcfDelete = async () => {
        const snap = await snapshotChar(char);
        const res = await removeFromCcfolia(char, [s.label]);
        if (!res.ok) return toast(res.why);
        renderBody();
        if (res.missing && res.missing.length) return toast(`코코포리아에 "${s.label}" 표정이 없어 패널에서만 뺐어요.`);
        if (res.before) return undoToast(`"${s.label}" 을 코코포리아에서 지웠어요.`, char, snap, res.before);
        toast(res.openedByUs ? `"${s.label}" 을 코코포리아에서 지웠어요.` : `"${s.label}" 을 코코포리아 편집창에서 지웠어요. 편집창을 닫으면 저장됩니다.`);
      };
      if (findCcfEditor(char)) {
        // 열린 편집창에서 지우는 것은 되돌리기가 안 되므로 두 번 누른다
        armed(delCcf, '한 번 더 누르면 코코포리아에서 지웁니다', runCcfDelete);
      } else {
        delCcf.addEventListener('click', async (e) => {
          e.stopPropagation();
          closeStandingMenu();
          await runCcfDelete();
        });
      }
    }
    document.body.appendChild(menu);
    // 화면 밖으로 나가지 않게
    const r = menu.getBoundingClientRect();
    menu.style.left = Math.max(4, Math.min(x, innerWidth - r.width - 4)) + 'px';
    menu.style.top = Math.max(4, Math.min(y, innerHeight - r.height - 4)) + 'px';
    standingMenu = menu;
    document.addEventListener('mousedown', onMenuOutside, true);
    document.addEventListener('keydown', onMenuKey, true);
    window.addEventListener('blur', closeStandingMenu);
  }

  // ----- 코코포리아 편집창에서 일하기 -----
  // 편집창이 열려 있으면 그대로 쓰고, 닫혀 있으면 열고(background → 페이지 쪽 코코포리아 상태) → 일 → 닫기(= 저장).
  // labels: 편집창이 막 열렸을 때 이 표정 줄들이 채워질 때까지 기다린다 (코코포리아가 열린 뒤 값을 채운다).
  // 반환: { ok, openedByUs, result, why }
  async function withCcfEditor(char, work, labels = []) {
    let form = findCcfEditor(char);
    const openedByUs = !form;
    if (!form) {
      const res = await msg('CCF_OPEN_CHARACTER', { name: char });
      if (!res || !res.ok) {
        return {
          ok: false,
          why:
            res && res.why === 'not-found'
              ? `코코포리아에서 "${char}" 캐릭터를 찾지 못했어요. 캐릭터 이름이 같은지 확인해 주세요.`
              : '코코포리아 편집창을 열지 못했어요. 캐릭터 편집창을 직접 열고 다시 해 주세요.',
        };
      }
      form = await waitFor(() => findCcfEditor(char), 5000);
      if (!form) return { ok: false, why: '코코포리아 편집창이 열리지 않았어요.' };
    }
    const want = labels.filter(Boolean);
    await waitFor(() => {
      const have = new Set(ccfFaceInputs(form).map((i) => i.value.trim()));
      return want.length ? want.some((l) => have.has(l)) : have.size > 0;
    }, openedByUs ? 3000 : 300);
    let result;
    try {
      result = await work(form);
    } catch (e) {
      result = { error: String(e && e.message) };
    }
    if (openedByUs) {
      await sleepMs(150);
      await ccfCloseEditor(form);
    }
    return { ok: true, openedByUs, result };
  }

  async function ccfCloseEditor(form) {
    const root = form.closest('.MuiDialog-root');
    const btn = root && root.querySelector('.MuiAppBar-root button');
    if (btn) btn.click();
    await waitFor(() => !document.contains(form), 3000);
  }

  // ----- 편집창 없이 코코포리아 캐릭터 바로 고치기 -----
  // background → 페이지 쪽에서 코코포리아의 updateRoomCharacter 를 부른다 (편집창 저장과 같은 쓰기).
  // 편집창이 열려 있으면 쓰지 않는다 — 열린 편집창을 닫을 때 그 창의 값으로 다시 덮이기 때문 (그때는 편집창에서 한다).
  // 반환 why: not-found(그런 캐릭터 없음) · no-face(그 표정 없음) 은 그대로 알리고,
  // 그 밖(코코포리아 구조가 바뀌어 바로 고치기를 못 함)은 편집창을 열고 닫는 방법으로 넘어간다.
  async function ccfDirect(char, op) {
    if (findCcfEditor(char)) return { ok: false, why: 'editor-open' };
    const res = await msg('CCF_CHARACTER_OP', { name: char, op });
    return res || { ok: false, why: 'no-result' };
  }
  const directFatal = (res) => res && (res.why === 'not-found' || res.why === 'no-face');
  const notFoundText = (char) => `코코포리아에서 "${char}" 캐릭터를 찾지 못했어요. 캐릭터 이름이 같은지 확인해 주세요.`;

  async function markMainInPanel(char, label) {
    await patchRoom((room) => {
      const list = (room.standings || {})[char];
      if (!list) return;
      room.standings[char] = list.map((x) => {
        const { main, ...rest } = x;
        return x.label === label ? { ...rest, main: true } : rest;
      });
    });
    renderBody();
  }

  // ----- 기본 스탠딩(코코포리아 말 이미지)으로 지정 -----
  async function setAsMainStanding(char, s) {
    // 편집창이 닫혀 있으면 바로 바꾼다 (맵시트 말 이미지가 곧바로 바뀐다)
    const snap = await snapshotChar(char);
    const direct = await ccfDirect(char, { kind: 'setIcon', label: s.label });
    if (direct.ok) {
      if (direct.already) toast(`"${s.label}" 은 이미 기본 스탠딩이에요.`);
      await markMainInPanel(char, s.label);
      if (!direct.already) undoToast(`"${s.label}" 을 기본 스탠딩으로 바꿨어요.`, char, snap, direct.before);
      return;
    }
    if (directFatal(direct)) {
      return toast(direct.why === 'not-found' ? notFoundText(char) : `코코포리아 "${char}" 에 "${s.label}" 표정이 없어요.`);
    }
    const run = await withCcfEditor(
      char,
      async (form) => {
        const input = ccfFaceInputs(form).find((i) => i.value.trim() === s.label);
        if (!input) return { missing: true };
        const btn = ccfFaceRowButtons(input).main;
        if (!btn) return { nobutton: true };
        if (btn.getAttribute('aria-current') === 'true' || btn.disabled) return { already: true };
        btn.click();
        await waitFor(() => btn.getAttribute('aria-current') === 'true' || btn.disabled, 1500);
        return { done: true };
      },
      [s.label]
    );
    if (!run.ok) return toast(run.why);
    const r = run.result || {};
    if (r.missing) return toast(`코코포리아 "${char}" 편집창에 "${s.label}" 표정이 없어요.`);
    if (r.nobutton) return toast('코코포리아 편집창에서 대표 이미지 버튼을 찾지 못했어요.');
    if (r.already) return toast(`"${s.label}" 은 이미 기본 스탠딩이에요.`);
    toast(
      run.openedByUs
        ? `"${s.label}" 을 기본 스탠딩으로 바꿨어요. 맵시트 말 이미지가 바뀝니다.`
        : `"${s.label}" 을 기본 스탠딩으로 골랐어요. 코코포리아 편집창을 닫으면 저장됩니다.`
    );
    await markMainInPanel(char, s.label);
  }

  // ----- 되돌리기 -----
  // 지우기 · 숨기기 · 옷장 옮기기는 두 번 누르게 하지 않고 바로 한 뒤 알림의 [되돌리기](5초)로 되돌린다.
  // 패널 기록은 바꾸기 전 스냅숏으로, 코코포리아를 바로 고친 것은 페이지 쪽이 돌려준 before 로 되돌린다.
  const CHAR_KEYS = ['standings', 'standingOrder', 'hiddenStandings', 'wardrobe', 'wardrobeOutfits'];
  async function snapshotChar(char) {
    const room = await getRoom();
    const snap = {};
    for (const k of CHAR_KEYS) snap[k] = room[k] && room[k][char] !== undefined ? JSON.parse(JSON.stringify(room[k][char])) : undefined;
    return snap;
  }
  function restoreChar(char, snap) {
    return patchRoom((r) => {
      for (const k of CHAR_KEYS) {
        if (snap[k] === undefined) {
          if (r[k]) delete r[k][char];
        } else {
          r[k] = r[k] || {};
          r[k][char] = snap[k];
        }
      }
    });
  }
  function undoToast(text, char, snap, ccfBefore) {
    toast(text, {
      action: {
        label: '되돌리기',
        run: async () => {
          let ccfOk = true;
          if (ccfBefore) {
            const res = await ccfDirect(char, { kind: 'restore', patch: ccfBefore });
            ccfOk = !!(res && res.ok);
          }
          await restoreChar(char, snap);
          lastDetectSig = '';
          renderBody();
          toast(ccfOk ? '되돌렸어요.' : '패널은 되돌렸지만 코코포리아 쪽은 못 했어요. 코코포리아에서 Ctrl+Z 로 되돌려 보세요.');
        },
      },
    });
  }

  // ----- 지우기 -----
  // 패널에서 숨기기: 패널 목록에서 빼 '숨김'으로 옮긴다
  //   (room.hiddenStandings[캐릭터] — 코코포리아에서 다시 읽어도 패널에 다시 담지 않는다. 고치기 창에서 다시 보이게 할 수 있다)
  //   옷장 · 순서는 남겨 둔다 (다시 보이게 할 때 제자리)
  async function removeFromPanel(char, labels) {
    const set = new Set(labels);
    await patchRoom((r) => {
      const list = (r.standings && r.standings[char]) || [];
      const hide = list.filter((x) => set.has(x.label)).map(({ main, ...rest }) => rest);
      if (r.standings && r.standings[char]) r.standings[char] = list.filter((x) => !set.has(x.label));
      if (hide.length) {
        r.hiddenStandings = r.hiddenStandings || {};
        const prev = (r.hiddenStandings[char] || []).filter((x) => !set.has(x.label));
        r.hiddenStandings[char] = [...prev, ...hide];
      }
    });
  }

  // 코코포리아에서 지우기: 편집창의 표정 줄을 지우고(열려 있지 않으면 열고 닫아 저장) 패널에서도 완전히 뺀다
  async function removeFromCcfolia(char, labels) {
    const set = new Set(labels);
    const dropFromPanel = () =>
      patchRoom((r) => {
        if (r.standings && r.standings[char]) r.standings[char] = r.standings[char].filter((x) => !set.has(x.label));
        if (r.hiddenStandings && r.hiddenStandings[char]) r.hiddenStandings[char] = r.hiddenStandings[char].filter((x) => !set.has(x.label));
        if (r.standingOrder && r.standingOrder[char]) r.standingOrder[char] = r.standingOrder[char].filter((l) => !set.has(l));
        if (r.wardrobe && r.wardrobe[char]) for (const l of labels) delete r.wardrobe[char][l];
      });
    const direct = await ccfDirect(char, { kind: 'edit', remove: labels });
    if (direct.ok) {
      await dropFromPanel();
      return { ok: true, openedByUs: true, removed: direct.removed, missing: direct.removed ? [] : labels, before: direct.before };
    }
    if (directFatal(direct)) return { ok: false, why: notFoundText(char) };
    const run = await withCcfEditor(
      char,
      async (form) => {
        let removed = 0;
        const missing = [];
        for (const label of labels) {
          const input = ccfFaceInputs(form).find((i) => i.value.trim() === label);
          const btn = input && ccfFaceRowButtons(input).remove;
          if (!btn) {
            missing.push(label);
            continue;
          }
          const before = ccfFaceInputs(form).length;
          btn.click();
          await waitFor(() => ccfFaceInputs(form).length < before, 1500);
          removed++;
        }
        return { removed, missing };
      },
      labels
    );
    if (!run.ok) return { ok: false, why: run.why };
    await dropFromPanel();
    return { ok: true, openedByUs: run.openedByUs, ...(run.result || {}) };
  }

  // ----- 스탠딩 일괄 가져오기 · 이름/옷 고치기 (공용 창) -----
  // float: 화면을 덮지 않는 떠 있는 창 — 열어 둔 채로 코코포리아(캐릭터 편집창 열기 등)를 만질 수 있다.
  //        머리줄을 잡고 옮길 수 있다.
  function openStandingModal(title, opts = {}) {
    const back = el('div', 'cst-root cst-modal-back' + (opts.float ? ' cst-modal-float' : ''));
    shieldFocus(back);
    // 패널과 같은 테마·포인트색으로
    for (const t of THEMES) if (panel.classList.contains('cst-theme-' + t)) back.classList.add('cst-theme-' + t);
    for (const v of ['--cst-accent', '--cst-accent-dark', '--cst-accent-soft']) {
      const x = panel.style.getPropertyValue(v);
      if (x) back.style.setProperty(v, x);
    }
    const box = el('div', 'cst-modal');
    const head = el('div', 'cst-modal-head');
    head.appendChild(el('span', 'cst-modal-title', title));
    const x = el('button', 'cst-iconbtn', '✕');
    x.title = '닫기';
    head.appendChild(x);
    const bodyEl = el('div', 'cst-modal-body');
    const foot = el('div', 'cst-modal-foot');
    box.append(head, bodyEl, foot);
    back.appendChild(box);
    document.body.appendChild(back);
    // 떠 있는 창은 우하단 모서리를 끌어 크기를 바꾼다. sizeKey 가 있으면 그 창 크기를 기억해 다음에도 그 크기로 연다
    let sizeObs = null;
    if (opts.float) {
      box.classList.add('cst-modal-resizable');
      if (opts.sizeKey) {
        getLocal({ modalSizes: {} })
          .then(({ modalSizes }) => {
            const sz = (modalSizes || {})[opts.sizeKey];
            if (!sz || !document.contains(box)) return;
            if (sz.w > 200) box.style.width = Math.min(sz.w, innerWidth - 16) + 'px';
            if (sz.h > 150) box.style.height = Math.min(sz.h, innerHeight - 80) + 'px';
          })
          .catch(() => {});
        let saveT = 0;
        sizeObs = new ResizeObserver(() => {
          // 사용자가 모서리를 끌면 브라우저가 width/height 를 직접 적는다 — 그때만 기억 (내용이 늘어나 커진 것은 제외)
          if (!box.style.width || !box.style.height) return;
          clearTimeout(saveT);
          saveT = setTimeout(async () => {
            const w = Math.round(box.offsetWidth);
            const h = Math.round(box.offsetHeight);
            const { modalSizes } = await getLocal({ modalSizes: {} });
            await setLocal({ modalSizes: { ...(modalSizes || {}), [opts.sizeKey]: { w, h } } });
          }, 500);
        });
        sizeObs.observe(box);
      }
    }
    const urls = [];
    const close = () => {
      for (const u of urls) URL.revokeObjectURL(u);
      if (sizeObs) sizeObs.disconnect();
      back.remove();
      document.removeEventListener('keydown', onKey, true);
    };
    const onKey = (e) => {
      if (e.key !== 'Escape') return;
      // 떠 있는 창인데 코코포리아 창을 만지던 중이면 Esc 는 코코포리아 몫이다
      if (opts.float && !box.contains(document.activeElement)) return;
      // 입력칸 안의 Esc 는 그 칸 몫이다 (옷장 이름 고치기 취소 등) — 창을 통째로 닫아 고친 것을 잃지 않게.
      // 보통 칸은 커서만 빼고, 한 번 더 누르면 창을 닫는다
      const t = e.target;
      if (t && box.contains(t) && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) {
        if (!t.closest('.cst-wd-chip')) t.blur();
        return;
      }
      e.stopPropagation();
      close();
    };
    document.addEventListener('keydown', onKey, true);
    x.addEventListener('click', close);
    if (!opts.float) {
      back.addEventListener('mousedown', (e) => {
        if (e.target === back) close();
      });
    } else {
      // 머리줄 끌어 옮기기
      head.classList.add('cst-modal-drag');
      let drag = null;
      head.addEventListener('pointerdown', (e) => {
        if (e.target.closest('button')) return;
        const r = box.getBoundingClientRect();
        drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
        head.setPointerCapture(e.pointerId);
      });
      head.addEventListener('pointermove', (e) => {
        if (!drag) return;
        const w = box.offsetWidth;
        box.style.left = Math.max(0, Math.min(innerWidth - w, e.clientX - drag.dx)) + 'px';
        box.style.top = Math.max(0, Math.min(innerHeight - 40, e.clientY - drag.dy)) + 'px';
      });
      const end = () => (drag = null);
      head.addEventListener('pointerup', end);
      head.addEventListener('pointercancel', end);
    }
    return { bodyEl, foot, close, urls, back };
  }

  // [여러 장 가져오기] — 파일을 고르면 가져오기 창. 스탠딩은 늘 코코포리아 캐릭터 표정으로 넣는다
  // (편집창이 닫혀 있으면 넣을 때 열고, 다 넣으면 닫아 저장한다).
  // 캐릭터마다 쓰던 파일 이름 규칙(칸 역할 · 이름 모양 · 번호 표기)을 기억한다 —
  // 같은 캐릭터 스탠딩을 또 가져올 때 드롭다운을 다시 고르지 않게. 방이 달라도 이름이 같으면 쓴다.
  const IMPORT_FMT_KEY = 'standingImportFmt';
  const IMPORT_FMT_MAX = 200;
  async function loadImportFmt(char) {
    if (!char) return null;
    const d = await getLocal({ [IMPORT_FMT_KEY]: {} });
    const rec = (d[IMPORT_FMT_KEY] || {})[char];
    return rec && Array.isArray(rec.roles) && rec.roles.length ? rec : null;
  }
  async function saveImportFmt(char, res) {
    if (!char || !res || !Array.isArray(res.roles) || !res.roles.length) return;
    const d = await getLocal({ [IMPORT_FMT_KEY]: {} });
    const all = d[IMPORT_FMT_KEY] || {};
    all[char] = { roles: [...res.roles], format: res.format || '', numStyle: res.numStyle || '', at: Date.now() };
    // 너무 많이 쌓이면 오래된 것부터 버린다
    const keys = Object.keys(all);
    if (keys.length > IMPORT_FMT_MAX) {
      keys.sort((a, b) => (all[a].at || 0) - (all[b].at || 0));
      for (const k of keys.slice(0, keys.length - IMPORT_FMT_MAX)) delete all[k];
    }
    await setLocal({ [IMPORT_FMT_KEY]: all });
  }

  const isImageFile = (f) => /^image\//.test(f.type) || /\.(png|jpe?g|webp|gif|avif|bmp)$/i.test(f.name);
  function pickStandingFiles() {
    const inp = document.createElement('input');
    inp.type = 'file';
    inp.accept = 'image/*';
    inp.multiple = true;
    inp.addEventListener('change', () => importFiles([...(inp.files || [])]));
    inp.click();
  }
  // 고르거나 끌어다 놓은 파일 → 가져오기 창 (창이 코코포리아 편집창을 알아서 살핀다)
  async function importFiles(all) {
    const isZip = (f) => /\.zip$/i.test(f.name) || f.type === 'application/zip' || f.type === 'application/x-zip-compressed';
    let files = all.filter(isImageFile);
    const notImages = all.filter((f) => !isImageFile(f) && !isZip(f)).map((f) => f.name);
    let preset = null;
    for (const z of all.filter(isZip)) {
      try {
        const { images, manifest } = await filesFromZip(z);
        files = files.concat(images);
        if (manifest && !preset) preset = { manifest, files: images };
        if (!images.length) notImages.push(`${z.name} (이미지 없음)`);
      } catch (e) {
        notImages.push(`${z.name} (zip 을 읽지 못함)`);
      }
    }
    if (files.length) openStandingImport(files, notImages, preset ? { preset } : {});
    else if (notImages.length) toast(`가져올 이미지가 없어요 (${notImages.join(', ')}).`);
  }

  // 이 방 코코포리아 캐릭터 표정으로 넣는다 (패널에서 보고 있는 캐릭터가 기본)
  async function openStandingImport(files, notImages = [], opts = {}) {
    const SN = window.CSTStandingNames;
    if (!SN) return toast('파일명 분석기를 불러오지 못했어요. 페이지를 새로고침해 주세요.');
    const roomChars = knownChars(await getRoom());
    const preset = opts.preset || null; // zip 넣기: json 에 적힌 캐릭터 · 이름 · 옷장
    // json 의 캐릭터가 이 방에 없으면 보고 있는 캐릭터로 (없는 캐릭터에는 넣을 수 없다)
    const presetName = preset && roomChars.includes(preset.manifest.name) ? preset.manifest.name : '';
    if (!roomChars.length) return toast('이 방 캐릭터를 아직 못 읽었어요. 코코포리아에서 캐릭터를 만들거나 편집창을 한 번 열어 주세요.');
    const openEditor = findCcfEditor();
    const openName = openEditor ? openEditor.querySelector('input[name="name"]').value.trim() : '';
    // 넣을 캐릭터 이름을 알려 주면 파일이 한 장이어도 캐릭터 칸을 알아본다
    let result = SN.analyze(files.map((f) => f.name), { charName: (preset && preset.manifest.name) || openName || state.currentChar });
    let forcedFormat = null; // 이름 규칙을 직접 고르면 다시 계산해도 그 규칙을 지킨다 (아니면 겹치지 않는 규칙을 다시 고른다)
    // 이 캐릭터에 쓰던 규칙이 있으면 그대로 (칸 수가 같을 때만 — 파일 이름 모양이 달라졌으면 새로 추측한다)
    const applySavedFmt = async (char) => {
      if (preset) return; // zip 은 json 에 적힌 대로
      const rec = await loadImportFmt(char);
      if (!rec || rec.roles.length !== result.columns.length) return;
      if (rec.roles.join('|') === result.roles.join('|') && (!rec.format || rec.format === result.format)) return;
      forcedFormat = rec.format || forcedFormat;
      result = SN.relabel(result, rec.roles, rec.format || null, rec.numStyle || result.numStyle);
      edited.label.clear();
      draw();
    };
    const edited = { label: new Map(), outfit: new Map() }; // 사용자가 직접 고친 칸 (다시 계산해도 지키기)
    if (preset) {
      // zip 의 json 대로 이름 · 옷장을 채운다 (파일 경로로 짝을 맞춘다)
      const byPath = new Map((preset.manifest.standings || []).map((x) => [x.file, x]));
      files.forEach((f, n) => {
        const m = byPath.get(f.zipPath || f.name);
        if (!m) return;
        edited.label.set(n, String(m.label || ''));
        edited.outfit.set(n, String(m.outfit || ''));
      });
    }
    const { bodyEl, foot, close, urls } = openStandingModal(`스탠딩 여러 장 가져오기 · ${files.length}장`, { float: true, sizeKey: 'import' });
    const thumbs = files.map((f) => {
      const u = URL.createObjectURL(f);
      urls.push(u);
      return u;
    });

    // 캐릭터
    const charRow = el('div', 'cst-modal-row');
    charRow.appendChild(el('label', 'cst-modal-lab', '캐릭터'));
    const charInp = el('select', 'cst-select');
    for (const c of roomChars) {
      const o = el('option', '', c);
      o.value = c;
      charInp.appendChild(o);
    }
    charInp.value = presetName || (roomChars.includes(state.currentChar) ? state.currentChar : roomChars[0]);
    charRow.appendChild(charInp);
    const typoBox = el('div', 'cst-modal-typos');
    const roleBox = el('div', 'cst-modal-roles');
    const fmtRow = el('div', 'cst-modal-row');
    const listBox = el('div', 'cst-modal-list');
    const warn = el('div', 'cst-modal-warn');
    const selBar = el('div', 'cst-wd-selbar');
    const selected = new Set(); // 고른 파일 (번호)
    let lastPicked = -1; // Shift+클릭으로 사이를 한꺼번에 고르기
    const skippedNote = el('div', 'cst-modal-warn');
    skippedNote.hidden = !notImages.length;
    skippedNote.textContent = notImages.length
      ? `이미지가 아니어서 뺀 파일 ${notImages.length}개: ${notImages.slice(0, 5).join(', ')}${notImages.length > 5 ? ' …' : ''}`
      : '';
    bodyEl.append(
      el('div', 'cst-hint cst-hint-help', '파일 이름을 칸별로 나눠 캐릭터 · 번호 · 옷 · 표정을 알아서 골랐어요. 칸 수는 + / − 로, 역할과 이름은 직접 바꿀 수 있어요.\n표정 · 번호 · 옷을 여러 칸에 주면 _ 로 이어 붙입니다 (웃음 + 눈감음 → 웃음_눈감음).'),
      skippedNote,
      charRow,
      typoBox,
      roleBox,
      fmtRow,
      warn,
      selBar,
      listBox
    );

    const recompute = (roles, format, numStyle) => {
      result = SN.relabel(result, roles || result.roles, format || forcedFormat, numStyle || result.numStyle);
      saveImportFmt(charInp.value.trim(), result); // 이 캐릭터에 쓰던 규칙으로 기억
      draw();
    };

    // 오타 고치기: 그 칸 값을 제안값으로 바꿔 다시 계산한다 (이름 규칙도 다시 고른다)
    const fixTypo = (t) => {
      result = SN.fixValue(result, t.role, t.value, t.suggest, t.col);
      result = SN.relabel(result, result.roles, forcedFormat, result.numStyle);
      draw();
    };

    function draw() {
      // 오타
      typoBox.innerHTML = '';
      for (const t of result.typos) {
        const line = el('div', 'cst-modal-typo', '');
        line.append(
          el('span', '', `'${t.value}' 는 '${t.suggest}' 의 오타 같아요 (${SN.ROLE_LABEL[t.role]} · ${t.count}장)`)
        );
        const fixBtn = el('button', 'cst-btn cst-mini-btn', '고치기');
        fixBtn.addEventListener('click', () => fixTypo(t));
        line.appendChild(fixBtn);
        typoBox.appendChild(line);
      }

      // 칸 역할 — 칸 수는 + / − 로 (줄이면 뒤 칸끼리 합치고, 늘리면 더 나눈다)
      roleBox.innerHTML = '';
      {
        const bar = el('div', 'cst-modal-colbar');
        bar.appendChild(el('span', 'cst-modal-lab', '파일 이름 칸'));
        // 오른쪽에 붙은 [− 칸 수 +] (칸 수는 아래 역할 칸 개수와 같게 — 괄호 번호 칸 포함)
        const stepper = el('span', 'cst-modal-stepper');
        const minus = el('button', 'cst-modal-stepbtn', '−');
        minus.title = '칸 줄이기 (마지막 두 칸을 합칩니다)';
        minus.disabled = !result.canRemove;
        const plus = el('button', 'cst-modal-stepbtn', '+');
        plus.title = result.canAdd ? '칸 늘리기 (더 나눕니다)' : '더 나눌 곳이 없어요';
        plus.disabled = !result.canAdd;
        const resize = (d) => {
          result = SN.resize(result, d);
          if (forcedFormat) result = SN.relabel(result, result.roles, forcedFormat, result.numStyle);
          edited.label.clear();
          edited.outfit.clear();
          draw();
        };
        minus.addEventListener('click', () => resize(-1));
        plus.addEventListener('click', () => resize(1));
        stepper.append(minus, el('span', 'cst-modal-stepval', String(result.columns.length)), plus);
        bar.appendChild(stepper);
        roleBox.appendChild(bar);
      }
      if (result.columns.length) {
        const cols = el('div', 'cst-modal-cols');
        result.columns.forEach((c, n) => {
          const cell = el('div', 'cst-modal-col');
          const sel = el('select', 'cst-select');
          for (const r of SN.ROLES) {
            const o = el('option', '', SN.ROLE_LABEL[r]);
            o.value = r;
            if (r === c.role) o.selected = true;
            sel.appendChild(o);
          }
          sel.addEventListener('change', () => {
            const roles = [...result.roles];
            // 캐릭터는 한 칸만 — 다른 칸이 캐릭터면 비운다. 번호 · 옷 · 표정은 여러 칸이면 '_' 로 이어 붙인다
            if (sel.value === 'char') roles.forEach((r, k) => r === 'char' && k !== n && (roles[k] = 'skip'));
            roles[n] = sel.value;
            edited.label.clear();
            recompute(roles, null);
          });
          // 괄호 번호 칸은 파일 이름에 보이는 모양 그대로 보여 준다
          cell.append(sel, el('div', 'cst-modal-sample', c.samples.map((v) => (c.paren ? `(${v})` : v)).join(' · ')));
          cols.appendChild(cell);
        });
        roleBox.appendChild(cols);
      }

      // 이름 규칙
      fmtRow.innerHTML = '';
      fmtRow.appendChild(el('label', 'cst-modal-lab', '스탠딩 이름'));
      const fmt = el('select', 'cst-select');
      for (const [k, v] of Object.entries(SN.LABEL_FORMATS)) {
        const o = el('option', '', v);
        o.value = k;
        if (k === result.format) o.selected = true;
        fmt.appendChild(o);
      }
      fmt.addEventListener('change', () => {
        edited.label.clear(); // 규칙을 바꾸면 직접 고친 이름은 새 규칙으로
        forcedFormat = fmt.value;
        recompute(null, fmt.value);
      });
      fmtRow.appendChild(fmt);
      // 번호 표기 — 번호 칸이 있을 때만: '1' 로 넣을지 '(1)' 로 넣을지
      if (result.roles.includes('num')) {
        const ns = el('select', 'cst-select cst-modal-numstyle');
        ns.title = '스탠딩 이름에 번호를 넣는 모양';
        for (const [k, v] of Object.entries(SN.NUM_STYLES)) {
          const o = el('option', '', '번호 ' + v);
          o.value = k;
          if (k === result.numStyle) o.selected = true;
          ns.appendChild(o);
        }
        ns.addEventListener('change', () => {
          edited.label.clear();
          recompute(null, null, ns.value);
        });
        fmtRow.appendChild(ns);
      }

      drawList();
    }

    // 여러 장 골라 옷장 한꺼번에 정하기: [전체] N장 고름 [옷장 정하기 ▾]
    function drawSelBar() {
      selBar.innerHTML = '';
      const total = result.items.length;
      const n = selected.size;
      const allBox = el('input', 'cst-wd-check');
      allBox.type = 'checkbox';
      allBox.checked = n > 0 && n === total;
      allBox.indeterminate = n > 0 && n < total;
      allBox.title = '전체 고르기 (줄의 체크는 Shift+클릭으로 사이를 한꺼번에)';
      allBox.addEventListener('change', () => {
        selected.clear();
        if (allBox.checked) result.items.forEach((_, k) => selected.add(k));
        drawList();
      });
      selBar.append(allBox, el('span', 'cst-wd-selcount', n ? `${n}장 고름` : '전체'));
      const move = el('select', 'cst-select cst-wd-move');
      const opt = (v, t) => {
        const o = el('option', '', t);
        o.value = v;
        move.appendChild(o);
      };
      opt('', '옷장 정하기');
      for (const o of [...new Set(rowsNow().map((r) => r.outfit).filter(Boolean))]) opt('o:' + o, o);
      opt('none', '옷 없음');
      opt('new', '새 옷장 이름 넣기');
      move.disabled = !n;
      move.addEventListener('change', () => {
        const v = move.value;
        move.value = '';
        if (v === 'new') return askNewOutfit(move);
        if (v === 'none') applyOutfit('');
        else if (v.startsWith('o:')) applyOutfit(v.slice(2));
      });
      selBar.appendChild(move);
    }
    function applyOutfit(o) {
      for (const k of selected) edited.outfit.set(k, o);
      selected.clear();
      drawList();
    }
    function askNewOutfit(replaceEl) {
      // 칩 모양 안의 입력칸 — 창의 Esc 처리가 커서를 빼지 않아 Esc 로 취소할 수 있다
      const wrap = el('span', 'cst-wd-chip editing');
      const inp = el('input', 'cst-input cst-wd-input');
      inp.placeholder = '새 옷장 이름';
      wrap.appendChild(inp);
      let done = false;
      const finish = (ok) => {
        if (done) return;
        done = true;
        const v = inp.value.trim();
        if (ok && v) applyOutfit(v);
        else drawSelBar();
      };
      inp.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') finish(true);
        else if (e.key === 'Escape') {
          e.stopPropagation();
          finish(false);
        }
      });
      inp.addEventListener('blur', () => finish(true));
      replaceEl.replaceWith(wrap);
      inp.focus();
    }

    function drawList() {
      const keepScroll = bodyEl.scrollTop;
      listBox.innerHTML = '';
      const rows = rowsNow();
      const seen = new Map();
      for (const r of rows) seen.set(r.label, (seen.get(r.label) || 0) + 1);
      result.items.forEach((it, n) => {
        const row = el('div', 'cst-modal-item' + (selected.has(n) ? ' selected' : ''));
        const check = el('input', 'cst-wd-check');
        check.type = 'checkbox';
        check.checked = selected.has(n);
        check.addEventListener('click', (e) => {
          const on = check.checked;
          const range = e.shiftKey && lastPicked >= 0 ? [Math.min(lastPicked, n), Math.max(lastPicked, n)] : [n, n];
          for (let k = range[0]; k <= range[1]; k++) {
            if (on) selected.add(k);
            else selected.delete(k);
          }
          lastPicked = n;
          if (range[0] !== range[1]) return drawList();
          row.classList.toggle('selected', on);
          drawSelBar();
        });
        const img = document.createElement('img');
        img.src = thumbs[n];
        img.alt = '';
        const outfitInp = el('input', 'cst-input cst-modal-outfit');
        outfitInp.placeholder = '옷';
        outfitInp.value = rows[n].outfit;
        outfitInp.addEventListener('input', () => {
          edited.outfit.set(n, outfitInp.value.trim());
          drawWarn();
        });
        outfitInp.addEventListener('change', drawSelBar);
        const labelInp = el('input', 'cst-input cst-modal-label');
        labelInp.placeholder = '스탠딩 이름';
        labelInp.value = rows[n].label;
        if ((seen.get(rows[n].label) || 0) > 1) labelInp.classList.add('dup');
        labelInp.addEventListener('input', () => {
          edited.label.set(n, labelInp.value.trim());
          drawWarn();
        });
        const file = el('span', 'cst-modal-file', it.file);
        file.title = it.file;
        const fields = el('div', 'cst-modal-fields', '');
        fields.append(outfitInp, labelInp);
        row.append(check, img, fields, file);
        listBox.appendChild(row);
      });
      drawSelBar();
      drawWarn();
      bodyEl.scrollTop = keepScroll;
    }

    function rowsNow() {
      return result.items.map((it, n) => ({
        label: edited.label.has(n) ? edited.label.get(n) : it.label,
        outfit: edited.outfit.has(n) ? edited.outfit.get(n) : it.outfit,
      }));
    }

    function drawWarn() {
      const rows = rowsNow();
      const count = new Map();
      for (const r of rows) count.set(r.label, (count.get(r.label) || 0) + 1);
      const dups = [...count].filter(([k, v]) => k && v > 1).map(([k]) => k);
      const empty = rows.filter((r) => !r.label).length;
      const outfitTypos = SN.findTypos(rows.map((r) => r.outfit));
      const msgs = [];
      if (dups.length) msgs.push(`이름이 겹쳐요: ${dups.join(', ')} (코코포리아는 @이름 으로 표정을 바꾸니 겹치면 안 됩니다)`);
      if (empty) msgs.push(`이름이 빈 스탠딩 ${empty}장`);
      for (const t of outfitTypos) msgs.push(`옷 '${t.value}' 는 '${t.suggest}' 의 오타 같아요`);
      warn.textContent = msgs.join('\n');
      warn.hidden = !msgs.length;
      for (const [n, inp] of [...listBox.querySelectorAll('.cst-modal-label')].entries()) {
        inp.classList.toggle('dup', dups.includes(rows[n].label) || !rows[n].label);
      }
      // 넣는 중에는 켜지 않는다 (이름칸을 고쳐도 두 번 넣지 않게)
      saveBtn.disabled = running || ccfBlocked || !!(dups.length || empty || !charInp.value.trim());
    }

    const cancel = el('button', 'cst-btn ghost', '취소');
    cancel.addEventListener('click', close);
    const saveBtn = el('button', 'cst-btn', `코코포리아에 넣기 (${files.length}장)`);
    charInp.addEventListener('change', () => {
      charTouched = true;
      drawWarn();
      drawCcfState();
      applySavedFmt(charInp.value.trim());
    });

    // 원본 그대로 코코포리아에 넣는다. 편집창이 열려 있으면 그 창에, 닫혀 있으면 열어서 넣고 닫아 저장한다 (열렸는지 계속 살핀다)
    let charTouched = !!presetName;
    let running = false;
    let ccfBlocked = false; // 다른 캐릭터 편집창이 열려 있음
    const ccfLine = el('div', 'cst-modal-ccf');
    bodyEl.insertBefore(ccfLine, bodyEl.firstChild.nextSibling);
    const bigCount = files.filter((f) => f.size > CCF_UPLOAD_LIMIT).length;
    const bigNote = bigCount ? ` 5MB 넘는 파일 ${bigCount}장은 코코포리아가 압축할지 물어봐요.` : '';
    const drawCcfState = () => {
      if (running) return;
      // 편집창이 열린 캐릭터로 맞춘다 (직접 고른 뒤에는 건드리지 않는다)
      const any = findCcfEditor();
      const anyName = any ? any.querySelector('input[name="name"]').value.trim() : '';
      if (anyName && !charTouched && charInp.value !== anyName) {
        if (![...charInp.options].some((o) => o.value === anyName)) {
          const o = el('option', '', anyName);
          o.value = anyName;
          charInp.appendChild(o);
        }
        charInp.value = anyName;
      }
      const form = findCcfEditor(charInp.value);
      // 다른 캐릭터 편집창이 열려 있으면 넣지 않는다 (그 창을 둔 채 다른 캐릭터 창을 열면 그 창에서 고친 것이 저장되지 않을 수 있다)
      const blocked = !form && !!any;
      ccfLine.classList.toggle('on', !!form);
      ccfLine.textContent = form
        ? `코코포리아 "${charInp.value}" 편집창이 열려 있어요. 원본 이미지를 코코포리아에 올리고 표정으로 넣습니다.${bigNote}`
        : blocked
          ? `코코포리아에 "${anyName}" 편집창이 열려 있어요. 그 창을 닫거나 캐릭터를 "${anyName}" 로 고르면 넣을 수 있어요.`
          : `넣으면 코코포리아 "${charInp.value}" 편집창을 열어 원본 그대로 올리고, 다 넣으면 닫아서 저장해요.${bigNote}`;
      saveBtn.title = form
        ? '코코포리아 이미지 목록(캐릭터)에 올리고 표정 줄을 만들어 이름을 적습니다. 편집창을 닫으면 코코포리아에 저장됩니다.'
        : '코코포리아 편집창을 열어 이미지를 올리고 표정 줄을 만든 뒤, 편집창을 닫아 저장합니다.';
      if (blocked !== ccfBlocked) {
        ccfBlocked = blocked;
        drawWarn();
      }
    };
    const watch = setInterval(() => {
      if (!document.contains(ccfLine)) return clearInterval(watch);
      drawCcfState();
    }, 800);

    saveBtn.addEventListener('click', async () => {
      const char = charInp.value.trim();
      const rows = rowsNow();
      saveBtn.disabled = true;
      cancel.disabled = true;
      running = true;
      const giveUp = (why) => {
        running = false;
        cancel.disabled = false;
        saveBtn.textContent = `코코포리아에 넣기 (${files.length}장)`;
        drawCcfState();
        drawWarn();
        toast(why);
      };
      let form = findCcfEditor(char);
      let openedByUs = false;
      if (!form) {
        if (findCcfEditor()) return giveUp('코코포리아에 다른 캐릭터 편집창이 열려 있어요. 닫고 다시 눌러 주세요.');
        saveBtn.textContent = '코코포리아 편집창 여는 중';
        ccfLine.textContent = `코코포리아 "${char}" 편집창을 여는 중`;
        const res = await msg('CCF_OPEN_CHARACTER', { name: char });
        if (!res || !res.ok) {
          return giveUp(
            res && res.why === 'not-found'
              ? notFoundText(char)
              : '코코포리아 편집창을 열지 못했어요. 캐릭터 편집창을 직접 열고 다시 눌러 주세요.'
          );
        }
        form = await waitFor(() => findCcfEditor(char), 5000);
        if (!form) return giveUp('코코포리아 편집창이 열리지 않았어요. 캐릭터 편집창을 직접 열고 다시 눌러 주세요.');
        openedByUs = true;
        // 코코포리아는 창을 연 뒤 표정 줄을 채운다. 채워지기 전에 줄을 더하면 덮일 수 있어 기다린다
        const roomNow = await getRoom();
        const had = (((roomNow.standings || {})[char]) || []).length + (((roomNow.hiddenStandings || {})[char]) || []).length;
        if (had) await waitFor(() => ccfFaceInputs(form).length > 0, 3000);
        await sleepMs(400);
      }
      {
        let stop = false;
        const stopBtn = el('button', 'cst-btn ghost', '멈추기');
        stopBtn.addEventListener('click', () => {
          stop = true;
          stopBtn.disabled = true;
          stopBtn.textContent = '멈추는 중';
        });
        cancel.replaceWith(stopBtn);
        const results = await insertIntoCcfolia(
          form,
          files,
          rows,
          (msg) => {
            saveBtn.textContent = msg;
            ccfLine.textContent = msg;
          },
          // 창을 닫아도(✕ · Esc) 멈춘다 — 멈추기 버튼이 창과 함께 사라지므로
          () => stop || !document.contains(form) || !document.contains(ccfLine)
        );
        // 옷장은 패널이 따로 기억한다 (스탠딩 자체는 코코포리아에서 자동으로 담긴다)
        const ok = results.filter((r) => r.status !== 'fail');
        if (ok.length) {
          const okLabels = new Set(ok.map((x) => x.label));
          await patchRoom((r) => {
            r.wardrobe = r.wardrobe || {};
            const w = r.wardrobe[char] || {};
            for (const x of ok) {
              if (x.outfit) w[x.label] = x.outfit;
              else w[x.label] = ''; // 옷 없음도 정한 값으로 (이름에서 다시 추측하지 않게)
            }
            r.wardrobe[char] = w;
            // 같은 이름을 숨겨 뒀으면 다시 보이게 한다 (새로 넣은 것이 숨김에 걸려 안 보이지 않게)
            if (r.hiddenStandings && r.hiddenStandings[char]) {
              const back = r.hiddenStandings[char].filter((x) => okLabels.has(x.label));
              r.hiddenStandings[char] = r.hiddenStandings[char].filter((x) => !okLabels.has(x.label));
              if (back.length) {
                r.standings = r.standings || {};
                const cur = r.standings[char] || [];
                r.standings[char] = [...cur, ...back.filter((x) => !cur.some((y) => y.label === x.label))];
              }
            }
          });
        }
        running = false;
        clearInterval(watch);
        // 이 창이 연 편집창은 닫아서 코코포리아에 저장한다
        if (openedByUs && document.contains(form)) {
          saveBtn.textContent = '코코포리아에 저장하는 중';
          await sleepMs(150);
          await ccfCloseEditor(form);
        }
        if (ok.length) {
          // 새 이미지로 맞춘다 (숨김에서 되살린 것은 예전 이미지로 들어가 있다)
          lastDetectSig = '';
          scheduleDetect();
        }
        if (ok.length) saveImportFmt(char, result);
        if (preset && ok.length) await applyZipExtras(char, preset.manifest);
        state.currentChar = char;
        renderBody();
        showImportReport(bodyEl, foot, close, char, results, notImages, openedByUs && !document.contains(form) ? 'saved' : 'open');
      }
    });
    foot.append(cancel, saveBtn);
    draw();
    drawCcfState();
    applySavedFmt(charInp.value.trim());
  }

  // zip 넣기 뒤: json 의 확대/위치 · 시트 · 이름 색 · 옷장 순서를 그 캐릭터에 (이미 있는 것은 두고 없는 것만)
  async function applyZipExtras(char, manifest) {
    if (!manifest) return;
    await patchRoom((r) => {
      if (manifest.standingThumb && !((r.standingThumbs || {})[char])) {
        if (r.standingThumbs === undefined) r.standingThumbs = legacyThumbMap(r);
        r.standingThumbs[char] = manifest.standingThumb;
      }
      if (manifest.sheet && !((r.sheets || {})[char])) {
        r.sheets = r.sheets || {};
        r.sheets[char] = manifest.sheet;
      }
      if (manifest.color && !((r.charColors || {})[char])) {
        r.charColors = r.charColors || {};
        r.charColors[char] = manifest.color;
      }
      if (Array.isArray(manifest.wardrobeOutfits) && manifest.wardrobeOutfits.length) {
        r.wardrobeOutfits = r.wardrobeOutfits || {};
        const outs = [...(r.wardrobeOutfits[char] || [])];
        for (const o of manifest.wardrobeOutfits) if (!outs.includes(o)) outs.push(o);
        r.wardrobeOutfits[char] = outs;
      }
    });
  }

  // 가져오기 결과 — 몇 장이 들어갔고, 무엇이 왜 실패했는지
  // ccfState: 'saved' 이 창이 편집창을 열고 닫아 저장함 · 'open' 사용자가 연 편집창에 넣음 (닫으면 저장)
  function showImportReport(bodyEl, foot, close, char, results, notImages, ccfState) {
    const added = results.filter((r) => r.status === 'added');
    const replaced = results.filter((r) => r.status === 'replaced');
    const failed = results.filter((r) => r.status === 'fail');
    const total = results.length + notImages.length;
    bodyEl.innerHTML = '';
    const head = el('div', 'cst-report-head', '');
    head.append(
      el('div', 'cst-report-big', `${added.length + replaced.length} / ${total}장 넣음`),
      el('div', 'cst-report-sub', `"${char}" · 새로 ${added.length} · 바꿔 넣음 ${replaced.length} · 실패 ${failed.length}${notImages.length ? ` · 이미지 아님 ${notImages.length}` : ''}`)
    );
    bodyEl.appendChild(head);
    const section = (title, list, cls) => {
      if (!list.length) return;
      const box = el('div', 'cst-report-sec ' + cls);
      box.appendChild(el('div', 'cst-report-title', `${title} ${list.length}`));
      for (const line of list) box.appendChild(el('div', 'cst-report-line', line));
      bodyEl.appendChild(box);
    };
    section('실패', failed.map((r) => `${r.file}: ${r.why}`), 'fail');
    section('이미지가 아니어서 뺌', notImages.map((n) => n), 'fail');
    section('같은 이름이 있어 바꿔 넣음', replaced.map((r) => `${r.label}  ←  ${r.file}`), 'warn');
    section('새로 넣음', added.map((r) => `${r.outfit ? r.outfit + ' · ' : ''}${r.label}  ←  ${r.file}`), 'ok');
    section(
      '새 이미지가 안 보여 코코포리아에 있던 같은 이름 이미지를 씀',
      [...added, ...replaced].filter((r) => r.reused).map((r) => `${r.label}  ←  ${r.file} (내용이 다르면 편집창에서 확인해 주세요)`),
      'warn'
    );
    if (added.length + replaced.length) {
      bodyEl.insertBefore(
        el(
          'div',
          'cst-modal-ccf on',
          ccfState === 'saved'
            ? '코코포리아 편집창을 닫아 저장했어요.'
            : '코코포리아 편집창을 닫으면 코코포리아에 저장됩니다. 닫기 전에 표정 줄을 확인해 보세요.'
        ),
        head.nextSibling
      );
    }
    foot.innerHTML = '';
    const done = el('button', 'cst-btn', '닫기');
    done.addEventListener('click', close);
    foot.append(el('span', 'cst-modal-note', failed.length ? '실패한 파일은 다시 골라 넣을 수 있어요.' : ''), done);
    toast(
      failed.length
        ? `${added.length + replaced.length}장 넣음 · ${failed.length}장 실패`
        : `"${char}" 스탠딩 ${added.length + replaced.length}장을 넣었어요.`
    );
  }

  // 옷장 · 보낼 이름 고치기
  //  · 옷장: 옷장마다 [이름(누르면 그 옷 전부 선택) 개수 ✎ ✕] · [+ 옷장 추가]. 순서는 room.wardrobeOutfits 에 기억한다
  //  · 여러 장 골라 한 번에 옷장으로 보내기 / 새 옷장 만들어 보내기 / 지우기
  //  · 보낼 이름 = 채팅에 @이름 으로 넣는 이름 = 코코포리아 표정 이름. 둘이 다르면 표정이 안 바뀐다.
  //    이름을 바꾸면 저장할 때 코코포리아 표정 이름도 같이 바꾼다.
  //  · 지우기: 패널에서 숨기기 / [코코포리아에서도 지우기]를 켜면 코코포리아 표정 자체도 지운다
  //  · 패널에서 숨긴 스탠딩은 위쪽 줄에서 다시 보이게 할 수 있다
  async function openStandingEditor() {
    const SN = window.CSTStandingNames;
    // 이미 열려 있으면 그 창을 쓴다 (두 창에서 저장하면 먼저 저장한 옷장이 덮인다)
    if (standingEditorBack && document.contains(standingEditorBack)) {
      const m = standingEditorBack.querySelector('.cst-modal');
      if (m && m.animate) m.animate([{ transform: 'scale(1.03)' }, { transform: 'none' }], 200);
      return;
    }
    const room = await getRoom();
    const char = state.currentChar;
    const list = (room.standings || {})[char] || [];
    const hiddenList = ((room.hiddenStandings || {})[char]) || [];
    if (!list.length && !hiddenList.length) return;
    const ordered = viewStandings(room, char);
    const outfitOf = wardrobeOf(room, char, ordered.map((s) => s.label));

    const { bodyEl, foot, close, back } = openStandingModal(`옷장 · 보낼 이름 고치기 · ${char}`, { float: true, sizeKey: 'wardrobe' });
    standingEditorBack = back;
    bodyEl.appendChild(
      el(
        'div',
        'cst-modal-ccf',
        '보낼 이름은 코코포리아 표정 이름입니다. 바꾸면 저장할 때 코코포리아 표정 이름도 같이 바꿔요.'
      )
    );
    // 패널에서 숨긴 스탠딩 — 누르면 다시 보이게 할 목록에 넣는다
    const restore = new Set();
    if (hiddenList.length) {
      const hid = el('div', 'cst-wd-bar cst-wd-hidden');
      hid.appendChild(el('span', 'cst-modal-lab', '숨긴 스탠딩'));
      for (const x of hiddenList) {
        const chip = el('button', 'cst-wd-add', '↺ ' + x.label);
        chip.title = '저장하면 패널에 다시 보입니다';
        chip.addEventListener('click', () => {
          if (restore.has(x.label)) restore.delete(x.label);
          else restore.add(x.label);
          chip.classList.toggle('on', restore.has(x.label));
          drawWarn();
        });
        hid.appendChild(chip);
      }
      bodyEl.appendChild(hid);
    }
    const wardrobeBar = el('div', 'cst-wd-bar');
    const selBar = el('div', 'cst-wd-selbar');
    const warn = el('div', 'cst-modal-warn');
    const listBox = el('div', 'cst-modal-list');
    const datalist = document.createElement('datalist');
    datalist.id = 'cst-outfits-' + Date.now();
    bodyEl.append(wardrobeBar, selBar, warn, listBox, datalist);

    const rows = ordered.map((s) => ({
      old: s.label,
      label: s.label,
      outfit: outfitOf.get(s.label) || '',
      img: s.img,
      deleted: false,
      selected: false,
    }));
    // 옷장 순서: 기억해 둔 순서 → 나머지는 처음 나온 순서
    let outfits = [...(((room.wardrobeOutfits || {})[char]) || [])];
    const outfitOps = []; // 옷장 이름 바꾸기 · 지우기 [예전, 새 이름('' 은 지움)] — 줄 목록에 없는 숨긴 스탠딩에도 적용
    const syncOutfits = () => {
      for (const r of rows) if (!r.deleted && r.outfit && !outfits.includes(r.outfit)) outfits.push(r.outfit);
      return outfits;
    };
    const live = () => rows.filter((r) => !r.deleted);
    const countIn = (o) => live().filter((r) => r.outfit === o).length;
    const saveBtn = el('button', 'cst-btn', '저장');

    // 새 옷장 이름 넣기 (칩 자리에 입력칸). 고른 스탠딩이 있으면 새 옷장으로 보낸다
    const askName = (initial, onDone) => {
      const box = el('span', 'cst-wd-chip editing');
      const inp = el('input', 'cst-input cst-wd-input');
      inp.value = initial || '';
      inp.placeholder = '옷장 이름';
      box.appendChild(inp);
      let done = false;
      const finish = (ok) => {
        if (done) return;
        done = true;
        onDone(ok ? inp.value.trim() : null);
      };
      inp.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') finish(true);
        else if (e.key === 'Escape') {
          e.stopPropagation();
          finish(false);
        }
      });
      inp.addEventListener('blur', () => finish(true));
      return { box, inp };
    };

    const moveSelected = (to) => {
      for (const r of rows) {
        if (r.selected && !r.deleted) {
          r.outfit = to;
          r.selected = false;
        }
      }
    };

    const addOutfit = (replaceEl) => {
      const { box, inp } = askName('', (name) => {
        if (name) {
          if (!outfits.includes(name)) outfits.push(name);
          moveSelected(name);
        }
        drawAll();
      });
      if (replaceEl) replaceEl.replaceWith(box);
      else wardrobeBar.appendChild(box);
      inp.focus();
    };

    function drawWardrobe() {
      wardrobeBar.innerHTML = '';
      wardrobeBar.appendChild(el('span', 'cst-modal-lab', '옷장'));
      for (const o of syncOutfits()) {
        const chip = el('span', 'cst-wd-chip');
        const name = el('button', 'cst-wd-name', o);
        name.title = '이 옷장 스탠딩을 모두 고르기';
        name.addEventListener('click', () => {
          const mine = live().filter((r) => r.outfit === o);
          const on = !mine.length || !mine.every((r) => r.selected);
          mine.forEach((r) => (r.selected = on));
          drawRows();
        });
        const ren = el('button', 'cst-wd-icon', '✎');
        ren.title = '옷장 이름 바꾸기 (같은 이름이 있으면 합칩니다)';
        ren.addEventListener('click', () => {
          const { box, inp } = askName(o, (next) => {
            if (next && next !== o) {
              for (const r of rows) if (r.outfit === o) r.outfit = next;
              outfitOps.push([o, next]);
              const at = outfits.indexOf(o);
              outfits = outfits.filter((x) => x !== o && x !== next);
              outfits.splice(Math.max(0, at), 0, next);
            }
            drawAll();
          });
          chip.replaceWith(box);
          inp.focus();
          inp.select();
        });
        const del = el('button', 'cst-wd-icon', '✕');
        del.title = '옷장 지우기 (안의 스탠딩은 옷 없음으로)';
        del.addEventListener('click', () => {
          for (const r of rows) if (r.outfit === o) r.outfit = '';
          outfitOps.push([o, '']);
          outfits = outfits.filter((x) => x !== o);
          drawAll();
        });
        chip.append(name, el('span', 'cst-wardrobe-count', String(countIn(o))), ren, del);
        wardrobeBar.appendChild(chip);
      }
      const none = countIn('');
      if (none) {
        const chip = el('span', 'cst-wd-chip muted');
        const name = el('button', 'cst-wd-name', NO_OUTFIT);
        name.title = '옷장이 없는 스탠딩을 모두 고르기';
        name.addEventListener('click', () => {
          const mine = live().filter((r) => !r.outfit);
          const on = !mine.every((r) => r.selected);
          mine.forEach((r) => (r.selected = on));
          drawRows();
        });
        chip.append(name, el('span', 'cst-wardrobe-count', String(none)));
        wardrobeBar.appendChild(chip);
      }
      const add = el('button', 'cst-wd-add', '+ 옷장 추가');
      add.title = '새 옷장을 만듭니다. 고른 스탠딩이 있으면 그 옷장으로 보냅니다.';
      add.addEventListener('click', () => addOutfit(add));
      wardrobeBar.appendChild(add);
      datalist.innerHTML = '';
      for (const o of outfits) {
        const op = document.createElement('option');
        op.value = o;
        datalist.appendChild(op);
      }
    }

    function drawSelBar() {
      selBar.innerHTML = '';
      const all = live();
      const n = all.filter((r) => r.selected).length;
      const allBox = el('input', 'cst-wd-check');
      allBox.type = 'checkbox';
      allBox.checked = n > 0 && n === all.length;
      allBox.indeterminate = n > 0 && n < all.length;
      allBox.title = '전체 고르기';
      allBox.addEventListener('change', () => {
        all.forEach((r) => (r.selected = allBox.checked));
        drawRows();
      });
      selBar.append(allBox, el('span', 'cst-wd-selcount', n ? `${n}장 고름` : '전체'));
      const move = el('select', 'cst-select cst-wd-move');
      const opt = (v, t) => {
        const o = el('option', '', t);
        o.value = v;
        move.appendChild(o);
      };
      opt('', '옷장으로 보내기');
      for (const o of outfits) opt('o:' + o, o);
      opt('none', NO_OUTFIT + ' (옷장 빼기)');
      opt('new', '새 옷장 만들어 보내기');
      move.disabled = !n;
      move.addEventListener('change', () => {
        const v = move.value;
        move.value = '';
        if (v === 'new') return addOutfit(null);
        if (v === 'none') moveSelected('');
        else if (v.startsWith('o:')) moveSelected(v.slice(2));
        drawAll();
      });
      const delSel = el('button', 'cst-btn ghost cst-mini-btn', '고른 것 지우기');
      delSel.disabled = !n;
      delSel.addEventListener('click', () => {
        for (const r of rows) {
          if (r.selected) {
            r.deleted = true;
            r.selected = false;
          }
        }
        drawAll();
      });
      selBar.append(move, delSel);
    }

    const drawWarn = () => {
      const alive = live();
      const count = new Map();
      for (const r of alive) count.set(r.label, (count.get(r.label) || 0) + 1);
      const dups = [...count].filter(([k, v]) => k && v > 1).map(([k]) => k);
      // 줄 목록 밖에서 코코포리아에 남는 이름(숨긴 스탠딩 · 패널에서만 지우는 줄)과도 겹치면 안 된다
      // (겹치면 코코포리아에 같은 이름 표정이 둘 생기고, 숨김에 걸려 둘 다 안 보인다)
      const outside = new Set([
        ...hiddenList.map((x) => x.label),
        ...rows.filter((r) => r.deleted && !ccfDelete.checked).map((r) => r.old),
      ]);
      const clash = [...new Set([
        ...alive.filter((r) => r.label && r.label !== r.old && outside.has(r.label)).map((r) => r.label),
        ...hiddenList.filter((x) => restore.has(x.label) && count.has(x.label)).map((x) => x.label),
      ])];
      const empty = alive.filter((r) => !r.label).length;
      const msgs = [];
      if (dups.length) msgs.push(`보낼 이름이 겹쳐요: ${dups.join(', ')}`);
      if (clash.length) msgs.push(`숨긴(또는 이번에 숨기는) 스탠딩과 이름이 겹쳐요: ${clash.join(', ')}`);
      if (empty) msgs.push(`보낼 이름이 빈 스탠딩 ${empty}장`);
      if (SN) for (const t of SN.findTypos(alive.map((r) => r.outfit))) msgs.push(`옷장 '${t.value}' 는 '${t.suggest}' 의 오타 같아요`);
      const gone = rows.filter((r) => r.deleted).length;
      if (gone) msgs.push(ccfDelete.checked ? `저장하면 코코포리아와 패널에서 ${gone}장을 지웁니다` : `저장하면 패널에서 ${gone}장을 숨깁니다`);
      if (restore.size) msgs.push(`저장하면 숨긴 스탠딩 ${restore.size}장을 다시 보이게 합니다`);
      warn.textContent = msgs.join('\n');
      warn.hidden = !msgs.length;
      [...listBox.querySelectorAll('.cst-modal-label')].forEach((inp, k) =>
        inp.classList.toggle('dup', !rows[k].deleted && (dups.includes(rows[k].label) || clash.includes(rows[k].label) || !rows[k].label))
      );
      saveBtn.disabled = !!(dups.length || clash.length || empty);
    };

    function drawRows() {
      listBox.innerHTML = '';
      rows.forEach((r) => {
        const row = el('div', 'cst-modal-item' + (r.deleted ? ' deleted' : '') + (r.selected ? ' selected' : ''));
        const check = el('input', 'cst-wd-check');
        check.type = 'checkbox';
        check.checked = r.selected;
        check.disabled = r.deleted;
        check.addEventListener('change', () => {
          r.selected = check.checked;
          row.classList.toggle('selected', r.selected);
          drawSelBar();
        });
        row.appendChild(check);
        if (r.img) {
          const img = document.createElement('img');
          img.src = r.img;
          img.alt = '';
          row.appendChild(img);
        } else {
          const ph = el('span', 'cst-modal-noimg');
          ph.innerHTML = window.faIcon ? window.faIcon('avatar') : '';
          row.appendChild(ph);
        }
        const fields = el('div', 'cst-modal-fields');
        const outfitInp = el('input', 'cst-input cst-modal-outfit');
        outfitInp.placeholder = '옷장';
        outfitInp.setAttribute('list', datalist.id);
        outfitInp.value = r.outfit;
        outfitInp.addEventListener('input', () => {
          r.outfit = outfitInp.value.trim();
          drawWarn();
        });
        outfitInp.addEventListener('change', () => drawWardrobe());
        const labelInp = el('input', 'cst-input cst-modal-label');
        labelInp.placeholder = '보낼 이름';
        labelInp.value = r.label;
        const preview = el('span', 'cst-modal-send');
        const drawPreview = () => {
          preview.textContent = r.label ? `채팅에 ${state.atPrefix ? '@' : ''}${r.label}` : '';
        };
        labelInp.title = '코코포리아 표정 이름입니다. 바꾸면 저장할 때 코코포리아 표정 이름도 바꿉니다.';
        labelInp.addEventListener('input', () => {
          r.label = labelInp.value.trim();
          drawPreview();
          drawWarn();
        });
        drawPreview();
        const nameBox = el('div', 'cst-modal-namebox');
        nameBox.append(labelInp, preview);
        const del = el('button', 'cst-iconbtn cst-modal-del', r.deleted ? '↺' : '✕');
        del.title = r.deleted ? '지우기 취소' : '지우기 (코코포리아에서도 지우기를 안 켜면 패널에서만 숨김)';
        del.addEventListener('click', () => {
          r.deleted = !r.deleted;
          r.selected = false;
          drawAll();
        });
        fields.append(outfitInp, nameBox);
        row.append(fields, del);
        listBox.appendChild(row);
      });
      drawSelBar();
      drawWarn();
    }

    function drawAll() {
      drawWardrobe();
      drawRows();
    }

    // 지운 것을 코코포리아에서도 지울지 (끄면 패널에서만 숨김)
    const ccfDelWrap = el('label', 'cst-wd-ccfdel');
    const ccfDelete = el('input', 'cst-wd-check');
    ccfDelete.type = 'checkbox';
    ccfDelete.addEventListener('change', drawWarn);
    ccfDelWrap.append(ccfDelete, el('span', '', '코코포리아에서도 지우기'));
    ccfDelWrap.title = '켜면 지운 스탠딩을 코코포리아 캐릭터에서도 지웁니다. 끄면 패널에서만 숨깁니다.';

    const cancel = el('button', 'cst-btn ghost', '취소');
    cancel.addEventListener('click', close);
    saveBtn.addEventListener('click', async () => {
      saveBtn.disabled = true;
      cancel.disabled = true;
      const snap = await snapshotChar(char); // 되돌리기용
      let ccfBefore = null;
      // 1) 코코포리아에 적용할 것: 이름 바꾸기 · (켰으면) 지우기
      const ccfRenames = rows.filter((r) => !r.deleted && r.old !== r.label);
      const ccfDeletes = ccfDelete.checked ? rows.filter((r) => r.deleted) : [];
      // 코코포리아가 받아들인 것만 패널에도 적용한다 (못 바꾼 이름을 패널만 바꾸면 @이름 이 안 먹는다)
      const renameOk = new Set(); // 이름을 바꿔도 되는 예전 이름 (코코포리아에서 바꿈 · 코코포리아에 원래 없음)
      const deleteOk = new Set(); // 완전히 지워도 되는 예전 이름
      let ccfNote = '';
      if (ccfRenames.length || ccfDeletes.length) {
        saveBtn.textContent = '코코포리아에 적용하는 중';
        const direct = await ccfDirect(char, {
          kind: 'edit',
          remove: ccfDeletes.map((r) => r.old),
          rename: ccfRenames.map((r) => [r.old, r.label]),
        });
        if (direct.ok && direct.before) ccfBefore = direct.before;
        const run = direct.ok
          ? { ok: true, openedByUs: true, result: direct }
          : directFatal(direct)
            ? { ok: false, why: notFoundText(char) }
            : await withCcfEditor(
                char,
                async (liveForm) => {
                  const out = { renamedLabels: [], removedLabels: [], missing: [], skipped: [] };
                  for (const r of ccfDeletes) {
                    const inp = ccfFaceInputs(liveForm).find((i) => i.value.trim() === r.old);
                    const btn = inp && ccfFaceRowButtons(inp).remove;
                    if (!btn) {
                      if (!inp) out.missing.push(r.old);
                      continue;
                    }
                    const before = ccfFaceInputs(liveForm).length;
                    btn.click();
                    if (await waitFor(() => ccfFaceInputs(liveForm).length < before, 1500)) out.removedLabels.push(r.old);
                  }
                  // 칸을 먼저 다 찾은 뒤 바꾼다 (a→b · b→a 처럼 서로 바꿔도 같은 칸을 두 번 고치지 않게)
                  const inputs = ccfFaceInputs(liveForm);
                  const targets = ccfRenames.map((r) => ({ r, inp: inputs.find((i) => i.value.trim() === r.old) }));
                  for (const { r, inp } of targets) {
                    if (!inp) {
                      out.missing.push(r.old);
                      continue;
                    }
                    setNativeValue(inp, r.label);
                    out.renamedLabels.push(r.old);
                  }
                  return out;
                },
                [...ccfRenames, ...ccfDeletes].map((r) => r.old)
              );
        if (!run.ok) ccfNote = ` 코코포리아에는 적용하지 못해 이름 바꾸기 · 지우기는 패널에도 적용하지 않았어요: ${run.why}`;
        else {
          const x = run.result || {};
          for (const l of x.renamedLabels || []) renameOk.add(l);
          for (const l of x.removedLabels || []) deleteOk.add(l);
          // 코코포리아에 원래 없던 이름은 패널에서만 고치면 된다
          for (const l of x.missing || []) {
            renameOk.add(l);
            deleteOk.add(l);
          }
          const bits = [];
          if ((x.renamedLabels || []).length) bits.push(`이름 ${x.renamedLabels.length}개`);
          if ((x.removedLabels || []).length) bits.push(`지우기 ${x.removedLabels.length}개`);
          if (bits.length) ccfNote = ` 코코포리아에도 ${bits.join(' · ')} 적용${run.openedByUs ? '' : ' (편집창을 닫으면 저장)'}.`;
          if ((x.skipped || []).length) ccfNote += ` 코코포리아에 같은 이름이 있어 못 바꾼 것: ${x.skipped.join(', ')}.`;
        }
      }
      // 2) 패널
      // 코코포리아에서 못 바꾼 이름은 예전 이름 그대로 둔다
      const finalLabel = (r) => (r.old !== r.label && !renameOk.has(r.old) ? r.old : r.label);
      const keptNames = rows.filter((r) => !r.deleted && r.label !== finalLabel(r));
      const deleted = rows.filter((r) => r.deleted);
      // 완전히 지우는 것: 코코포리아에서도 지운 것 (코코포리아에 원래 없던 것 포함). 코코포리아에 남는 것은 숨긴다
      const hardGone = new Set(deleted.filter((r) => deleteOk.has(r.old)).map((r) => r.old));
      const hideGone = deleted.filter((r) => !hardGone.has(r.old));
      const keepOutfits = syncOutfits().slice();
      const rowLabels = new Set(rows.map((r) => r.old));
      await patchRoom((room2) => {
        room2.standings = room2.standings || {};
        const alive = new Map(rows.filter((r) => !r.deleted).map((r) => [r.old, r]));
        const cur = room2.standings[char] || [];
        const goneAll = new Set(deleted.map((r) => r.old));
        // 숨길 것은 숨김 목록으로
        room2.hiddenStandings = room2.hiddenStandings || {};
        const hiddenPrev = room2.hiddenStandings[char] || [];
        let hiddenNow = hiddenPrev.filter((x) => !restore.has(x.label) && !hardGone.has(x.label));
        const back = hiddenPrev.filter((x) => restore.has(x.label));
        for (const r of hideGone) {
          const e = cur.find((x) => x.label === r.old);
          if (e) {
            const { main, ...rest } = e;
            hiddenNow = [...hiddenNow.filter((x) => x.label !== r.old), rest];
          }
        }
        room2.hiddenStandings[char] = hiddenNow;
        room2.standings[char] = [
          ...cur.filter((x) => !goneAll.has(x.label)).map((x) => (alive.get(x.label) ? { ...x, label: finalLabel(alive.get(x.label)) } : x)),
          ...back.filter((x) => !cur.some((y) => y.label === x.label)),
        ];
        room2.standingOrder = room2.standingOrder || {};
        room2.standingOrder[char] = (room2.standingOrder[char] || [])
          .filter((l) => !hardGone.has(l))
          .map((l) => (alive.get(l) ? finalLabel(alive.get(l)) : l));
        room2.wardrobe = room2.wardrobe || {};
        const w = { ...(room2.wardrobe[char] || {}) };
        // 옷장 이름 바꾸기 · 지우기는 줄 목록에 없는 숨긴 스탠딩에도 적용한다
        for (const [from, to] of outfitOps) {
          for (const k of Object.keys(w)) if (!rowLabels.has(k) && w[k] === from) w[k] = to;
        }
        // 이름이 엇갈려 바뀌어도(a→b · b→a) 옷장을 잃지 않게: 예전 이름을 먼저 다 지우고 새 이름으로 쓴다
        for (const r of rows) {
          if (hardGone.has(r.old) || (!r.deleted && finalLabel(r) !== r.old)) delete w[r.old];
        }
        for (const r of rows) {
          if (r.deleted) continue; // 숨긴 것은 옷장 그대로 (다시 보이면 제자리)
          // 옷 없음('')도 정한 값으로 남긴다 — 비워 두면 '잠옷_졸림' 같은 이름에서 옷을 다시 추측해 버린다
          w[finalLabel(r)] = r.outfit || '';
        }
        room2.wardrobe[char] = w;
        // 옷장 순서 (비어 있는 옷장도 기억해 두면 다음에 바로 보낼 수 있다)
        room2.wardrobeOutfits = room2.wardrobeOutfits || {};
        room2.wardrobeOutfits[char] = keepOutfits;
      });
      close();
      const parts = [];
      if (hardGone.size) parts.push(`${hardGone.size}장 지움`);
      if (hideGone.length) parts.push(`${hideGone.length}장 숨김`);
      if (restore.size) parts.push(`${restore.size}장 다시 보이기`);
      if (keptNames.length) parts.push(`이름 ${keptNames.length}개는 코코포리아에 못 바꿔 그대로`);
      renderBody();
      undoToast((parts.length ? parts.join(' · ') + '. ' : '') + '옷장과 보낼 이름을 저장했어요.' + ccfNote, char, snap, ccfBefore);
    });
    foot.append(ccfDelWrap, cancel, saveBtn);
    drawAll();
  }

  // ----- 스탠딩 zip 받기 · 넣기 -----
  // zip 안: [옷장/]표정 이름.확장자 + cocofo-standings.json (이름 · 옷장 · 순서 · 확대/위치 · 시트 · 이름 색)
  // 넣을 때는 json 대로 이름 · 옷장을 채운 가져오기 창을 연다 (코코포리아 편집창이 열려 있으면 코코포리아에 넣기).
  const ZIP_MANIFEST = 'cocofo-standings.json';
  const safeFileName = (s) => String(s || '').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').trim() || '이름없음';
  const extOfMime = (m) => ({ 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif', 'image/avif': 'avif', 'image/bmp': 'bmp' })[String(m || '').split(';')[0].trim()] || '';
  function downloadBlob(blob, name) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }

  async function exportStandingZip(char) {
    if (!window.CSTUnzip || !window.CSTUnzip.zip) return toast('zip 도구를 불러오지 못했어요. 페이지를 새로고침해 주세요.');
    const room = await getRoom();
    const list = sortStandings(room, char, 'manual');
    if (!list.length) return toast('받을 스탠딩이 없어요.');
    const outfitMap = wardrobeOf(room, char, list.map((s) => s.label));
    toast(`"${char}" 스탠딩 ${list.length}장을 모으는 중…`);
    const files = [];
    const entries = [];
    const used = new Set();
    let failed = 0;
    for (const s of list) {
      try {
        // 코코포리아 이미지는 브라우저에 이미 받아 둔 것을 먼저 쓴다 (새로 받는 일을 줄이게)
        const res = await fetch(s.img, { cache: 'force-cache' });
        if (!res.ok) throw new Error(String(res.status));
        const blob = await res.blob();
        const ext = extOfMime(blob.type) || (String(s.img).match(/\.(png|jpe?g|webp|gif|avif|bmp)(?:[?#]|$)/i) || [])[1] || 'png';
        const outfit = outfitMap.get(s.label) || '';
        let path = (outfit ? safeFileName(outfit) + '/' : '') + safeFileName(s.label) + '.' + ext.toLowerCase();
        for (let n = 2; used.has(path); n++) path = path.replace(/(\.[^.]+)$/, ` (${n})$1`);
        used.add(path);
        files.push({ name: path, bytes: new Uint8Array(await blob.arrayBuffer()) });
        entries.push({ file: path, label: s.label, outfit, main: !!s.main });
      } catch (e) {
        failed++;
      }
    }
    if (!files.length) return toast('이미지를 하나도 받지 못했어요.');
    const manifest = {
      kind: 'cst-standings',
      version: 1,
      name: char,
      exportedAt: new Date().toISOString(),
      standings: entries,
      wardrobeOutfits: ((room.wardrobeOutfits || {})[char]) || [],
      standingThumb: ((room.standingThumbs || {})[char]) || null,
      sheet: ((room.sheets || {})[char]) || null,
      color: ((room.charColors || {})[char]) || '',
    };
    files.push({ name: ZIP_MANIFEST, bytes: new TextEncoder().encode(JSON.stringify(manifest, null, 2)) });
    downloadBlob(window.CSTUnzip.zip(files), `${safeFileName(char)}_스탠딩.zip`);
    toast(`"${char}" 스탠딩 ${entries.length}장을 zip 으로 받았어요.` + (failed ? ` (${failed}장은 이미지를 받지 못해 뺐어요)` : ''));
  }

  function pickStandingZip() {
    const inp = document.createElement('input');
    inp.type = 'file';
    inp.accept = '.zip,application/zip';
    inp.addEventListener('change', () => {
      const f = inp.files && inp.files[0];
      if (f) importFiles([f]);
    });
    inp.click();
  }

  // zip 풀기 → 이미지 File 들 + json (있으면)
  async function filesFromZip(file) {
    const entries = await window.CSTUnzip.unzip(await file.arrayBuffer());
    let manifest = null;
    const images = [];
    for (const e of entries) {
      const base = e.name.split('/').pop();
      if (base === ZIP_MANIFEST) {
        try {
          manifest = JSON.parse(new TextDecoder().decode(e.bytes));
        } catch (_) {}
        continue;
      }
      if (!/\.(png|jpe?g|webp|gif|avif|bmp)$/i.test(base)) continue;
      const ext = base.split('.').pop().toLowerCase();
      const type = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif', avif: 'image/avif', bmp: 'image/bmp' }[ext];
      const f = new File([e.bytes], base, { type });
      f.zipPath = e.name;
      images.push(f);
    }
    return { images, manifest: manifest && manifest.kind === 'cst-standings' ? manifest : null };
  }

  // ----- 캐릭터를 다른 방으로 복사 / 다른 방에서 가져오기 -----
  // 이 확장이 방마다 기억하는 캐릭터 기록(옷장 · 확대/위치 · 시트 · 이름 색)을 옮긴다.
  // 스탠딩은 패널에만 둘 수 없으니 다른 방에서 가져올 때 이 방 코코포리아 캐릭터 표정으로 넣는다
  // (이미 코코포리아에 올라간 이미지 주소라 다시 올리지 않는다). 다른 방으로 보낼 때는 스탠딩을 옮기지 않는다.
  const COPY_PARTS = [
    ['standings', '스탠딩'],
    ['wardrobe', '옷장'],
    ['thumb', '확대 · 위치'],
    ['sheet', '시트'],
    ['color', '이름 색'],
  ];
  function charPartsOf(room, char) {
    return {
      standings: ((room.standings || {})[char] || []).filter((s) => CCF_IMAGE_URL.test(s.img || '')).length,
      wardrobe: Object.keys(((room.wardrobe || {})[char]) || {}).length + (((room.wardrobeOutfits || {})[char]) || []).length,
      thumb: !!((room.standingThumbs || {})[char]),
      sheet: !!((room.sheets || {})[char]),
      color: !!((room.charColors || {})[char]),
    };
  }
  // 옛 공통 확대 · 위치 값을 그 방 캐릭터들에 나눠 준 지도 (useThumbOf 와 같은 규칙)
  function legacyThumbMap(room) {
    const legacy = state.legacyThumb;
    const changed = legacy && ['zoom', 'posX', 'posY'].some((k) => Number(legacy[k]) !== THUMB_DEFAULT[k]);
    const map = {};
    if (changed) for (const c of knownChars(room)) map[c] = { ...THUMB_DEFAULT, ...legacy };
    return map;
  }
  // src 방의 char 기록(옷장 · 확대/위치 · 시트 · 이름 색)을 dst 방 기록에 넣는다. keepTarget: 같은 표정의 옷은 dst 것을 둔다.
  // 스탠딩은 여기서 옮기지 않는다 (addFacesToCcfolia). 반환: 넣은 것 요약
  function copyCharInto(dst, src, char, parts, keepTarget) {
    const clone = (v) => JSON.parse(JSON.stringify(v));
    const done = [];
    if (parts.wardrobe) {
      dst.wardrobe = dst.wardrobe || {};
      dst.wardrobeOutfits = dst.wardrobeOutfits || {};
      const a = clone(((src.wardrobe || {})[char]) || {});
      const b = (dst.wardrobe[char]) || {};
      dst.wardrobe[char] = keepTarget ? { ...a, ...b } : { ...b, ...a };
      const outs = [...((dst.wardrobeOutfits[char]) || [])];
      for (const o of ((src.wardrobeOutfits || {})[char]) || []) if (!outs.includes(o)) outs.push(o);
      dst.wardrobeOutfits[char] = outs;
      done.push('옷장');
    }
    if (parts.thumb && (src.standingThumbs || {})[char]) {
      if (dst.standingThumbs === undefined) dst.standingThumbs = legacyThumbMap(dst);
      dst.standingThumbs[char] = clone(src.standingThumbs[char]);
      done.push('확대 · 위치');
    }
    if (parts.sheet && (src.sheets || {})[char]) {
      dst.sheets = dst.sheets || {};
      dst.sheets[char] = clone(src.sheets[char]);
      done.push('시트');
    }
    if (parts.color && (src.charColors || {})[char]) {
      dst.charColors = dst.charColors || {};
      dst.charColors[char] = src.charColors[char];
      done.push('이름 색');
    }
    return done;
  }

  const roomLabel = (id, r) => (r && r.name) || id;
  const shortDate = (t) => {
    if (!t) return '';
    const d = new Date(t);
    return `${d.getMonth() + 1}/${d.getDate()}`;
  };

  // 다른 방 · JSON 의 스탠딩을 이 방 코코포리아 캐릭터 표정으로 넣는다 (편집창 없이, 코코포리아에 올라간 이미지 주소만).
  // 같은 이름 표정은 replace 일 때만 바꾼다. 캐릭터에 말 이미지가 없으면 기본 스탠딩으로 채운다.
  // 반환: 페이지 쪽 결과 { ok, why?, added, replaced, skipped, before }
  async function addFacesToCcfolia(char, standings, replace) {
    const usable = (standings || []).filter((s) => s && s.label && CCF_IMAGE_URL.test(s.img || ''));
    if (!usable.length) return { ok: true, added: 0, replaced: 0, skipped: [] };
    const main = usable.find((s) => s.main);
    return ccfDirect(char, {
      kind: 'addFaces',
      faces: usable.map((s) => ({ label: s.label, iconUrl: s.img })),
      replace: !!replace,
      iconUrl: main ? main.img : '',
    });
  }
  const ccfWhyText = (char, why) =>
    why === 'not-found'
      ? `코코포리아에 "${char}" 캐릭터가 없어 스탠딩을 못 넣었어요`
      : why === 'editor-open'
        ? `"${char}" 편집창이 열려 있어 스탠딩을 못 넣었어요 (닫고 다시)`
        : `"${char}" 스탠딩을 코코포리아에 넣지 못했어요`;

  // 옮길 것 고르기 줄 (체크) — 있는 것만 켤 수 있다
  function copyPartsRow(bodyEl, counts, parts = COPY_PARTS) {
    const box = el('div', 'cst-copy-parts');
    const picks = {};
    for (const [k, t] of parts) {
      const has = !!counts[k];
      const lab = el('label', 'cst-copy-part' + (has ? '' : ' off'));
      if (k === 'standings') lab.title = '이 방 코코포리아 캐릭터 표정으로 넣습니다. 이미 올라간 이미지라 다시 올리지 않아요.';
      const cb = el('input', 'cst-wd-check');
      cb.type = 'checkbox';
      cb.checked = has;
      cb.disabled = !has;
      picks[k] = cb;
      const n = k === 'standings' && counts[k] ? ` ${counts[k]}장` : '';
      lab.append(cb, el('span', '', t + n));
      box.appendChild(lab);
    }
    bodyEl.appendChild(box);
    return () => Object.fromEntries(Object.entries(picks).map(([k, cb]) => [k, cb.checked && !cb.disabled]));
  }
  function keepRow(bodyEl) {
    const row = el('div', 'cst-modal-row');
    row.appendChild(el('label', 'cst-modal-lab', '같은 표정'));
    const sel = el('select', 'cst-select');
    for (const [v, t] of [['keep', '받는 방에 있는 것은 그대로'], ['replace', '보내는 쪽 것으로 바꾸기']]) {
      const o = el('option', '', t);
      o.value = v;
      sel.appendChild(o);
    }
    row.appendChild(sel);
    bodyEl.appendChild(row);
    return () => sel.value !== 'replace';
  }

  // 이 방 캐릭터 → 다른 방
  async function openCopyCharacter(char) {
    if (!char) return;
    const rooms = await RoomStore.loadAll();
    const here = rooms[roomId] || (await getRoom());
    const others = Object.entries(rooms)
      .filter(([id]) => id !== roomId)
      .sort((a, b) => (b[1].lastVisit || 0) - (a[1].lastVisit || 0));
    if (!others.length) return toast('복사할 다른 방 기록이 없어요. 다른 방에 한 번 들어가면 목록에 생겨요.');
    const { bodyEl, foot, close } = openStandingModal(`"${char}" 다른 방에 복사`);
    bodyEl.appendChild(el('div', 'cst-hint cst-hint-help', '고른 방의 패널 기록에 이 캐릭터의 옷장 · 확대/위치 · 시트 · 이름 색을 넣습니다. 스탠딩은 그 방에서 [다른 방에서 가져오기]로 코코포리아 캐릭터에 넣어요.'));
    const list = el('div', 'cst-copy-rooms');
    let target = '';
    const saveBtn = el('button', 'cst-btn', '복사');
    saveBtn.disabled = true;
    for (const [id, r] of others) {
      const row = el('label', 'cst-copy-room');
      const rb = el('input', '');
      rb.type = 'radio';
      rb.name = 'cst-copy-room';
      rb.addEventListener('change', () => {
        target = id;
        saveBtn.disabled = false;
        list.querySelectorAll('.cst-copy-room').forEach((x) => x.classList.toggle('on', x === row));
      });
      const has = knownChars(r).includes(char);
      row.append(rb, el('span', 'cst-copy-name', roomLabel(id, r)), el('span', 'cst-copy-meta', (has ? '같은 캐릭터 있음 · ' : '') + shortDate(r.lastVisit)));
      list.appendChild(row);
    }
    bodyEl.appendChild(list);
    const partsOf = copyPartsRow(bodyEl, charPartsOf(here, char), COPY_PARTS.filter(([k]) => k !== 'standings'));
    const keepOf = keepRow(bodyEl);
    const cancel = el('button', 'cst-btn ghost', '취소');
    cancel.addEventListener('click', close);
    saveBtn.addEventListener('click', async () => {
      if (!target) return;
      saveBtn.disabled = true;
      let done = [];
      try {
        const src = (await RoomStore.loadRoom(roomId)) || here;
        await patchRoomById(target, (dst) => {
          done = copyCharInto(dst, src, char, partsOf(), keepOf());
        });
      } catch (e) {
        saveBtn.disabled = false;
        return toast('복사하지 못했어요. 그 방 기록을 찾지 못했습니다.');
      }
      close();
      toast(`"${roomLabel(target, rooms[target])}" 에 "${char}" 복사 · ${done.join(' · ') || '넣은 것 없음'}`);
    });
    foot.append(cancel, saveBtn);
  }

  // 다른 방 캐릭터 → 이 방 (캐릭터 JSON 가져오기 창에서)
  async function openCopyFromRoom() {
    const rooms = await RoomStore.loadAll();
    const others = Object.entries(rooms)
      .filter(([id, r]) => id !== roomId && knownChars(r).length)
      .sort((a, b) => (b[1].lastVisit || 0) - (a[1].lastVisit || 0));
    if (!others.length) return toast('캐릭터를 기억하는 다른 방이 없어요.');
    const { bodyEl, foot, close } = openStandingModal('다른 방에서 캐릭터 가져오기');
    bodyEl.appendChild(el('div', 'cst-hint cst-hint-help', '스탠딩은 이 방 코코포리아 캐릭터 표정으로 넣고(이미 올라간 이미지라 다시 올리지 않아요), 옷장 · 확대/위치 · 시트 · 이름 색은 패널에 담습니다.'));
    const roomRow = el('div', 'cst-modal-row');
    roomRow.appendChild(el('label', 'cst-modal-lab', '방'));
    const roomSel = el('select', 'cst-select');
    for (const [id, r] of others) {
      const o = el('option', '', `${roomLabel(id, r)} · ${knownChars(r).length}명`);
      o.value = id;
      roomSel.appendChild(o);
    }
    roomRow.appendChild(roomSel);
    bodyEl.appendChild(roomRow);
    const charBox = el('div', 'cst-copy-rooms');
    bodyEl.appendChild(charBox);
    const partsHost = el('div', '');
    bodyEl.appendChild(partsHost);
    const keepOf = keepRow(bodyEl);
    const saveBtn = el('button', 'cst-btn', '이 방으로 가져오기');
    let partsOf = () => ({});
    let picked = new Set();
    const here = await getRoom();
    const drawChars = () => {
      const src = rooms[roomSel.value];
      charBox.innerHTML = '';
      picked = new Set();
      const all = { standings: 0, wardrobe: 0, thumb: false, sheet: false, color: false };
      for (const c of knownChars(src)) {
        const counts = charPartsOf(src, c);
        for (const k of Object.keys(all)) all[k] = k === 'standings' ? all[k] + counts[k] : all[k] || counts[k];
        const row = el('label', 'cst-copy-room');
        const cb = el('input', 'cst-wd-check');
        cb.type = 'checkbox';
        cb.addEventListener('change', () => {
          if (cb.checked) picked.add(c);
          else picked.delete(c);
          row.classList.toggle('on', cb.checked);
          saveBtn.disabled = !picked.size;
        });
        const bits = [counts.standings ? `스탠딩 ${counts.standings}` : '', counts.sheet ? '시트' : ''].filter(Boolean).join(' · ');
        row.append(cb, el('span', 'cst-copy-name', c), el('span', 'cst-copy-meta', (knownChars(here).includes(c) ? '이 방에 있음 · ' : '') + (bits || '이름만')));
        charBox.appendChild(row);
      }
      partsHost.innerHTML = '';
      partsOf = copyPartsRow(partsHost, all);
      saveBtn.disabled = true;
    };
    roomSel.addEventListener('change', drawChars);
    drawChars();
    const cancel = el('button', 'cst-btn ghost', '취소');
    cancel.addEventListener('click', close);
    saveBtn.addEventListener('click', async () => {
      if (!picked.size) return;
      saveBtn.disabled = true;
      const src = rooms[roomSel.value];
      const parts = partsOf();
      const keep = keepOf();
      const names = [...picked];
      const snap = names.length === 1 ? await snapshotChar(names[0]) : null; // 한 명이면 [되돌리기]
      await patchRoom((dst) => {
        for (const c of names) copyCharInto(dst, src, c, parts, keep);
      });
      const notes = [];
      let faces = 0;
      let before = null;
      if (parts.standings) {
        saveBtn.textContent = '코코포리아에 넣는 중';
        for (const c of names) {
          const res = await addFacesToCcfolia(c, sortStandings(src, c, 'manual'), !keep);
          if (!res || !res.ok) {
            notes.push(ccfWhyText(c, res && res.why));
            continue;
          }
          faces += (res.added || 0) + (res.replaced || 0);
          if (res.before) before = res.before;
        }
      }
      close();
      if (!state.currentChar) state.currentChar = names[0];
      const text =
        `"${roomLabel(roomSel.value, src)}" 에서 캐릭터 ${names.length}명을 가져왔어요.` +
        (parts.standings ? ` 코코포리아에 표정 ${faces}장을 넣었어요.` : '') +
        (notes.length ? ` ${notes.join(' · ')}.` : '');
      if (snap) undoToast(text, names[0], snap, before);
      else toast(text);
      renderBody();
    });
    foot.append(cancel, saveBtn);
  }

  // ----- 캐릭터 JSON (코코포리아 형식) 복사 · 가져오기 -----
  // 코코포리아 캐릭터 말 형식 { kind: 'character', data } — 캐릭터 시트 사이트들이 내보내는 것과 같고,
  // 코코포리아 방 화면에서 Ctrl+V 로 붙여넣으면 캐릭터가 새로 생긴다.
  // 코코포리아가 캐릭터를 붙여넣을 때 그대로 두는 이미지 주소 (그 밖은 비운다 — 2026-09 번들)
  const CCF_IMAGE_URL = /^https:\/\/(firebasestorage\.googleapis\.com\/v0\/b\/ccfolia-160aa\.appspot\.com\/o|(storage|go|sound-master-assets)\.ccfolia-cdn\.net)/i;
  function toCcfoliaCharacter(name, sheet, standings, color) {
    const num = (v) => {
      const t = String(v == null ? '' : v).trim();
      return t !== '' && Number.isFinite(Number(t)) ? Number(t) : 0;
    };
    const sh = sheet || {};
    // 코코포리아는 붙여넣을 때 자기 저장소 주소가 아닌 이미지는 비운다 → 다른 사이트 이미지는 뺀다
    const usable = (standings || []).filter((s) => s.label && CCF_IMAGE_URL.test(s.img || ''));
    const faces = usable.map((s) => ({ label: s.label, iconUrl: s.img }));
    // 말 이미지: 기본 스탠딩(없으면 첫 표정)
    const main = usable.find((s) => s.main) || usable[0];
    const data = {
      name,
      initiative: num(sh.initiative),
      externalUrl: sh.externalUrl || '',
      status: (sh.status || []).map((x) => ({ label: x.label, value: num(x.value), max: num(x.max) })),
      params: (sh.params || []).map((x) => ({ label: x.label, value: String(x.value == null ? '' : x.value) })),
      faces,
      commands: sh.commands || '',
      memo: sh.memo || '',
    };
    if (main) data.iconUrl = main.img;
    if (color) data.color = color;
    return { kind: 'character', data };
  }

  // 붙여넣은 글이나 파일 → [{ name, sheet, standings }]
  // 받는 것: 코코포리아 캐릭터 JSON(여러 개 · 한 줄에 하나씩도), 코코포선생 '시트 전부 파일로 저장' 파일, 예전 '시트 JSON 복사'
  function parseCharacterJson(text) {
    const src = String(text || '').trim();
    if (!src) return { list: [], error: '' };
    let values = [];
    let bad = 0;
    try {
      values = [JSON.parse(src)];
    } catch (_) {
      // JSON 여러 개를 이어 붙인 경우 (한 줄에 하나씩 · 줄바꿈 없이 {…}{…} · 보기 좋게 펼친 것 여러 개)
      for (const part of splitJsonValues(src)) {
        try {
          values.push(JSON.parse(part));
        } catch (e) {
          bad++;
        }
      }
      if (!values.length) return { list: [], error: 'JSON 으로 읽을 수 없습니다. 복사한 내용이 다 들어왔는지 확인해 주세요.' };
    }
    const byName = new Map();
    const add = (name, sheet, standings, color) => {
      name = String(name || '').trim();
      if (!name) return;
      const cur = byName.get(name) || { name, sheet: null, standings: [], color: '' };
      if (sheet) cur.sheet = sheet;
      if (standings && standings.length) cur.standings = standings;
      if (color && /^#[0-9a-f]{3,8}$/i.test(color)) cur.color = color;
      byName.set(name, cur);
    };
    const str = (v) => String(v == null ? '' : v);
    const fromCcfolia = (d) => {
      const sheet = {
        status: (Array.isArray(d.status) ? d.status : [])
          .filter((x) => x && typeof x === 'object')
          .map((x) => ({ label: str(x.label).trim(), value: str(x.value), max: str(x.max) }))
          .filter((x) => x.label),
        params: (Array.isArray(d.params) ? d.params : [])
          .filter((x) => x && typeof x === 'object')
          .map((x) => ({ label: str(x.label).trim(), value: str(x.value) }))
          .filter((x) => x.label),
        commands: str(d.commands),
        memo: str(d.memo),
        initiative: str(d.initiative),
        externalUrl: str(d.externalUrl),
        at: Date.now(),
      };
      const standings = (Array.isArray(d.faces) ? d.faces : [])
        .filter((f) => f && f.label && f.iconUrl)
        .map((f) => ({ label: str(f.label).trim(), img: str(f.iconUrl), ...(d.iconUrl && str(f.iconUrl) === str(d.iconUrl) ? { main: true } : {}) }));
      add(d.name, sheetHasContent(sheet) ? sheet : null, standings, str(d.color).trim());
    };
    const walk = (v) => {
      if (Array.isArray(v)) return v.forEach(walk);
      if (!v || typeof v !== 'object') return;
      if (v.kind === 'character' && v.data) return fromCcfolia(v.data);
      if (v.kind === 'cst-character-sheet') return add(v.name, v.sheet || null, null);
      if (v.kind === 'cst-character-sheets') {
        const sheets = v.sheets || {};
        const st = v.standings || {};
        for (const n of new Set([...Object.keys(sheets), ...Object.keys(st)])) {
          add(n, sheets[n] || null, (st[n] || []).filter((s) => s && s.label).map(({ imported, ...s }) => s));
        }
        return;
      }
      // kind 없이 data 만 온 경우
      if (v.name && (v.status || v.params || v.faces || v.commands)) return fromCcfolia(v);
    };
    values.forEach(walk);
    const list = [...byName.values()];
    if (!list.length) return { list, error: '캐릭터를 찾지 못했습니다. 코코포리아 캐릭터 JSON 인지 확인해 주세요.' };
    return { list, error: bad ? `읽지 못한 JSON ${bad}개는 뺐어요.` : '' };
  }

  // 이어 붙인 JSON 값들을 하나씩 잘라 낸다 (문자열 안의 괄호는 세지 않는다)
  function splitJsonValues(src) {
    const out = [];
    let depth = 0;
    let start = -1;
    let inStr = false;
    let esc = false;
    for (let i = 0; i < src.length; i++) {
      const c = src[i];
      if (inStr) {
        if (esc) esc = false;
        else if (c === '\\') esc = true;
        else if (c === '"') inStr = false;
        continue;
      }
      if (c === '"') inStr = true;
      else if (c === '{' || c === '[') {
        if (depth === 0) start = i;
        depth++;
      } else if (c === '}' || c === ']') {
        depth--;
        if (depth === 0 && start >= 0) {
          out.push(src.slice(start, i + 1));
          start = -1;
        }
        if (depth < 0) depth = 0;
      }
    }
    if (depth > 0 && start >= 0) out.push(src.slice(start));
    return out;
  }

  async function openCharacterImport() {
    const { bodyEl, foot, close } = openStandingModal('캐릭터 JSON 가져오기');
    bodyEl.appendChild(
      el(
        'div',
        'cst-hint cst-hint-help',
        '코코포리아 캐릭터 JSON(캐릭터 시트 사이트의 코코포리아 출력, [코코포리아용 복사])이나\n[이 방 시트 전부 파일로 저장] 파일을 넣으면 시트 · 이름 색은 패널에 담고, 스탠딩은 이 방 코코포리아 캐릭터 표정으로 넣습니다.\n이 방에 없는 캐릭터는 코코포리아에 JSON 을 Ctrl+V 로 붙여넣으면 만들어져요.'
      )
    );
    const ta = el('textarea', 'cst-input cst-json-paste');
    ta.placeholder = '여기에 붙여넣기 (Ctrl+V)';
    ta.rows = 6;
    const fileBtn = el('button', 'cst-btn ghost cst-mini-btn', '파일에서 열기');
    const preview = el('div', 'cst-modal-list');
    const warn = el('div', 'cst-modal-warn');
    const fromRoomBtn = el('button', 'cst-btn ghost cst-mini-btn', '다른 방에서 가져오기');
    fromRoomBtn.title = '이 확장이 기억하는 다른 방의 캐릭터를 가져옵니다. 스탠딩은 이 방 코코포리아 캐릭터 표정으로 넣어요.';
    fromRoomBtn.addEventListener('click', () => {
      close();
      openCopyFromRoom();
    });
    const srcRow = el('div', 'cst-row');
    srcRow.append(fileBtn, fromRoomBtn);
    fileBtn.style.marginLeft = '0';
    bodyEl.append(ta, srcRow, warn, preview);

    let parsed = { list: [] };
    const room = await getRoom();
    // 이름 색은 이 방에 정한 색이 없을 때만 넣는다 (코코포리아 기본 회색은 넣지 않는다)
    const isNewColor = (c) => !!c.color && !((room.charColors || {})[c.name]) && !/^#888(888)?$/i.test(c.color);
    const draw = () => {
      try {
        parsed = parseCharacterJson(ta.value);
      } catch (e) {
        parsed = { list: [], error: 'JSON 을 읽다가 멈췄어요. 코코포리아 캐릭터 JSON 인지 확인해 주세요.' };
      }
      warn.textContent = parsed.error;
      warn.hidden = !parsed.error;
      preview.innerHTML = '';
      for (const c of parsed.list) {
        const sh = c.sheet || {};
        const bits = [];
        if (sh.status && sh.status.length) bits.push(`능력치 ${sh.status.length}`);
        if (sh.params && sh.params.length) bits.push(`파라미터 ${sh.params.length}`);
        const pal = (sh.commands || '').trim();
        if (pal) bits.push(`채팅 팔레트 ${pal.split('\n').length}줄`);
        const facesOk = c.standings.filter((s) => CCF_IMAGE_URL.test(s.img || '')).length;
        if (facesOk) bits.push(`스탠딩 ${facesOk}장`);
        if (c.color && isNewColor(c) ) bits.push('이름 색');
        const had = !!((room.standings || {})[c.name] || (room.sheets || {})[c.name]);
        const line = el(
          'div',
          'cst-report-line',
          `${c.name} · ${bits.join(' · ') || '이름만'}${had ? ' · 이미 있음 (시트는 덮어쓰고, 같은 이름 표정은 그대로)' : ''}`
        );
        preview.appendChild(line);
      }
      saveBtn.disabled = !parsed.list.length;
      saveBtn.textContent = parsed.list.length ? `${parsed.list.length}명 가져오기` : '가져오기';
    };
    ta.addEventListener('input', draw);
    fileBtn.addEventListener('click', () => {
      const inp = document.createElement('input');
      inp.type = 'file';
      inp.accept = '.json,.txt,application/json,text/plain';
      inp.addEventListener('change', async () => {
        const f = inp.files && inp.files[0];
        if (!f) return;
        ta.value = await f.text();
        draw();
      });
      inp.click();
    });

    const cancel = el('button', 'cst-btn ghost', '취소');
    cancel.addEventListener('click', close);
    const saveBtn = el('button', 'cst-btn', '가져오기');
    saveBtn.disabled = true;
    saveBtn.addEventListener('click', async () => {
      const list = parsed.list;
      if (!list.length) return;
      saveBtn.disabled = true;
      let sheetsN = 0;
      let facesN = 0;
      await patchRoom((r) => {
        r.sheets = r.sheets || {};
        for (const c of list) {
          if (c.sheet) {
            r.sheets[c.name] = { ...c.sheet, at: c.sheet.at || Date.now() };
            sheetsN++;
          }
          // 이름 색은 이 방 전용 색으로 (패널 [색상] 탭) — 이미 정한 색은 그대로
          if (c.color && !((r.charColors || {})[c.name]) && !/^#888(888)?$/i.test(c.color)) {
            r.charColors = r.charColors || {};
            r.charColors[c.name] = c.color;
          }
        }
      });
      // 스탠딩은 이 방 코코포리아 캐릭터 표정으로 (같은 이름 표정은 그대로)
      const notes = [];
      const withFaces = list.filter((c) => c.standings.some((s) => CCF_IMAGE_URL.test(s.img || '')));
      if (withFaces.length) saveBtn.textContent = '코코포리아에 넣는 중';
      for (const c of withFaces) {
        const res = await addFacesToCcfolia(c.name, c.standings, false);
        if (!res || !res.ok) notes.push(ccfWhyText(c.name, res && res.why));
        else facesN += res.added || 0;
      }
      close();
      if (!state.currentChar) state.currentChar = list[0].name;
      toast(`캐릭터 ${list.length}명 가져옴 · 시트 ${sheetsN} · 코코포리아에 표정 ${facesN}장` + (notes.length ? ` · ${notes.join(' · ')}` : ''));
      renderBody();
    });
    foot.append(cancel, saveBtn);
    setTimeout(() => ta.focus(), 0);
  }

  // ----- 캐릭터 시트 백업 (능력치·파라미터·채팅 팔레트·메모) -----
  // 캐릭터 편집창을 열어두면 스탠딩과 함께 자동으로 담긴다.
  function renderSheetBackup(room) {
    const sheets = room.sheets || {};
    const names = Object.keys(sheets);

    const sec3 = foldBlock('sheet', '4', '캐릭터 시트 백업', '방에 들어오면 내 캐릭터의 능력치·채팅 팔레트·메모가 자동으로 담깁니다.');
    const wrap = el('div', 'cst-sliders');
    sec3.appendChild(wrap);

    const importBtn = el('button', 'cst-btn ghost', '캐릭터 JSON 가져오기');
    importBtn.style.flex = '1';
    importBtn.title = '코코포리아 캐릭터 JSON 붙여넣기나 시트 파일로 시트 · 스탠딩을 담습니다';
    importBtn.addEventListener('click', openCharacterImport);

    if (!names.length) {
      wrap.appendChild(el('div', 'cst-hint', '아직 담아둔 시트가 없습니다.'));
      const r = el('div', 'cst-row');
      r.appendChild(importBtn);
      wrap.appendChild(r);
      body.appendChild(sec3);
      return;
    }

    wrap.appendChild(el('div', 'cst-hint', `${names.length}명 시트 저장됨 — 편집창을 열 때마다 최신으로 갱신됩니다.`));

    const pickRow = el('div', 'cst-row');
    const sel = el('select', 'cst-select');
    for (const n of names) {
      const o = el('option', '', n);
      o.value = n;
      if (n === state.sheetChar) o.selected = true;
      sel.appendChild(o);
    }
    if (!state.sheetChar || !names.includes(state.sheetChar)) state.sheetChar = names[0];
    sel.value = state.sheetChar;
    const delBtn = el('button', 'cst-btn ghost', '삭제');
    delBtn.title = '이 캐릭터의 저장된 시트만 지웁니다 (스탠딩은 그대로)';
    pickRow.append(sel, delBtn);
    wrap.appendChild(pickRow);

    const view = el('div', 'cst-hint');
    view.style.whiteSpace = 'pre-wrap';
    wrap.appendChild(view);

    const btnRow = el('div', 'cst-row');
    const palBtn = el('button', 'cst-btn ghost', '채팅 팔레트 복사');
    palBtn.style.flex = '1';
    const jsonBtn = el('button', 'cst-btn ghost', '코코포리아용 복사');
    jsonBtn.style.flex = '1';
    jsonBtn.title = '코코포리아 방 화면에서 Ctrl+V 로 붙여넣으면 이 캐릭터가 새로 생깁니다 (능력치 · 파라미터 · 채팅 팔레트 · 메모 · 스탠딩)';
    btnRow.append(palBtn, jsonBtn);
    wrap.appendChild(btnRow);

    const fileRow = el('div', 'cst-row');
    const saveAllBtn = el('button', 'cst-btn ghost', '이 방 시트 전부 파일로 저장');
    saveAllBtn.style.flex = '1';
    fileRow.append(importBtn, saveAllBtn);
    wrap.appendChild(fileRow);

    function draw() {
      const sh = sheets[state.sheetChar] || {};
      const lines = [];
      if (sh.status && sh.status.length) {
        lines.push('능력치  ' + sh.status.map((x) => `${x.label} ${x.value}${x.max ? '/' + x.max : ''}`).join('  ·  '));
      }
      if (sh.params && sh.params.length) {
        lines.push('파라미터  ' + sh.params.map((x) => `${x.label} ${x.value}`).join('  ·  '));
      }
      const pal = (sh.commands || '').trim();
      lines.push(pal ? `채팅 팔레트  ${pal.split('\n').length}줄` : '채팅 팔레트  없음');
      if ((sh.memo || '').trim()) lines.push('메모  ' + sh.memo.trim().slice(0, 60) + (sh.memo.length > 60 ? '…' : ''));
      if (sh.at) {
        const d = new Date(sh.at);
        const pad = (n) => String(n).padStart(2, '0');
        lines.push(`담은 때  ${d.getFullYear()}.${pad(d.getMonth() + 1)}.${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`);
      }
      view.textContent = lines.join('\n');
      palBtn.disabled = !pal;
    }

    sel.addEventListener('change', () => {
      state.sheetChar = sel.value;
      draw();
    });

    palBtn.addEventListener('click', () => {
      const sh = sheets[state.sheetChar] || {};
      navigator.clipboard
        .writeText(sh.commands || '')
        .then(() => toast(`"${state.sheetChar}" 채팅 팔레트 복사됨`))
        .catch(() => toast('복사 실패'));
    });

    jsonBtn.addEventListener('click', async () => {
      const name = state.sheetChar;
      const { charColors } = await getLocal({ charColors: {} });
      const color = (room.charColors || {})[name] || (charColors || {})[name] || '';
      const list = (room.standings || {})[name] || [];
      const payload = toCcfoliaCharacter(name, sheets[name], list, color);
      const skipped = list.length - payload.data.faces.length;
      navigator.clipboard
        .writeText(JSON.stringify(payload))
        .then(() =>
          toast(
            `"${name}" 복사됨. 코코포리아 방에서 Ctrl+V 로 붙여넣으세요.` +
              (skipped ? ` (코코포리아에 올라간 이미지가 아닌 스탠딩 ${skipped}장은 뺐어요)` : '')
          )
        )
        .catch(() => toast('복사 실패'));
    });

    saveAllBtn.addEventListener('click', () => {
      const payload = {
        kind: 'cst-character-sheets',
        version: 1,
        roomName: room.name || '코코포리아',
        at: Date.now(),
        sheets,
        standings: room.standings || {},
      };
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const safe = (room.name || '코코포리아').replace(/[\/:*?"<>|]/g, '_').slice(0, 40);
      a.href = url;
      a.download = `${safe}_캐릭터시트.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
      toast(`시트 ${names.length}명 분을 파일로 저장했습니다.`);
    });

    delBtn.addEventListener('click', async () => {
      const gone = state.sheetChar;
      await patchRoom((r) => {
        if (r.sheets) delete r.sheets[gone];
      });
      state.sheetChar = '';
      toast(`"${gone}" 시트를 지웠습니다.`);
      renderBody();
    });

    draw();
    body.appendChild(sec3);
  }

  // ----- 색상 (직접 입력 저장 전용, 전역/이 방 전용 선택) -----
  async function renderColor() {
    const { charColors } = await getLocal({ charColors: {} });
    const room = await getRoom();
    const roomColors = room.charColors || {};
    body.innerHTML = '';

    body.appendChild(
      el('div', 'cst-hint cst-hint-help', '캐릭터 이름과 색상 코드를 입력해 저장하세요.\n목록 클릭 시 색상 코드가 복사됩니다.')
    );

    const manual = el('div', 'cst-row');
    const nameIn = el('input', 'cst-input');
    nameIn.placeholder = '캐릭터 이름';
    if (state.detected && state.detected.name) nameIn.value = state.detected.name;
    const hexIn = el('input', 'cst-input');
    hexIn.placeholder = '#ff5555';
    hexIn.style.maxWidth = '76px';
    const pick = document.createElement('input');
    pick.type = 'color';
    pick.className = 'cst-color-pick';
    pick.value = '#e05252';
    pick.addEventListener('input', () => (hexIn.value = pick.value));
    hexIn.addEventListener('input', () => {
      const h = normalizeHex(hexIn.value);
      if (h) pick.value = h;
    });
    const addBtn = el('button', 'cst-btn', '저장');
    manual.append(nameIn, hexIn, pick, addBtn);
    body.appendChild(manual);

    addBtn.addEventListener('click', async () => {
      const nm = nameIn.value.trim();
      const hx = normalizeHex(hexIn.value) || normalizeHex(pick.value);
      if (!nm) return toast('캐릭터 이름을 입력해 주세요.');
      if (!hx) return toast('색상 코드가 올바르지 않아요. 예: #ff5555');
      const { charColors: cc } = await getLocal({ charColors: {} });
      cc[nm] = hx;
      await setLocal({ charColors: cc });
      toast(`"${nm}" → ${hx} 저장됨 (목록에서 '이 방' O/X 전환 가능)`);
      renderBody();
    });

    // 캐릭터별 "이 방에서만" O/X 전환: O = 이 방 전용, X = 모든 방 공통
    function colorItem(name, value, roomOnly) {
      const item = el('div', 'cst-color-item');
      item.title = '클릭하면 색상 코드를 복사합니다.';
      const chip = el('span', 'cst-color-chip');
      chip.style.background = value;
      const label = el('span', 'cst-color-name', name);

      const scopeBtn = el('button', 'cst-scope-btn' + (roomOnly ? ' on' : ''), '이 방 ' + (roomOnly ? 'O' : 'X'));
      scopeBtn.title = roomOnly
        ? '이 방 전용 색상 — 클릭하면 모든 방 공통으로 전환'
        : '모든 방 공통 색상 — 클릭하면 이 방 전용으로 전환';
      scopeBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        if (roomOnly) {
          // 이 방 전용 → 공통
          const { charColors: cc } = await getLocal({ charColors: {} });
          cc[name] = value;
          await setLocal({ charColors: cc });
          await patchRoom((r) => {
            if (r.charColors) delete r.charColors[name];
          });
        } else {
          // 공통 → 이 방 전용
          await patchRoom((r) => {
            r.charColors = r.charColors || {};
            r.charColors[name] = value;
          });
          const { charColors: cc } = await getLocal({ charColors: {} });
          delete cc[name];
          await setLocal({ charColors: cc });
        }
        renderBody();
      });

      const code = el('span', '', value);
      code.style.cssText = 'font-size:11px;color:var(--cst-sub);flex-shrink:0;';
      const del = el('button', 'cst-del');
      del.innerHTML = window.faIcon ? window.faIcon('xmark') : '✕';
      del.title = '삭제';
      del.addEventListener('click', async (e) => {
        e.stopPropagation();
        if (roomOnly) {
          await patchRoom((r) => {
            if (r.charColors) delete r.charColors[name];
          });
        } else {
          const { charColors: cc } = await getLocal({ charColors: {} });
          delete cc[name];
          await setLocal({ charColors: cc });
        }
        renderBody();
      });

      item.append(chip, label, scopeBtn, code, del);
      item.addEventListener('click', () => {
        if (navigator.clipboard) {
          navigator.clipboard
            .writeText(value)
            .then(() => toast(`${value} 복사됨 — 캐릭터 편집창 색상 칸에 붙여넣으세요.`))
            .catch(() => toast(value));
        } else toast(value);
      });
      return item;
    }

    const roomNames = Object.keys(roomColors);
    const globalNames = Object.keys(charColors).filter((n) => !roomNames.includes(n));
    if (!roomNames.length && !globalNames.length) {
      body.appendChild(el('div', 'cst-hint', '저장된 색상이 없습니다.'));
      return;
    }

    const list = el('div', 'cst-color-list');
    for (const name of roomNames) list.appendChild(colorItem(name, roomColors[name], true));
    for (const name of globalNames) list.appendChild(colorItem(name, charColors[name], false));
    body.appendChild(list);
  }

  // ----- 메모 (방 공지 + 세션 메모 여러 개, 상단 고정은 선택) -----
  // 공지는 memos 배열에서 id '__notice__' 인 항목으로 다룬다 (기존 room.memo와 호환 유지).
  const NOTICE_ID = '__notice__';

  function memoList(room) {
    const out = [];
    out.push({
      id: NOTICE_ID,
      text: room.memo || '',
      pinned: !!room.memoPinned,
      collapsed: room.noticeCollapsed !== false,
      isNotice: true,
    });
    for (const mo of Array.isArray(room.memos) ? room.memos : []) {
      out.push({ ...mo, pinned: !!mo.pinned, collapsed: mo.collapsed !== false, isNotice: false });
    }
    return out;
  }

  function patchMemo(id, fn) {
    return patchRoom((r) => {
      if (id === NOTICE_ID) {
        const view = { text: r.memo || '', pinned: !!r.memoPinned, collapsed: r.noticeCollapsed !== false };
        fn(view);
        r.memo = view.text;
        r.memoPinned = view.pinned;
        r.noticeCollapsed = view.collapsed;
        return;
      }
      const hit = (r.memos || []).find((x) => x.id === id);
      if (hit) fn(hit);
    });
  }

  // ----- 세션 준비 체크리스트 (방마다) -----
  // 가운데에 딱 맞는 체크 표시.
  // Font Awesome 체크는 획이 오른쪽 위로 길게 뻗어 눈으로 보면 오른쪽에 쏠려 보인다.
  // 잉크의 가로·세로 중심이 뷰박스 중심(8,8)에 정확히 오도록 직접 그렸다.
  const CHECK_MARK =
    '<svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="3.5,8.4 6.4,11.3 12.5,4.7"/></svg>';

  function renderChecklist(room) {
    const list = Array.isArray(room.checklist) ? room.checklist : [];
    const wrap = el('div', 'cst-check');

    // ---- 머리: 제목 + 진행 + 상단 표시 핀 ----
    const head = el('div', 'cst-check-head');
    head.appendChild(el('span', 'cst-check-title', '세션 준비'));
    const count = el('span', 'cst-check-count', '');
    head.appendChild(count);
    const pinned = !!room.checklistPinned;
    const pin = el('button', 'cst-pin-btn cst-check-pin' + (pinned ? ' on' : ''), pinned ? '방에 표시 중' : '방에 표시');
    pin.type = 'button';
    pin.title = pinned ? '방 화면에서 내리기' : '방 화면에 메모들과 함께 띄우기 (위치는 메모 탭의 고정 메모 바 설정에서)';
    pin.addEventListener('click', async () => {
      await patchRoom((r) => (r.checklistPinned = !pinned));
      refreshNoticeBar();
      renderBody();
    });
    head.appendChild(pin);
    wrap.appendChild(head);

    const bar = el('div', 'cst-check-bar');
    const fill = el('div', 'cst-check-fill');
    bar.appendChild(fill);
    wrap.appendChild(bar);

    const rows = el('div', 'cst-check-rows');
    wrap.appendChild(rows);

    function refreshCount() {
      const all = rows.querySelectorAll('.cst-check-row').length;
      const on = rows.querySelectorAll('.cst-check-row.done').length;
      count.textContent = all ? `${on} / ${all}` : '';
      fill.style.width = all ? (on / all) * 100 + '%' : '0%';
      bar.classList.toggle('cst-hide', !all);
      wrap.classList.toggle('all-done', all > 0 && on === all);
      footRow.classList.toggle('cst-hide', !all);
    }

    // ---- 항목 한 줄 ----
    function mkRow(it) {
      const row = el('div', 'cst-check-row' + (it.done ? ' done' : ''));

      const box = el('button', 'cst-check-box');
      box.type = 'button';
      box.title = '했음/안 했음';
      box.innerHTML = CHECK_MARK;
      box.addEventListener('click', async () => {
        const on = !row.classList.contains('done');
        row.classList.toggle('done', on);
        refreshCount();
        await patchRoom((r) => {
          const hit = (r.checklist || []).find((x) => x.id === it.id);
          if (hit) hit.done = on;
        });
      });

      const txt = el('input', 'cst-check-text');
      txt.value = it.text || '';
      txt.placeholder = '내용';
      txt.addEventListener('change', () => {
        patchRoom((r) => {
          const hit = (r.checklist || []).find((x) => x.id === it.id);
          if (hit) hit.text = txt.value;
        });
      });
      // 항목 안에서 엔터를 누르면 바로 아래에 새 항목을 만들어 이어서 적는다
      txt.addEventListener('keydown', (e) => {
        if (e.key !== 'Enter') return;
        e.preventDefault();
        txt.blur();
        addItem('', row);
      });

      const del = el('button', 'cst-check-del');
      del.type = 'button';
      del.innerHTML = window.faIcon ? window.faIcon('xmark') : '✕';
      del.title = '이 항목 지우기';
      del.addEventListener('click', async () => {
        row.remove();
        refreshCount();
        await patchRoom((r) => {
          r.checklist = (r.checklist || []).filter((x) => x.id !== it.id);
        });
      });

      row.append(box, txt, del);
      return row;
    }

    for (const it of list) rows.appendChild(mkRow(it));

    // ---- 항목 추가 ----
    // 화면을 다시 그리지 않고 줄만 덧붙인다 — 그래야 엔터로 계속 이어 적을 수 있다.
    async function addItem(text, afterRow) {
      const it = { id: 'c' + Date.now() + Math.floor(Math.random() * 100), text: text || '', done: false };
      const row = mkRow(it);
      if (afterRow && afterRow.parentElement === rows) afterRow.insertAdjacentElement('afterend', row);
      else rows.appendChild(row);
      refreshCount();
      const input = row.querySelector('.cst-check-text');
      input.focus();
      await patchRoom((r) => {
        r.checklist = Array.isArray(r.checklist) ? r.checklist : [];
        const at = afterRow ? [...rows.children].indexOf(row) : r.checklist.length;
        r.checklist.splice(at, 0, it);
      });
    }

    const addBtn = el('button', 'cst-check-add', '');
    addBtn.type = 'button';
    addBtn.innerHTML = (window.faIcon ? window.faIcon('plus') : '+') + '<span>항목 추가</span>';
    addBtn.title = '엔터로 계속 이어서 적을 수 있어요';
    addBtn.addEventListener('click', () => addItem(''));
    wrap.appendChild(addBtn);

    // ---- 발: 전부 해제 / 비우기 ----
    const footRow = el('div', 'cst-check-foot');
    const resetBtn = el('button', 'cst-check-foot-btn', '체크 전부 해제');
    resetBtn.type = 'button';
    resetBtn.title = '항목은 그대로 두고 체크만 풉니다 (다음 회차용)';
    resetBtn.addEventListener('click', async () => {
      for (const r of rows.querySelectorAll('.cst-check-row')) r.classList.remove('done');
      refreshCount();
      await patchRoom((r) => {
        for (const x of r.checklist || []) x.done = false;
      });
    });
    const clearBtn = el('button', 'cst-check-foot-btn', '목록 비우기');
    clearBtn.type = 'button';
    clearBtn.addEventListener('click', async () => {
      if (!confirm('체크리스트 항목을 전부 지울까요?')) return;
      rows.innerHTML = '';
      refreshCount();
      await patchRoom((r) => {
        r.checklist = [];
      });
    });
    footRow.append(resetBtn, clearBtn);
    wrap.appendChild(footRow);

    refreshCount();
    return wrap;
  }

  async function renderMemo() {
    const room = await getRoom();
    body.innerHTML = '';

    body.appendChild(renderChecklist(room));

    body.appendChild(
      el('div', 'cst-hint cst-hint-help', '[방에 표시]를 누른 메모만 방 화면에 뜹니다. (기본은 표시 안 함)')
    );

    // 고정 메모 바 설정 — 위치·글자 크기 (v9.2: 팝업 설정에서 이곳으로 이동)
    {
      const barSet = el('div', 'cst-sliders');
      barSet.appendChild(el('div', 'cst-slider-row', '고정 메모 바'));

      const posRow = el('div', 'cst-slider-row');
      posRow.append(el('label', '', '위치'));
      const posBtns = el('div', 'cst-colbtns');
      for (const [v, label] of [['top', '상단'], ['bottom', '하단']]) {
        const b = el('button', 'cst-colbtn' + ((state.noticePos === 'bottom' ? 'bottom' : 'top') === v ? ' on' : ''), label);
        b.addEventListener('click', () => {
          state.noticePos = v;
          setSync({ noticePos: v });
          for (const c of posBtns.children) c.classList.toggle('on', c === b);
          refreshNoticeBar();
        });
        posBtns.appendChild(b);
      }
      posRow.appendChild(posBtns);
      barSet.appendChild(posRow);

      const fsRow = el('div', 'cst-slider-row');
      fsRow.append(el('label', '', '글자 크기'));
      const fsRange = document.createElement('input');
      fsRange.type = 'range';
      fsRange.min = 10;
      fsRange.max = 18;
      fsRange.step = 1;
      fsRange.value = Number(state.noticeFont) || 12;
      const fsOut = el('output', '', (Number(state.noticeFont) || 12) + 'px');
      let fsTimer = 0;
      fsRange.addEventListener('input', () => {
        const v = Number(fsRange.value) || 12;
        fsOut.textContent = v + 'px';
        state.noticeFont = v;
        if (noticeBar) noticeBar.style.setProperty('--cst-notice-fs', v + 'px');
        // sync 저장은 분당 쓰기 한도가 있어 묶어서 보낸다
        clearTimeout(fsTimer);
        fsTimer = setTimeout(() => setSync({ noticeFont: v }), 300);
      });
      fsRow.append(fsRange, fsOut);
      barSet.appendChild(fsRow);
      body.appendChild(barSet);
    }

    const items = memoList(room);
    const wrap = el('div', 'cst-sliders');
    wrap.appendChild(el('div', 'cst-slider-row', '메모'));

    for (const mo of items) {
      const card = el('div', 'cst-memo-card');
      const top = el('div', 'cst-memo-card-top');

      if (mo.isNotice) {
        top.appendChild(el('span', 'cst-memo-date', '방 공지'));
      } else {
        const dt = new Date(mo.at || Date.now());
        const pad = (n) => String(n).padStart(2, '0');
        top.appendChild(
          el('span', 'cst-memo-date', `${pad(dt.getMonth() + 1)}.${pad(dt.getDate())} ${pad(dt.getHours())}:${pad(dt.getMinutes())}`)
        );
      }

      const btns = el('span', 'cst-memo-card-btns');
      const pin = el('button', 'cst-pin-btn' + (mo.pinned ? ' on' : ''), mo.pinned ? '방에 표시 중' : '방에 표시');
      pin.title = mo.pinned ? '방 화면에서 내리기' : '방 화면에 표시 (위치는 아래 고정 메모 바 설정에서)';
      pin.addEventListener('click', async () => {
        await patchMemo(mo.id, (x) => (x.pinned = !mo.pinned));
        refreshNoticeBar();
        renderBody();
      });
      btns.appendChild(pin);

      if (!mo.isNotice) {
        const del = el('button', 'cst-del');
        del.innerHTML = window.faIcon ? window.faIcon('xmark') : '✕';
        del.title = '이 메모 삭제';
        del.addEventListener('click', async () => {
          await patchRoom((r) => {
            r.memos = (r.memos || []).filter((x) => x.id !== mo.id);
          });
          refreshNoticeBar();
          renderBody();
        });
        btns.appendChild(del);
      }
      top.appendChild(btns);

      const ta = el('textarea', 'cst-memo cst-memo-mini');
      ta.value = mo.text || '';
      ta.placeholder = mo.isNotice ? '방 공지 (자동 저장)' : '메모 내용 (자동 저장)';
      const sv = el('div', 'cst-memo-saved', '');
      let t2 = 0;
      ta.addEventListener('input', () => {
        clearTimeout(t2);
        sv.textContent = '입력 중…';
        t2 = setTimeout(async () => {
          await patchMemo(mo.id, (x) => (x.text = ta.value));
          sv.textContent = '저장됨 ✓';
          refreshNoticeBar();
        }, 500);
      });
      card.append(top, ta, sv);
      wrap.appendChild(card);
    }

    const addBtn = el('button', 'cst-btn ghost', '+ 새 메모');
    addBtn.style.width = '100%';
    addBtn.addEventListener('click', async () => {
      await patchRoom((r) => {
        r.memos = r.memos || [];
        // 적은 순서대로 아래로 쌓인다 (전에는 맨 위에 끼어들어 헷갈렸음)
        r.memos.push({
          id: Date.now() + '_' + Math.random().toString(36).slice(2, 7),
          text: '',
          at: Date.now(),
          pinned: false,
        });
      });
      renderBody();
    });
    wrap.appendChild(addBtn);
    body.appendChild(wrap);
  }

  // ----- 상단 고정 메모 바 (핀한 메모만, 드래그 정렬, 클릭 접기 — 편집은 패널 메모 탭에서) -----
  let noticeBar = null;

  const CHECK_NOTICE_ID = '__checklist__';

  // 채팅 별창(/rooms/ID/chat 등 하위 경로)에는 띄우지 않는다 — 메인 방 화면에서만
  const isMainRoomPage = /^\/rooms\/[^/]+\/?$/.test(location.pathname) && !/chat/i.test(location.search);

  async function refreshNoticeBar() {
    if (!isMainRoomPage) {
      if (noticeBar) noticeBar.style.display = 'none';
      return;
    }
    const room = await getRoom();
    const pinned = memoList(room).filter((m) => m.pinned && (m.text || '').trim());
    // 세션 준비도 핀하면 메모들과 같은 줄에 놓인다
    const showCheck = !!room.checklistPinned && (room.checklist || []).length > 0;
    if (showCheck) pinned.push({ id: CHECK_NOTICE_ID, isCheck: true, collapsed: room.checklistCollapsed !== false });

    if (!pinned.length) {
      if (noticeBar) noticeBar.style.display = 'none';
      return;
    }
    if (!noticeBar) {
      noticeBar = el('div', 'cst-root');
      noticeBar.id = 'cst-notice';
      shieldFocus(noticeBar);
      document.body.appendChild(noticeBar);
      applyTheme();
    }
    noticeBar.style.display = 'flex';
    noticeBar.style.setProperty('--cst-notice-fs', (Number(state.noticeFont) || 12) + 'px');
    noticeBar.innerHTML = '';
    placeNoticeBar();

    // 저장된 순서대로 나열 (드래그로 바꾼 순서)
    const order = Array.isArray(room.noticeOrder) ? room.noticeOrder : [];
    pinned.sort((a, b) => {
      const ia = order.indexOf(a.id);
      const ib = order.indexOf(b.id);
      return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib);
    });

    pinned.forEach((mo, i) =>
      noticeBar.appendChild(mo.isCheck ? checkNoticeCard(room, i, pinned) : noticeCard(mo, i, pinned))
    );
  }

  // 화면의 가로 띠(bandTop~bandBottom) 안에서 코코포리아 요소들이 차지한 구간을 빼고 남는 빈 구간들.
  // 상단 바(메모 위쪽 배치)와 하단 띠(좌하단 배치)가 같은 계산을 쓴다.
  // 성능: 채팅 로그 안의 인장 img·버튼은 수천 개라 rect 계산(강제 레이아웃) 전에 제외하고,
  // 같은 인자의 연속 호출(재생성 직후 onChanged 중복 등)은 250ms 캐시로 흡수한다.
  // (resize 핸들러의 300ms 지연 재배치는 캐시보다 늦어 새로 계산된다)
  let gapCache = { key: '', at: 0, val: null };
  function freeGaps(bandTop, bandBottom, leftLimit, rightLimit) {
    const key = [bandTop, bandBottom, leftLimit, rightLimit, innerWidth, innerHeight].join('/');
    if (gapCache.key === key && performance.now() - gapCache.at < 250) return gapCache.val;
    const log = document.querySelector('[role="log"]');
    const spans = [];
    for (const elx of document.querySelectorAll('button, [role="button"], h6, a, input, textarea, svg, img')) {
      if (log && log.contains(elx)) continue;
      if (elx.closest && elx.closest('.cst-root')) continue;
      const r = elx.getBoundingClientRect();
      if (!r.width || !r.height) continue;
      if (r.bottom < bandTop || r.top > bandBottom) continue;
      if (r.right < leftLimit || r.left > rightLimit) continue;
      spans.push([Math.max(leftLimit, r.left - 6), Math.min(rightLimit, r.right + 6)]);
    }
    spans.sort((a, b) => a[0] - b[0]);
    const merged = [];
    for (const sp of spans) {
      const last = merged[merged.length - 1];
      if (last && sp[0] <= last[1]) last[1] = Math.max(last[1], sp[1]);
      else merged.push(sp.slice());
    }
    const gaps = [];
    let cur = leftLimit;
    for (const m of merged) {
      if (m[0] - cur > 0) gaps.push({ left: cur, width: m[0] - cur });
      cur = Math.max(cur, m[1]);
    }
    if (rightLimit - cur > 0) gaps.push({ left: cur, width: rightLimit - cur });
    const val = { gaps, occupied: merged.length > 0 };
    gapCache = { key, at: performance.now(), val };
    return val;
  }

  // 상단 바 아래로 내려 전체 폭을 쓰는 자리
  function belowSlot() {
    return { left: 12, width: Math.min(560, innerWidth - 24), below: true };
  }

  // 상단: 코코포리아 상단 바(0~64px)에서 방 이름·아이콘 버튼 "사이"의 가장 넓은 틈.
  // minWidth보다 좁으면 상단 바 아래로 내려 전체 폭을 쓴다 (말줄임으로라도 보이게).
  function noticeSlot(minWidth) {
    const { gaps, occupied } = freeGaps(2, 64, 0, innerWidth);
    if (!occupied) return { left: 12, width: Math.min(560, innerWidth - 24) };
    const inner = gaps.filter((g) => g.left > 0 && g.left + g.width < innerWidth);
    const best = inner.reduce((a, b) => (!a || b.width > a.width ? b : a), null);
    if (!best || best.width < minWidth) return belowSlot();
    return { left: best.left + 4, width: Math.max(120, best.width - 8) };
  }

  // 하단(좌하단): 화면 아래 띠(72px)에서 버튼들과 채팅창을 피해 왼쪽부터 빈 구간을 찾는다.
  // 공간이 넓어 창을 줄여도 웬만하면 살아남는다.
  function bottomSlot() {
    let leftLimit = 8;
    let rightLimit = innerWidth - 8;
    // 채팅창(드로어)은 통째로 피한다 — 메모가 채팅창 위로 넘어가면 안 된다.
    // 전체 폭 레이아웃 컨테이너를 드로어로 오인하지 않게 MuiDrawer-paper만 본다.
    const log = document.querySelector('[role="log"]');
    const drawer = log && log.closest('.MuiDrawer-paper');
    if (drawer) {
      const d = drawer.getBoundingClientRect();
      if (d.width && d.height) {
        if (d.width >= innerWidth - 40) return null; // 채팅창이 화면을 다 덮은 상태
        if (d.left > innerWidth / 2) rightLimit = Math.min(rightLimit, d.left - 8);
        else if (d.right < innerWidth / 2) leftLimit = Math.max(leftLimit, d.right + 8);
      }
    }
    const { gaps } = freeGaps(innerHeight - 72, innerHeight, leftLimit, rightLimit);
    if (!gaps.length) return null;
    // 왼쪽부터 160px 이상 되는 첫 빈 구간, 없으면 가장 넓은 것
    const pick = gaps.find((g) => g.width >= 160) || gaps.reduce((a, b) => (b.width > a.width ? b : a));
    if (pick.width < 120) return null;
    return { left: pick.left + 4, width: Math.min(560, pick.width - 8) };
  }

  function placeNoticeBar() {
    if (!noticeBar || noticeBar.style.display === 'none') return;
    const bottom = state.noticePos === 'bottom';
    noticeBar.classList.toggle('cst-notice-bottom', bottom);
    const slot = bottom ? bottomSlot() : noticeSlot(160);
    // 정말 넣을 자리가 없을 때만 숨긴다
    if (!slot || innerWidth < 300 || slot.width < 120) {
      noticeBar.style.visibility = 'hidden';
      return;
    }
    noticeBar.style.visibility = '';
    noticeBar.style.left = Math.round(slot.left) + 'px';
    noticeBar.style.width = Math.round(slot.width) + 'px';
    noticeBar.style.maxWidth = Math.round(slot.width) + 'px';
    if (bottom) {
      noticeBar.style.top = 'auto';
      noticeBar.style.bottom = '8px';
    } else {
      noticeBar.style.bottom = 'auto';
      noticeBar.style.top = (slot.below ? 68 : 8) + 'px';
    }
  }

  let placeTimer = 0;
  addEventListener('resize', () => {
    placeNoticeBar();
    // 코코포리아 레이아웃이 늦게 따라오는 경우를 위해 한 번 더
    clearTimeout(placeTimer);
    placeTimer = setTimeout(placeNoticeBar, 300);
  });

  // 상단 바에 뜨는 세션 준비 카드. 여기서도 바로 체크할 수 있다.
  function checkNoticeCard(room, index, siblings) {
    const list = room.checklist || [];
    const done = list.filter((x) => x.done).length;
    const collapsed = room.checklistCollapsed !== false;

    const card = el('div', 'cst-notice-card cst-notice-check' + (collapsed ? ' cst-notice-collapsed' : ''));
    attachNoticeDrag(card, index, siblings);

    const chev = el('button', 'cst-notice-chev', collapsed ? '▸' : '▾');
    chev.title = collapsed ? '펼치기' : '접기';
    chev.addEventListener('click', async (e) => {
      e.stopPropagation();
      await patchRoom((r) => (r.checklistCollapsed = !collapsed));
      refreshNoticeBar();
    });
    card.appendChild(chev);

    const body2 = el('div', 'cst-notice-check-body');
    const title = el('div', 'cst-notice-check-head');
    title.append(
      el('span', 'cst-notice-check-t', '세션 준비'),
      el('span', 'cst-notice-check-n', `${done} / ${list.length}`)
    );
    body2.appendChild(title);

    if (!collapsed) {
      const ul = el('div', 'cst-notice-check-list');
      for (const it of list) {
        const row = el('div', 'cst-notice-check-row' + (it.done ? ' done' : ''));
        const box = el('button', 'cst-notice-check-box');
        box.type = 'button';
        box.innerHTML = CHECK_MARK;
        box.addEventListener('click', async (e) => {
          e.stopPropagation();
          await patchRoom((r) => {
            const hit = (r.checklist || []).find((x) => x.id === it.id);
            if (hit) hit.done = !it.done;
          });
          refreshNoticeBar();
          if (state.activeTab === 'memo' && panel && panel.style.display !== 'none') renderBody();
        });
        row.append(box, el('span', '', it.text || ''));
        ul.appendChild(row);
      }
      body2.appendChild(ul);
    }
    card.appendChild(body2);
    return card;
  }

  // 상단 카드 공통 드래그 순서 바꾸기
  function attachNoticeDrag(card, index, siblings) {
    card.draggable = true;
    card.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('text/plain', String(index));
      card.classList.add('cst-notice-dragging');
    });
    card.addEventListener('dragend', () => card.classList.remove('cst-notice-dragging'));
    card.addEventListener('dragover', (e) => {
      e.preventDefault();
      card.classList.add('cst-notice-dragover');
    });
    card.addEventListener('dragleave', () => card.classList.remove('cst-notice-dragover'));
    card.addEventListener('drop', async (e) => {
      e.preventDefault();
      card.classList.remove('cst-notice-dragover');
      const from = Number(e.dataTransfer.getData('text/plain'));
      if (Number.isNaN(from) || from === index) return;
      const ids = siblings.map((x) => x.id);
      const [moved] = ids.splice(from, 1);
      ids.splice(index, 0, moved);
      await patchRoom((r) => (r.noticeOrder = ids));
      refreshNoticeBar();
    });
  }

  function noticeCard(mo, index, siblings) {
    const card = el('div', 'cst-notice-card');
    card.draggable = true;
    card.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('text/plain', String(index));
      card.classList.add('cst-notice-dragging');
    });
    card.addEventListener('dragend', () => card.classList.remove('cst-notice-dragging'));
    card.addEventListener('dragover', (e) => {
      e.preventDefault();
      card.classList.add('cst-notice-dragover');
    });
    card.addEventListener('dragleave', () => card.classList.remove('cst-notice-dragover'));
    card.addEventListener('drop', async (e) => {
      e.preventDefault();
      card.classList.remove('cst-notice-dragover');
      const from = Number(e.dataTransfer.getData('text/plain'));
      if (Number.isNaN(from) || from === index) return;
      const ids = siblings.map((x) => x.id);
      const [moved] = ids.splice(from, 1);
      ids.splice(index, 0, moved);
      await patchRoom((r) => (r.noticeOrder = ids));
      refreshNoticeBar();
    });
    const text = (mo.text || '').trim();

    // 한 줄로 다 보이는 짧은 메모는 접을 필요가 없다 → 화살표를 안 만든다
    const multiline = /\n/.test(text);
    card.classList.toggle('cst-notice-collapsed', mo.collapsed && multiline);

    const textEl = el('div', 'cst-notice-text');
    textEl.textContent = mo.collapsed && multiline ? text.split('\n')[0] : text;
    textEl.title = multiline ? '클릭하면 접기/펼치기 · 편집은 패널의 메모 탭에서' : '편집은 패널의 메모 탭에서';
    if (multiline) {
      textEl.addEventListener('click', async () => {
        await patchMemo(mo.id, (x) => (x.collapsed = !mo.collapsed));
        refreshNoticeBar();
      });
    }

    if (multiline) {
      const chev = el('button', 'cst-notice-chev', mo.collapsed ? '▸' : '▾');
      chev.title = mo.collapsed ? '펼치기' : '접기';
      chev.addEventListener('click', async (e) => {
        e.stopPropagation();
        await patchMemo(mo.id, (x) => (x.collapsed = !mo.collapsed));
        refreshNoticeBar();
      });
      card.appendChild(chev);
    }
    card.appendChild(textEl);
    return card;
  }

  // ----- 특수문자 -----
  function renderChars() {
    body.innerHTML = '';
    const wrap = el('div', 'cst-chars');
    for (const ch of state.specialChars) {
      const b = el('button', 'cst-char', ch);
      b.addEventListener('click', () => insertAtCursor(ch));
      wrap.appendChild(b);
    }
    body.appendChild(wrap);
    body.appendChild(
      el('div', 'cst-hint cst-hint-help', '클릭하면 채팅 입력창 커서 위치에 삽입됩니다.\n목록은 팝업 → 설정에서 편집할 수 있어요.')
    );
    renderRoomRules();
  }

  // 설정 이름 옆 [?] — 마우스를 올리면 설명이 뜬다 (팝업 · 스튜디오와 같은 모양)
  function helpBtn(tip) {
    const b = el('button', 'cst-help-btn', '?');
    b.type = 'button';
    b.dataset.tip = tip;
    b.title = tip; // 툴팁이 가려지는 자리에서도 읽을 수 있게
    b.addEventListener('click', (e) => e.preventDefault());
    return b;
  }

  // ----- 이 방 전용 텍스트 대치·스니펫 (v12.0) -----
  // 공통 규칙은 팝업 설정에, 방마다 다른 것(캐릭터 이름 약어, 이 방 KP 정형문 등)은 여기에.
  const RULE_HELP =
    "이 방에서만 먹는 규칙입니다 (공통 규칙보다 먼저 적용).\n\n정규식 — 글자 '모양' 으로 찾아 바꾸기\n· \\d 는 숫자 한 글자, + 는 '하나 이상' → \\d+ 는 숫자 여러 자리\n· ( ) 로 묶은 부분은 바꿀 때 $1, $2 로 다시 쓸 수 있습니다\n· 예: (\\d+)d(\\d+) → $1D$2  ·  3d6 을 치면 3D6 으로\n· 예: ㅋ{3,} → ㅋㅋㅋ  ·  ㅋ 을 3번 이상 치면 3번으로\n\n스니펫 — 짧은 약어를 긴 문장으로\n· ;약어 를 치고 스페이스나 Tab 을 누르면 펼쳐집니다\n· 여러 줄도 됩니다 (아래 칸에서 Shift+Enter)\n· {날짜} → 2026.09.15 · {시간} → 21:07 · {요일} → 월\n· 예: ;kp → 【KP】  ·  ;날 → 오늘은 {날짜} {요일}요일";
  const RULE_KIND_LABEL = { plain: '일반', regex: '정규식', snippet: '스니펫' };
  function ruleKindOf(r) {
    return r && (r.kind === 'regex' || r.kind === 'snippet') ? r.kind : 'plain';
  }

  async function renderRoomRules() {
    if (state.activeTab !== 'chars') return;
    const room = await getRoom();
    if (state.activeTab !== 'chars') return;
    const rules = Array.isArray(room.replaceRules) ? room.replaceRules : [];

    const box = el('div', 'cst-sliders');
    // 제목 옆 [?] — 팝업 [텍스트 대치 규칙]과 같은 설명 (정규식 · 스니펫 예시)
    const head = el('div', 'cst-slider-row cst-rule-head', '이 방 전용 대치 · 스니펫');
    head.appendChild(helpBtn(RULE_HELP));
    box.appendChild(head);

    const list = el('div', 'cst-rule-list');
    if (!rules.length) list.appendChild(el('div', 'cst-hint', '아직 규칙이 없어요.'));
    rules.forEach((r, i) => {
      const kind = ruleKindOf(r);
      const row = el('div', 'cst-rule-row');
      const badge = el('span', 'cst-rule-kind cst-rule-kind-' + kind, RULE_KIND_LABEL[kind]);
      const from = el('span', 'cst-rule-from', String(r.from || ''));
      from.title = String(r.from || '');
      const arrow = el('span', 'cst-rule-arrow', '→');
      const toText = String(r.to == null ? '' : r.to);
      const to = el('span', 'cst-rule-to', toText.replace(/\n/g, ' ⏎ '));
      to.title = toText;
      const del = el('button', 'cst-iconbtn cst-rule-del', '✕');
      del.title = '삭제';
      del.addEventListener('click', async () => {
        await patchRoom((rm) => {
          rm.replaceRules = (rm.replaceRules || []).filter((_, j) => j !== i);
        });
        renderBody();
      });
      row.append(badge, from, arrow, to, del);
      list.appendChild(row);
    });
    box.appendChild(list);

    const form = el('div', 'cst-rule-form');
    const kindSel = el('select', 'cst-select cst-rule-kind-sel');
    for (const [k, label] of Object.entries(RULE_KIND_LABEL)) {
      const o = el('option', '', label);
      o.value = k;
      kindSel.appendChild(o);
    }
    const fromIn = el('input', 'cst-input');
    fromIn.type = 'text';
    fromIn.spellcheck = false;
    const toIn = el('textarea', 'cst-input cst-rule-to-in');
    toIn.rows = 1;
    toIn.spellcheck = false;
    const addBtn = el('button', 'cst-btn', '추가');
    const hint = el('div', 'cst-hint cst-rule-hint');
    const PH = {
      plain: ['입력 (예: ...)', '변환 (예: …)'],
      regex: ['패턴 (예: (\\d+)d(\\d+))', '치환 (예: $1D$2)'],
      snippet: ['약어 (예: ;kp)', '펼칠 문장 (Shift+Enter 줄바꿈)'],
    };
    const HINT = {
      plain: '입력한 글자가 그대로 바뀝니다.',
      regex: '커서 앞 문자열이 패턴에 맞으면 바뀝니다. 묶음은 $1 $2로 참조.',
      snippet: '약어에는 공백을 넣을 수 없어요. 예: ;kp → 【KP】',
    };
    const syncKind = () => {
      const k = kindSel.value;
      fromIn.placeholder = PH[k][0];
      toIn.placeholder = PH[k][1];
      hint.textContent = HINT[k];
    };
    kindSel.addEventListener('change', syncKind);
    syncKind();

    const add = async () => {
      const kind = kindSel.value;
      const from = kind === 'snippet' ? fromIn.value.trim() : fromIn.value;
      const to = toIn.value;
      if (!from || !to || (kind === 'plain' && from === to)) return;
      if (kind === 'regex') {
        try {
          new RegExp('(?:' + from + ')$');
        } catch (err) {
          hint.textContent = '정규식 오류: ' + String((err && err.message) || err);
          return;
        }
      }
      if (kind === 'snippet' && /\s/.test(from)) {
        hint.textContent = '스니펫 약어에는 공백을 넣을 수 없어요.';
        return;
      }
      const rule = { from, to };
      if (kind !== 'plain') rule.kind = kind;
      await patchRoom((rm) => {
        const cur = Array.isArray(rm.replaceRules) ? rm.replaceRules : [];
        rm.replaceRules = [rule, ...cur.filter((r) => !(r.from === from && ruleKindOf(r) === kind))];
      });
      toast('이 방 규칙을 추가했어요.');
      renderBody();
    };
    addBtn.addEventListener('click', add);
    toIn.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        add();
      }
    });
    fromIn.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        toIn.focus();
      }
    });

    const row1 = el('div', 'cst-row');
    row1.append(kindSel, fromIn);
    const row2 = el('div', 'cst-row');
    row2.append(toIn, addBtn);
    form.append(row1, row2, hint);
    box.appendChild(form);
    body.appendChild(box);
  }


  // ----- 사이즈 -----
  function renderSize() {
    body.innerHTML = '';
    const css = { ...(state.standingCss || {}) };

    body.appendChild(el('div', 'cst-hint cst-hint-help', '방 중앙에 뜨는 스탠딩·대화창의 크기를 조절합니다. 빈 칸은 코코포리아 기본값.'));

    let saveTimer = 0;
    function queueSave() {
      clearTimeout(saveTimer);
      saveTimer = setTimeout(() => {
        state.standingCss = { ...css };
        suppressCssEcho = true;
        setSync({ standingCss: state.standingCss });
      }, 400);
    }

    // 묶음 카드: 제목 + 줄들
    function mkSec(title, rows) {
      const sec = el('div', 'cst-size-sec');
      sec.appendChild(el('div', 'cst-size-sec-t', title));
      for (const r of rows) if (r) sec.appendChild(r);
      return sec;
    }

    // 한 줄 = 라벨 + 값. 설명은 줄 밑에 깔지 않고 툴팁으로만.
    function mkCheck(labelText, desc, key) {
      const r = el('div', 'cst-size-row');
      if (desc) r.title = desc;
      const sw = mkSwitch(!!css[key], (on) => {
        css[key] = on;
        queueSave();
      });
      const lab = el('label', '', labelText);
      lab.htmlFor = sw.input.id;
      lab.style.cursor = 'pointer';
      r.append(lab, sw.wrap);
      return r;
    }

    // 숫자 칸 + px 단위 — 라벨·칸·단위가 한 줄에 (빈 칸 = '기본').
    // type=number 는 크롬이 e · + · . 같은 글자도 받아서, 텍스트 칸에 숫자만 남기는 방식으로.
    // 입력 직후 한 번 정리한다 — 타이핑·붙여넣기("600px" → 600)·드롭 전부 같은 길.
    // allowNeg 면 맨 앞의 '-' 하나만 허용 (좌우·세로 위치).
    function mkNum(labelText, desc, key, allowNeg) {
      const r = el('div', 'cst-size-row');
      if (desc) r.title = desc;
      const lab = el('label', '', labelText);
      const inp = document.createElement('input');
      inp.type = 'text';
      inp.inputMode = allowNeg ? 'text' : 'numeric';
      inp.autocomplete = 'off';
      inp.className = 'cst-size-num';
      inp.placeholder = '기본';
      lab.htmlFor = inp.id = 'cst-num-' + key;
      if (css[key] !== undefined && css[key] !== null && css[key] !== '') inp.value = css[key];
      const clean = (v) => {
        let s2 = String(v).replace(/[^\d-]/g, '');
        const neg = allowNeg && s2.startsWith('-');
        s2 = s2.replace(/-/g, '');
        return (neg ? '-' : '') + s2;
      };
      inp.addEventListener('input', () => {
        const v = clean(inp.value);
        if (v !== inp.value) {
          const pos = inp.selectionStart;
          inp.value = v; // 잡글자 제거 (커서는 제거된 만큼만 당겨 둔다)
          try { inp.setSelectionRange(Math.min(pos, v.length), Math.min(pos, v.length)); } catch (_) {}
        }
        css[key] = v === '' || v === '-' ? '' : Number(v);
        queueSave();
      });
      r.append(lab, inp, el('span', 'cst-size-unit', 'px'));
      return r;
    }

    body.append(
      mkSec('스탠딩', [
        mkCheck('이미지 원본 크기', '켜면 가로 크기를 무시합니다', 'originalSize'),
        mkNum('가로 크기', '', 'width'),
        mkNum('좌우 위치', '왼쪽 기준 · 마이너스 가능', 'left', true),
      ]),
      mkSec('대화창', [
        mkNum('세로 위치', '아래 기준 · 마이너스 가능', 'bottom', true),
        // 배포본(dist)에는 대화창 가로·높이 조절이 없다 (lib/edition.js)
        LITE ? null : mkNum('가로 크기', '', 'dialogWidth'),
        LITE ? null : mkNum('높이', '', 'dialogHeight'),
      ]),
      mkSec('글자', [mkNum('캐릭터명', '', 'nameSize'), mkNum('대사', '', 'dialogueSize')])
    );

    const resetRow = el('div', 'cst-size-reset');
    const resetBtn = el('button', 'cst-btn ghost cst-sm', '전부 기본값으로');
    resetBtn.addEventListener('click', () => {
      state.standingCss = {};
      suppressCssEcho = true;
      setSync({ standingCss: {} });
      renderBody();
    });
    resetRow.appendChild(resetBtn);
    body.appendChild(resetRow);
  }

  // ----- 맵시트 캡처 -----
  const capState = { format: 'png', scale: 1, gifSec: 4, gifWidth: 720, gifSpeed: 1, gifSmooth: false, gifFps: 15 };

  function renderCapture() {
    body.innerHTML = '';
    body.appendChild(el('div', 'cst-hint cst-hint-help', '맵시트를 이미지로 저장합니다.'));

    // 저장 형식
    const fmtRow = el('div', 'cst-slider-row');
    fmtRow.appendChild(el('label', '', '저장 형식'));
    const fmtWrap = el('div', 'cst-colbtns');
    for (const [v, label, tip] of [
      ['png', 'PNG', '투명 유지 · 무손실'],
      ['jpg', 'JPG', '파일이 가벼움'],
      ['gif', 'GIF', '움직이는 맵시트 기록용 (색이 256개로 줄어듭니다)'],
    ]) {
      const b = el('button', 'cst-colbtn' + (v === capState.format ? ' on' : ''), label);
      b.title = tip;
      b.addEventListener('click', () => {
        capState.format = v;
        for (const c of fmtWrap.children) c.classList.toggle('on', c === b);
        applyFmtRows();
      });
      fmtWrap.appendChild(b);
    }

    // 형식에 따라 어떤 줄을 보일지
    function applyFmtRows() {
      const isGif = capState.format === 'gif';
      gifRow.classList.toggle('cst-hide', !isGif);
      scaleRow.classList.toggle('cst-hide', isGif); // 배율은 정지 이미지 전용
      gifModeRow.classList.toggle('cst-hide', !isGif);
      gifFpsRow.classList.toggle('cst-hide', !isGif || !capState.gifSmooth);
    }
    fmtRow.appendChild(fmtWrap);

    // 배율
    const scaleRow = el('div', 'cst-slider-row');
    scaleRow.appendChild(el('label', '', '배율'));
    const scaleWrap = el('div', 'cst-colbtns');
    for (const v of [1, 2, 4]) {
      const b = el('button', 'cst-colbtn' + (v === capState.scale ? ' on' : ''), v + 'x');
      b.title = v === 1 ? '지금 화면 그대로' : '브라우저를 잠깐 확대해서 더 큰 해상도로 찍습니다';
      b.addEventListener('click', () => {
        capState.scale = v;
        for (const c of scaleWrap.children) c.classList.toggle('on', c === b);
      });
      scaleWrap.appendChild(b);
    }
    scaleRow.appendChild(scaleWrap);

    // GIF 길이
    const gifRow = el('div', 'cst-slider-row');
    gifRow.appendChild(el('label', '', '길이'));
    const gifRange = document.createElement('input');
    gifRange.type = 'range';
    gifRange.min = 2;
    gifRange.max = 10;
    gifRange.value = capState.gifSec;
    const gifOut = el('output', '', capState.gifSec + '초');
    gifRange.addEventListener('input', () => {
      capState.gifSec = Number(gifRange.value);
      gifOut.textContent = capState.gifSec + '초';
    });
    gifRow.append(gifRange, gifOut);


    // 찍는 방식 — 화면 찍기는 초당 2컷이 한계, 탭 영상은 더 잘게 딸 수 있다
    const gifModeRow = el('div', 'cst-slider-row');
    gifModeRow.appendChild(el('label', '', '찍는 방식'));
    const gifModeWrap = el('div', 'cst-colbtns');
    for (const [v, label] of [[false, '화면 찍기'], [true, '매끄럽게']]) {
      const b = el('button', 'cst-colbtn' + (v === capState.gifSmooth ? ' on' : ''), label);
      b.title = v
        ? '탭 영상을 받아 초당 10~30컷으로 찍습니다 (쓸 수 없으면 화면 찍기로 넘어갑니다)'
        : '초당 2컷 — 어디서나 되지만 뚝뚝 끊깁니다';
      b.addEventListener('click', () => {
        capState.gifSmooth = v;
        for (const c of gifModeWrap.children) c.classList.toggle('on', c === b);
        gifFpsRow.classList.toggle('cst-hide', !v || capState.format !== 'gif');
      });
      gifModeWrap.appendChild(b);
    }
    gifModeRow.appendChild(gifModeWrap);

    // 초당 컷 수 (매끄럽게 모드에서만)
    const gifFpsRow = el('div', 'cst-slider-row');
    gifFpsRow.appendChild(el('label', '', '초당 컷'));
    const gifFpsWrap = el('div', 'cst-colbtns');
    for (const v of [10, 15, 20, 30]) {
      const b = el('button', 'cst-colbtn' + (v === capState.gifFps ? ' on' : ''), v + '컷');
      b.title =
        v >= 30
          ? '가장 매끄럽지만 파일이 아주 커집니다 (담는 폭도 480px로 줄어듭니다)'
          : v >= 20
            ? '매끄럽습니다 (담는 폭 600px)'
            : '적당합니다 (담는 폭 720px)';
      b.addEventListener('click', () => {
        capState.gifFps = v;
        for (const c of gifFpsWrap.children) c.classList.toggle('on', c === b);
      });
      gifFpsWrap.appendChild(b);
    }
    gifFpsRow.appendChild(gifFpsWrap);



    const gifRows = [gifRow, gifModeRow, gifFpsRow];

    const opts = el('div', 'cst-sliders');
    opts.append(fmtRow, scaleRow, gifRow, gifModeRow, gifFpsRow);
    body.appendChild(opts);
    applyFmtRows();

    // 캡처 버튼들
    const autoBtn = el('button', 'cst-btn', '맵시트 자동 인식');
    autoBtn.style.width = '100%';
    autoBtn.title = '맵시트(격자판 또는 배경 이미지)를 찾아 그 부분만 잘라 저장합니다';
    autoBtn.addEventListener('click', () => runCapture('auto'));
    body.appendChild(autoBtn);

    const row1 = el('div', 'cst-row');
    const dragBtn = el('button', 'cst-btn ghost', '영역 드래그');
    dragBtn.style.flex = '1';
    dragBtn.title = '드래그한 범위 안에서 맵시트 경계를 자동으로 다듬어 저장합니다';
    dragBtn.addEventListener('click', () => runCapture('drag'));
    const dragRawBtn = el('button', 'cst-btn ghost', '드래그(그대로)');
    dragRawBtn.style.flex = '1';
    dragRawBtn.title = '드래그한 범위를 다듬지 않고 그대로 저장';
    dragRawBtn.addEventListener('click', () => runCapture('dragRaw'));
    row1.append(dragBtn, dragRawBtn);
    body.appendChild(row1);

    const row2 = el('div', 'cst-row');
    const boardBtn = el('button', 'cst-btn ghost', '맵 전체 (채팅 제외)');
    boardBtn.style.flex = '1';
    boardBtn.addEventListener('click', () => runCapture('board'));
    const fullBtn = el('button', 'cst-btn ghost', '화면 전체');
    fullBtn.addEventListener('click', () => runCapture('full'));
    row2.append(boardBtn, fullBtn);
    body.appendChild(row2);

    // 이 방에서 전에 드래그한 영역 — 매번 다시 그리지 않아도 되게
    const savedRow = el('div', 'cst-row');
    savedRow.classList.add('cst-hide');
    const savedBtn = el('button', 'cst-btn ghost', '저장한 영역으로 찍기');
    savedBtn.style.flex = '1';
    const savedClearBtn = el('button', 'cst-btn ghost', '영역 잊기');
    savedRow.append(savedBtn, savedClearBtn);
    body.appendChild(savedRow);

    getRoom().then((room) => {
      const v = room && room.capRect;
      if (!v || !v.rw || !v.rh) return;
      const r = ratioToRect(v);
      savedRow.classList.remove('cst-hide');
      savedBtn.title = `${r.w}×${r.h}px 자리 — ${v.mode === 'dragRaw' ? '다듬지 않고 그대로' : '경계를 다듬어서'} 찍습니다`;
      savedBtn.addEventListener('click', () => runCapture(v.mode || 'drag', ratioToRect(v)));
      savedClearBtn.addEventListener('click', async () => {
        await patchRoom((rm) => {
          delete rm.capRect;
        });
        renderCapture();
        toast('저장한 캡처 영역을 지웠습니다.');
      });
    });

    const row3 = el('div', 'cst-row');
    const origBtn = el('button', 'cst-btn ghost', '맵시트 원본 파일만 받기');
    origBtn.style.flex = '1';
    origBtn.title = '맵시트가 이미지 한 장일 때 그 원본을 그대로 내려받습니다 (캐릭터·말은 안 나옴)';
    origBtn.addEventListener('click', () => runCapture('original'));
    row3.appendChild(origBtn);
    body.appendChild(row3);

    capProgress = el('div', 'cst-log-progress', '');
    body.appendChild(capProgress);

    body.appendChild(
      el(
        'div',
        'cst-hint cst-hint-help',
        '자동 인식이 빗나가면 [영역 드래그]로 맵시트를 적당히 감싸주세요. 그 안에서 실제 경계를 찾아 잘라냅니다.\n' +
          '한 번 드래그한 영역은 이 방에 기억해 두어, 다음부터는 [저장한 영역으로 찍기]로 바로 찍을 수 있습니다.\n' +
          'GIF는 브라우저 제한 때문에 초당 2컷으로만 찍힙니다. 실제 속도로 재생하면 끊겨 보이니\n' +
          '[재생 속도]를 2~3배로 두면 훨씬 매끄럽습니다 (컷 수는 그대로).'
      )
    );
  }

  // ---------- 방마다 캡처 영역 기억 ----------
  // 창 크기가 달라져도 쓸 수 있게 화면 비율로 담아둔다.
  function rectToRatio(r) {
    return {
      rx: r.x / innerWidth,
      ry: r.y / innerHeight,
      rw: r.w / innerWidth,
      rh: r.h / innerHeight,
    };
  }

  function ratioToRect(v) {
    return {
      x: Math.round(v.rx * innerWidth),
      y: Math.round(v.ry * innerHeight),
      w: Math.round(v.rw * innerWidth),
      h: Math.round(v.rh * innerHeight),
    };
  }

  async function saveCapRect(rect, mode) {
    try {
      await patchRoom((rm) => {
        rm.capRect = { ...rectToRatio(rect), mode, at: Date.now() };
      });
    } catch (_) {}
  }

  let capProgress = null;
  function capSay(msg) {
    if (capProgress) capProgress.textContent = msg;
  }

  // ---------- 맵시트 영역 찾기 ----------
  // 채팅 패널(오른쪽)의 위치 — 맵 영역의 오른쪽 경계로 쓴다
  function findChatPanelRect() {
    const starts = [
      chatLogEls()[0],
      document.querySelector('[data-virtuoso-scroller], [data-testid="virtuoso-scroller"]'),
      document.querySelector('div[class*="MuiInputBase-root"] textarea'),
    ].filter(Boolean);
    let best = null;
    for (const start of starts) {
      let elx = start;
      for (let i = 0; i < 10 && elx && elx !== document.body; i++) {
        const r = elx.getBoundingClientRect();
        if (r.height > innerHeight * 0.5 && r.width > 180 && r.width < innerWidth * 0.6) {
          if (!best || r.width > best.width) best = r;
        }
        elx = elx.parentElement;
      }
    }
    return best;
  }

  function boardRect() {
    const chat = findChatPanelRect();
    const right = chat && chat.left > innerWidth * 0.4 ? chat.left : innerWidth;
    return { x: 0, y: 0, w: Math.max(1, right), h: innerHeight };
  }

  // DOM에서 맵시트로 보이는 요소 찾기.
  // 코코포리아 맵시트는 ① 격자 배경이 깔린 보드 ② 배경 이미지 한 장 두 형태다.
  // 흐림(blur) 처리된 뒤쪽 배경은 제외해야 진짜 맵시트만 남는다.
  function findMapSheet() {
    const board = boardRect();
    const boardArea = board.w * board.h;
    let best = null;

    const consider = (elx, url) => {
      if (elx.closest && elx.closest('.cst-root')) return;
      const cs = getComputedStyle(elx);
      if (cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) < 0.15) return;
      if (/blur\(/.test(cs.filter || '')) return; // 흐린 배경막은 맵시트가 아니다
      const r = elx.getBoundingClientRect();
      const x = Math.max(board.x, r.left);
      const y = Math.max(board.y, r.top);
      const x2 = Math.min(board.x + board.w, r.right);
      const y2 = Math.min(board.y + board.h, r.bottom);
      const w = x2 - x;
      const h = y2 - y;
      if (w < 80 || h < 80) return;
      const area = w * h;
      if (area < boardArea * 0.06) return;
      if (area > boardArea * 0.99) return; // 화면 전체를 덮는 배경막은 제외
      if (!best || area > best.area) best = { rect: { x, y, w, h }, area, el: elx, url: url || '' };
    };

    for (const elx of document.querySelectorAll('img')) {
      consider(elx, elx.currentSrc || elx.src || '');
    }
    for (const elx of document.querySelectorAll('canvas, video')) consider(elx, '');
    for (const elx of document.querySelectorAll('div, section, main, span')) {
      const cs = getComputedStyle(elx);
      const bg = cs.backgroundImage;
      if (!bg || bg === 'none') continue;
      const m = bg.match(/url\(["']?([^"')]+)["']?\)/);
      // 격자(repeating-gradient)도 맵시트 후보
      consider(elx, m ? m[1] : '');
    }
    return best;
  }

  // ---------- 픽셀 기반 경계 다듬기 ----------
  // 캡처 이미지에서 "내용이 있는" 영역만 남긴다.
  // 격자판은 선이, 맵시트 이미지는 또렷한 무늬가 변화량을 만들고,
  // 빈 검은 보드나 흐릿한 배경은 변화량이 거의 없다 → 그 차이로 경계를 찾는다.
  function trimByContent(canvas, rect, tight) {
    const W = Math.round(rect.w);
    const H = Math.round(rect.h);
    if (W < 20 || H < 20) return rect;
    const AW = Math.min(480, W);
    const AH = Math.max(1, Math.round((H * AW) / W));
    const small = document.createElement('canvas');
    small.width = AW;
    small.height = AH;
    const sc = small.getContext('2d', { willReadFrequently: true });
    sc.drawImage(canvas, Math.round(rect.x), Math.round(rect.y), W, H, 0, 0, AW, AH);
    let px;
    try {
      px = sc.getImageData(0, 0, AW, AH).data;
    } catch (_) {
      return rect;
    }

    const lum = new Float32Array(AW * AH);
    for (let i = 0, p = 0; p < lum.length; i += 4, p++) {
      lum[p] = 0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2];
    }
    const rowE = new Float32Array(AH);
    const colE = new Float32Array(AW);
    for (let y = 1; y < AH; y++) {
      for (let x = 1; x < AW; x++) {
        const p = y * AW + x;
        const g = Math.abs(lum[p] - lum[p - 1]) + Math.abs(lum[p] - lum[p - AW]);
        rowE[y] += g;
        colE[x] += g;
      }
    }
    const cut = (arr, len) => {
      let max = 0;
      for (let i = 0; i < len; i++) if (arr[i] > max) max = arr[i];
      if (max <= 0) return null;
      // 직접 드래그한 경우엔 더 바짝 조인다 (주변 여백이 남는다는 피드백 반영)
      const th = max * (tight ? 0.3 : 0.14);
      let a = 0;
      let b = len - 1;
      while (a < len && arr[a] < th) a++;
      while (b > a && arr[b] < th) b--;
      return a >= b ? null : [a, b];
    };
    const rc = cut(rowE, AH);
    const cc = cut(colE, AW);
    if (!rc || !cc) return rect;

    const sx = W / AW;
    const sy = H / AH;
    const pad = tight ? 0 : 2;
    const nx = rect.x + Math.max(0, (cc[0] - pad) * sx);
    const ny = rect.y + Math.max(0, (rc[0] - pad) * sy);
    const nw = Math.min(W - (nx - rect.x), (cc[1] - cc[0] + 1 + pad * 2) * sx);
    const nh = Math.min(H - (ny - rect.y), (rc[1] - rc[0] + 1 + pad * 2) * sy);
    if (nw < 40 || nh < 40) return rect;
    return { x: nx, y: ny, w: nw, h: nh };
  }

  // ---------- 캡처 실행 ----------
  // 캡처 순간 마우스가 올라가 있어 생긴 hover 강조가 같이 찍히는 것을 막는다
  function suppressHover() {
    const st = document.createElement('style');
    st.id = 'cst-nohover';
    st.textContent =
      '*, *::before, *::after { transition: none !important; animation: none !important; }' +
      'body * { cursor: none !important; }';
    document.documentElement.appendChild(st);
    // 포인터를 화면 밖으로 보낸 것처럼 이벤트를 흘려 hover 상태를 푼다
    try {
      const ev = (t) => document.elementFromPoint(2, 2) &&
        document.elementFromPoint(2, 2).dispatchEvent(new PointerEvent(t, { bubbles: true, clientX: -50, clientY: -50 }));
      ev('pointerout');
      ev('pointerleave');
      ev('mouseout');
    } catch (_) {}
    return () => st.remove();
  }

  function hideOurUi() {
    const hidden = [];
    for (const elx of [panel, fab, noticeBar, toastEl]) {
      if (elx && elx.style.display !== 'none') {
        hidden.push([elx, elx.style.display]);
        elx.style.display = 'none';
      }
    }
    return () => {
      for (const [elx, disp] of hidden) elx.style.display = disp;
    };
  }

  function msg(type, payload) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type, ...(payload || {}) }, (r) =>
          resolve(chrome.runtime.lastError ? { ok: false, error: chrome.runtime.lastError.message } : r)
        );
      } catch (err) {
        resolve({ ok: false, error: String(err && err.message) });
      }
    });
  }

  function loadImg(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error('이미지를 읽지 못했어요.'));
      img.src = src;
    });
  }

  async function shoot() {
    const res = await msg('CAPTURE_VISIBLE');
    if (!res || !res.ok || !res.dataUrl) throw new Error((res && res.error) || '캡처 응답 없음');
    const img = await loadImg(res.dataUrl);
    const cv = document.createElement('canvas');
    cv.width = img.width;
    cv.height = img.height;
    cv.getContext('2d').drawImage(img, 0, 0);
    return { canvas: cv, scale: img.width / innerWidth };
  }

  // 사람이 읽는 파일 크기
  function fmtSize(bytes) {
    if (bytes < 1024) return bytes + 'B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + 'KB';
    return (bytes / 1048576).toFixed(2) + 'MB';
  }

  function saveBlob(blob, ext) {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    const stamp = `${String(d.getFullYear()).slice(2)}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${capName}_맵시트_${stamp}.${ext}`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 20000);
  }

  let capName = '코코포리아';

  // 원본 이미지 그대로 저장 (맵시트가 이미지 한 장일 때 — 화면 캡처보다 훨씬 고화질)
  async function saveOriginal(url) {
    const res = await fetch(url, { mode: 'cors' });
    if (!res.ok) throw new Error('원본 이미지를 받지 못했어요.');
    const blob = await res.blob();
    const bmp = await createImageBitmap(blob).catch(() => null);
    const ext = (blob.type.split('/')[1] || 'png').replace('jpeg', 'jpg');
    saveBlob(blob, ext);
    return bmp ? `${bmp.width}×${bmp.height}` : '원본';
  }

  async function runCapture(mode, reuseRect) {
    if (capBusy) return;
    capBusy = true;
    capStop = false;
    try {
      const room = await getRoom();
      capName = (room.name || '코코포리아').replace(/[\\/:*?"<>|]/g, '_').slice(0, 40);

      // 드래그 모드는 먼저 범위를 받는다
      let dragRect = reuseRect || null;
      if ((mode === 'drag' || mode === 'dragRaw') && !dragRect) {
        panel.style.display = 'none';
        dragRect = await new Promise((r) => startAreaSelect(r));
        panel.style.display = 'flex';
        if (!dragRect) {
          capBusy = false;
          return;
        }
        // 다음에 또 쓸 수 있게 이 방의 영역으로 기억해 둔다
        await saveCapRect(dragRect, mode);
        if (state.activeTab === 'capture') renderCapture();
      }

      // '원본 파일' 모드일 때만 맵시트 이미지 원본을 그대로 받는다.
      // (자동 인식은 전경·배경·캐릭터가 다 보이는 화면 그대로를 찍어야 한다)
      if (mode === 'original') {
        const sheet = findMapSheet();
        if (!sheet || !/^https?:/i.test(sheet.url)) {
          capSay('맵시트가 이미지 파일이 아니라 원본을 받을 수 없어요. [맵시트 자동 인식]을 써 주세요.');
          capBusy = false;
          return;
        }
        capSay('원본 이미지 받는 중…');
        const size = await saveOriginal(sheet.url);
        capSay(`원본 이미지 그대로 저장됨 (${size}) — 캐릭터 말은 포함되지 않습니다`);
        toast(`맵시트 원본 저장됨 (${size})`);
        capBusy = false;
        return;
      }

      if (capState.format === 'gif') {
        await captureGif(mode, dragRect);
      } else {
        await captureStill(mode, dragRect);
      }
    } catch (err) {
      const msgText = friendlyError(err);
      capSay(msgText);
      toast(msgText);
    }
    capBusy = false;
  }

  let capBusy = false;
  let capStop = false;

  // 개발자 오류 문구를 사용자가 이해할 수 있는 말로 바꾼다
  function friendlyError(err) {
    const raw = String((err && err.message) || err || '');
    if (/Extension context invalidated|context invalidated/i.test(raw)) {
      return '확장이 방금 업데이트돼서 연결이 끊겼어요. 페이지를 새로고침(F5)한 뒤 다시 시도해 주세요.';
    }
    if (/MAX_CAPTURE|quota|too many/i.test(raw)) {
      return '캡처를 너무 빠르게 반복했어요. 몇 초 뒤에 다시 눌러 주세요.';
    }
    if (/activeTab|permission|not allowed/i.test(raw)) {
      return '이 탭을 캡처할 권한이 없어요. 코코포리아 방 화면에서 실행했는지 확인해 주세요.';
    }
    if (/응답 없음|no tab|Receiving end does not exist/i.test(raw)) {
      return '확장 백그라운드가 응답하지 않아요. 페이지를 새로고침하거나 브라우저를 다시 켜 주세요.';
    }
    if (/원본 이미지를 받지 못했|Failed to fetch|NetworkError/i.test(raw)) {
      return '이미지를 내려받지 못했어요. 인터넷 연결을 확인하거나 [맵시트 자동 인식]으로 화면을 찍어 주세요.';
    }
    if (/변환 실패|toBlob/i.test(raw)) {
      return '이미지를 파일로 만드는 데 실패했어요. 캡처 영역이 너무 크지 않은지 확인해 주세요.';
    }
    return '캡처에 실패했어요: ' + raw;
  }

  // 배율 적용: 브라우저를 확대해 실제로 더 큰 픽셀로 렌더링시킨다.
  // 확대해도 캡처 해상도가 늘지 않는 화면(뷰포트에 꽉 맞춘 레이아웃)이면 원래대로 되돌린다.
  // ---------- 배율 캡처 ----------
  // 배율을 올리는 방법은 크롬 확대율을 올려 같은 영역에 픽셀을 더 담는 것뿐이다.
  // 그런데 확대하면 화면이 다시 배치돼서, 맵시트가 잘리거나
  // 엉뚱한 요소(넓어진 채팅창)가 제일 큰 후보로 잡히는 일이 있었다.
  // 그래서 확대 전 "화면에서 차지하던 비율"을 기억해 두고,
  // 확대 후에도 배치가 그대로인지 확인한 다음에만 그 배율로 찍는다.
  // 어긋나면 배율을 한 단계 낮춰 다시 보고, 끝까지 안 맞으면 1배율로 찍는다.
  function viewportFrac(r) {
    return {
      fx: r.x / innerWidth,
      fy: r.y / innerHeight,
      fw: r.w / innerWidth,
      fh: r.h / innerHeight,
    };
  }

  function fracToRect(f) {
    return {
      x: f.fx * innerWidth,
      y: f.fy * innerHeight,
      w: f.fw * innerWidth,
      h: f.fh * innerHeight,
    };
  }

  function fracClose(a, b, tol) {
    const t = tol || 0.04;
    return (
      Math.abs(a.fx - b.fx) < t &&
      Math.abs(a.fy - b.fy) < t &&
      Math.abs(a.fw - b.fw) < t &&
      Math.abs(a.fh - b.fh) < t
    );
  }

  // 찍을 영역을 1배율에서 먼저 정하고, 배율을 낮춰가며 배치가 유지되는 지점을 찾는다.
  // 반환: { s, r, scale, asked } — r은 그때 화면 좌표(CSS px)
  async function shootAtBestScale(mode, dragRect) {
    const base0 = rectFor(mode, dragRect);
    if (!base0 || base0.w < 4 || base0.h < 4) return null;
    const want = viewportFrac(base0);
    const boardBefore = viewportFrac(boardRect());
    const asked = capState.scale;

    const steps = asked === 4 ? [4, 2, 1] : asked === 2 ? [2, 1] : [1];
    const z = asked > 1 ? await msg('GET_ZOOM') : null;
    const base = z && z.ok ? z.factor : 1;
    const unzoom = async () => {
      await msg('SET_ZOOM', { factor: base });
      await new Promise((r) => setTimeout(r, 250));
    };

    for (const k of steps) {
      if (k > 1) {
        const set = await msg('SET_ZOOM', { factor: base * k });
        if (!set || !set.ok) continue;
        await new Promise((r) => setTimeout(r, 700));
        // 확대해도 화면 배치가 비율 그대로인지 확인 — 아니면 이 배율은 쓸 수 없다
        if (!fracClose(boardBefore, viewportFrac(boardRect()))) {
          await unzoom();
          continue;
        }
      }
      await new Promise((r) => requestAnimationFrame(() => setTimeout(r, 80)));
      const s = await shoot();
      const r = fracToRect(want);
      if (k > 1) await unzoom();
      return { s, r, scale: k, asked };
    }
    return null;
  }

  function rectFor(mode, dragRect) {
    if (mode === 'full') return { x: 0, y: 0, w: innerWidth, h: innerHeight };
    if (mode === 'board') return boardRect();
    if (mode === 'drag' || mode === 'dragRaw') return dragRect;
    const sheet = findMapSheet();
    return sheet ? sheet.rect : boardRect();
  }

  async function captureStill(mode, dragRect) {
    capSay('캡처 중…');
    const restore = hideOurUi();
    const unhover = suppressHover();
    let shot;
    try {
      shot = await shootAtBestScale(mode, dragRect);
    } finally {
      unhover();
      restore();
    }
    if (!shot) {
      capSay('찍을 영역을 찾지 못했어요. [영역 드래그]로 직접 감싸 주세요.');
      return;
    }

    const { s, r } = shot;
    let rect = { x: r.x * s.scale, y: r.y * s.scale, w: r.w * s.scale, h: r.h * s.scale };
    // 자동 인식/드래그(다듬기)는 픽셀 경계로 한 번 더 조인다
    if (mode === 'auto' || mode === 'drag' || mode === 'board') {
      rect = trimByContent(s.canvas, rect, mode === 'drag');
    }

    const cv = document.createElement('canvas');
    cv.width = Math.max(1, Math.round(rect.w));
    cv.height = Math.max(1, Math.round(rect.h));
    cv.getContext('2d').drawImage(
      s.canvas,
      Math.round(rect.x),
      Math.round(rect.y),
      cv.width,
      cv.height,
      0,
      0,
      cv.width,
      cv.height
    );

    const scaleNote =
      shot.scale === shot.asked
        ? shot.scale > 1
          ? ` · ${shot.scale}배율`
          : ''
        : ` · ${shot.asked}배율을 요청했지만 확대하면 화면 배치가 바뀌어 맵시트가 잘리므로 ${shot.scale}배율로 찍었어요`;
    capSay(`찍었어요 — ${cv.width}×${cv.height}px${scaleNote}. 미리보기에서 확인 후 저장하세요.`);
    showCapturePreview(cv, mode, dragRect);
  }

  // ---------- 캡처 미리보기 (저장 전에 확인하고 배율 바꿔 다시 찍기) ----------
  let previewOverlay = null;

  let previewObjUrl = '';

  function closeCapturePreview() {
    if (previewObjUrl) {
      URL.revokeObjectURL(previewObjUrl);
      previewObjUrl = '';
    }
    if (previewOverlay) {
      previewOverlay.remove();
      previewOverlay = null;
    }
  }

  // gif를 넘기면 캔버스 대신 그 GIF를 움직이는 채로 보여준다.
  //   gif = { blob, bytes, w, h, delayMs, count, src }
  // src(원본 프레임)가 함께 오면 미리보기에서 재생 속도·가로 크기를 바로 바꿀 수 있다 — 다시 찍지 않는다.
  function showCapturePreview(canvas, mode, dragRect, gif) {
    closeCapturePreview();
    const ov = el('div', 'cst-root');
    ov.id = 'cst-cap-preview';
    previewOverlay = ov;

    let cur = gif || null; // 지금 보고 있는 GIF
    const box = el('div', 'cst-cap-box');
    const head = el('div', 'cst-cap-head');
    const title = el('span', 'cst-cap-title', '');
    const closeBtn = el('button', 'cst-iconbtn', '✕');
    closeBtn.addEventListener('click', closeCapturePreview);
    head.append(title, closeBtn);

    const imgWrap = el('div', 'cst-cap-imgwrap');
    const img = document.createElement('img');
    imgWrap.appendChild(img);
    function paint() {
      if (cur) {
        if (previewObjUrl) URL.revokeObjectURL(previewObjUrl);
        previewObjUrl = URL.createObjectURL(cur.blob);
        img.src = previewObjUrl;
        title.textContent =
          `GIF 미리보기 — ${cur.w}×${cur.h}px · ${cur.count}컷 · ` +
          `컷당 ${(cur.delayMs / 1000).toFixed(2)}초 · ${fmtSize(cur.blob.size)}`;
      } else {
        img.src = canvas.toDataURL('image/png');
        title.textContent = `캡처 미리보기 — ${canvas.width}×${canvas.height}px`;
      }
    }

    const foot = el('div', 'cst-cap-foot');

    if (cur && cur.src) {
      // ---- GIF: 속도·크기를 슬라이더로 그 자리에서 바꾼다 ----
      let speed = capState.gifSpeed;
      let width = cur.w;
      const busy = el('span', 'cst-cap-lab', '');

      // 재생 속도 — 파일 안의 지연 값만 고쳐 쓰면 되므로 즉시 끝난다.
      // 0.25배(느리게)부터 8배까지 0.05 단위.
      const spBox = el('label', 'cst-cap-slider');
      const spLab = el('span', 'cst-cap-lab', '');
      const spRange = document.createElement('input');
      spRange.type = 'range';
      spRange.min = '0.25';
      spRange.max = '8';
      spRange.step = '0.05';
      spRange.value = String(speed);
      const showSpeed = () => {
        const ms = Math.max(20, Math.round(cur.src.realGap / speed));
        spLab.textContent = `재생 ${speed.toFixed(2)}배 · 컷당 ${(ms / 1000).toFixed(2)}초`;
      };
      const applySpeed = () => {
        const ms = Math.max(20, Math.round(cur.src.realGap / speed));
        const patched = window.CSTGif.setDelay(cur.bytes, ms);
        cur = { ...cur, bytes: patched.bytes, blob: new Blob([patched.bytes], { type: 'image/gif' }), delayMs: ms };
        paint();
      };
      spRange.addEventListener('input', () => {
        speed = Number(spRange.value) || 1;
        capState.gifSpeed = speed;
        showSpeed();
        applySpeed(); // 1ms면 끝나니 끄는 대로 바로 반영
      });
      spBox.append(spLab, spRange);

      // 가로 크기 — 프레임을 줄여 다시 만들어야 하므로 놓았을 때만 반영한다
      const wBox = el('label', 'cst-cap-slider');
      const wLab = el('span', 'cst-cap-lab', '');
      const wRange = document.createElement('input');
      wRange.type = 'range';
      wRange.min = String(Math.min(240, cur.src.w));
      wRange.max = String(cur.src.w);
      wRange.step = '8';
      wRange.value = String(width);
      const showWidth = (v) => {
        const h = Math.round((cur.src.h * v) / cur.src.w);
        wLab.textContent = `가로 ${v}px (${v}×${h})` + (v >= cur.src.w ? ' 최대' : '');
      };
      wRange.addEventListener('input', () => showWidth(Number(wRange.value)));
      wRange.addEventListener('change', async () => {
        const v = Number(wRange.value);
        if (v === width) return;
        width = v;
        capState.gifWidth = v;
        busy.textContent = '다시 만드는 중…';
        await new Promise((r) => setTimeout(r, 20));
        cur = { ...buildGif(cur.src, v, speed), src: cur.src };
        busy.textContent = '';
        showWidth(v);
        paint();
      });
      wBox.append(wLab, wRange);

      showSpeed();
      showWidth(width);
      foot.append(spBox, wBox, busy);

    } else {
      // ---- 정지 이미지: 배율은 실제 픽셀을 더 받아와야 하므로 다시 찍어야 한다 ----
      const scaleWrap = el('div', 'cst-colbtns');
      for (const v of [1, 2, 4]) {
        const b = el('button', 'cst-colbtn' + (v === capState.scale ? ' on' : ''), v + 'x');
        b.title = v === 1 ? '지금 화면 그대로' : '더 큰 해상도로 다시 찍습니다 (픽셀을 새로 받아와야 해서 재촬영)';
        b.addEventListener('click', async () => {
          capState.scale = v;
          for (const c of scaleWrap.children) c.classList.toggle('on', c === b);
          closeCapturePreview();
          await runCapture(mode, dragRect);
        });
        scaleWrap.appendChild(b);
      }
      foot.append(el('span', 'cst-cap-lab', '배율'), scaleWrap);
    }

    const saveBtn = el('button', 'cst-btn', '저장');
    saveBtn.addEventListener('click', async () => {
      if (cur) {
        saveBlob(cur.blob, 'gif');
        const sz = fmtSize(cur.blob.size);
        capSay(`GIF 저장됨 — ${cur.w}×${cur.h}px · ${cur.count}컷 · 컷당 ${(cur.delayMs / 1000).toFixed(2)}초 · ${sz}`);
        toast(`GIF 저장됨 (${cur.count}컷 · ${sz})`);
        closeCapturePreview();
        return;
      }
      const isJpg = capState.format === 'jpg';
      try {
        const blob = await new Promise((resolve, reject) =>
          canvas.toBlob(
            (b) => (b ? resolve(b) : reject(new Error('이미지 변환 실패'))),
            isJpg ? 'image/jpeg' : 'image/png',
            isJpg ? 0.94 : undefined
          )
        );
        saveBlob(blob, isJpg ? 'jpg' : 'png');
        const sz = fmtSize(blob.size);
        capSay(`저장됨 — ${canvas.width}×${canvas.height}px · ${sz}`);
        toast(`맵시트 저장됨 (${canvas.width}×${canvas.height}px · ${sz})`);
      } catch (err) {
        toast(friendlyError(err));
      }
      closeCapturePreview();
    });

    foot.append(saveBtn);
    box.append(head, imgWrap, foot);
    ov.appendChild(box);
    ov.addEventListener('click', (e) => {
      if (e.target === ov) closeCapturePreview();
    });
    document.body.appendChild(ov);
    applyTheme();
    paint();
  }

  // ---------- 매끄러운 GIF (탭 영상 스트림) ----------
  // 화면 찍기(captureVisibleTab)는 초당 2번으로 묶여 있어 프레임을 잘게 딸 수 없다.
  // 탭 영상 스트림을 받으면 초당 10~30컷까지 뽑을 수 있다.
  // 쓸 수 없는 환경이면 화면 찍기 방식으로 조용히 되돌아간다.
  // 탭 영상 스트림을 얻는다. 두 가지 길을 차례로 시도한다.
  //  ① chrome.tabCapture — 대화상자가 없어 편하지만, 확장이 이 탭에 대해
  //     "사용자 조작으로 불려온" 상태여야 해서 막히는 경우가 있다.
  //  ② getDisplayMedia — 공유할 화면을 고르는 대화상자가 뜨지만 확실히 된다.
  //     preferCurrentTab으로 지금 탭이 먼저 뜨게 해 둔다.
  const streamErrors = [];

  async function grabTabStream(maxFps) {
    streamErrors.length = 0;

    // ① tabCapture
    try {
      const res = await msg('GET_STREAM_ID');
      if (!res || !res.ok) throw new Error((res && res.error) || '스트림 ID 발급 실패');
      // 크기를 안 주면 크롬이 기본 해상도로 내보내며 비율이 다르면 위아래 검은 띠를 넣는다.
      // 뷰포트의 실제 픽셀 크기를 그대로 요구해 영상 좌표 = 화면 좌표가 되게 한다.
      const dpr = window.devicePixelRatio || 1;
      const vw = Math.max(2, Math.round(innerWidth * dpr));
      const vh = Math.max(2, Math.round(innerHeight * dpr));
      const ask = (size) =>
        navigator.mediaDevices.getUserMedia({
          audio: false,
          video: {
            mandatory: {
              chromeMediaSource: 'tab',
              chromeMediaSourceId: res.streamId,
              maxFrameRate: maxFps || 30,
              ...(size ? { minWidth: vw, maxWidth: vw, minHeight: vh, maxHeight: vh } : {}),
            },
          },
        });
      let st;
      try {
        st = await ask(true);
      } catch (_) {
        // 정확한 크기를 못 맞추는 환경이면 크기 조건 없이 다시 (검은 띠는 뒤에서 보정한다)
        st = await ask(false);
      }
      return { stream: st, how: 'tab' };
    } catch (err) {
      streamErrors.push('탭 캡처: ' + ((err && err.message) || (err && err.name) || 'error'));
    }

    // ② getDisplayMedia (대화상자)
    if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
      throw new Error(streamErrors.join(' / ') + ' / 이 브라우저는 화면 공유를 지원하지 않습니다');
    }
    try {
      const st = await navigator.mediaDevices.getDisplayMedia({
        audio: false,
        video: { frameRate: { ideal: maxFps || 30 } },
        preferCurrentTab: true,
      });
      return { stream: st, how: 'display' };
    } catch (err) {
      streamErrors.push('화면 공유: ' + ((err && err.message) || (err && err.name) || 'error'));
      throw new Error(streamErrors.join(' / '));
    }
  }

  async function grabSmoothFrames(mode, dragRect, hud) {
    hud.set('영상 스트림 준비 중… (화면 공유 창이 뜨면 이 탭을 골라 주세요)');
    const got = await grabTabStream(capState.gifFps);
    const stream = got.stream;

    const video = document.createElement('video');
    video.muted = true;
    video.playsInline = true;
    video.srcObject = stream;
    const stop = () => {
      try {
        for (const t of stream.getTracks()) t.stop();
      } catch (_) {}
      video.srcObject = null;
    };

    try {
      await video.play();
      // 첫 프레임이 들어올 때까지
      for (let i = 0; i < 60 && !video.videoWidth; i++) await new Promise((r) => setTimeout(r, 50));
      if (!video.videoWidth) throw new Error('탭 영상이 시작되지 않았습니다.');

      // 영상 비율이 뷰포트와 다르면 크롬이 검은 띠를 넣어 맞춘다 (레터박스/필러박스).
      // 그 띠 두께만큼 원점을 옮겨야 화면 찍기 방식과 같은 자리가 잘린다.
      const vwAspect = innerWidth / innerHeight;
      const vAspect = video.videoWidth / video.videoHeight;
      let contentW = video.videoWidth;
      let contentH = video.videoHeight;
      let offX = 0;
      let offY = 0;
      if (Math.abs(vAspect - vwAspect) > 0.005) {
        if (vAspect > vwAspect) {
          contentW = video.videoHeight * vwAspect; // 좌우 띠
          offX = (video.videoWidth - contentW) / 2;
        } else {
          contentH = video.videoWidth / vwAspect; // 위아래 띠
          offY = (video.videoHeight - contentH) / 2;
        }
      }
      const vScale = contentW / innerWidth;
      const r0 = mode === 'drag' || mode === 'dragRaw' ? dragRect : rectFor(mode, null);
      let px = { x: offX + r0.x * vScale, y: offY + r0.y * vScale, w: r0.w * vScale, h: r0.h * vScale };

      // 경계 다듬기는 한 프레임을 캔버스에 올려놓고 판단한다
      const probe = document.createElement('canvas');
      probe.width = video.videoWidth;
      probe.height = video.videoHeight;
      probe.getContext('2d', { willReadFrequently: true }).drawImage(video, 0, 0);
      if (mode === 'auto' || mode === 'drag' || mode === 'board') px = trimByContent(probe, px, mode === 'drag');
      // 영상은 계속 흘러 들어오므로 표시기를 촬영 영역 밖으로 치워 둔다
      hud.avoid({ x: (px.x - offX) / vScale, y: (px.y - offY) / vScale, w: px.w / vScale, h: px.h / vScale });

      // 컷이 많아지므로 담아두는 폭을 줄인다 (프레임 수 × 픽셀이 메모리를 잡아먹는다)
      const capW = keepWidthFor(Math.min(GIF_MAX_FRAMES, Math.round(capState.gifSec * capState.gifFps)), px.w, px.h);
      const k = px.w > capW ? capW / px.w : 1;
      const W = Math.max(1, Math.round(px.w * k));
      const H = Math.max(1, Math.round(px.h * k));

      const cv = document.createElement('canvas');
      cv.width = W;
      cv.height = H;
      const ctx = cv.getContext('2d', { willReadFrequently: true });

      const fps = capState.gifFps;
      const step = 1000 / fps;
      const total = Math.min(GIF_MAX_FRAMES, Math.max(2, Math.round(capState.gifSec * fps)));
      const frames = [];
      const t0 = Date.now();
      for (let i = 0; i < total; i++) {
        if (capStop) break;
        hud.set(`매끄러운 GIF 촬영 중 ${i + 1}/${total} (초당 ${fps}컷)`);
        ctx.drawImage(video, Math.round(px.x), Math.round(px.y), Math.round(px.w), Math.round(px.h), 0, 0, W, H);
        frames.push(ctx.getImageData(0, 0, W, H).data);
        const due = t0 + (i + 1) * step - Date.now();
        if (due > 0) await new Promise((r) => setTimeout(r, due));
      }
      const elapsed = Date.now() - t0;
      // 실제로 걸린 시간을 컷 수로 나눈 값이 진짜 간격이다
      const realGap = frames.length > 1 ? elapsed / frames.length : step;
      return { frames, w: W, h: H, realGap, fps };
    } finally {
      stop();
    }
  }

  const GIF_MAX_FRAMES = 150;
  const GIF_MAX_W = 2560; // 사람이 고를 수 있는 최대 폭
  // 담아두는 프레임 전체 픽셀 수 상한. RGBA 4바이트니까 약 160MB.
  // 컷이 적으면 크게, 많으면 작게 — 알아서 균형이 잡힌다.
  const GIF_PIXEL_BUDGET = 40e6;

  function keepWidthFor(frameCount, w, h) {
    const aspect = Math.max(0.1, w / Math.max(1, h));
    const byBudget = Math.floor(Math.sqrt((GIF_PIXEL_BUDGET / Math.max(1, frameCount)) * aspect));
    return Math.max(240, Math.min(GIF_MAX_W, byBudget, Math.round(w)));
  }

  async function captureGif(mode, dragRect) {
    if (!window.CSTGif) {
      toast('GIF 인코더를 불러오지 못했어요. 페이지를 새로고침해 주세요.');
      return;
    }

    // 매끄럽게 모드 — 실패하면 아래 화면 찍기 방식으로 내려간다
    if (capState.gifSmooth) {
      const restore0 = hideOurUi();
      const unhover0 = suppressHover();
      const hud0 = showCaptureHud();
      let src = null;
      let why = '';
      try {
        src = await grabSmoothFrames(mode, dragRect, hud0);
      } catch (err) {
        why = (err && err.message) || '실패';
      } finally {
        unhover0();
        restore0();
        hud0.done();
      }
      if (src && src.frames.length) {
        capSay('GIF 만드는 중… (잠시 걸립니다)');
        await new Promise((r) => setTimeout(r, 30));
        const out = buildGif(src, Math.min(capState.gifWidth, src.w), capState.gifSpeed);
        capSay(
          `GIF 완성 — ${out.w}×${out.h}px · ${src.frames.length}컷 (초당 ${src.fps}컷) · ${fmtSize(out.blob.size)}.`
        );
        showCapturePreview(null, mode, dragRect, { ...out, src });
        return;
      }
      capSay(`매끄럽게 찍지 못해 화면 찍기(초당 2컷)로 진행합니다 — ${why}`);
      await new Promise((r) => setTimeout(r, 600));
    }

    const FPS = 2; // 브라우저가 탭 캡처를 초당 2회로 제한한다
    const total = Math.max(2, capState.gifSec * FPS);
    const restore = hideOurUi();
    const unhover = suppressHover();
    const hud = showCaptureHud();
    const frames = [];
    const gaps = []; // 컷 사이 실제로 걸린 시간
    let W = 0;
    let H = 0;
    try {
      await new Promise((r) => requestAnimationFrame(() => setTimeout(r, 80)));
      let rect = null;
      let prevAt = 0;
      for (let i = 0; i < total; i++) {
        if (capStop) break;
        const t0 = Date.now();
        hud.set(`GIF 촬영 중 ${i + 1}/${total}`);
        // 표시기가 컷에 찍히지 않게 찍는 순간만 숨긴다 (숨김이 그려질 한 프레임을 기다린 뒤 촬영)
        hud.hide();
        await new Promise((r) => requestAnimationFrame(() => setTimeout(r, 0)));
        let s;
        try {
          s = await shoot();
        } finally {
          hud.show();
        }
        if (prevAt) gaps.push(t0 - prevAt);
        prevAt = t0;
        if (!rect) {
          const r0 = mode === 'drag' || mode === 'dragRaw' ? dragRect : rectFor(mode, null);
          let px = { x: r0.x * s.scale, y: r0.y * s.scale, w: r0.w * s.scale, h: r0.h * s.scale };
          if (mode === 'auto' || mode === 'drag' || mode === 'board') px = trimByContent(s.canvas, px, mode === 'drag');
          // 프레임은 담을 수 있는 가장 큰 폭으로 담아둔다.
          // 그래야 미리보기에서 가로 크기를 바꿀 때 다시 찍지 않고 줄여서 다시 만들 수 있다.
          const keep = keepWidthFor(total, px.w, px.h);
          const k = px.w > keep ? keep / px.w : 1;
          rect = px;
          W = Math.max(1, Math.round(px.w * k));
          H = Math.max(1, Math.round(px.h * k));
        }
        const cv = document.createElement('canvas');
        cv.width = W;
        cv.height = H;
        const ctx = cv.getContext('2d', { willReadFrequently: true });
        ctx.drawImage(s.canvas, Math.round(rect.x), Math.round(rect.y), Math.round(rect.w), Math.round(rect.h), 0, 0, W, H);
        frames.push(ctx.getImageData(0, 0, W, H).data);
        capSay(`GIF 촬영 중 ${i + 1}/${total}…`);
        const wait = 1000 / FPS - (Date.now() - t0);
        if (wait > 0) await new Promise((r) => setTimeout(r, wait));
      }
    } finally {
      unhover();
      restore();
      hud.done();
    }

    if (!frames.length) {
      capSay('GIF 촬영이 중단됐어요.');
      return;
    }
    capSay('GIF 만드는 중… (잠시 걸립니다)');
    await new Promise((r) => setTimeout(r, 30));

    // 실제로 찍힌 간격의 중앙값. 브라우저 제한 때문에 500ms보다 늘어지는 일이 흔한데,
    // 예전에는 무조건 500ms로 적어서 실제보다 빠르게 재생됐다.
    const realGap = gaps.length
      ? [...gaps].sort((a, b) => a - b)[Math.floor(gaps.length / 2)]
      : 1000 / FPS;
    // 재생 속도: 실제 속도(1) / 조금 빠르게(2) / 빠르게(3)
    const delayMs = Math.max(20, Math.round(realGap / capState.gifSpeed));

    // 담아둔 프레임(원본 폭 W)과 실제 간격을 들고 미리보기로 넘긴다.
    // 미리보기에서 가로 크기·재생 속도를 바꿀 때 다시 찍지 않고 여기서 다시 만든다.
    const src = { frames, w: W, h: H, realGap };
    const out = buildGif(src, Math.min(capState.gifWidth, W), capState.gifSpeed);
    capSay(`GIF 완성 — ${out.w}×${out.h}px · ${frames.length}컷 · ${fmtSize(out.blob.size)}. 미리보기에서 속도·크기를 바꿔볼 수 있어요.`);
    showCapturePreview(null, mode, dragRect, { ...out, src });
  }

  // 담아둔 프레임으로 GIF를 만든다. 폭을 줄이는 것만 한다 (없는 픽셀을 늘리지는 않는다).

  function buildGif(src, targetW, speed) {
    const w = Math.max(16, Math.min(targetW || src.w, src.w));
    const h = Math.max(1, Math.round((src.h * w) / src.w));
    let frames = src.frames;
    if (w !== src.w) {
      // 프레임마다 줄여 다시 그린다
      const from = document.createElement('canvas');
      from.width = src.w;
      from.height = src.h;
      const fctx = from.getContext('2d', { willReadFrequently: true });
      const to = document.createElement('canvas');
      to.width = w;
      to.height = h;
      const tctx = to.getContext('2d', { willReadFrequently: true });
      tctx.imageSmoothingEnabled = true;
      tctx.imageSmoothingQuality = 'high';
      frames = src.frames.map((data) => {
        fctx.putImageData(new ImageData(new Uint8ClampedArray(data), src.w, src.h), 0, 0);
        tctx.clearRect(0, 0, w, h);
        tctx.drawImage(from, 0, 0, w, h);
        return tctx.getImageData(0, 0, w, h).data;
      });
    }
    const delayMs = Math.max(20, Math.round(src.realGap / (speed || 1)));
    const bytes = window.CSTGif.encode(frames, w, h, { delayMs, maxColors: 255 });
    return { blob: new Blob([bytes], { type: 'image/gif' }), bytes, w, h, delayMs, count: frames.length };
  }

  // 패널을 숨긴 동안에도 진행 상황이 보이도록 화면에 띄우는 표시기 (중지 버튼 포함)
  function showCaptureHud() {
    const hud = el('div', 'cst-root');
    hud.id = 'cst-cap-hud';
    const txt = el('span', 'cst-cap-hud-text', '준비 중…');
    const stop = el('button', 'cst-btn ghost', '중지');
    stop.addEventListener('click', () => {
      capStop = true;
      txt.textContent = '중지하는 중…';
    });
    hud.append(txt, stop);
    document.body.appendChild(hud);
    applyTheme();
    // 촬영 영역(CSS px)과 겹치지 않는 자리로 옮긴다 — 겹치지 않는 자리가 없으면 숨긴다.
    // (탭 캡처에는 이 표시기도 같이 찍히므로, 크게 찍을 때 "촬영 중 8/8"이 GIF에 남던 문제)
    const avoid = (rc) => {
      if (!rc) return;
      hud.style.visibility = '';
      const w = hud.offsetWidth || 240;
      const h = hud.offsetHeight || 40;
      const M = 10;
      const spots = [
        { left: innerWidth / 2 - w / 2, top: innerHeight - 26 - h },
        { left: innerWidth / 2 - w / 2, top: 26 },
        { left: innerWidth - 16 - w, top: innerHeight / 2 - h / 2 },
        { left: 16, top: innerHeight / 2 - h / 2 },
        { left: innerWidth - 16 - w, top: 26 },
        { left: 16, top: 26 },
        { left: innerWidth - 16 - w, top: innerHeight - 26 - h },
        { left: 16, top: innerHeight - 26 - h },
      ];
      const overlaps = (p) =>
        !(p.left + w + M < rc.x || p.left - M > rc.x + rc.w || p.top + h + M < rc.y || p.top - M > rc.y + rc.h);
      const ok = spots.find((p) => !overlaps(p));
      if (!ok) {
        hud.style.visibility = 'hidden';
        return;
      }
      hud.style.left = Math.round(ok.left) + 'px';
      hud.style.top = Math.round(ok.top) + 'px';
      hud.style.bottom = 'auto';
      hud.style.transform = 'none';
    };
    return {
      set: (m) => (txt.textContent = m),
      hide: () => (hud.style.visibility = 'hidden'),
      show: () => (hud.style.visibility = ''),
      avoid,
      done: () => hud.remove(),
    };
  }

  // 드래그로 영역 선택 → cb(rect | null)
  function startAreaSelect(cb) {
    const ov = el('div', 'cst-root');
    ov.style.cssText = 'position:fixed;inset:0;z-index:2147483100;cursor:crosshair;background:rgba(0,0,0,.25);';
    const tip = el('div', '', '맵시트를 대충 감싸도록 드래그하세요 — ESC 취소');
    tip.style.cssText =
      'position:absolute;top:14px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,.75);color:#fff;' +
      'padding:6px 14px;border-radius:99px;font-size:12px;font-family:sans-serif;pointer-events:none;';
    const box = el('div');
    box.style.cssText =
      'position:absolute;border:2px solid #e05252;background:rgba(224,82,82,.12);display:none;pointer-events:none;';
    ov.append(tip, box);
    document.body.appendChild(ov);

    let sx = 0;
    let sy = 0;
    let dragging = false;
    const done = (rect) => {
      ov.remove();
      document.removeEventListener('keydown', onKey, true);
      cb(rect);
    };
    const onKey = (e) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        done(null);
      }
    };
    document.addEventListener('keydown', onKey, true);
    ov.addEventListener('pointerdown', (e) => {
      dragging = true;
      sx = e.clientX;
      sy = e.clientY;
      box.style.display = 'block';
      ov.setPointerCapture(e.pointerId);
    });
    ov.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      box.style.left = Math.min(sx, e.clientX) + 'px';
      box.style.top = Math.min(sy, e.clientY) + 'px';
      box.style.width = Math.abs(e.clientX - sx) + 'px';
      box.style.height = Math.abs(e.clientY - sy) + 'px';
    });
    ov.addEventListener('pointerup', (e) => {
      if (!dragging) return;
      const rect = {
        x: Math.min(sx, e.clientX),
        y: Math.min(sy, e.clientY),
        w: Math.abs(e.clientX - sx),
        h: Math.abs(e.clientY - sy),
      };
      done(rect.w > 8 && rect.h > 8 ? rect : null);
    });
  }

  // ----- 토스트 -----
  let toastEl = null;
  function toast(msg, opts = {}) {
    if (!toastEl) {
      toastEl = el('div', 'cst-root');
      toastEl.style.cssText =
        'position:fixed;left:50%;bottom:90px;transform:translateX(-50%);z-index:2147483001;' +
        'background:var(--cst-card);color:var(--cst-text);border:1px solid var(--cst-border);' +
        'border-radius:10px;padding:8px 14px;font-size:12px;box-shadow:var(--cst-shadow);display:none;max-width:70vw;';
      document.body.appendChild(toastEl);
      applyTheme();
    }
    toastEl.textContent = msg;
    // opts.action { label, run } — 알림에 버튼 하나 (되돌리기 등). 버튼이 있으면 5초 동안 보인다
    if (opts.action) {
      const b = document.createElement('button');
      b.className = 'cst-toast-action';
      b.textContent = opts.action.label || '되돌리기';
      b.addEventListener(
        'click',
        async () => {
          clearTimeout(toastEl._t);
          toastEl.style.display = 'none';
          try {
            await opts.action.run();
          } catch (_) {}
        },
        { once: true }
      );
      toastEl.appendChild(b);
    }
    toastEl.style.display = 'block';
    clearTimeout(toastEl._t);
    toastEl._t = setTimeout(() => (toastEl.style.display = 'none'), opts.ms || (opts.action ? 5000 : 2200));
  }

  // 채팅 스크롤 영역 찾기 — 수집기(background.js findScroller)와 같은 방식.
  // 코코포리아가 data-virtuoso-scroller 를 떼어내도, 채팅 항목의 조상 중
  // 실제로 스크롤되는 요소를 찾아내면 과거 로그 자동 스크롤은 그대로 된다.
  // 채팅 메시지 줄 — 코코포리아는 2026-08 무렵 react-virtuoso 를 TanStack Virtual 로 바꿨다.
  // 줄은 여전히 <div data-index> 이고 채팅 목록은 role="log" 인 스크롤 칸이다.
  // [data-index] 는 슬라이더(span) · 캐러셀(.slick-slide)에도 붙으므로 그런 것은 뺀다.
  function chatLogEls() {
    return [...document.querySelectorAll('[role="log"]')].filter((n) => !n.closest('.cst-root'));
  }
  function chatRows() {
    const logs = chatLogEls();
    if (logs.length) return logs.flatMap((l) => [...l.querySelectorAll('div[data-index]')]);
    return [...document.querySelectorAll('div[data-index]:not(.slick-slide)')].filter((n) => !n.closest('.cst-root, .MuiSlider-root'));
  }

  function findChatScroller() {
    // 1순위: role="log" 채팅 목록 (메시지가 가장 많은 것, 비었으면 보이는 것)
    const logs = chatLogEls();
    if (logs.length) {
      let bestLog = null;
      let most = -1;
      for (const l of logs) {
        const cnt = l.querySelectorAll('[data-index] .MuiListItemText-primary').length;
        const score = cnt * 2 + (l.offsetParent ? 1 : 0);
        if (score > most) {
          bestLog = l;
          most = score;
        }
      }
      if (bestLog) return bestLog;
    }
    const cand = [...document.querySelectorAll('[data-virtuoso-scroller], [data-testid="virtuoso-scroller"]')];
    let best = null;
    let bestCount = 0;
    for (const sc of cand) {
      const cnt = sc.querySelectorAll('[data-index] .MuiListItemText-primary').length;
      if (cnt > bestCount) {
        best = sc;
        bestCount = cnt;
      }
    }
    if (best) return best;
    const items = [...document.querySelectorAll('[data-index]')].filter((it) => it.querySelector('.MuiListItemText-primary'));
    for (const it of items.slice(0, 3)) {
      let p = it.parentElement;
      while (p && p !== document.body) {
        if (p.scrollHeight > p.clientHeight + 20 && /(auto|scroll|overlay)/.test(getComputedStyle(p).overflowY)) return p;
        p = p.parentElement;
      }
    }
    return null;
  }

  // ---------------- 화면 구조 진단 (헬스체크, v12.0) ----------------
  // 코코포리아가 화면 구조를 바꾸면 기능이 "조용히" 안 된다. 방에 들어온 뒤 주요 셀렉터를 검사해
  // 실패한 것이 있으면 상단 배너로 알려주고, 어느 기능이 영향을 받는지 적어 둔다.
  function chatTabsForHealth() {
    const starts = [];
    const input = findChatInput();
    if (input) starts.push(input);
    const sc = findChatScroller();
    if (sc) starts.push(sc);
    for (const start of starts) {
      let elx = start;
      for (let i = 0; i < 12 && elx; i++) {
        if (elx.querySelector) {
          const tl = elx.querySelector('[role="tablist"], .MuiTabs-root');
          if (tl && tl.querySelectorAll('[role="tab"], .MuiTab-root').length >= 2) return true;
        }
        elx = elx.parentElement;
      }
    }
    return false;
  }

  // dist:false 인 항목은 배포본에서 검사하지 않는다 (로그 수집 전용이라 볼 이유가 없다).
  // distAffects 는 배포본에서 대신 보여줄 영향 범위 (수집이 없으니 문구가 달라진다).
  const HEALTH_CHECKS = [
    { id: 'input', label: '채팅 입력창', critical: true, affects: '스탠딩 클릭 입력 · 특수문자 · 스니펫 · NPC 픽커', test: () => !!findChatInput() },
    { id: 'items', label: '채팅 메시지 목록', critical: true, needsMessages: true, affects: '로그 백업 · 자동 백업 · 언급 알림', distAffects: '언급 알림', test: () => !!document.querySelector('[data-index] .MuiListItemText-primary') },
    { id: 'body', label: '메시지 본문', critical: true, needsMessages: true, affects: '로그 백업(본문 읽기)', distAffects: '언급 알림(본문 읽기)', test: () => !!document.querySelector('[data-index] .MuiListItemText-secondary') },
    { id: 'scroller', label: '채팅 스크롤 영역', critical: false, needsMessages: true, dist: false, affects: '로그 백업(과거 로그 자동 스크롤)', test: () => !!findChatScroller() },
    { id: 'tabs', label: '채팅 탭바', critical: false, affects: '탭 전부 수집 · 탭별 알림', distAffects: '탭별 알림', test: chatTabsForHealth },
    { id: 'avatar', label: '메시지 아바타', critical: false, needsMessages: true, dist: false, affects: '로그의 표정 이미지', test: () => !!document.querySelector('[data-index] .MuiListItemAvatar-root img') },
    { id: 'gear', label: '설정(톱니) 버튼', critical: false, affects: '패널 버튼 자리 (폴백: 화면 구석에 표시)', test: () => !!findCcfoliaSettingsButton() },
    { id: 'roomname', label: '방 이름', critical: false, affects: '방 기록의 방 이름', test: () => !!document.querySelector('h6[class*="MuiTypography-subtitle2"]') },
  ];

  // 각 검사 → 'ok' | 'fail' | 'unknown'
  function runHealthCheck() {
    // 예전엔 [data-index] 가 하나라도 있으면 메시지가 있다고 봤다. 그런데 음량 슬라이더 등에도 붙어 있어
    // 새로 만든 방(채팅이 빈 방)에서 "메시지 목록 · 본문 · 스크롤 · 아바타 실패"로 잘못 떴다.
    const hasAnyMessage = chatRows().length > 0;
    const out = [];
    for (const c of HEALTH_CHECKS) {
      if (LITE && c.dist === false) continue;
      let status = 'unknown';
      try {
        if (c.needsMessages && !hasAnyMessage) status = 'unknown';
        else status = c.test() ? 'ok' : 'fail';
      } catch (_) {
        status = 'fail';
      }
      out.push({ ...c, status, affects: (LITE && c.distAffects) || c.affects });
    }
    return out;
  }

  let healthBanner = null;
  let lastHealth = null;

  function healthSignature(results) {
    const fails = results.filter((r) => r.status === 'fail').map((r) => r.id).sort();
    let ver = '';
    try {
      ver = extAlive() ? chrome.runtime.getManifest().version : '';
    } catch (_) {}
    return ver + '|' + fails.join(',');
  }

  async function showHealthBanner(results) {
    const fails = results.filter((r) => r.status === 'fail');
    if (!fails.length) {
      if (healthBanner) healthBanner.style.display = 'none';
      return;
    }
    const sig = healthSignature(results);
    const { healthDismissed } = await getLocal({ healthDismissed: '' });
    if (healthDismissed === sig) return; // 같은 실패 조합은 이미 닫았다

    if (!healthBanner) {
      healthBanner = el('div', 'cst-root');
      healthBanner.id = 'cst-health';
      document.body.appendChild(healthBanner);
      applyTheme();
    }
    healthBanner.innerHTML = '';
    healthBanner.style.display = 'flex';
    const critical = fails.some((r) => r.critical);
    healthBanner.classList.toggle('cst-health-critical', critical);

    const head = el('div', 'cst-health-head');
    const ic = el('span', 'cst-health-ic');
    ic.innerHTML = window.faIcon ? window.faIcon('warning') : '!';
    const affected = [...new Set(fails.map((r) => r.affects))].join(' / ');
    const msg = el('span', 'cst-health-msg', `코코포리아 화면 구조가 바뀐 것 같아요 — 지금 안 될 수 있는 기능: ${affected}`);
    head.append(ic, msg);

    const detail = el('div', 'cst-health-detail');
    detail.style.display = 'none';
    for (const r of results) {
      const row = el('div', 'cst-health-row cst-health-' + r.status);
      const mark = el('span', 'cst-health-mark');
      mark.innerHTML = r.status === 'ok' ? (window.faIcon ? window.faIcon('check') : 'O') : r.status === 'fail' ? (window.faIcon ? window.faIcon('xmark') : 'X') : '?';
      row.append(mark, el('span', 'cst-health-label', r.label), el('span', 'cst-health-aff', r.status === 'fail' ? r.affects : r.status === 'unknown' ? '메시지가 없어 확인 불가' : ''));
      detail.appendChild(row);
    }
    detail.appendChild(el('div', 'cst-hint cst-hint-help', '확장이 최신인지 확인하고, 최신에서도 그러면 제보해 주세요. (패널 [로그] 탭 → 화면 구조 진단에서 언제든 다시 볼 수 있어요)'));

    const btns = el('div', 'cst-health-btns');
    const moreBtn = el('button', 'cst-btn ghost cst-mini-btn', '자세히');
    moreBtn.addEventListener('click', () => {
      const open = detail.style.display === 'none';
      detail.style.display = open ? 'block' : 'none';
      moreBtn.textContent = open ? '접기' : '자세히';
    });
    const againBtn = el('button', 'cst-btn ghost cst-mini-btn', '다시 검사');
    againBtn.addEventListener('click', () => {
      const res = runHealthCheck();
      lastHealth = res;
      showHealthBanner(res);
      if (!res.some((r) => r.status === 'fail')) toast('지금은 모두 정상이에요.');
    });
    const closeBtn = el('button', 'cst-btn ghost cst-mini-btn', '닫기');
    closeBtn.title = '같은 문제가 계속되는 동안에는 다시 띄우지 않아요';
    closeBtn.addEventListener('click', async () => {
      await setLocal({ healthDismissed: sig });
      healthBanner.style.display = 'none';
    });
    btns.append(moreBtn, againBtn, closeBtn);
    head.appendChild(btns);
    healthBanner.append(head, detail);
  }

  // 방에 들어온 직후에는 아직 안 그려진 것이 많다. 몇 번 재검사해서 끝까지 실패하는 것만 알린다.
  function scheduleHealthChecks() {
    const delays = [8000, 20000, 35000];
    let i = 0;
    const tick = () => {
      if (!extAlive()) return;
      const res = runHealthCheck();
      lastHealth = res;
      const fails = res.some((r) => r.status === 'fail');
      i++;
      if (fails && i < delays.length) {
        setTimeout(tick, delays[i] - delays[i - 1]);
        return;
      }
      showHealthBanner(res);
      // 이후 10분마다 조용히 재검사 (새로 깨진 것이 있으면 배너)
      setInterval(() => {
        if (!extAlive()) return;
        const r2 = runHealthCheck();
        lastHealth = r2;
        showHealthBanner(r2);
      }, 10 * 60 * 1000);
    };
    setTimeout(tick, delays[0]);
  }

  // [로그] 탭에 붙는 진단 상자
  function healthSection() {
    const wrap = el('div', 'cst-sliders');
    wrap.appendChild(el('div', 'cst-slider-row', '화면 구조 진단'));
    wrap.appendChild(el('div', 'cst-hint cst-hint-help', '코코포리아가 업데이트되어 기능이 안 될 때, 어떤 부분이 안 맞는지 확인합니다.'));
    const box = el('div', 'cst-log-summary cst-health-box');
    const render = (results) => {
      box.innerHTML = '';
      if (!results) {
        box.appendChild(el('div', 'cst-log-summary-line', '아직 검사 전이에요. [지금 검사]를 눌러 주세요.'));
        return;
      }
      for (const r of results) {
        const row = el('div', 'cst-health-row cst-health-' + r.status);
        const mark = el('span', 'cst-health-mark');
        mark.innerHTML = r.status === 'ok' ? (window.faIcon ? window.faIcon('check') : 'O') : r.status === 'fail' ? (window.faIcon ? window.faIcon('xmark') : 'X') : '?';
        row.append(mark, el('span', 'cst-health-label', r.label), el('span', 'cst-health-aff', r.status === 'fail' ? r.affects : r.status === 'unknown' ? '메시지가 없어 확인 불가' : ''));
        box.appendChild(row);
      }
      const fails = results.filter((r) => r.status === 'fail').length;
      box.appendChild(el('div', 'cst-log-summary-line', fails ? `실패 ${fails}개 — 이 항목과 관련된 기능은 지금 안 될 수 있어요.` : '모두 정상이에요.'));
    };
    render(lastHealth);
    const btn = el('button', 'cst-btn ghost', '지금 검사');
    btn.style.width = '100%';
    btn.style.marginTop = '6px';
    btn.addEventListener('click', () => {
      lastHealth = runHealthCheck();
      render(lastHealth);
      showHealthBanner(lastHealth);
    });
    wrap.append(box, btn);
    return wrap;
  }


  // ---------------- 초기화 ----------------
  async function init() {
    const s = await getSync({
      theme: 'dark',
      accentColor: '',
      ccfPanel: true,
      specialChars: DEFAULT_CHARS,
      standingThumb: { zoom: 100, posX: 50, posY: 15 },
      standingCols: 3,
      standingCss: {},
      standingAtPrefix: true,
      noticePos: 'top',
      noticeFont: 12,
      helpOn: true,
      wardrobeLayout: 'tabs',
      standingHideOutfit: true,
      standingSharpen: true,
      standingSort: 'manual',
      standingSortReverse: false, // 예전 [역순] 버튼 — 새 정렬로 옮기고 지운다
      standingColsFixed: true,
      standingFollowSpeaker: true,
      standingThumbPerOutfit: true,
      standingSaveAllChars: false,
      updAutoReload: true,
    });
    reloadOnUpdate = s.updAutoReload !== false;
    if (!window.CST_LITE) {
      // 개인용: 팝업에서 '배포용 보기'를 켜 두었으면 배포본과 같은 화면으로 그린다
      const ed = await getLocal({ editionPreview: 'full' });
      const pv = ed && ed.editionPreview;
      if (pv === 'dist' || pv === 'distdev') LITE = true;
    }
    state.theme = THEMES.includes(s.theme) ? s.theme : 'dark';
    state.accent = s.accentColor || '';
    state.helpOn = s.helpOn !== false;
    state.noticePos = s.noticePos === 'bottom' ? 'bottom' : 'top';
    state.noticeFont = Number(s.noticeFont) || 12;
    state.atPrefix = s.standingAtPrefix !== false;
    state.panelOn = s.ccfPanel !== false;
    state.specialChars =
      Array.isArray(s.specialChars) && s.specialChars.length ? s.specialChars : DEFAULT_CHARS;
    state.legacyThumb = s.standingThumb || null; // 예전 모든 캐릭터 공통 값 — 방마다 처음 한 번 캐릭터들에 나눠 준다
    state.thumb = state.thumbSet.base;
    state.cols = [1, 2, 3, 4, 5, 6].includes(s.standingCols) ? s.standingCols : 3;
    state.colsFixed = s.standingColsFixed !== false;
    state.standingCss = s.standingCss || {};
    state.wardrobeLayout = ['tabs', 'toc', 'fold'].includes(s.wardrobeLayout) ? s.wardrobeLayout : 'tabs';
    state.hideOutfit = s.standingHideOutfit !== false;
    state.standingSort = SORT_KEYS.includes(s.standingSort) ? s.standingSort : 'manual';
    if (s.standingSortReverse === true) {
      // 예전 정렬 + 역순 → 새 정렬 하나로 (이름순 역순 = 이름 Z-A순, 추가순 역순 = 최근 추가부터)
      state.standingSort = { name: 'name_desc', added: 'recent' }[state.standingSort] || state.standingSort;
      setSync({ standingSort: state.standingSort, standingSortReverse: false });
    }
    state.sharpen = s.standingSharpen !== false;
    state.followSpeaker = s.standingFollowSpeaker !== false;
    state.saveAllChars = s.standingSaveAllChars === true;
    state.thumbPerOutfit = s.standingThumbPerOutfit !== false;
    try {
      const { panelUi } = await getLocal({ panelUi: null });
      if (panelUi && typeof panelUi === 'object') state.panelUi = { fold: {}, ...panelUi };
    } catch (_) {}
    if (!state.panelOn) return;
    buildUI();
    refreshNoticeBar();
    scheduleHealthChecks();
    startCharacterWatch();
  }

  if (extAlive()) chrome.storage.onChanged.addListener((changes, area) => {
    // 세션 관리자 등 다른 화면에서 공지를 고치면 방 화면 공지 바도 갱신.
    // 단, rooms 키는 방문 시각·시트 저장 등으로 수시로 쓰인다 — 공지 바에 실제로
    // 쓰이는 필드가 "이 방"에서 바뀐 경우에만 재생성한다 (전량 재렌더 + 문서 스캔 방지).
    if (area === 'local' && changes.editionPreview) applyEditionPreview(changes.editionPreview.newValue);
    if (area === 'local' && changes.rooms) {
      const NB_FIELDS = ['memos', 'notice', 'checklist', 'checklistPinned', 'checklistCollapsed', 'noticeOrder'];
      const ov = (changes.rooms.oldValue || {})[roomId] || {};
      const nv = (changes.rooms.newValue || {})[roomId] || {};
      for (const k of NB_FIELDS) {
        if (JSON.stringify(ov[k]) !== JSON.stringify(nv[k])) {
          refreshNoticeBar();
          break;
        }
      }
      return;
    }
    if (area !== 'sync') return;
    if (changes.theme || changes.accentColor || changes.helpOn) {
      if (changes.theme) state.theme = THEMES.includes(changes.theme.newValue) ? changes.theme.newValue : 'dark';
      if (changes.accentColor) state.accent = changes.accentColor.newValue || '';
      if (changes.helpOn) state.helpOn = changes.helpOn.newValue !== false;
      applyTheme();
    }
    if (changes.noticePos || changes.noticeFont) {
      if (changes.noticePos) state.noticePos = changes.noticePos.newValue === 'bottom' ? 'bottom' : 'top';
      if (changes.noticeFont) state.noticeFont = Number(changes.noticeFont.newValue) || 12;
      refreshNoticeBar();
    }
    if (changes.updAutoReload) reloadOnUpdate = changes.updAutoReload.newValue !== false;
    // 이 창에서 바꾼 값이 되돌아온 것이면(이미 같은 값) 다시 그리지 않는다 — 두 번 그리다 스크롤이 튀지 않게
    if (changes.standingColsFixed) {
      const v = changes.standingColsFixed.newValue !== false;
      if (state.colsFixed !== v) {
        state.colsFixed = v;
        if (state.activeTab === 'standing') renderBody();
      }
    }
    if (changes.standingSort) {
      const v = SORT_KEYS.includes(changes.standingSort.newValue) ? changes.standingSort.newValue : 'manual';
      if (state.standingSort !== v) {
        state.standingSort = v;
        if (state.activeTab === 'standing') renderBody();
      }
    }
    if (changes.standingThumbPerOutfit) {
      const v = changes.standingThumbPerOutfit.newValue !== false;
      if (state.thumbPerOutfit !== v) {
        state.thumbPerOutfit = v;
        if (state.activeTab === 'standing') renderBody();
      }
    }
    if (changes.standingSaveAllChars) {
      const v = changes.standingSaveAllChars.newValue === true;
      if (state.saveAllChars !== v) {
        state.saveAllChars = v;
        storeCharsSig = '';
        startCharacterWatch();
      }
    }
    if (changes.standingFollowSpeaker) {
      const v = changes.standingFollowSpeaker.newValue !== false;
      if (state.followSpeaker !== v) {
        state.followSpeaker = v;
        if (state.activeTab === 'standing') renderBody();
      }
    }
    if (changes.standingHideOutfit) {
      const v = changes.standingHideOutfit.newValue !== false;
      if (state.hideOutfit !== v) {
        state.hideOutfit = v;
        if (state.activeTab === 'standing') renderBody();
      }
    }
    if (changes.standingSharpen) {
      state.sharpen = changes.standingSharpen.newValue !== false;
      refreshThumbStyles();
    }
    if (changes.wardrobeLayout) {
      const v = ['tabs', 'toc', 'fold'].includes(changes.wardrobeLayout.newValue) ? changes.wardrobeLayout.newValue : 'tabs';
      if (state.wardrobeLayout !== v) {
        state.wardrobeLayout = v;
        if (state.activeTab === 'standing') renderBody();
      }
    }
    if (changes.specialChars) {
      state.specialChars = changes.specialChars.newValue || DEFAULT_CHARS;
      if (state.activeTab === 'chars') renderBody();
    }
    if (changes.standingCols) {
      if (suppressColsEcho) {
        suppressColsEcho = false;
      } else {
        state.cols = changes.standingCols.newValue || 3;
        if (state.activeTab === 'standing') renderBody();
      }
    }
    if (changes.standingCss) {
      if (suppressCssEcho) suppressCssEcho = false;
      else state.standingCss = changes.standingCss.newValue || {};
    }
    if (changes.standingAtPrefix) {
      state.atPrefix = changes.standingAtPrefix.newValue !== false;
    }
    if (changes.ccfPanel) {
      const on = changes.ccfPanel.newValue !== false;
      if (on && !panel) buildUI();
      if (panel) panel.style.display = on ? panel.style.display : 'none';
      if (fab) fab.style.display = on ? 'flex' : 'none';
    }
  });

  if (document.readyState === 'loading') {
    window.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
