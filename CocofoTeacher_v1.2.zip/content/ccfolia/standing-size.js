// 코코포리아 선생님 — 스탠딩/대화창 사이즈 조절 (size114 확프 이식)
// 미연시 스타일로 중앙에 표시되는 스탠딩 이미지·대화창 크기를 조절한다.
// 설정: chrome.storage.sync의 standingCss
(() => {
  if (window.__cstStandingSizeLoaded) return;
  window.__cstStandingSizeLoaded = true;

  const EXT = typeof chrome !== 'undefined' && chrome.storage && chrome.runtime;
  if (!EXT) return;
  // 배포본: 대화창 가로·높이 조절 없음 (lib/edition.js). 개인용에서 팝업 [에디션 보기]를 배포용으로 두면 똑같이 (바꾸면 바로 반영)
  let LITE = !!window.CST_LITE;
  let lastRaw = null;

  // 저장값은 여기서 한 번 정리해서 쓴다 — 숫자 키는 유한한 숫자만(0 포함), 아니면 없는 것으로.
  // 옛 빌드·백업 복원으로 들어온 문자열/NaN 이 CSS 에 그대로 끼어드는 것을 막고,
  // 배포본에서는 대화창 가로·높이를 아예 지워 buildCss·forceApply·hasAny 가 모두 무시하게 한다.
  const NUM_KEYS = ['width', 'left', 'bottom', 'nameSize', 'dialogueSize', 'dialogWidth', 'dialogHeight'];
  const has = (v) => typeof v === 'number' && Number.isFinite(v);
  function sanitize(raw) {
    const s = {};
    if (!raw || typeof raw !== 'object') return s;
    s.originalSize = !!raw.originalSize;
    for (const k of NUM_KEYS) {
      if (LITE && (k === 'dialogWidth' || k === 'dialogHeight')) continue;
      const v = raw[k];
      const n = typeof v === 'number' ? v : typeof v === 'string' && v.trim() !== '' ? Number(v) : NaN;
      if (Number.isFinite(n)) s[k] = n;
    }
    return s;
  }

  // 코코포리아 최신 마크업 (2026-07 대응, size114 기준)
  const MSG_SELECTOR = '[aria-label="メッセージ"]'; // 스탠딩+대화창 전체 래퍼
  const BOX_SELECTOR = MSG_SELECTOR + ' > div'; // 대화창 배경 박스
  const TEXT_SELECTOR = BOX_SELECTOR + ' > div:last-child'; // 대사 스크롤 영역

  const STYLE_ID = 'cst-standing-size-css';
  let settings = null;
  let interval = null;

  function standingSelector() {
    return MSG_SELECTOR + ' img, ' + MSG_SELECTOR + ' > img';
  }

  function buildCss(s) {
    const rules = [];
    if (s.originalSize) {
      rules.push(`${standingSelector()} {
        width: auto !important; max-width: none !important; min-width: 0 !important; height: auto !important;
      }`);
    } else if (has(s.width)) {
      rules.push(`${standingSelector()} {
        width: ${s.width}px !important; max-width: ${s.width}px !important; min-width: ${s.width}px !important; height: auto !important;
      }`);
    }
    if (has(s.left)) {
      rules.push(`${standingSelector()} { left: ${s.left}px !important; }`);
    }
    if (has(s.bottom)) {
      rules.push(`${MSG_SELECTOR} { bottom: ${s.bottom}px !important; }`);
    }
    if (has(s.nameSize)) {
      rules.push(`${MSG_SELECTOR} h6 { font-size: ${s.nameSize}px !important; }`);
    }
    if (has(s.dialogueSize)) {
      rules.push(`${TEXT_SELECTOR} p { font-size: ${s.dialogueSize}px !important; }`);
    }
    if (has(s.dialogWidth)) {
      rules.push(`${BOX_SELECTOR} { width: ${s.dialogWidth}px !important; max-width: ${s.dialogWidth}px !important; }
        ${MSG_SELECTOR} { max-width: ${s.dialogWidth}px !important; }`);
    }
    if (has(s.dialogHeight)) {
      rules.push(`${TEXT_SELECTOR} {
        height: ${s.dialogHeight}px !important; max-height: ${s.dialogHeight}px !important; min-height: ${s.dialogHeight}px !important;
        overflow-y: auto !important; box-sizing: border-box !important;
      }
      ${TEXT_SELECTOR} p { overflow-wrap: anywhere !important; word-break: break-word !important; white-space: pre-wrap !important; margin: 0 !important; }
      ${BOX_SELECTOR} { min-height: ${s.dialogHeight}px !important; }`);
    }
    return rules.join('\n');
  }

  // 코코포리아가 인라인 스타일을 다시 씌우는 경우 대비한 강제 재적용.
  // 성능: 이미 원하는 값이면 setProperty를 건너뛴다 — 2초마다 무조건 재기입하면
  // 값이 같아도 스타일 무효화가 일어난다. 탭이 숨겨져 있을 때도 쉰다.
  function setP(el, prop, val) {
    if (el.style.getPropertyValue(prop) !== val || el.style.getPropertyPriority(prop) !== 'important') {
      el.style.setProperty(prop, val, 'important');
    }
  }

  function forceApply() {
    if (!settings || document.hidden) return;
    const s = settings;
    const imgs = document.querySelectorAll(standingSelector());
    imgs.forEach((el) => {
      if (s.originalSize) {
        setP(el, 'width', 'auto');
        setP(el, 'max-width', 'none');
        setP(el, 'min-width', '0');
        setP(el, 'height', 'auto');
      } else if (has(s.width)) {
        setP(el, 'width', s.width + 'px');
        setP(el, 'max-width', s.width + 'px');
        setP(el, 'min-width', s.width + 'px');
        setP(el, 'height', 'auto');
      }
      if (has(s.left)) {
        setP(el, 'left', s.left + 'px');
      }
    });
    if (has(s.dialogWidth)) {
      document.querySelectorAll(BOX_SELECTOR).forEach((el) => {
        setP(el, 'width', s.dialogWidth + 'px');
        setP(el, 'max-width', s.dialogWidth + 'px');
      });
    }
    if (has(s.dialogHeight)) {
      document.querySelectorAll(TEXT_SELECTOR).forEach((el) => {
        setP(el, 'height', s.dialogHeight + 'px');
        setP(el, 'max-height', s.dialogHeight + 'px');
        setP(el, 'min-height', s.dialogHeight + 'px');
        setP(el, 'overflow-y', 'auto');
      });
    }
    if (has(s.bottom)) {
      document.querySelectorAll(MSG_SELECTOR).forEach((el) => {
        setP(el, 'bottom', s.bottom + 'px');
      });
    }
  }

  function clearApplied() {
    const style = document.getElementById(STYLE_ID);
    if (style) style.remove();
    if (interval) {
      clearInterval(interval);
      interval = null;
    }
    document.querySelectorAll(standingSelector()).forEach((el) => {
      for (const p of ['width', 'max-width', 'min-width', 'height', 'left']) el.style.removeProperty(p);
    });
    document.querySelectorAll(TEXT_SELECTOR).forEach((el) => {
      for (const p of ['height', 'max-height', 'min-height', 'overflow-y']) el.style.removeProperty(p);
    });
    document.querySelectorAll(BOX_SELECTOR).forEach((el) => {
      for (const p of ['width', 'max-width', 'min-height']) el.style.removeProperty(p);
    });
    document.querySelectorAll(MSG_SELECTOR).forEach((el) => el.style.removeProperty('bottom'));
  }

  function hasAny(s) {
    return !!s && (!!s.originalSize || NUM_KEYS.some((k) => has(s[k])));
  }

  function apply(raw) {
    lastRaw = raw;
    clearApplied();
    const s = sanitize(raw);
    settings = hasAny(s) ? s : null;
    if (!settings) return;
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = buildCss(settings);
    (document.head || document.documentElement).appendChild(style);
    forceApply();
    setTimeout(forceApply, 300);
    setTimeout(forceApply, 1000);
    interval = setInterval(forceApply, 2000);
  }


  // 확장을 새로고침하면 남아 있던 이 스크립트의 chrome.* 연결이 끊긴다
  // ("Extension context invalidated"). 호출 전에 살아 있는지 확인한다.
  function extAlive() {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (_) {
      return false;
    }
  }

  if (!extAlive()) return;
  const isPreviewDist = (pv) => pv === 'dist' || pv === 'distdev';
  const start = () =>
    chrome.storage.sync.get({ standingCss: null }, (d) => {
      if (chrome.runtime.lastError) return;
      if (hasAny(sanitize(d.standingCss))) apply(d.standingCss);
    });
  if (window.CST_LITE) start();
  else {
    chrome.storage.local.get({ editionPreview: 'full' }, (d) => {
      if (!chrome.runtime.lastError && d && isPreviewDist(d.editionPreview)) LITE = true;
      start();
    });
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync' && changes.standingCss) apply(changes.standingCss.newValue);
    if (area === 'local' && changes.editionPreview && !window.CST_LITE) {
      const next = isPreviewDist(changes.editionPreview.newValue);
      if (next !== LITE) {
        LITE = next;
        if (lastRaw) apply(lastRaw);
      }
    }
  });
})();
