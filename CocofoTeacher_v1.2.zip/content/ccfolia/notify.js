// 코코포리아 선생님 — 채팅 알림 (소리 · 데스크톱)
// v8.0: 알림 세분화
//  · 알림 받을 탭 지정 (예: 메인, 비밀) — 채팅 탭의 안읽음 배지가 늘어나는 것을 감시
//  · 내 이름이 언급될 때만 — 지금 보고 있는 탭에 새로 붙는 대사 본문을 읽어 판단
//    (다른 탭의 대사 내용은 화면에 없으므로 언급 감지는 보고 있는 탭에서만 된다)
//  · 데스크톱 알림 — optional 권한(notifications)을 팝업에서 켤 때 요청, 백그라운드가 띄운다
// 기존 <title> 감지는 폴백으로 남긴다 (필터가 하나도 없을 때만 — 내용을 모르니 필터 판단 불가).
// 스크롤 오탐 방지 가드:
//  1) 이 창에서 최근 2초 안에 스크롤/휠/포인터 조작이 있었으면 알림 억제
//  2) 알림은 1.5초에 1회로 제한
//  3) 탭·창이 포커스 상태면 알림 없음
(() => {
  if (window.__cstNotifyLoaded) return;
  window.__cstNotifyLoaded = true;

  const EXT = typeof chrome !== 'undefined' && chrome.storage && chrome.runtime;
  if (!EXT) return;

  const sound = new Audio(chrome.runtime.getURL('sounds/notify.mp3'));
  sound.volume = 1;
  // 크롬 자동재생 정책: 이 페이지를 한 번도 건드리지 않았으면 소리가 막힌다 (창을 띄워만 두면 안 울리던 원인).
  // 첫 조작 때 소리 없이 한 번 재생해 잠금을 풀어 둔다.
  let audioUnlocked = false;
  function unlockAudio() {
    if (audioUnlocked) return;
    audioUnlocked = true;
    try {
      sound.muted = true;
      const p = sound.play();
      const done = () => {
        try {
          sound.pause();
          sound.currentTime = 0;
        } catch (_) {}
        sound.muted = false;
      };
      if (p && p.then) p.then(done).catch(() => (sound.muted = false));
      else done();
    } catch (_) {
      sound.muted = false;
    }
  }
  function playSound() {
    try {
      sound.currentTime = 0;
    } catch (_) {}
    const p = sound.play();
    if (p && p.catch) p.catch(() => {});
  }

  const DEFAULTS = {
    ccfNotify: true, // 전체 켜기/끄기
    notifySound: true, // 소리
    notifyDesktop: false, // 데스크톱 알림
    notifyTabs: [], // 알림 받을 탭 이름들 (비면 전부)
    notifyMention: false, // 내 이름이 언급될 때만
    notifyMentionWords: [], // 언급으로 볼 단어
    notifyMentionMyChars: true, // 내 캐릭터 이름(room.myChars)도 언급으로 본다
  };
  let cfg = { ...DEFAULTS };
  const roomId = (location.pathname.match(/\/rooms\/([^/?#]+)/) || [])[1] || '';
  let myChars = [];
  let roomName = '';
  const startedAt = Date.now();
  const WARMUP_MS = 8000; // 방에 막 들어왔을 때 쏟아지는 과거 대사는 새 채팅이 아니다

  // 확장을 새로고침하면 남아 있던 이 스크립트의 chrome.* 연결이 끊긴다
  // ("Extension context invalidated"). 호출 전에 살아 있는지 확인한다.
  function extAlive() {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (_) {
      return false;
    }
  }

  function norm(s) {
    return String(s || '').trim().toLowerCase();
  }

  function loadCfg() {
    if (!extAlive()) return;
    try {
      chrome.storage.sync.get(DEFAULTS, (s) => {
        if (chrome.runtime.lastError || !s) return;
        cfg = { ...DEFAULTS, ...s };
        if (!Array.isArray(cfg.notifyTabs)) cfg.notifyTabs = [];
        if (!Array.isArray(cfg.notifyMentionWords)) cfg.notifyMentionWords = [];
      });
      if (roomId) {
        chrome.storage.local.get({ rooms: {} }, (d) => {
          if (chrome.runtime.lastError || !d) return;
          const room = (d.rooms || {})[roomId] || {};
          myChars = Array.isArray(room.myChars) ? room.myChars : [];
          roomName = room.name || '';
        });
      }
    } catch (_) {}
  }
  loadCfg();
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'sync' && Object.keys(changes).some((k) => k in DEFAULTS)) loadCfg();
      if (area === 'local' && changes.rooms && roomId) {
        const room = ((changes.rooms.newValue || {})[roomId]) || {};
        myChars = Array.isArray(room.myChars) ? room.myChars : [];
        roomName = room.name || roomName;
      }
    });
  } catch (_) {}

  // ---- 사용자 조작 감지 (스크롤 오탐 가드) ----
  let lastUserAction = 0;
  const markAction = () => {
    lastUserAction = Date.now();
    unlockAudio();
  };
  window.addEventListener('wheel', markAction, { passive: true, capture: true });
  window.addEventListener('scroll', markAction, { passive: true, capture: true });
  window.addEventListener('pointerdown', markAction, { passive: true, capture: true });
  window.addEventListener('keydown', markAction, { passive: true, capture: true });

  // ---- 필터 ----
  function filtersActive() {
    return (cfg.notifyTabs && cfg.notifyTabs.length > 0) || !!cfg.notifyMention;
  }

  function tabAllowed(tab) {
    const list = (cfg.notifyTabs || []).map(norm).filter(Boolean);
    if (!list.length) return true;
    // 어느 탭인지 모를 때: 탭 목록을 아예 못 찾았으면(코코포리아 구조 변경 등) 막지 않는다.
    // 막아 버리면 알림이 통째로 사라지고 이유도 안 보인다.
    if (!tab) return !tabListFound;
    const t = norm(tab);
    return list.some((x) => t === x || t.includes(x) || x.includes(t));
  }

  function mentionWords() {
    const words = [...(cfg.notifyMentionWords || [])];
    if (cfg.notifyMentionMyChars !== false) words.push(...myChars);
    return words.map(norm).filter(Boolean);
  }

  function mentioned(text) {
    if (!cfg.notifyMention) return true;
    // 언급으로 볼 단어가 하나도 없으면(단어 미입력 + 내 캐릭터 미파악) 전부 막히게 된다 —
    // 그럴 때는 필터가 없는 것으로 본다 (팝업 설정에도 같은 안내가 있다)
    if (!mentionWords().length) return true;
    if (!text) return false;
    const hay = norm(text);
    return mentionWords().some((w) => hay.includes(w));
  }

  // ---- 알림 실행 ----
  let lastPlay = 0;
  // ev: { source: 'title'|'badge'|'item', tab, name, text }
  function handle(ev) {
    if (!cfg.ccfNotify) return;
    if (document.hasFocus()) return;
    const now = Date.now();
    if (now - startedAt < WARMUP_MS) return; // 방에 막 들어왔을 때(제목이 뒤늦게 바뀌는 것 포함)는 알리지 않는다
    if (now - lastUserAction < 2000) return; // 사용자가 직접 조작 중 → 신규 채팅 아님
    if (ev.source === 'title' && filtersActive()) return; // 어느 탭·무슨 내용인지 모르면 필터 판단 불가
    if (!tabAllowed(ev.tab)) return;
    if (!mentioned(ev.text)) return;
    if (now - lastPlay < 1500) return; // 연타 방지
    lastPlay = now;
    // 같은 방을 여러 창 · 여러 탭으로 띄워 두면 창마다 울린다 → background 가 처음 온 것만 통과시킨다
    claim(roomId + '\x1f' + (ev.tab || '') + '\x1f' + (ev.name || '') + '\x1f' + (ev.text || ev.source)).then((ok) => {
      if (!ok) return;
      if (cfg.notifySound !== false) playSound();
      if (cfg.notifyDesktop) desktop(ev);
    });
  }

  // background 에 '이 알림은 내가 울린다'고 알린다 (3초 안에 같은 알림이면 다른 창은 조용히)
  function claim(key) {
    return new Promise((r) => {
      if (!extAlive()) return r(true);
      try {
        chrome.runtime.sendMessage({ type: 'NOTIFY_CLAIM', key }, (res) => {
          if (chrome.runtime.lastError) return r(true); // background 가 답이 없으면 그냥 울린다
          r(!res || res.ok !== false);
        });
      } catch (_) {
        r(true);
      }
    });
  }

  // 인장(스탠딩) 이미지를 알림 아이콘으로 쓴다.
  // chrome.notifications 는 확장 안 파일이나 data URL 만 확실히 받으므로 페이지 쪽에서 바꿔 넘긴다.
  const iconCache = new Map(); // 이미지 주소 → data URL ('' = 실패, 다시 시도하지 않음)

  async function toDataUrl(src) {
    if (!src) return '';
    if (/^data:/.test(src)) return src;
    if (iconCache.has(src)) return iconCache.get(src);
    let out = '';
    try {
      const res = await fetch(src, { cache: 'force-cache' });
      if (res.ok) {
        const blob = await res.blob();
        if (blob.size <= 2 * 1024 * 1024) {
          out = await new Promise((r) => {
            const fr = new FileReader();
            fr.onload = () => r(String(fr.result || ''));
            fr.onerror = () => r('');
            fr.readAsDataURL(blob);
          });
        }
      }
    } catch (_) {
      out = ''; // CORS 등으로 못 받으면 확장 아이콘으로 (알림 자체는 뜬다)
    }
    iconCache.set(src, out);
    if (iconCache.size > 40) iconCache.delete(iconCache.keys().next().value);
    return out;
  }

  // 알림 생김새: 제목 = 캐릭터 이름, 본문 = 대사, 아래 줄 = 방 이름 · 탭
  // 내용을 모르는 경우(다른 탭 배지·제목 변화)에만 '새 채팅이 도착했습니다'로 간다.
  async function desktop(ev) {
    if (!extAlive()) return;
    const room = roomName || document.title.replace(/^\(\d+\)\s*/, '') || '코코포리아';
    const body = ev.text ? ev.text.replace(/\s+/g, ' ').slice(0, 180) : '';
    const title = ev.name || room;
    const message = body || (ev.tab ? `[${ev.tab}] 새 채팅이 도착했습니다` : '새 채팅이 도착했습니다');
    const contextMessage = ev.tab ? `${room} · ${ev.tab}` : room;
    const iconUrl = await toDataUrl(ev.icon);
    if (!extAlive()) return;
    try {
      chrome.runtime.sendMessage(
        { type: 'DESKTOP_NOTIFY', title, message, contextMessage, iconUrl, silent: cfg.notifySound !== false },
        () => void chrome.runtime.lastError
      );
    } catch (_) {}
  }

  // ---- ① <title> 변경 감지 (폴백) ----
  // 코코포리아는 안읽음 수를 제목 앞에 "(3) 방 이름" 으로 붙이고, 읽으면 다시 뗀다 (2026-09 번들 확인).
  // 예전에는 제목이 '바뀌기만 해도' 알렸더니, 방 이름이 뒤늦게 들어오거나 안읽음 수가 줄어들 때도
  // 아무 일 없이 소리가 났다 → 앞의 숫자가 늘어난 것만 새 채팅으로 본다.
  // DOM 감시가 먼저 잡았으면 1.5초 제한에 걸려 중복되지 않는다. 조금 늦게 처리해 DOM 쪽에 우선권을 준다.
  const titleCount = (t) => {
    const m = String(t || '').match(/^\s*\((\d+)\)/);
    return m ? Number(m[1]) : 0;
  };
  function observeTitle() {
    const head = document.head;
    if (!head) return;
    let titleObserver = null;
    let lastTitle = document.title;
    let lastCount = titleCount(document.title);

    function watch(titleElem) {
      if (titleObserver) titleObserver.disconnect();
      if (!titleElem) return;
      titleObserver = new MutationObserver(() => {
        const cur = titleElem.textContent.trim();
        if (cur === lastTitle) return;
        lastTitle = cur;
        const n = titleCount(cur);
        const prev = lastCount;
        lastCount = n;
        if (n <= prev) return; // 방 이름만 바뀜 · 안읽음 수가 줄거나 지워짐 → 새 채팅이 아니다
        setTimeout(() => handle({ source: 'title' }), 400);
      });
      titleObserver.observe(titleElem, { characterData: true, childList: true, subtree: true });
    }

    new MutationObserver((muts) => {
      for (const mu of muts) {
        for (const node of mu.addedNodes) {
          if (node.nodeType === Node.ELEMENT_NODE && node.tagName === 'TITLE') watch(node);
        }
      }
    }).observe(head, { childList: true });

    watch(document.querySelector('head > title'));
  }

  // ---- ② 채팅 탭 배지 감시 (어느 탭에 새 글이 왔는지) ----
  function findChatInput() {
    return document.querySelector('div[class*="MuiInputBase-root"] textarea') || document.querySelector('textarea');
  }

  function findTabList() {
    const starts = [];
    const input = findChatInput();
    if (input) starts.push(input);
    // 채팅 목록: 지금은 role="log" (TanStack Virtual), 예전 react-virtuoso 표식도 남겨 둔다
    const sc = document.querySelector('[role="log"], [data-virtuoso-scroller], [data-testid="virtuoso-scroller"]');
    if (sc) starts.push(sc);
    for (const start of starts) {
      let elx = start;
      for (let i = 0; i < 12 && elx; i++) {
        if (elx.querySelector) {
          const tl = elx.querySelector('[role="tablist"], .MuiTabs-root');
          if (tl) {
            const tabs = [...tl.querySelectorAll('[role="tab"], .MuiTab-root')];
            if (tabs.length >= 2) return tabs;
          }
        }
        elx = elx.parentElement;
      }
    }
    return [];
  }

  function readTab(tabEl) {
    let name = '';
    try {
      const clone = tabEl.cloneNode(true);
      clone.querySelectorAll('.MuiBadge-badge, svg').forEach((x) => x.remove());
      name = (clone.textContent || '').trim();
    } catch (_) {
      name = (tabEl.textContent || '').trim();
    }
    let badge = 0;
    const b = tabEl.querySelector('.MuiBadge-badge');
    if (b && !b.classList.contains('MuiBadge-invisible')) {
      const n = parseInt((b.textContent || '').replace(/\D/g, ''), 10);
      badge = Number.isFinite(n) && n > 0 ? n : 1; // 숫자 없는 점 배지는 1로 본다
    }
    const selected = tabEl.getAttribute('aria-selected') === 'true' || tabEl.classList.contains('Mui-selected');
    return { name, badge, selected };
  }

  const badgeState = new Map(); // 탭 이름 → 마지막 배지 수
  let currentTabName = '';
  let tabListFound = false; // 탭 목록을 찾은 적이 있는가 (못 찾으면 탭 필터로 막지 않는다)

  // 지금 보고 있는 탭 이름 — 1초 주기 감시를 기다리지 않고 바로 읽는다
  function readCurrentTab() {
    let tabs = [];
    try {
      tabs = findTabList();
    } catch (_) {}
    if (!tabs.length) return '';
    tabListFound = true;
    for (const t of tabs) {
      const r = readTab(t);
      if (r.selected && r.name) return r.name;
    }
    return '';
  }

  function pollBadges() {
    let tabs;
    try {
      tabs = findTabList();
    } catch (_) {
      return;
    }
    if (!tabs.length) return;
    tabListFound = true;
    for (const t of tabs) {
      const r = readTab(t);
      if (!r.name) continue;
      if (r.selected) currentTabName = r.name;
      const prev = badgeState.get(r.name);
      if (prev != null && r.badge > prev) handle({ source: 'badge', tab: r.name });
      badgeState.set(r.name, r.badge);
    }
  }

  // ---- ③ 보고 있는 탭에 새로 붙는 대사 (본문 → 언급 판단) ----
  const seen = new Map(); // key → 1 (삽입 순서 유지, 오래된 것부터 버림)
  const SEEN_MAX = 4000;
  let scanTimer = 0;

  // 이름 칸에 시각이 붙어 오는 경우가 있다 ("김탐정 12:01") — 알림 제목에 시각이 끼지 않게 떼어낸다.
  // 수집기(background.js)의 cleanNameTail 과 같은 규칙: 시각을 실제로 떼어냈을 때만 구분자를 정리한다.
  const NAME_TIME_TAIL =
    /[\s\u00a0]*[-–—·|]?[\s\u00a0]*(?:(?:오전|오후|AM|PM)\s*)?\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM)?$/i;

  function cleanName(raw) {
    const t = String(raw || '').trim();
    const cut = t.replace(NAME_TIME_TAIL, '').trim();
    if (!cut || cut === t) return t;
    return cut.replace(/[\s\u00a0]+[-–—·|][\s\u00a0]*$/, '').trim() || cut;
  }

  function itemKey(nm, tx) {
    return (nm.textContent || '').trim() + '\x1f' + (tx.textContent || '').trim();
  }

  // 새 채팅 판정: 채팅 목록은 가상 스크롤이라 화면에 그려진 줄만 있다.
  // 줄의 data-index 는 뒤로 갈수록 커지므로, '지금까지 본 가장 큰 번호보다 큰 줄'만 새 채팅으로 본다.
  // (스크롤해서 예전 줄이 다시 그려질 때 울리던 오탐 방지 — 탭을 바꾸면 번호가 다시 시작하므로 초기화)
  let maxIdx = -1;
  let maxIdxTab = null;

  function scanItems() {
    const items = [...document.querySelectorAll('[data-index]')].filter((it) =>
      it.querySelector('.MuiListItemText-primary')
    );
    if (!items.length) return;
    const lastIdx = items.length - 1;
    const warm = Date.now() - startedAt < WARMUP_MS;
    const tabNow = currentTabName || readCurrentTab();
    if (tabNow !== maxIdxTab) {
      maxIdxTab = tabNow;
      maxIdx = -1;
    }
    let seenMax = maxIdx;
    items.forEach((it, i) => {
      const nm = it.querySelector('.MuiListItemText-primary');
      const tx = it.querySelector('.MuiListItemText-secondary');
      if (!nm || !tx) return;
      const key = itemKey(nm, tx);
      const idx = Number(it.dataset.index);
      const fresh = Number.isFinite(idx) ? idx > maxIdx : i >= lastIdx - 2;
      if (Number.isFinite(idx) && idx > seenMax) seenMax = idx;
      if (seen.has(key)) return;
      seen.set(key, 1);
      if (seen.size > SEEN_MAX) seen.delete(seen.keys().next().value);
      if (warm) return;
      // 새 채팅은 목록 맨 아래에 붙는다. 위쪽에 새로 보이는 것은 과거 로그 로딩이다.
      if (!fresh || i < lastIdx - 2) return;
      const nameNode = nm.firstChild;
      const rawName = (nameNode && nameNode.nodeType === 3 ? nameNode.textContent : nm.textContent || '').trim();
      let tab = currentTabName || readCurrentTab();
      let name = cleanName(rawName);
      const m = rawName.match(/^\[([^\]]+)\]\s*(.+)$/);
      if (m) {
        tab = m[1].trim();
        name = cleanName(m[2]);
      }
      const av = it.querySelector('.MuiListItemAvatar-root img');
      handle({
        source: 'item',
        tab,
        name,
        text: (tx.textContent || '').trim(),
        icon: av ? av.getAttribute('src') || '' : '',
      });
    });
    maxIdx = seenMax;
  }

  // 숨은 탭에서는 setTimeout · setInterval 이 1분까지 밀린다 (크롬 절전).
  // 화면이 바뀐 그 자리에서(관찰 콜백은 안 밀린다) 바로 훑되, 너무 잦지 않게 시간으로만 눌러 둔다.
  let lastScanAt = 0;
  let lastBadgeAt = 0;
  function scanNow() {
    lastScanAt = Date.now();
    scanItems();
    if (lastScanAt - lastBadgeAt >= 500) {
      lastBadgeAt = lastScanAt;
      pollBadges();
    }
  }
  function scheduleScan() {
    clearTimeout(scanTimer);
    if (Date.now() - lastScanAt >= 200) return scanNow();
    scanTimer = setTimeout(scanNow, 200);
  }

  function start() {
    observeTitle();
    try {
      new MutationObserver(scheduleScan).observe(document.body, { childList: true, subtree: true, characterData: true });
    } catch (_) {}
    scanItems();
    setInterval(pollBadges, 1000);
  }

  if (document.readyState === 'loading') {
    window.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();
