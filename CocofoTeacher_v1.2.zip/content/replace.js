// 코코포리아 선생님 — 텍스트 대치 (예: "..." → "…")
// v8.0: 규칙 종류 셋 — 일반(글자 그대로) / 정규식(커서 앞 문자열이 패턴에 맞으면) / 스니펫(;약어 + 스페이스·Tab → 긴 문장)
//       + 방별 규칙(rooms[roomId].replaceRules, 코코포리아 방 안에서만 · 공통 규칙보다 먼저 적용)
// ccfolia.com 에서는 항상 동작, 그 외에는 설정의 허용 사이트 목록에 있어야 동작.
(() => {
  if (window.__cocofoReplaceLoaded) return;
  window.__cocofoReplaceLoaded = true;

  const EXT = typeof chrome !== 'undefined' && chrome.storage && chrome.runtime;
  if (!EXT) return;

  // 광고·트래커용 초소형 iframe에서는 아무것도 하지 않는다 (all_frames)
  try {
    if (window.self !== window.top && (innerWidth < 50 || innerHeight < 50)) return;
  } catch (_) {}

  const DEFAULT_RULES = [
    { from: '...', to: '…' },
    { from: '--', to: '―' },
  ];

  const isCcfolia = /(^|\.)ccfolia\.com$/.test(location.hostname);
  const roomId = isCcfolia ? (location.pathname.match(/^\/rooms\/([^/?#]+)/) || [])[1] || '' : '';

  let enabled = true;
  let globalRules = DEFAULT_RULES;
  let roomRules = [];
  let compiled = []; // { kind, from, to, re }
  let siteAllowed = false;
  let applying = false; // 우리 스스로 발생시킨 input 이벤트 무시용

  function extAlive() {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (_) {
      return false;
    }
  }

  function hostAllowed(sites) {
    const host = location.hostname;
    if (isCcfolia) return true;
    return (sites || []).some((s) => {
      const t = String(s).trim().toLowerCase();
      return t && (host === t || host.endsWith('.' + t));
    });
  }

  // 규칙 종류: 'plain'(기본) | 'regex' | 'snippet'
  function kindOf(r) {
    return r && (r.kind === 'regex' || r.kind === 'snippet') ? r.kind : 'plain';
  }

  function compileRules() {
    compiled = [];
    // 방 전용 규칙이 공통 규칙보다 먼저 (같은 입력이면 방 규칙이 이긴다)
    for (const r of [...roomRules, ...globalRules]) {
      if (!r) continue;
      const from = String(r.from || '');
      const to = String(r.to == null ? '' : r.to);
      if (!from) continue;
      const kind = kindOf(r);
      if (kind === 'plain' && (!to || from === to)) continue;
      if (kind === 'snippet' && !to) continue;
      let re = null;
      if (kind === 'regex') {
        try {
          re = new RegExp('(?:' + from + ')$', r.flags && /i/.test(String(r.flags)) ? 'i' : '');
        } catch (_) {
          continue; // 잘못된 패턴은 건너뛴다 (팝업에서 미리 검사하지만 손으로 고친 저장값 대비)
        }
      }
      compiled.push({ kind, from, to, re });
    }
  }

  function loadRoomRules(rooms) {
    if (!roomId) return;
    const room = (rooms || {})[roomId];
    roomRules = room && Array.isArray(room.replaceRules) ? room.replaceRules : [];
  }

  function loadSettings() {
    if (!extAlive()) return;
    try {
      chrome.storage.sync.get(
        { ccfReplaceOn: true, replaceRules: DEFAULT_RULES, replaceSites: [] },
        (s) => {
          if (chrome.runtime.lastError || !s) return;
          enabled = s.ccfReplaceOn !== false;
          globalRules = Array.isArray(s.replaceRules) && s.replaceRules.length ? s.replaceRules : [];
          siteAllowed = hostAllowed(s.replaceSites);
          compileRules();
        }
      );
      if (roomId) {
        chrome.storage.local.get({ rooms: {} }, (d) => {
          if (chrome.runtime.lastError || !d) return;
          loadRoomRules(d.rooms);
          compileRules();
        });
      }
    } catch (_) {}
  }

  loadSettings();
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'sync' && (changes.ccfReplaceOn || changes.replaceRules || changes.replaceSites)) loadSettings();
      if (area === 'local' && changes.rooms && roomId) {
        loadRoomRules(changes.rooms.newValue);
        compileRules();
      }
    });
  } catch (_) {}

  // ---- 스니펫 자리표시자 ----
  function expandSnippet(to) {
    const d = new Date();
    const p = (n) => String(n).padStart(2, '0');
    const WEEK = ['일', '월', '화', '수', '목', '금', '토'];
    return String(to)
      .replace(/\{날짜\}/g, `${d.getFullYear()}.${p(d.getMonth() + 1)}.${p(d.getDate())}`)
      .replace(/\{시간\}/g, `${p(d.getHours())}:${p(d.getMinutes())}`)
      .replace(/\{요일\}/g, WEEK[d.getDay()]);
  }

  // ---- 입력창 값 교체 (React 등 프레임워크 상태에도 반영) ----
  function applyEdit(el, start, end, insert) {
    const val = el.value;
    const newVal = val.slice(0, start) + insert + val.slice(end);
    const newPos = start + insert.length;
    applying = true;
    try {
      const proto =
        el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
      setter.call(el, newVal);
      el.setSelectionRange(newPos, newPos);
      el.dispatchEvent(new Event('input', { bubbles: true }));
    } finally {
      applying = false;
    }
  }

  // 스니펫 트리거가 커서 바로 앞에 있는지 (앞은 문장 처음이거나 공백이어야 한다)
  function snippetAt(prefix) {
    for (const r of compiled) {
      if (r.kind !== 'snippet') continue;
      if (!prefix.endsWith(r.from)) continue;
      const before = prefix.charAt(prefix.length - r.from.length - 1);
      if (before && !/\s/.test(before)) continue;
      return r;
    }
    return null;
  }

  // 커서 직전 문자열이 규칙에 맞으면 치환
  function tryReplace(el) {
    const pos = el.selectionStart;
    if (pos == null) return;
    const val = el.value;
    const prefix = val.slice(0, pos);

    // 스니펫: "…;kp " 처럼 스페이스가 방금 찍혔을 때 (스페이스는 삼킨다)
    if (prefix.endsWith(' ')) {
      const r = snippetAt(prefix.slice(0, -1));
      if (r) {
        applyEdit(el, pos - 1 - r.from.length, pos, expandSnippet(r.to));
        return;
      }
    }

    for (const r of compiled) {
      if (r.kind === 'regex') {
        const m = prefix.match(r.re);
        if (!m || !m[0]) continue; // 빈 문자열 매치는 무시 (무한 치환 방지)
        const newPrefix = prefix.replace(r.re, r.to);
        if (newPrefix === prefix) continue;
        applyEdit(el, 0, pos, newPrefix);
        return;
      }
      if (r.kind !== 'plain') continue;
      const from = r.from;
      if (pos >= from.length && val.slice(pos - from.length, pos) === from) {
        // "...." 처럼 규칙보다 긴 반복 입력 중이면 잠시 보류 (다음 입력에서 판단)
        const next = val.slice(pos, pos + 1);
        if (next && from.endsWith(next)) continue;
        applyEdit(el, pos - from.length, pos, r.to);
        return;
      }
    }
  }

  function isTextField(el) {
    return (
      el instanceof HTMLTextAreaElement ||
      (el instanceof HTMLInputElement && ['text', 'search', 'url', 'tel', ''].includes(el.type || ''))
    );
  }

  document.addEventListener(
    'input',
    (e) => {
      if (applying || !enabled || !siteAllowed) return;
      const el = e.target;
      if (!el || !isTextField(el)) return;
      // IME 조합 중에는 건드리지 않음 (한글 입력 깨짐 방지)
      if (e.isComposing) return;
      tryReplace(el);
    },
    true
  );

  // 스니펫: Tab 키로도 펼친다 (";kp" 뒤에 Tab)
  document.addEventListener(
    'keydown',
    (e) => {
      if (!enabled || !siteAllowed || e.key !== 'Tab' || e.isComposing) return;
      const el = e.target;
      if (!el || !isTextField(el)) return;
      const pos = el.selectionStart;
      if (pos == null || pos !== el.selectionEnd) return;
      const r = snippetAt(el.value.slice(0, pos));
      if (!r) return;
      e.preventDefault();
      e.stopPropagation();
      applyEdit(el, pos - r.from.length, pos, expandSnippet(r.to));
    },
    true
  );
})();
