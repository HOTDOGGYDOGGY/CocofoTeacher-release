// [main] 저장·내보내기 · 이미지 보강 · 통계 · 파일 열기 · 초기화
// ---------- 저장/내보내기 ----------
$('saveSettingsBtn').addEventListener('click', async () => {
  await saveLogSettings(s);
  $('saveSettingsBtn').textContent = '저장됨 ✓';
  setTimeout(() => ($('saveSettingsBtn').textContent = '설정 저장'), 1200);
});

$('exportBtn').addEventListener('click', async () => {
  const btn = $('exportBtn');
  btn.disabled = true;
  try {
    await saveLogSettings(s); // 원클릭에도 같은 설정이 적용되게 함께 저장
    let msgs = data.messages;
    if ($('sEmbed').checked) {
      msgs = await B.embedImagesInMessages(msgs, {
        onProgress: (d, t) => (btn.textContent = `이미지 내장 중 ${d}/${t}…`),
      });
    }
    btn.textContent = '파일 생성 중…';
    const sExp = { ...s };
    if (s.theme === 'image') sExp.__bgImage = bgImage || '';
    sExp.__headerImage = headerImage || '';
    const result = await B.exportAll(msgs, sExp, data.roomName);
    btn.textContent = `저장됨 ✓ (${result.files}개 파일)`;
    btn.title = (result.names || []).join('\n');
  } catch (e) {
    btn.textContent = '실패: ' + e.message;
  }
  btn.disabled = false;
  setTimeout(() => (btn.textContent = '이 설정으로 로그 저장'), 2500);
});

$('previewAllBtn').addEventListener('click', () => {
  previewAll = !previewAll;
  $('previewAllBtn').textContent = previewAll ? '앞부분만' : '전체 보기';
  renderPreview();
});

// ---------- 이미지 보강 ----------
function isGoodUrl(u) {
  return /^(https?:|data:)/i.test(u || '') && !brokenUrls.has(u);
}

function missingStats() {
  // name -> { empty, broken } — 시스템 메시지는 원래 인장이 없으니 세지 않는다
  const by = new Map();
  for (const m of data.messages) {
    if (m.divider || m.sys) continue;
    const st = by.get(m.name) || { empty: 0, broken: 0 };
    if (!m.imgUrl) st.empty++;
    else if (brokenUrls.has(m.imgUrl)) st.broken++;
    by.set(m.name, st);
  }
  for (const [k, v] of by) if (!v.empty && !v.broken) by.delete(k);
  return by;
}

function needsFill(m) {
  return !m.divider && !m.sys && (!m.imgUrl || brokenUrls.has(m.imgUrl));
}

function applyUrlToChar(name, url) {
  let n = 0;
  for (const m of data.messages) {
    if (needsFill(m) && m.name === name) {
      m.imgUrl = url;
      n++;
    }
  }
  return n;
}

let imgFixCharTarget = ''; // 파일 업로드 대상 캐릭터

function renderImgFix() {
  const box = $('imgFixRows');
  box.innerHTML = '';
  const by = missingStats();
  const totalEmpty = [...by.values()].reduce((a, x) => a + x.empty, 0);
  const totalBroken = [...by.values()].reduce((a, x) => a + x.broken, 0);
  $('imgFixStatus').textContent = by.size
    ? `빈 이미지 ${totalEmpty}개 · 깨진 이미지 ${totalBroken}개 (${by.size}명)`
    : brokenUrls.size || checkedOnce
      ? '비었거나 깨진 이미지가 없습니다.'
      : '이미지가 빈 메시지가 없습니다. URL이 있어도 깨졌을 수 있으니 [깨진 이미지 검사]를 눌러보세요.';
  if (!by.size) return;

  for (const [name, st] of by) {
    const row = document.createElement('div');
    row.className = 'imgfix-row';
    const nm = document.createElement('span');
    nm.className = 'cname';
    nm.textContent = `${name} (${st.empty + st.broken})`;
    nm.title = `${name}: 빈 ${st.empty} · 깨짐 ${st.broken}`;
    const inp = document.createElement('input');
    inp.type = 'text';
    inp.placeholder = '이미지 URL 붙여넣기';
    const apply = document.createElement('button');
    apply.className = 'st-btn ghost st-mini';
    apply.textContent = '적용';
    apply.addEventListener('click', () => {
      const url = inp.value.trim();
      if (!/^(https?:|data:)/i.test(url)) return;
      applyUrlToChar(name, url);
      renderImgFix();
      renderPreview();
    });
    const fileBtn = document.createElement('button');
    fileBtn.className = 'st-btn ghost st-mini';
    fileBtn.textContent = '파일';
    fileBtn.title = '내 PC의 이미지 파일로 채우기 (HTML에 내장됨)';
    fileBtn.addEventListener('click', () => {
      imgFixCharTarget = name;
      $('charImgInput').click();
    });
    row.append(nm, inp, apply, fileBtn);
    box.appendChild(row);
  }
}

$('charImgInput').addEventListener('change', async () => {
  const file = $('charImgInput').files[0];
  $('charImgInput').value = '';
  if (!file || !imgFixCharTarget) return;
  try {
    const dataUrl = await fileToDataUrl(file, 256, 'image/webp', 0.85);
    const n = applyUrlToChar(imgFixCharTarget, dataUrl);
    $('imgFixStatus').textContent = `"${imgFixCharTarget}" ${n}개 채움 ✓`;
    setTimeout(renderImgFix, 1200);
    renderPreview();
  } catch (e) {
    $('imgFixStatus').textContent = '이미지를 읽지 못했습니다: ' + e.message;
  }
});

// 깨진 이미지 검사: 고유 URL을 실제로 로드해봐서 실패하는 것 표시
let checkedOnce = false;
// URL이 살아 있는지 실제로 불러 본다 (onProgress(done, total))
async function checkBrokenImages(onProgress) {
  const urls = [...new Set(data.messages.filter((m) => !m.divider && /^https?:/i.test(m.imgUrl || '')).map((m) => m.imgUrl))];
  brokenUrls.clear();
  let done = 0;
  const test = (url) =>
    new Promise((resolve) => {
      const img = new Image();
      const timer = setTimeout(() => {
        img.src = '';
        resolve(false);
      }, 10000);
      img.onload = () => {
        clearTimeout(timer);
        resolve(true);
      };
      img.onerror = () => {
        clearTimeout(timer);
        resolve(false);
      };
      img.src = url;
    });
  // 6개씩 병렬
  for (let i = 0; i < urls.length; i += 6) {
    const batch = urls.slice(i, i + 6);
    const results = await Promise.all(batch.map(test));
    results.forEach((ok, j) => {
      if (!ok) brokenUrls.add(batch[j]);
    });
    done += batch.length;
    if (onProgress) onProgress(done, urls.length);
  }
  checkedOnce = true;
  return brokenUrls.size;
}

$('imgCheckBtn').addEventListener('click', async () => {
  const btn = $('imgCheckBtn');
  btn.disabled = true;
  const n = await checkBrokenImages((d, t) => (btn.textContent = `검사 중 ${d}/${t}…`));
  btn.textContent = n ? `깨진 URL ${n}개 발견` : '깨진 이미지 없음 ✓';
  btn.disabled = false;
  setTimeout(() => (btn.textContent = '깨진 이미지 검사'), 2600);
  renderImgFix();
});

// 저장된 스탠딩 꾸러미 — 이 방을 먼저 보고, 없으면 다른 방까지 뒤진다
async function standingPools() {
  const { lastLogCollection } = await getLocal({ lastLogCollection: null });
  const rooms = await CSTRoomStore.loadAll();
  const roomId = lastLogCollection && lastLogCollection.roomId;
  const pools = [];
  if (roomId && rooms[roomId] && rooms[roomId].standings) pools.push(rooms[roomId].standings);
  for (const [rid, r] of Object.entries(rooms || {})) {
    if (rid !== roomId && r.standings && Object.keys(r.standings).length) pools.push(r.standings);
  }
  return pools;
}

// 로그 이름과 저장된 이름이 살짝 달라도 (괄호 주석 등) 찾아준다
function poolLookup(pools, name) {
  const simplify = (n) => String(n || '').trim().replace(/\s*[(（].*?[)）]\s*$/, '');
  for (const pool of pools) {
    for (const k of [name, String(name || '').trim(), simplify(name)]) {
      if (pool[k] && pool[k].length) return pool[k];
    }
    for (const key of Object.keys(pool)) {
      if (key.includes(name) || name.includes(key)) {
        if (pool[key] && pool[key].length) return pool[key];
      }
    }
  }
  return null;
}

// 대사 안의 @표정 표시로 스탠딩을 골라 채운다.
// 코코포리아에서는 @이름으로 표정을 바꾸므로, 마지막으로 부른 표정이 그 캐릭터의 현재 얼굴이다.
function fillByFaceTags(pools) {
  const cur = new Map(); // 캐릭터 -> 마지막으로 부른 표정 이미지
  let filled = 0;
  for (const m of data.messages) {
    if (m.divider) continue;
    const list = poolLookup(pools, m.name);
    if (list && list.length) {
      const tag = (m.text || '').match(/@([^\s@,.·、。]{1,20})/);
      if (tag) {
        const want = tag[1].toLowerCase();
        const hit = list.find((x) => String(x.label || '').replace(/^@/, '').toLowerCase() === want);
        if (hit && /^https?:/i.test(hit.img || '')) cur.set(m.name, hit.img);
      }
    }
    if (!needsFill(m)) continue;
    const img = cur.get(m.name);
    if (img && !brokenUrls.has(img)) {
      m.imgUrl = img;
      filled++;
    }
  }
  return filled;
}

// 캐릭터별 대표 이미지로 채우기
function fillByStandings(pools) {
  let filled = 0;
  for (const name of missingStats().keys()) {
    const list = poolLookup(pools, name);
    if (!list) continue;
    const withImg = list.find((x) => /^https?:/i.test(x.img || '')) || list[0];
    const img = withImg && withImg.img;
    if (img && !brokenUrls.has(img)) filled += applyUrlToChar(name, img);
  }
  return filled;
}

$('fillFromStandingsBtn').addEventListener('click', async () => {
  const { lastLogCollection } = await getLocal({ lastLogCollection: null });
  const rooms = await CSTRoomStore.loadAll();
  const roomId = lastLogCollection && lastLogCollection.roomId;
  const simplify = (n) => String(n || '').trim().replace(/\s*[(（].*?[)）]\s*$/, '');
  const pools = [];
  if (roomId && rooms[roomId] && rooms[roomId].standings) pools.push(rooms[roomId].standings);
  for (const [rid, r] of Object.entries(rooms || {})) {
    if (rid !== roomId && r.standings && Object.keys(r.standings).length) pools.push(r.standings);
  }
  const findImg = (name) => {
    for (const pool of pools) {
      const keys = [name, name.trim(), simplify(name)];
      for (const k of keys) {
        const list = pool[k];
        if (list && list.length) {
          const withImg = list.find((x) => /^https?:/i.test(x.img || '')) || list[0];
          if (withImg && withImg.img) return withImg.img;
        }
      }
      // 부분 일치 (저장된 이름이 로그 이름을 포함하거나 그 반대)
      for (const key of Object.keys(pool)) {
        if (key.includes(name) || name.includes(key)) {
          const list = pool[key];
          if (list && list.length && list[0].img) return list[0].img;
        }
      }
    }
    return '';
  };
  let filled = 0;
  const by = missingStats();
  for (const name of by.keys()) {
    const img = findImg(name);
    if (img && !brokenUrls.has(img)) filled += applyUrlToChar(name, img);
  }
  $('fillFromStandingsBtn').textContent = filled ? `${filled}개 채움 ✓` : '매칭되는 스탠딩 없음';
  setTimeout(() => ($('fillFromStandingsBtn').textContent = '스탠딩으로 채우기'), 2200);
  renderImgFix();
  renderPreview();
});

// 이웃 대사로 채우기: 같은 캐릭터의 가장 가까운 정상 이미지 재사용
// 같은 캐릭터의 가장 가까운 멀쩡한 이미지를 가져온다
function fillByNeighbor() {
  const msgs = data.messages;
  let filled = 0;
  // 캐릭터별 정상 이미지 위치 인덱스
  const goodIdx = new Map(); // name -> [{i, url}]
  msgs.forEach((m, i) => {
    if (!m.divider && isGoodUrl(m.imgUrl)) {
      if (!goodIdx.has(m.name)) goodIdx.set(m.name, []);
      goodIdx.get(m.name).push({ i, url: m.imgUrl });
    }
  });
  msgs.forEach((m, i) => {
    if (!needsFill(m)) return;
    const list = goodIdx.get(m.name);
    if (!list || !list.length) return;
    // list는 인덱스 오름차순 — 이진 탐색으로 양옆 후보만 비교한다.
    // (예전엔 결측마다 전체 목록을 훑어, 결측 절반짜리 대형 로그에서 수 초 멈췄다.
    //  같은 거리면 앞쪽(왼쪽 이웃)이 이기는 규칙은 그대로)
    let lo = 0;
    let hi = list.length;
    while (lo < hi) {
      const mid = (lo + hi) >> 1;
      if (list[mid].i < i) lo = mid + 1;
      else hi = mid;
    }
    const left = list[lo - 1];
    const right = list[lo];
    const best = !right || (left && i - left.i <= right.i - i) ? left : right;
    m.imgUrl = best.url;
    filled++;
  });
  return filled;
}

$('fillNeighborBtn').addEventListener('click', () => {
  const filled = fillByNeighbor();
  $('fillNeighborBtn').textContent = filled ? `${filled}개 채움 ✓` : '채울 이웃 이미지 없음';
  setTimeout(() => ($('fillNeighborBtn').textContent = '이웃 대사로 채우기'), 2200);
  renderImgFix();
  renderPreview();
});

// ---------- 이미지 한 번에 채우기 ----------
// 깨진 것 찾기 → 표정(@) 매칭 → 대표 스탠딩 → 이웃 대사 순으로 훑는다.
// 앞 단계가 정확한 순서라 뒤 단계는 남은 것만 메운다.
$('imgAutoBtn').addEventListener('click', async () => {
  const btn = $('imgAutoBtn');
  const out = $('imgAutoStatus');
  btn.disabled = true;
  const before = [...missingStats().values()].reduce((a, x) => a + x.empty + x.broken, 0);
  try {
    btn.textContent = '깨진 이미지 검사 중…';
    out.textContent = '';
    await checkBrokenImages((d, t) => (btn.textContent = `깨진 이미지 검사 ${d}/${t}…`));

    btn.textContent = '스탠딩 맞추는 중…';
    const pools = await standingPools();
    const steps = [];
    const byFace = pools.length ? fillByFaceTags(pools) : 0;
    if (byFace) steps.push(`표정(@) ${byFace}개`);
    const byStand = pools.length ? fillByStandings(pools) : 0;
    if (byStand) steps.push(`스탠딩 ${byStand}개`);
    const byNear = fillByNeighbor();
    if (byNear) steps.push(`이웃 대사 ${byNear}개`);

    const left = [...missingStats().values()].reduce((a, x) => a + x.empty + x.broken, 0);
    out.textContent = steps.length
      ? `${steps.join(' · ')} 채움 · ${before}개 중 ${left}개 남음` +
        (left ? ' (남은 것은 아래에서 직접 넣거나 캐릭터 JSON을 붙여넣어 주세요)' : ' ✓')
      : pools.length
        ? '채울 수 있는 이미지를 못 찾았습니다. 캐릭터 이름이 저장된 스탠딩 이름과 같은지 확인해 주세요.'
        : '저장된 스탠딩이 없습니다. 방에서 캐릭터 편집창을 열어 스탠딩을 모아 두거나, 캐릭터 JSON을 붙여넣어 주세요.';
    renderImgFix();
    renderPreview();
  } catch (e) {
    out.textContent = '실패: ' + e.message;
  }
  btn.disabled = false;
  btn.textContent = '이미지 한 번에 채우기';
});

// 배포본에는 kkul-log 연동이 없다 — 업로드용(변환기용) 파일 저장과 kkul 안내를 뺀다 (lib/edition.js)
if (window.CST_LITE) {
  const compat = $('sCompat');
  const compatRow = compat && compat.closest('label');
  if (compatRow) compatRow.style.display = 'none';
  const charTip = document.querySelector('.st-help[data-tip*="kkul"]');
  if (charTip) charTip.dataset.tip = '코코포리아 코마 출력 JSON을 붙여넣습니다.';
}

// 캐릭터 JSON(코코포리아 코마 출력 / kkul 형식) 붙여넣기로 채우기
function extractJsonObjects(text) {
  const results = [];
  let depth = 0;
  let start = -1;
  let inStr = false;
  let esc = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inStr) {
      if (esc) esc = false;
      else if (c === '\\') esc = true;
      else if (c === '"') inStr = false;
      continue;
    }
    if (c === '"') {
      inStr = true;
      continue;
    }
    if (c === '{') {
      if (depth === 0) start = i;
      depth++;
    } else if (c === '}') {
      depth--;
      if (depth === 0 && start !== -1) {
        results.push(text.slice(start, i + 1));
        start = -1;
      }
    }
  }
  return results;
}

$('charJsonApplyBtn').addEventListener('click', async () => {
  const text = $('charJsonInput').value.trim();
  const out = $('charJsonStatus');
  if (!text) {
    out.textContent = '붙여넣은 내용이 없습니다.';
    return;
  }
  const chars = [];
  for (const block of extractJsonObjects(text)) {
    try {
      const parsed = JSON.parse(block);
      const d = parsed && parsed.kind === 'character' && parsed.data ? parsed.data : parsed;
      if (d && typeof d.name === 'string' && d.name.trim()) chars.push(d);
    } catch (_) {}
  }
  if (!chars.length) {
    out.textContent = '인식 가능한 캐릭터 JSON을 찾지 못했습니다.';
    return;
  }
  let filled = 0;
  const applied = [];
  const { lastLogCollection } = await getLocal({ lastLogCollection: null });
  const logRoomId = lastLogCollection && lastLogCollection.roomId;
  const logRoom = logRoomId ? await CSTRoomStore.loadRoom(logRoomId) : null;
  const rooms = logRoom ? { [logRoomId]: logRoom } : {};
  for (const d of chars) {
    const name = d.name.trim();
    const faces = Array.isArray(d.faces) ? d.faces : [];
    const urls = [d.iconUrl, ...faces.map((f) => f && f.iconUrl)].filter((u) => /^https?:/i.test(u || ''));
    if (urls.length) {
      const n = applyUrlToChar(name, urls[0]);
      if (n) {
        filled += n;
        applied.push(`${name}(${n})`);
      }
      // 스탠딩 저장소에도 등록 → 패널·다음 백업에서 재사용
      if (lastLogCollection && lastLogCollection.roomId && rooms[lastLogCollection.roomId]) {
        const room = rooms[lastLogCollection.roomId];
        room.standings = room.standings || {};
        if (!room.standings[name] || !room.standings[name].length) {
          room.standings[name] = faces
            .filter((f) => f && /^https?:/i.test(f.iconUrl || ''))
            .map((f) => ({ label: String(f.label || '').replace(/^@/, '') || '기본', img: f.iconUrl }));
          if (!room.standings[name].length && /^https?:/i.test(d.iconUrl || '')) {
            room.standings[name] = [{ label: '기본', img: d.iconUrl }];
          }
        }
      }
    }
  }
  if (logRoom) await CSTRoomStore.saveRoom(logRoomId, logRoom);
  out.textContent = filled
    ? `${applied.join(', ')} · 총 ${filled}개 채움 ✓ (스탠딩 저장소에도 등록)`
    : `이름은 인식했지만(${chars.map((c) => c.name).join(', ')}) 메시지와 매칭되거나 채울 것이 없었습니다. 캐릭터 이름과 로그 이름이 같은지 확인해 주세요.`;
  renderImgFix();
  renderPreview();
});

// ---------- 파일 → dataURL 유틸 ----------
function fileToDataUrl(file, maxSize, mime, quality) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      try {
        const scale = Math.min(1, maxSize / Math.max(img.naturalWidth, img.naturalHeight));
        const w = Math.max(1, Math.round(img.naturalWidth * scale));
        const h = Math.max(1, Math.round(img.naturalHeight * scale));
        const cv = document.createElement('canvas');
        cv.width = w;
        cv.height = h;
        cv.getContext('2d').drawImage(img, 0, 0, w, h);
        resolve(cv.toDataURL(mime || 'image/webp', quality || 0.85));
      } catch (e) {
        reject(e);
      } finally {
        URL.revokeObjectURL(url);
      }
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('이미지 로드 실패'));
    };
    img.src = url;
  });
}

// ---------- 통계 ----------
$('statsBtn').addEventListener('click', () => {
  statsMode = !statsMode;
  // 통계 화면일 때는 버튼을 포인트색으로 — 돌아가는 길이 눈에 띄게
  $('statsBtn').textContent = statsMode ? '미리보기로' : '통계 보기';
  $('statsBtn').classList.toggle('on', statsMode);
  renderPreview();
});

$('saveStatsBtn').addEventListener('click', () => {
  B.download(
    B.buildStatsHtml(data.messages, data.roomName, collectedAt),
    `${B.sanitizeFilename(data.roomName)}_통계_${B.fileStamp()}.html`
  );
  $('saveStatsBtn').textContent = '저장됨';
  setTimeout(() => ($('saveStatsBtn').textContent = '통계 HTML 저장 (플레이타임·발화·주사위·대성공/대실패)'), 1500);
});

// ---------- 통계 이미지 카드 (PNG) ----------
// KoPub 폰트를 카드에도 쓴다 (확장 안에 있는 woff2를 FontFace로 등록)
let cardFontReady = null;
function ensureCardFont() {
  if (cardFontReady) return cardFontReady;
  cardFontReady = (async () => {
    try {
      if (!(typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) || !window.FontFace) return;
      const faces = [
        ['fonts/KoPubWorldDotumMedium.woff2', '500'],
        ['fonts/KoPubWorldDotumBold.woff2', '700'],
      ];
      for (const [path, weight] of faces) {
        const ff = new FontFace('KoPubWorldDotum', `url(${chrome.runtime.getURL(path)})`, { weight });
        await ff.load();
        document.fonts.add(ff);
      }
    } catch (_) {}
  })();
  return cardFontReady;
}

let cardBlobUrl = '';
let cardFileName = '';
function closeCardOverlay() {
  $('cardOverlay').hidden = true;
  if (cardBlobUrl) URL.revokeObjectURL(cardBlobUrl);
  cardBlobUrl = '';
}

$('statsCardBtn').addEventListener('click', async () => {
  const btn = $('statsCardBtn');
  btn.disabled = true;
  btn.textContent = '그리는 중…';
  try {
    await ensureCardFont();
    const kept = B.applyDeletions(data.messages, s);
    const cv = await B.buildStatsCard(kept, data.roomName, collectedAt, {
      theme: $('statsCardTheme').value,
      width: Number($('statsCardWidth').value) || 1200,
    });
    const blob = await new Promise((r) => cv.toBlob(r, 'image/png'));
    if (!blob) throw new Error('PNG 변환 실패');
    if (cardBlobUrl) URL.revokeObjectURL(cardBlobUrl);
    cardBlobUrl = URL.createObjectURL(blob);
    cardFileName = `${B.sanitizeFilename(data.roomName)}_통계카드_${B.fileStamp()}.png`;
    $('cardImg').src = cardBlobUrl;
    $('cardTitle').textContent = `통계 이미지 카드 · ${cv.width}×${cv.height}px · ${(blob.size / 1024).toFixed(0)}KB`;
    $('cardOverlay').hidden = false;
    $('statsCardInfo').textContent = '마음에 들면 [PNG 저장]. 테마·크기를 바꿔 다시 만들 수 있어요.';
  } catch (err) {
    $('statsCardInfo').textContent = '카드 생성 실패: ' + String((err && err.message) || err);
  }
  btn.disabled = false;
  btn.textContent = '통계 이미지 카드 만들기 (PNG · SNS 공유용)';
});

$('cardSaveBtn').addEventListener('click', () => {
  if (!cardBlobUrl) return;
  const a = document.createElement('a');
  a.href = cardBlobUrl;
  a.download = cardFileName || 'stats-card.png';
  document.body.appendChild(a);
  a.click();
  a.remove();
  $('cardSaveBtn').textContent = '저장됨';
  setTimeout(() => ($('cardSaveBtn').textContent = 'PNG 저장'), 1500);
});
$('cardCloseBtn').addEventListener('click', closeCardOverlay);
$('cardOverlay').addEventListener('click', (e) => {
  if (e.target === $('cardOverlay')) closeCardOverlay();
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && !$('cardOverlay').hidden) closeCardOverlay();
});


// ---------- 파일 열기 (저장해둔 로그 HTML 다시 보기/재편집) ----------
// 예시 데이터 불러오기 — 수집본 없이도 스타일을 만져볼 수 있게 (탭 3종·주사위·편집·시스템 메시지 포함)
$('sampleBtn').addEventListener('click', async () => {
  const prevRoom = data ? data.roomName : '';
  collectedAt = T0 + 300000;
  data = {
    roomName: SAMPLE_ROOM,
    messages: B.localizeTimes(SAMPLE.map((m) => ({ ...m })), collectedAt, tsFormat),
    tabNames: ['메인', '정보', '잡담'],
  };
  assignIds(data.messages);
  brokenUrls.clear();
  checkedOnce = false;
  $('srcInfo').textContent = '예시 데이터로 미리보기 중';
  data.plainFormat = false; // 예시 데이터에는 회색=시스템 판정을 쓰지 않는다
  updateGraySysRow();
  // 로그를 열 때와 같은 규칙 — 방 이름을 채워 둔 머리말이면 예시 데이터로 갈아 끼운다
  await askKeepHeader(data.roomName, prevRoom);
  renderTabStyles();
  renderCharRows();
  renderRoundRows();
  renderPreview();
  renderImgFix();
});


// ---------- zip 로그 읽기 ----------
// 코코포리아가 내려주는 zip 에는 로그 html/json 과 (형태에 따라) 표정 이미지가 함께 들어 있다.
// 라이브러리 없이 브라우저 기본 기능(DecompressionStream)으로 푼다.
function fileBaseName(n) {
  return String(n || '').replace(/\.[^.]+$/, '');
}

// 파일 이름에서 방 이름만 남긴다 ('예시방_log' · '예시방[all]' · '예시방 (1)' → '예시방')
function roomNameFromFile(n) {
  return (
    fileBaseName(n)
      .replace(/\s*\[[^\]]*\]\s*$/, '')
      .replace(/\s*\(\d+\)\s*$/, '')
      .replace(/[_-]?log$/i, '')
      .trim() || fileBaseName(n)
  );
}

// zip 읽기는 lib/unzip.js 가 담당한다 (자동 업데이트도 같은 코드를 쓴다)
const unzip = (buf) => window.CSTUnzip.unzip(buf);
// zip 안에서 인장으로 쓸 이미지 파일
const IMG_EXT = /\.(png|jpe?g|gif|webp|bmp|avif)$/i;

async function readZipLogs(file) {
  const entries = await unzip(await file.arrayBuffer());
  const images = new Map(); // 파일 이름(및 확장자 뺀 이름) → data URL
  for (const e of entries) {
    if (!IMG_EXT.test(e.name)) continue;
    const ext = (e.name.match(IMG_EXT) || [])[1].toLowerCase();
    const mime = ext === 'jpg' ? 'image/jpeg' : 'image/' + ext;
    const url = await new Promise((r) => {
      const fr = new FileReader();
      fr.onload = () => r(fr.result);
      fr.readAsDataURL(new Blob([e.bytes], { type: mime }));
    });
    const base = e.name.split('/').pop();
    images.set(e.name, url);
    images.set(base, url);
    images.set(fileBaseName(base), url);
  }
  const dec = new TextDecoder('utf-8');
  let logs = [];
  for (const e of entries) {
    if (!/\.(html?|json)$/i.test(e.name)) continue;
    logs.push({ name: e.name.split('/').pop(), text: dec.decode(e.bytes), images });
  }
  // 같은 로그가 html·json 둘 다 들어 있으면 json 만 쓴다 (시각·색·표정 정보가 더 많다)
  const jsonBases = new Set(logs.filter((l) => /\.json$/i.test(l.name)).map((l) => fileBaseName(l.name)));
  if (jsonBases.size) logs = logs.filter((l) => /\.json$/i.test(l.name) || !jsonBases.has(fileBaseName(l.name)));
  if (!logs.length) throw new Error('zip 안에 로그(html·json) 파일이 없습니다');
  return logs;
}

// 로그가 이미지 파일을 이름으로 가리키면 (data URL 이 아니면) zip 안 이미지로 바꿔 준다
function linkZipImages(messages, images) {
  if (!images || !images.size) return;
  for (const m of messages) {
    const u = m.imgUrl || '';
    if (!u || /^(data:|https?:)/i.test(u)) continue;
    const key = u.replace(/^\.?\//, '');
    const hit = images.get(key) || images.get(key.split('/').pop()) || images.get(fileBaseName(key.split('/').pop()));
    if (hit) m.imgUrl = hit;
  }
}

// 고른 파일을 읽어 { name, text, images? } 목록으로 편다.
// zip 은 안에 든 html·json 을 꺼내고, 같은 로그의 html·json 이 함께 있으면 json 만 남긴다
// (코코포리아가 두 형식을 같이 내려주는데, 그대로 두면 같은 대사가 두 벌 들어온다).
async function expandLogFiles(files, onError) {
  const items = [];
  for (const f of files) {
    if (/\.zip$/i.test(f.name)) {
      try {
        items.push(...(await readZipLogs(f)));
      } catch (e) {
        if (onError) onError(e);
      }
    } else {
      items.push({ name: f.name, text: await f.text() });
    }
  }
  const jsonBase = new Set(items.filter((x) => /\.json$/i.test(x.name)).map((x) => fileBaseName(x.name)));
  const picked = jsonBase.size
    ? items.filter((x) => /\.json$/i.test(x.name) || !jsonBase.has(fileBaseName(x.name)))
    : items;
  return { picked, skippedSame: items.length - picked.length };
}

// 고른 파일을 읽어 파싱 결과 목록으로 (내용이 겹치는 파일은 뺀다)
async function parseLogFiles(files, onError) {
  const { picked, skippedSame } = await expandLogFiles(files, onError);
  const parsedAll = [];
  for (const it of picked) {
    const parsed = B.parseLogFile(it.text, roomNameFromFile(it.name));
    if (!parsed.messages.length) continue;
    if (it.images) linkZipImages(parsed.messages, it.images);
    parsedAll.push({ parsed, file: { name: it.name } });
  }
  const { kept, dropped } = dropContainedLogs(parsedAll);
  return { parsedAll: kept, picked, skippedSame, skippedWhole: dropped.length };
}

// 코코포리아 zip 에는 탭별 파일과 모든 탭을 합친 파일([すべて] · [all])이 함께 들어 있다.
// 그대로 다 읽으면 같은 대사가 두 벌 들어오므로, 다른 파일에 통째로 들어 있는 파일은 뺀다.
// 파일 이름이 아니라 내용으로 판정한다 — 코코포리아 UI 언어에 따라 이름이 달라지기 때문.
function dropContainedLogs(list) {
  const keyOf = (m) => (m.name || '') + '\x1f' + (m.text || '') + '\x1f' + (m.exact || m.ts || '');
  const order = new Map(list.map((x, i) => [x, i]));
  const bySize = [...list].sort((a, b) => b.parsed.messages.length - a.parsed.messages.length);
  const kept = [];
  const seen = new Set();
  const dropped = [];
  for (const item of bySize) {
    const keys = item.parsed.messages.filter((m) => !m.divider).map(keyOf);
    if (keys.length && keys.every((k) => seen.has(k))) {
      dropped.push(item);
      continue;
    }
    kept.push(item);
    for (const k of keys) seen.add(k);
  }
  kept.sort((a, b) => order.get(a) - order.get(b));
  return { kept, dropped };
}

// 이미지 없이 텍스트로 내보낸 HTML(<p> 형식)에는 /system 표식이 없다.
// 코코포리아가 그 형식에서 시스템 메시지를 회색으로만 구분하므로, 원하는 사람만 켜서 쓰게 한다.
const GRAY_SYS = '#888888';

function applyGraySys(messages, on) {
  let n = 0;
  for (const m of messages || []) {
    if (m.divider) continue;
    if (on) {
      if (!m.sys && (m.color || '').toLowerCase() === GRAY_SYS) {
        m.__grayName = m.name || '';
        m.name = '';
        m.imgUrl = '';
        m.sys = true;
        n++;
      }
    } else if (m.sys && m.__grayName !== undefined) {
      m.name = m.__grayName;
      delete m.__grayName;
      m.sys = false;
      n++;
    }
  }
  return n;
}

// 토글은 늘 자리에 둔다 (파일을 바꿀 때마다 사라졌다 나타나면 찾기 어렵다).
// 그 형식이 아닐 때는 흐리게 잠그고, 그 형식을 열면 접힌 묶음을 펴 주고 안내도 한 줄 남긴다.
function updateGraySysRow(notify) {
  const row = $('graySysRow');
  if (!row) return;
  const show = !!(data && data.plainFormat);
  const box = $('sGraySys');
  box.checked = !!s.plainGraySys;
  box.disabled = !show;
  row.classList.toggle('st-check-off', !show);
  row.title = show
    ? '이 로그에는 /system 표식이 없습니다 — 회색(#888888) 줄을 시스템 메시지로 봅니다.'
    : '지금 연 로그에는 /system 표식이 있어 이 설정이 필요 없습니다 (이미지 없는 텍스트 HTML 에서만 씁니다).';
  if (!show) return;
  const group = row.closest('.st-group');
  if (group && group.classList.contains('folded')) {
    const title = group.querySelector('.st-group-fold');
    if (title) title.click(); // 접힘 상태 저장까지 그대로 따라간다
  }
  if (notify && !s.plainGraySys) {
    $('srcInfo').textContent +=
      ' · 이 형식에는 /system 표식이 없습니다 — [주사위·명령어·시스템]의 [회색 줄을 시스템 메시지로 보기]를 켜 보세요.';
  }
}

$('sGraySys').addEventListener('change', () => {
  s.plainGraySys = $('sGraySys').checked;
  // 이 판정은 /system 표식이 없는 형식(이미지 없는 텍스트 HTML)에서만 쓴다.
  // 다른 로그·예시 데이터에서는 회색이 그냥 '색 안 정한 캐릭터'라 건드리면 안 된다.
  if (!data || !data.plainFormat) return;
  applyGraySys(data.messages, s.plainGraySys);
  renderTabStyles();
  renderCharRows();
  renderImgFix();
  renderPreview();
});

// 다른 로그를 열면 머리말은 앞 세션 것이 그대로 남는다.
//  · 제목이 '방 이름을 자동으로 채운 것'이면 새 방 이름으로 조용히 갈아 끼운다
//    (예전 설정엔 표식이 없으므로, 앞서 열려 있던 방 이름과 같으면 자동으로 본다)
//  · 사람이 직접 쓴 제목·부제목·설명·세션 카드 이미지가 있을 때만 유지할지 물어본다
//  · 디자인·색·크기 같은 스타일은 어느 쪽이든 건드리지 않는다
async function askKeepHeader(roomName, prevRoom) {
  const H = s.header || {};
  const autoTitle = !!H.title && (H.__titleAuto || H.title === SAMPLE_ROOM || (!!prevRoom && H.title === prevRoom));
  let changed = false;
  if (autoTitle && H.title !== roomName) {
    H.title = roomName || '';
    H.__titleAuto = true;
    $('hTitle').value = H.title;
    changed = true;
  }
  const bits = [];
  if (H.title && !autoTitle) bits.push('제목');
  if (H.sub) bits.push('부제목');
  if (H.desc) bits.push('설명');
  if (headerImage) bits.push('세션 카드 이미지');
  if (!bits.length) {
    if (changed) await saveLogSettings(s);
    return;
  }
  const keep = confirm(
    `앞서 쓰던 머리말(${bits.join(' · ')})을 그대로 둘까요?\n\n` +
      `확인 — 그대로 씁니다\n` +
      `취소 — 새로 연 로그에 맞춰 비웁니다 (제목은 방 이름 "${roomName}")`
  );
  if (!keep) {
    H.title = roomName || '';
    H.__titleAuto = true;
    H.sub = '';
    H.desc = '';
    $('hTitle').value = H.title;
    $('hSub').value = '';
    $('hDesc').value = '';
    if (headerImage) {
      headerImage = '';
      await setLocal({ logHeaderImage: '' });
      updateHeaderImgInfo();
    }
    changed = true;
  }
  if (changed) await saveLogSettings(s);
}

// 화면을 처음 그릴 때(수집본 · 로그 백업 · 예시)도 같은 규칙으로 제목을 맞춘다 — 묻지 않고 조용히.
// 앞서 예시 데이터를 보던 설정이 남아 제목이 '[예시 데이터]' 로 굳던 문제.
async function syncAutoTitle(roomName) {
  const H = s.header || {};
  if (!roomName || H.title === roomName) return;
  if (H.title && !H.__titleAuto && H.title !== SAMPLE_ROOM) return; // 사람이 직접 쓴 제목은 지킨다
  H.title = roomName;
  H.__titleAuto = true;
  H.__titleTouched = true;
  const inp = $('hTitle');
  if (inp) inp.value = H.title;
  await saveLogSettings(s);
}

$('openFileBtn').addEventListener('click', () => $('fileInput').click());
$('fileInput').addEventListener('change', async () => {
  const files = [...$('fileInput').files];
  if (!files.length) return;
  const prevRoom = data ? data.roomName : ''; // 머리말 제목이 '앞 방 이름 그대로'인지 판단용
  const merged = [];
  let firstRoom = '';
  let okFiles = 0;
  let zipError = '';
  const { parsedAll, skippedSame, skippedWhole } = await parseLogFiles(files, (e) => {
    zipError = `zip 을 읽지 못했습니다: ${e.message}`;
    $('srcInfo').textContent = zipError;
  });

  // 코코포리아 공식 "로그 HTML 저장"은 탭마다 파일이 하나씩 나온다.
  // 같은 방의 탭별 파일을 한꺼번에 열면 회차가 아니라 "탭"으로 합쳐서 시간순 합본을 만든다.
  const asTabs =
    parsedAll.length > 1 &&
    parsedAll.every((x) => x.parsed.format === 'ccfolia-export' && x.parsed.tab) &&
    new Set(parsedAll.map((x) => x.parsed.roomName)).size === 1;
  // 공식 저장 파일(html·json)은 메시지마다 채널·시각이 들어 있다 →
  // 여러 개를 열어도 '회차'로 끊지 않고 하나의 로그로 시간순 합친다
  const OFFICIAL = new Set(['ccfolia-export', 'ccfolia-json', 'ccfolia-plain']);
  const asOne = !asTabs && parsedAll.length > 1 && parsedAll.every((x) => OFFICIAL.has(x.parsed.format));
  const tabNames = [];
  for (const { parsed, file } of parsedAll) {
    if (!firstRoom) firstRoom = parsed.roomName;
    if (asTabs) {
      tabNames.push(parsed.tab);
      for (const m of parsed.messages) merged.push({ ...m, tabOrder: okFiles, seq: merged.length });
    } else {
      if (parsedAll.length > 1 && !asOne) {
        merged.push({ divider: true, text: `${okFiles + 1}회차 — ${file.name.replace(/\.html?$/i, '')}`, tabOrder: 0, seq: merged.length });
      }
      for (const m of parsed.messages) merged.push({ ...m, tabOrder: 0, seq: merged.length });
    }
    okFiles++;
  }
  if (!merged.length) {
    // zip 자체를 못 읽은 경우엔 그 이유를 남겨 둔다 (덮어쓰면 원인을 알 수 없다)
    $('srcInfo').textContent =
      zipError || '메시지를 읽지 못했습니다 (지원: 코코포 선생님 로그 · 코코포리아 공식 로그 HTML/JSON/ZIP · 변환기용 형식)';
    return;
  }
  data = {
    // 겹쳐서 건너뛴 파일을 빼고 '실제로 읽은 파일'이 하나면 그 방 이름 그대로
    roomName: asTabs || asOne || parsedAll.length === 1 ? firstRoom : `${firstRoom} 통합본`,
    messages: asTabs || asOne ? B.sortForMerge(merged) : merged,
    tabNames,
  };
  const isOfficial = parsedAll.length && parsedAll[0].parsed.format === 'ccfolia-export';
  $('srcInfo').textContent = asTabs
    ? `코코포리아 공식 로그 ${okFiles}개 탭 합침 (${merged.length}개 메시지: ${tabNames.join(' / ')})`
    : okFiles > 1
      ? `${okFiles}개 파일 이어붙임 (${merged.filter((m) => !m.divider).length}개 메시지)`
      : `${isOfficial ? '코코포리아 공식 로그 ' : ''}파일 "${(parsedAll[0] && parsedAll[0].file.name) || files[0].name}" (${merged.length}개 메시지)`;
  if (skippedSame) $('srcInfo').textContent += ` · 같은 로그의 html ${skippedSame}개는 json 과 겹쳐 건너뜀`;
  if (skippedWhole) $('srcInfo').textContent += ` · 내용이 겹치는 파일 ${skippedWhole}개는 건너뜀 (탭별 파일과 전부 합친 파일)`;
  // 이미지 없는 텍스트 HTML 은 시스템 메시지 표식이 없다 — 켜 두었으면 회색 줄을 시스템으로 본다
  data.plainFormat = parsedAll.some((x) => x.parsed.format === 'ccfolia-plain');
  if (data.plainFormat && s.plainGraySys) applyGraySys(data.messages, true);
  updateGraySysRow(true);
  await askKeepHeader(data.roomName, prevRoom);
  collectedAt = Date.now();
  data.messages = B.localizeTimes(data.messages, collectedAt, tsFormat);
  assignIds(data.messages);
  brokenUrls.clear();
  checkedOnce = false;
  renderTabStyles();
  renderCharRows();
  renderRoundRows();
  renderPreview();
  renderImgFix();
  $('fileInput').value = '';
});

// ---------- 로그 합치기 ----------
// 겹친 대사는 절대 알아서 지우지 않는다. 먼저 몇 건인지 보여주고,
// 사람이 [겹친 것 지우기]를 눌렀을 때만 지운다.
function dupKey(m, ignoreTs) {
  const base = (m.name || '') + '\x1f' + (m.text || '');
  return ignoreTs ? base : base + '\x1f' + (m.exact || m.ts || '');
}

function findDups() {
  const ignoreTs = $('dupIgnoreTs').checked;
  const seen = new Map(); // key -> 첫 번째 메시지
  const extras = []; // 두 번째 이후로 나온 것들
  for (const m of data.messages) {
    if (m.divider) continue;
    const k = dupKey(m, ignoreTs);
    if (seen.has(k)) extras.push(m);
    else seen.set(k, m);
  }
  return extras;
}

function renderDupRows(extras) {
  const box = $('dupRows');
  box.innerHTML = '';
  for (const m of extras.slice(0, 40)) {
    const row = document.createElement('div');
    row.className = 'dup-row';
    const who = document.createElement('b');
    who.textContent = m.name || '이름 없음';
    row.append(who, document.createTextNode(`  ${(m.ts || '').trim()}  ${(m.text || '').slice(0, 60)}`));
    box.appendChild(row);
  }
  if (extras.length > 40) {
    const more = document.createElement('div');
    more.className = 'dup-row';
    more.textContent = `… 그리고 ${extras.length - 40}건 더`;
    box.appendChild(more);
  }
}

$('dupScanBtn').addEventListener('click', () => {
  const extras = findDups();
  renderDupRows(extras);
  $('dupRemoveBtn').disabled = !extras.length;
  $('dupInfo').textContent = extras.length
    ? `겹친 대사 ${extras.length}건. 아래 목록을 확인하고 [겹친 것 지우기]를 누르세요. (첫 번째 것만 남깁니다)`
    : '겹친 대사가 없습니다.';
});

$('dupRemoveBtn').addEventListener('click', () => {
  const extras = findDups();
  if (!extras.length) return;
  if (!confirm(`겹친 대사 ${extras.length}건을 지울까요? (각각 첫 번째 것만 남습니다 · Ctrl+Z로 되돌릴 수 있습니다)`)) return;
  pushUndo(`겹친 대사 ${extras.length}건 정리`);
  const drop = new Set(extras); // 객체 자체로 골라낸다 (id가 겹쳐도 안전)
  data.messages = data.messages.filter((m) => !drop.has(m));
  $('dupRows').innerHTML = '';
  $('dupRemoveBtn').disabled = true;
  $('dupInfo').textContent = `${extras.length}건을 지웠습니다.`;
  renderCharRows();
  renderFilterRows();
  renderImgFix();
  renderPreview();
  renderRoundRows();
});

// ---- 회차 구분선 이름 ----
function renderRoundRows() {
  const box = $('roundRows');
  box.innerHTML = '';
  const dividers = data.messages.filter((m) => m.divider);
  if (!dividers.length) {
    const d = document.createElement('div');
    d.className = 'st-desc';
    d.textContent = '회차 구분선이 없습니다. 파일을 2개 이상 열거나 붙이면 생깁니다.';
    box.appendChild(d);
    return;
  }
  for (const dv of dividers) {
    const row = document.createElement('div');
    row.className = 'round-row';
    const inp = document.createElement('input');
    inp.type = 'text';
    inp.value = dv.text || '';
    inp.title = '회차 이름. 로그 가운데 구분선에 그대로 나옵니다';
    inp.addEventListener('change', () => {
      pushUndo('회차 이름');
      dv.text = inp.value;
      renderPreview();
    });
    const x = document.createElement('button');
    x.className = 'rr-x';
    x.type = 'button';
    x.textContent = '✕';
    x.title = '이 구분선 지우기';
    x.addEventListener('click', () => {
      pushUndo('구분선 삭제');
      data.messages = data.messages.filter((m) => m !== dv);
      renderRoundRows();
      renderPreview();
    });
    row.append(inp, x);
    box.appendChild(row);
  }
}

// ---- 파일 더 붙이기 ----
$('mergeAddBtn').addEventListener('click', () => $('mergeFileInput').click());
$('mergeFileInput').addEventListener('change', async () => {
  const files = [...$('mergeFileInput').files];
  $('mergeFileInput').value = '';
  if (!files.length) return;
  pushUndo(`파일 ${files.length}개 붙이기`);
  const round = data.messages.filter((m) => m.divider).length;
  let added = 0;
  let n = 0;
  // 여는 것과 같은 방식으로 읽는다 — zip 안의 파일까지 펴고, 내용이 겹치는 파일은 뺀다
  let zipError = '';
  const { parsedAll, skippedSame, skippedWhole } = await parseLogFiles(files, (e) => {
    zipError = `zip 을 읽지 못했습니다: ${e.message}`;
    $('dupInfo').textContent = zipError;
  });
  for (const { parsed, file } of parsedAll) {
    n++;
    data.messages.push({
      divider: true,
      text: `${round + n}회차 — ${fileBaseName(file.name)}`,
      tabOrder: 0,
      seq: data.messages.length,
    });
    for (const m of parsed.messages) {
      data.messages.push({ ...m, tabOrder: 0, seq: data.messages.length });
      added++;
    }
  }
  if (!added) {
    $('dupInfo').textContent =
      zipError || '메시지를 읽지 못했습니다 (지원: 코코포 선생님 로그 · 코코포리아 공식 로그 HTML/JSON/ZIP · 변환기용 형식)';
    return;
  }
  data.messages = B.localizeTimes(data.messages, collectedAt, tsFormat);
  assignIds(data.messages);
  // 붙인 파일 중에 이미지 없는 텍스트 HTML 이 있으면 그 설정을 따른다
  if (parsedAll.some((x) => x.parsed.format === 'ccfolia-plain')) {
    data.plainFormat = true;
    if (s.plainGraySys) applyGraySys(data.messages, true);
  }
  updateGraySysRow();
  const skipNote =
    (skippedSame ? ` · 같은 로그의 html ${skippedSame}개는 json 과 겹쳐 건너뜀` : '') +
    (skippedWhole ? ` · 내용이 겹치는 파일 ${skippedWhole}개는 건너뜀` : '');
  $('srcInfo').textContent = `파일 ${n}개를 뒤에 붙였습니다 (+${added}개 메시지 · 전체 ${data.messages.filter((m) => !m.divider).length}개)${skipNote}`;
  $('dupInfo').textContent = '붙인 뒤에는 [겹친 대사 찾기]로 확인해 보세요.';
  renderTabStyles();
  renderCharRows();
  renderFilterRows();
  renderImgFix();
  renderRoundRows();
  renderPreview();
});

// ---------- 설정 공유 (JSON 내보내기/가져오기) ----------
$('exportSettingsBtn').addEventListener('click', () => {
  const json = JSON.stringify({ kind: 'cst-log-settings', version: 2, settings: s }, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `코코포선생님_로그설정_${B.fileStamp()}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  if (navigator.clipboard) navigator.clipboard.writeText(json).catch(() => {});
  $('shareInfo').textContent = 'JSON 파일 저장 + 클립보드에 복사됨 ✓';
});

$('importSettingsBtn').addEventListener('click', () => $('settingsFileInput').click());
$('settingsFileInput').addEventListener('change', async () => {
  const file = $('settingsFileInput').files[0];
  if (!file) return;
  try {
    const obj = JSON.parse(await file.text());
    const incoming = obj && obj.kind === 'cst-log-settings' ? obj.settings : obj;
    if (!incoming || typeof incoming !== 'object') throw new Error('형식 오류');
    s = B.normalizeSettings(incoming);
    await saveLogSettings(s);
    $('shareInfo').textContent = `"${file.name}" 설정 적용됨 ✓`;
    // 폼 다시 그리기: 값 갱신
    location.reload();
  } catch (_) {
    $('shareInfo').textContent = '가져오기 실패. 코코포 선생님 로그 설정 JSON이 아닙니다.';
  }
  $('settingsFileInput').value = '';
});

// ---------- 저장한 스타일 (프리셋) ----------
// 설정 한 벌을 이름 붙여 담아둔다. 배경·머리말 이미지까지 같이 담아야
// "그때 그 느낌"이 그대로 돌아온다.
let presets = [];

function presetInfo(msg) {
  $('presetInfo').textContent = msg || '';
}

function renderPresetSel(keepId) {
  const sel = $('presetSel');
  const prev = keepId != null ? String(keepId) : sel.value;
  sel.innerHTML = '';
  if (!presets.length) {
    const o = document.createElement('option');
    o.value = '';
    o.textContent = '저장한 스타일 없음';
    sel.appendChild(o);
    sel.disabled = true;
    return;
  }
  sel.disabled = false;
  for (const p of presets) {
    const o = document.createElement('option');
    o.value = String(p.id);
    const d = new Date(p.at || 0);
    const pad = (n) => String(n).padStart(2, '0');
    o.textContent = `${p.name}  (${pad(d.getMonth() + 1)}.${pad(d.getDate())})`;
    sel.appendChild(o);
  }
  if (prev && presets.some((p) => String(p.id) === prev)) sel.value = prev;
}

async function savePresets() {
  await setLocal({ logPresets: presets });
}

function currentPresetPayload(name) {
  return {
    id: Date.now() + Math.floor(Math.random() * 1000),
    name,
    at: Date.now(),
    settings: JSON.parse(JSON.stringify(s)),
    bgImage: bgImage || '',
    headerImage: headerImage || '',
  };
}

$('presetSaveBtn').addEventListener('click', async () => {
  const name = (prompt('저장할 이름을 적어주세요.', '스타일 ' + (presets.length + 1)) || '').trim();
  if (!name) return;
  const p = currentPresetPayload(name);
  presets.push(p);
  await savePresets();
  renderPresetSel(p.id);
  presetInfo(`"${name}" 저장됨 ✓`);
});

$('presetOverBtn').addEventListener('click', async () => {
  const id = $('presetSel').value;
  const idx = presets.findIndex((p) => String(p.id) === id);
  if (idx < 0) return presetInfo('덮어쓸 스타일을 먼저 고르세요.');
  if (!confirm(`"${presets[idx].name}"을(를) 지금 설정으로 덮어쓸까요?`)) return;
  const keep = presets[idx];
  presets[idx] = { ...currentPresetPayload(keep.name), id: keep.id };
  await savePresets();
  renderPresetSel(keep.id);
  presetInfo(`"${keep.name}" 덮어씀 ✓`);
});

$('presetRenameBtn').addEventListener('click', async () => {
  const id = $('presetSel').value;
  const p = presets.find((x) => String(x.id) === id);
  if (!p) return presetInfo('이름을 바꿀 스타일을 먼저 고르세요.');
  const name = (prompt('새 이름', p.name) || '').trim();
  if (!name) return;
  p.name = name;
  await savePresets();
  renderPresetSel(p.id);
  presetInfo('이름 바뀜 ✓');
});

$('presetDelBtn').addEventListener('click', async () => {
  const id = $('presetSel').value;
  const p = presets.find((x) => String(x.id) === id);
  if (!p) return presetInfo('삭제할 스타일을 먼저 고르세요.');
  if (!confirm(`"${p.name}"을(를) 삭제할까요?`)) return;
  presets = presets.filter((x) => String(x.id) !== id);
  await savePresets();
  renderPresetSel();
  presetInfo('삭제됨');
});

$('presetApplyBtn').addEventListener('click', async () => {
  const id = $('presetSel').value;
  const p = presets.find((x) => String(x.id) === id);
  if (!p) return presetInfo('불러올 스타일을 먼저 고르세요.');
  // 설정 폼이 워낙 많아 값만 바꿔 끼우면 놓치는 칸이 생긴다.
  // 저장한 뒤 새로 그리는 편이 확실하다 (수집한 로그는 저장소에 있어 그대로 남는다).
  await saveLogSettings(B.normalizeSettings(p.settings));
  await setLocal({ logBgImage: p.bgImage || '', logHeaderImage: p.headerImage || '' });
  presetInfo(`"${p.name}" 적용 중…`);
  location.reload();
});

// ---------- 초기화 ----------
window.__studioState = 'start';
(async () => {
  await applyPageTheme();
  window.__studioState = 'theme-ok';
  const logSettings = await loadLogSettings();
  s = B.normalizeSettings(logSettings);

  const { lastLogCollection, logBgImage, logHeaderImage, logPresets } = await getLocal({
    lastLogCollection: null,
    logBgImage: '',
    logHeaderImage: '',
    logPresets: [],
  });
  presets = Array.isArray(logPresets) ? logPresets : [];
  renderPresetSel();
  bgImage = logBgImage || '';
  headerImage = logHeaderImage || '';
  if (lastLogCollection && Array.isArray(lastLogCollection.messages) && lastLogCollection.messages.length) {
    collectedAt = lastLogCollection.at || Date.now();
    data = {
      roomName: lastLogCollection.roomName || '코코포리아',
      // "先週 木曜日 1:57" 같은 일본어 상대 표기를 실제 날짜로 바꿔 둔다
      messages: B.localizeTimes(lastLogCollection.messages, collectedAt, tsFormat),
      tabNames: lastLogCollection.tabNames || [],
    };
    const d = new Date(lastLogCollection.at || Date.now());
    const pad = (n) => String(n).padStart(2, '0');
    $('srcInfo').textContent =
      `"${data.roomName}" 수집본 (${pad(d.getMonth() + 1)}.${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())} · ${data.messages.length}개 메시지)`;
  } else {
    collectedAt = T0 + 300000;
    data = { roomName: SAMPLE_ROOM, messages: B.localizeTimes(SAMPLE.map((m) => ({ ...m })), collectedAt, tsFormat), tabNames: ['메인', '정보', '잡담'] };
    // 배포본에는 수집 기능이 없다 — '수집된 로그가 없어'라는 기본 문구 대신 파일을 열라고 안내한다
    if (window.CST_LITE) $('srcInfo').textContent = '로그 파일을 열기 전 — 예시 데이터로 미리보기 중';
    $('exportBtn').disabled = false; // 예시 데이터도 저장은 가능하지만 안내 유지
  }

  assignIds(data.messages);
  data.plainFormat = false; // 처음 화면(수집본·예시)은 그 형식이 아니다
  updateGraySysRow();
  await syncAutoTitle(data.roomName); // 수집본 · 로그 백업을 열면 제목도 그 방 이름으로
  $('sEmbed').checked = !!s.embedImages;
  $('sEmbed').addEventListener('change', () => {
    s.embedImages = $('sEmbed').checked;
  });
  try {
    previewFontCss = await B.resolveKopubCss(false);
  } catch (_) {}
  bindForm();
  bindGroupFolding();
  renderTabStyles();
  renderBadgeOnlyRows();
  renderCharRows();
  renderRoundRows();
  renderImgFix();
  renderPreview();
  window.__studioState = 'ready';
})().catch((e) => {
  window.__studioState = 'error: ' + e.message;
  window.__studioErr = e.stack;
});
