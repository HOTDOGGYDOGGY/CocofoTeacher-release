// [edit] 미리보기 렌더 · 대사 편집 · 캐릭터 목록
// ---------- 미리보기 (로그 / 통계) ----------
let statsMode = false;
let previewAll = false;
let previewMode = 'merged'; // merged(시간순 합본) | perTab(탭별)
let previewFontCss = null; // kopub 로컬 폰트 (미리보기용 URL 참조)

function buildPreviewSettings() {
  const sPrev = { ...s };
  if (s.font === 'kopub' && previewFontCss != null) sPrev.__fontCss = previewFontCss;
  if (s.theme === 'image') sPrev.__bgImage = bgImage || '';
  sPrev.__headerImage = headerImage || '';
  sPrev.__editable = editMode;
  sPrev.__preview = true; // 인라인 onerror 대신 리스너로 (CSP)
  return sPrev;
}

// 미리보기를 다시 그려도 보던 위치를 유지한다 (설정 하나 바꿀 때마다 맨 위로 튀지 않게)
function setPreviewHtml(html) {
  const fr = $('preview');
  let keep = 0;
  try {
    const w = fr.contentWindow;
    const d = fr.contentDocument;
    keep = (w && w.scrollY) || (d && d.documentElement && d.documentElement.scrollTop) || 0;
  } catch (_) {}
  fr.addEventListener(
    'load',
    () => {
      try {
        if (keep) fr.contentWindow.scrollTo(0, keep);
      } catch (_) {}
      // 깨진 인장 숨기기 — 저장 파일의 인라인 onerror 역할을 미리보기에서는 여기서 한다.
      // 이미지마다 리스너를 달지 않고 문서에 캡처 리스너 하나 (error 는 버블되지 않는다).
      try {
        const d = fr.contentDocument;
        const hideBroken = (im) => {
          if (im && im.tagName === 'IMG' && (im.classList.contains('ic') || im.classList.contains('ic-img'))) im.style.visibility = 'hidden';
        };
        d.addEventListener('error', (e) => hideBroken(e.target), true);
        // load 이전에 이미 실패한 것들은 한 번 훑는다
        for (const im of d.querySelectorAll('img.ic, img.ic-img')) if (im.complete && im.naturalWidth === 0) hideBroken(im);
      } catch (_) {}
      bindPreviewEditing();
    },
    { once: true }
  );
  fr.srcdoc = html;
}

// ---- 파이프라인 캐시 ----
// 필터→이미지 상속→정렬은 전체 배열 6~8회 순회짜리인데, 렌더의 대부분은 폰트·색 같은
// "스타일만" 바뀐 경우다. 스타일 렌더(queueRender 경유)는 지난 결과를 재사용하고,
// 데이터가 바뀌는 경로(renderPreview 직접 호출)는 항상 새로 계산한다.
// 파이프라인에 실제로 영향을 주는 설정은 rowFilters · 탭별 mode(hide 포함) · previewMode 뿐.
let pipeCache = null; // { key, msgs }
let statsCache = null; // 통계 HTML (데이터가 바뀌면 renderPreview 직접 호출로 무효화)

function pipelineKey() {
  const modes = {};
  for (const k of Object.keys(s.tabStyles || {})) modes[k] = (s.tabStyles[k] && s.tabStyles[k].mode) || 'normal';
  return JSON.stringify([s.rowFilters, modes, previewMode]);
}

function renderPreview(reusePipeline) {
  if (statsMode) {
    $('previewInfo').textContent = '통계 미리보기';
    // 통계는 설정과 무관 — 데이터가 그대로면 재계산하지 않는다
    if (!(reusePipeline && statsCache)) statsCache = B.buildStatsHtml(data.messages, data.roomName, collectedAt);
    setPreviewHtml(statsCache);
    return;
  }
  if (!reusePipeline) {
    pipeCache = null;
    statsCache = null;
  }
  let msgs;
  const key = pipelineKey();
  if (pipeCache && pipeCache.key === key) {
    msgs = pipeCache.msgs;
  } else {
    // applyDeletions·applyFilters 모두 새 배열을 반환하므로 방어 복사([...kept])는 불필요
    const kept = B.applyDeletions(data.messages, s);
    const filtered = B.fixImageUrls(B.applyFilters(kept, s));
    if (previewMode === 'perTab') {
      // 저장 방식 '탭별 파일'과 같은 순서 — 탭 안에서는 수집 순서 그대로
      const byTab = new Map();
      for (const m of filtered) {
        const t = m.divider ? '' : m.tab || '메인';
        if (!byTab.has(t)) byTab.set(t, []);
        byTab.get(t).push(m);
      }
      msgs = [];
      for (const [t, list] of byTab) {
        list.sort((a, b) => (a.tabOrder || 0) - (b.tabOrder || 0) || (a.seq || 0) - (b.seq || 0));
        if (t) msgs.push({ divider: true, text: t });
        for (const m of list) msgs.push(m); // push(...list)는 초대형 탭에서 스택 오버플로
      }
    } else {
      msgs = B.sortForMerge(filtered);
    }
    pipeCache = { key, msgs };
  }
  const slice = previewAll ? msgs : msgs.slice(0, 120);
  // 방 이름·필터 개수는 표시하지 않는다 (미리보기 머리줄은 최대한 미니멀하게)
  if (!previewAll && msgs.length > 120) {
    let shown = 0;
    for (const m of msgs) if (!m.divider) shown++;
    $('previewInfo').textContent = `앞 120개만 표시 중 · [전체 보기]로 전부 (${shown}개)`;
  } else {
    $('previewInfo').textContent = '';
  }
  const html = B.buildHtml(slice, buildPreviewSettings(), { roomName: data.roomName, singleTab: false });
  setPreviewHtml(html);
}

function queueRender() {
  clearTimeout(renderTimer);
  // 설정 컨트롤에서 오는 렌더 — 데이터는 그대로이므로 파이프라인 캐시를 재사용
  renderTimer = setTimeout(() => renderPreview(true), 150);
}

// 기준 날짜·형식이 바뀌면 표시 시각을 다시 계산한다 (직접 고친 대사는 건드리지 않음)
function relocalize() {
  const keep = new Map();
  for (const m of data.messages) if (m.__tsEdited) keep.set(m.__id, m.ts);
  data.messages = B.localizeTimes(data.messages, collectedAt, tsFormat);
  for (const m of data.messages) if (keep.has(m.__id)) m.ts = keep.get(m.__id);
  assignIds(data.messages);
  updateTsInfo();
  renderPreview();
}

function updateTsInfo() {
  const times = data.messages
    .filter((m) => !m.divider && typeof m.exact === 'number' && m.exact > 1e12)
    .map((m) => m.exact);
  const el = $('tsInfo');
  if (!times.length) {
    el.textContent = '시각을 읽지 못했습니다. 기준 날짜를 직접 골라 주세요.';
    return;
  }
  // 스프레드(Math.min(...arr))는 대형 로그에서 인자 개수 한도로 RangeError가 난다
  let min = Infinity;
  let max = -Infinity;
  for (const t of times) {
    if (t < min) min = t;
    if (t > max) max = t;
  }
  const f = (t) => {
    const d = new Date(t);
    const p = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}.${p(d.getMonth() + 1)}.${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
  };
  const derived = data.messages.some((m) => m.__derived);
  el.textContent =
    `${f(min)} ~ ${f(max)}` +
    (derived ? ' (화면에 보이던 상대 시각에서 계산. 어긋나면 기준 날짜를 바꿔 주세요)' : ' (코코포리아 내부 시각 그대로)');
}

// ---------- 되돌리기 (Ctrl+Z) ----------
// 대사를 고치거나 지우기 직전 상태를 통째로 담아둔다.
// 스타일 설정은 담지 않는다 — 되돌리기는 "글"에 대한 것이라야 헷갈리지 않는다.
const UNDO_MAX = 40;
let undoStack = [];

function snapshotMsgs() {
  return data.messages.map((m) => ({ ...m }));
}

function pushUndo(label) {
  undoStack.push({ label: label || '편집', msgs: snapshotMsgs() });
  if (undoStack.length > UNDO_MAX) undoStack.shift();
  // 단계 수 제한만으로는 부족하다 — 10k 로그 × 40단계면 스냅샷 객체만 수십만 개.
  // 총 원소 예산을 넘으면 오래된 것부터 버린다 (최근 되돌리기는 항상 살아 있음)
  const UNDO_ELEM_BUDGET = 200000;
  let total = 0;
  for (const u of undoStack) total += u.msgs.length;
  while (undoStack.length > 1 && total > UNDO_ELEM_BUDGET) {
    total -= undoStack.shift().msgs.length;
  }
  updateUndoBtn();
}

function updateUndoBtn() {
  const btn = $('undoBtn');
  if (!btn) return;
  const n = undoStack.length;
  btn.disabled = !n;
  btn.title = n ? `되돌리기: ${undoStack[n - 1].label} (Ctrl+Z) · ${n}단계 남음` : '되돌릴 편집이 없습니다';
}

function doUndo() {
  const snap = undoStack.pop();
  if (!snap) return;
  data.messages = snap.msgs;
  assignIds(data.messages);
  closeMsgEditor();
  updateUndoBtn();
  renderCharRows();
  renderFilterRows();
  renderImgFix();
  renderPreview();
  $('srcInfo').textContent = `되돌렸습니다: ${snap.label}`;
}

function isTypingTarget(t) {
  return !!t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable);
}

function bindUndoKey(doc) {
  doc.addEventListener('keydown', (e) => {
    if (!(e.ctrlKey || e.metaKey) || e.shiftKey || e.key.toLowerCase() !== 'z') return;
    if (isTypingTarget(e.target)) return; // 입력칸 안에서는 브라우저 기본 되돌리기가 맞다
    e.preventDefault();
    doUndo();
  });
}

bindUndoKey(document);
$('undoBtn').addEventListener('click', doUndo);

// ---------- 미리보기에서 대사 편집 ----------
// 미리보기 iframe은 같은 출처라, 스크립트를 넣지 않고도 바깥에서 클릭을 붙일 수 있다
// 여러 개 고르기: 그냥 클릭=하나 / Shift+클릭=여기까지 죽 / Ctrl(⌘)+클릭=하나씩 더하기
let picked = new Set();
let pickAnchor = null;

function previewOrderIds() {
  const doc = $('preview').contentDocument;
  if (!doc) return [];
  return [...doc.querySelectorAll('[data-mid]')].map((el) => el.dataset.mid);
}

function paintPicked() {
  const doc = $('preview').contentDocument;
  if (!doc) return;
  for (const el of doc.querySelectorAll('[data-mid]')) {
    el.classList.toggle('cst-picked', picked.has(el.dataset.mid));
  }
  const n = picked.size;
  $('bulkBar').classList.toggle('hidden', n < 2);
  $('bulkCount').textContent = `${n}개 선택`;
}

function clearPicked() {
  picked.clear();
  pickAnchor = null;
  paintPicked();
}

function bindPreviewEditing() {
  if (!editMode) return;
  const doc = $('preview').contentDocument;
  if (!doc) return;
  paintPicked(); // 다시 그린 뒤에도 골라둔 것이 남아 있게
  bindUndoKey(doc); // 미리보기 안을 클릭한 상태에서도 Ctrl+Z가 먹게
  doc.addEventListener('click', (e) => {
    const row = e.target.closest && e.target.closest('[data-mid]');
    if (!row) return;
    e.preventDefault();
    const id = row.dataset.mid;

    if (e.shiftKey && pickAnchor) {
      const ids = previewOrderIds();
      const a = ids.indexOf(pickAnchor);
      const b = ids.indexOf(id);
      if (a >= 0 && b >= 0) {
        for (const x of ids.slice(Math.min(a, b), Math.max(a, b) + 1)) picked.add(x);
      }
      closeMsgEditor(true);
      paintPicked();
      return;
    }

    if (e.ctrlKey || e.metaKey) {
      if (picked.has(id)) picked.delete(id);
      else picked.add(id);
      pickAnchor = id;
      closeMsgEditor(true);
      paintPicked();
      return;
    }

    picked = new Set([id]);
    pickAnchor = id;
    paintPicked();
    openMsgEditor(id);
  });
}

// ---------- 고른 대사 한꺼번에 ----------
function pickedMsgs() {
  return data.messages.filter((m) => picked.has(m.__id));
}

function afterBulk(msg) {
  renderCharRows();
  renderFilterRows();
  renderImgFix();
  renderPreview();
  if (msg) $('srcInfo').textContent = msg;
}

$('bulkClear').addEventListener('click', clearPicked);

$('bulkDelete').addEventListener('click', () => {
  const list = pickedMsgs();
  if (!list.length) return;
  if (!confirm(`고른 대사 ${list.length}개를 지울까요?`)) return;
  pushUndo(`대사 ${list.length}개 삭제`);
  data.messages = data.messages.filter((m) => !picked.has(m.__id));
  clearPicked();
  afterBulk(`대사 ${list.length}개를 지웠습니다.`);
});

$('bulkName').addEventListener('click', () => {
  const list = pickedMsgs();
  if (!list.length) return;
  const cur = list[0].name || '';
  const name = prompt(`고른 ${list.length}개의 이름 (비우면 이름은 그대로, 색만 바꿉니다)`, cur);
  if (name === null) return;
  const color = prompt('이름 색 (#rrggbb, 비우면 색은 그대로)', normalizeHex(list[0].color) || '');
  if (color === null) return;
  const hex = normalizeHex(color);
  pushUndo(`대사 ${list.length}개 이름·색`);
  for (const m of list) {
    if (name.trim()) m.name = name.trim();
    if (hex) m.color = hex;
  }
  afterBulk(`${list.length}개에 적용했습니다.`);
});

$('bulkReplace').addEventListener('click', () => {
  const list = pickedMsgs();
  if (!list.length) return;
  const from = prompt(`고른 ${list.length}개 안에서 찾을 말`, '');
  if (!from) return;
  const to = prompt(`"${from}" → 바꿀 말 (비우면 지웁니다)`, '');
  if (to === null) return;
  let n = 0;
  pushUndo('찾아 바꾸기');
  for (const m of list) {
    if (!m.text || !m.text.includes(from)) continue;
    m.text = m.text.split(from).join(to);
    m.__edited = true;
    n++;
  }
  afterBulk(`${n}개 대사에서 "${from}"을(를) 바꿨습니다.`);
});

// 대사 편집기에서 고르고 있는 인장 (저장할 때 반영)
let editingIcon = '';

function paintMeIcon() {
  const btn = $('meIcon');
  btn.classList.toggle('has-img', !!editingIcon);
  btn.style.backgroundImage = editingIcon ? `url("${editingIcon.replace(/"/g, '%22')}")` : '';
  if (!btn.innerHTML) btn.innerHTML = typeof faIcon === 'function' ? faIcon('avatar') : '';
}

function openMsgEditor(id) {
  const m = findMsg(id);
  if (!m) return;
  editingId = id;
  editingIcon = m.imgUrl || '';
  paintMeIcon();
  $('meName').value = m.name || '';
  $('meColor').value = normalizeHex(m.color) || '#888888';
  $('meTs').value = m.ts || '';
  $('meText').value = m.text || '';
  // 어느 대사를 고치는지 한눈에
  const idx = data.messages.findIndex((x) => x.__id === id);
  $('meWho').textContent = `${m.name || '이름 없음'}${m.tab ? ' · ' + m.tab : ''}  (${idx + 1}번째)`;
  $('meBadge').textContent = isDiceLike(m.text) ? '주사위' : '대사';
  $('msgEditor').classList.remove('hidden');
  const ta = $('meText');
  ta.focus();
  ta.setSelectionRange(ta.value.length, ta.value.length);
}

function isDiceLike(t) {
  try {
    return B.isDice(t) || B.isCmd(t);
  } catch (_) {
    return false;
  }
}

function closeMsgEditor(keepPicked) {
  editingId = null;
  $('msgEditor').classList.add('hidden');
  if (keepPicked === true) return;
  clearPicked();
}

$('meClose').addEventListener('click', closeMsgEditor);

$('msgEditor').addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    e.stopPropagation();
    closeMsgEditor();
  } else if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
    e.preventDefault();
    $('meSave').click();
  }
});

$('meSave').addEventListener('click', () => {
  const m = findMsg(editingId);
  if (!m) return closeMsgEditor();
  pushUndo('대사 수정');
  m.name = $('meName').value.trim() || m.name;
  m.color = $('meColor').value;
  m.imgUrl = editingIcon;
  // 시각을 직접 고쳤을 때만 잠근다 (형식·기준 날짜를 바꿔도 안 덮이게)
  if ($('meTs').value !== (m.ts || '')) {
    m.ts = $('meTs').value;
    m.__tsEdited = true;
  }
  m.text = $('meText').value;
  m.__edited = true;
  closeMsgEditor();
  renderCharRows();
  renderImgFix();
  renderPreview();
});

$('meDelete').addEventListener('click', () => {
  const m = findMsg(editingId);
  if (!m) return closeMsgEditor();
  if (!confirm(`"${(m.text || '').slice(0, 30)}…" 이 대사를 지울까요?`)) return;
  pushUndo('대사 삭제');
  data.messages = data.messages.filter((x) => x.__id !== editingId);
  closeMsgEditor();
  renderCharRows();
  renderFilterRows();
  renderImgFix();
  renderPreview();
});

$('meApplyAll').addEventListener('click', () => {
  const m = findMsg(editingId);
  if (!m) return;
  const oldName = m.name;
  const newName = $('meName').value.trim() || oldName;
  const color = $('meColor').value;
  const icon = editingIcon;
  pushUndo('이름·색·인장 일괄');
  let n = 0;
  for (const x of data.messages) {
    if (!x.divider && !x.sys && x.name === oldName) {
      x.name = newName;
      x.color = color;
      x.imgUrl = icon;
      n++;
    }
  }
  m.text = $('meText').value;
  m.ts = $('meTs').value;
  closeMsgEditor();
  renderCharRows();
  renderImgFix();
  renderPreview();
  $('srcInfo').textContent = `"${oldName}" ${n}개 대사에 이름·색·인장을 적용했습니다.`;
});

$('editModeBtn').addEventListener('click', () => {
  editMode = !editMode;
  $('editModeBtn').classList.toggle('on', editMode);
  $('editModeBtn').textContent = editMode ? '편집 끝내기' : '대사 편집';
  if (!editMode) closeMsgEditor();
  else clearPicked();
  renderPreview();
});

// ---------- 찾기 · 바꾸기 (로그 전체) ----------
function findTargets() {
  const withDice = $('findDice').checked;
  return data.messages.filter((m) => !m.divider && (withDice || !isDiceLike(m.text)));
}

// 대소문자를 가리지 않을 때도 원문의 다른 부분은 손대지 않도록 인덱스로 자른다
function replaceAllIn(str, from, to, caseSensitive) {
  if (!str) return { out: str, n: 0 };
  if (caseSensitive) {
    const parts = str.split(from);
    return { out: parts.join(to), n: parts.length - 1 };
  }
  const hay = str.toLowerCase();
  const needle = from.toLowerCase();
  let out = '';
  let i = 0;
  let n = 0;
  for (;;) {
    const at = hay.indexOf(needle, i);
    if (at < 0) break;
    out += str.slice(i, at) + to;
    i = at + needle.length;
    n++;
  }
  out += str.slice(i);
  return { out, n };
}

function runFind(apply) {
  const from = $('findFrom').value;
  if (!from) {
    $('findInfo').textContent = '찾을 말을 적어 주세요.';
    return;
  }
  const to = $('findTo').value;
  const cs = $('findCase').checked;
  const doNames = $('findNames').checked;
  const list = findTargets();

  let hits = 0;
  let rows = 0;
  for (const m of list) {
    const a = replaceAllIn(m.text || '', from, to, cs);
    const b = doNames ? replaceAllIn(m.name || '', from, to, cs) : { out: m.name, n: 0 };
    if (!a.n && !b.n) continue;
    hits += a.n + b.n;
    rows++;
    if (apply) {
      if (a.n) {
        m.text = a.out;
        m.__edited = true;
      }
      if (b.n) m.name = b.out;
    }
  }

  if (!hits) {
    $('findInfo').textContent = `"${from}" 을(를) 찾지 못했습니다.`;
    return;
  }
  if (!apply) {
    $('findInfo').textContent = `${rows}개 대사에서 ${hits}군데 찾았습니다. [모두 바꾸기]를 누르면 고칩니다.`;
    return;
  }
  $('findInfo').textContent = `${rows}개 대사에서 ${hits}군데 바꿨습니다. (Ctrl+Z로 되돌리기)`;
  renderCharRows();
  renderFilterRows();
  renderImgFix();
  renderPreview();
}

$('findCountBtn').addEventListener('click', () => runFind(false));
$('findApplyBtn').addEventListener('click', () => {
  const from = $('findFrom').value;
  if (!from) return runFind(false);
  pushUndo(`"${from}" 찾아 바꾸기`);
  runFind(true);
});
$('findFrom').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') runFind(false);
});
$('findTo').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') $('findApplyBtn').click();
});

// ---------- 캐릭터 (이름 수정 · 이름 색 · 인장 일괄) ----------
// 이름 색은 "지금 쓰이고 있는 색 전부"를 보여 준다. 초반엔 색이 없다가 나중에 생긴 캐릭터도
// 색 하나로 뭉뚱그리지 않는다. 동그라미 오른쪽 위 ✕ 를 누르면 그 색을 지우고,
// 그 색을 쓰던 대사는 목록에서 그 다음 색으로 합쳐진다 (마지막 색이면 앞 색으로).
const NO_COLOR = '\u0000'; // '색 없음' 을 목록에서 다루기 위한 표식

function charColorList(name) {
  const seen = new Map(); // 색 → 개수 (처음 나온 순서 유지)
  for (const m of data.messages) {
    if (m.divider || m.sys || m.name !== name) continue;
    const c = /^#[0-9a-f]{6}$/i.test(m.color || '') ? m.color.toLowerCase() : NO_COLOR;
    seen.set(c, (seen.get(c) || 0) + 1);
  }
  return [...seen.entries()].map(([color, count]) => ({ color, count }));
}

function isColorOf(m, color) {
  const c = /^#[0-9a-f]{6}$/i.test(m.color || '') ? m.color.toLowerCase() : NO_COLOR;
  return c === color;
}

// 색 하나를 지우고 그 대사들을 다음 색으로 합친다
function mergeCharColor(name, list, idx) {
  const from = list[idx];
  const to = list[idx + 1] || list[idx - 1];
  if (!to) return;
  pushUndo('이름 색 합치기');
  let n = 0;
  for (const m of data.messages) {
    if (m.divider || m.sys || m.name !== name) continue;
    if (!isColorOf(m, from.color)) continue;
    m.color = to.color === NO_COLOR ? '' : to.color;
    n++;
  }
  renderCharRows();
  renderPreview();
  $('srcInfo').textContent = `"${name}" ${n}개 대사의 이름 색을 ${
    to.color === NO_COLOR ? '색 없음으로' : to.color + ' 으로'
  } 합쳤습니다.`;
}

// 인장 일괄 변경 — 그 캐릭터의 모든 대사에 같은 그림을 넣는다 (빈 것만이 아니라 전부)
function applyIconToChar(name, url) {
  pushUndo('인장 일괄');
  let n = 0;
  for (const m of data.messages) {
    if (m.divider || m.sys || m.name !== name) continue;
    m.imgUrl = url;
    n++;
  }
  renderCharRows();
  renderImgFix();
  renderPreview();
  $('srcInfo').textContent = url ? `"${name}" ${n}개 대사의 인장을 바꿨습니다.` : `"${name}" 인장을 지웠습니다 (${n}개).`;
  return n;
}

// ---------- 캐릭터별 인장 확대 · 위치 ----------
// 코코포리아 백업의 인장은 스탠딩의 일부만 담겨 얼굴이 잘려 보이는 일이 많다.
// 한 캐릭터에 맞춰 두면 그 캐릭터의 모든 표정이 같은 확대 · 위치로 보인다 (설정 charAvatar[이름]).
const AVATAR_DEF = { zoom: 100, x: 50, y: 0 };

// 'center top' · '50% 12%' 같은 값을 { x, y } 로
function parseObjPos(v) {
  const t = String(v || '').trim().toLowerCase();
  if (!t) return { x: AVATAR_DEF.x, y: AVATAR_DEF.y };
  const KEY = { left: 0, top: 0, center: 50, right: 100, bottom: 100 };
  const parts = t.split(/\s+/).slice(0, 2);
  const val = (p, def) => {
    if (p == null) return def;
    if (p in KEY) return KEY[p];
    const n = parseFloat(p);
    return Number.isFinite(n) && /%$/.test(p) ? Math.max(0, Math.min(100, n)) : def;
  };
  // 'top' 하나만 온 경우처럼 세로 값만 있는 표기도 받아 준다
  if (parts.length === 1) {
    const p = parts[0];
    if (p === 'top' || p === 'bottom') return { x: 50, y: KEY[p] };
    return { x: val(p, AVATAR_DEF.x), y: AVATAR_DEF.y };
  }
  return { x: val(parts[0], AVATAR_DEF.x), y: val(parts[1], AVATAR_DEF.y) };
}

// 보정 기본값 (전체 설정) — 캐릭터가 따로 정해 두지 않았을 때
const fxDefault = () => B.normFx(s.avatarFx, null);

// 지금 값 — 설정에 있으면 그것, 없으면 파일에서 읽어 온 그 캐릭터 첫 대사의 값
function charAvatarValue(name) {
  const av = (s.charAvatar || {})[name];
  const fx = B.effectiveFx(s, av);
  if (av && typeof av === 'object') {
    return {
      zoom: Math.max(100, Math.min(400, Number(av.zoom) || 100)),
      x: Math.max(0, Math.min(100, Number(av.x == null ? AVATAR_DEF.x : av.x))),
      y: Math.max(0, Math.min(100, Number(av.y == null ? AVATAR_DEF.y : av.y))),
      fx,
    };
  }
  const first = data.messages.find((m) => !m.divider && !m.sys && m.name === name && m.imgUrl);
  const pos = parseObjPos(first && first.objPos);
  return { zoom: Math.max(100, Math.min(400, Number(first && first.objZoom) || 100)), x: pos.x, y: pos.y, fx };
}
const hasCharAvatar = (name) => !!(s.charAvatar || {})[name];

// 그 캐릭터가 쓰는 인장들 (많이 쓰인 순서)
function charIconList(name, limit = 12) {
  const cnt = new Map();
  for (const m of data.messages) {
    if (m.divider || m.sys || m.name !== name || !m.imgUrl) continue;
    cnt.set(m.imgUrl, (cnt.get(m.imgUrl) || 0) + 1);
  }
  return [...cnt.entries()].sort((a, b) => b[1] - a[1]).slice(0, limit).map(([u]) => u);
}

let avatarSaveTimer = 0;
function setCharAvatar(name, v) {
  s.charAvatar = s.charAvatar || {};
  const def = fxDefault();
  const rec = { zoom: Math.round(v.zoom), x: Math.round(v.x), y: Math.round(v.y) };
  // 보정은 전체 기본값과 다른 것만 이 캐릭터에 남긴다 (같으면 기본값을 따라간다)
  const fx = B.normFx(v.fx, def);
  const diff = {};
  for (const k of Object.keys(fx)) if (fx[k] !== def[k]) diff[k] = fx[k];
  if (Object.keys(diff).length) rec.fx = diff;
  s.charAvatar[name] = rec;
  clearTimeout(avatarSaveTimer);
  avatarSaveTimer = setTimeout(() => saveLogSettings(s), 600);
}
function clearCharAvatar(name) {
  if (s.charAvatar) delete s.charAvatar[name];
  clearTimeout(avatarSaveTimer);
  avatarSaveTimer = setTimeout(() => saveLogSettings(s), 600);
}

// ---------- 인장 보정 UI (또렷하게 · 매끈하게, 겹쳐 쓸 수 있다) ----------
// ctx = { get(): 지금 값 {sharpen, smooth}, set(patch), sample(): 미리보기에 쓸 그림 주소 }
const FX_TIP = {
  none: '보정 없이 그대로 (둘 다 끄기)',
  sharpen: '또렷하게 — 작아서 흐릿한 인장을 살려 준다 (누르면 켜고 끄기)',
  smooth: '매끈하게 — 계단처럼 도드라진 픽셀을 눌러 준다 (누르면 켜고 끄기)',
};
const FX_ON_DEFAULT = 35; // 꺼져 있던 것을 누르면 이 값으로 켠다

function buildFxUi(host, ctx) {
  host.innerHTML = '';
  host.classList.add('fx-ui');
  const looks = document.createElement('div');
  looks.className = 'fx-looks';
  const thumbs = [];
  for (const [key, label] of B.FX_LOOKS) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'fx-look';
    b.dataset.look = key;
    b.title = FX_TIP[key] || label;
    const im = document.createElement('img');
    im.alt = '';
    im.loading = 'lazy';
    const cap = document.createElement('span');
    cap.textContent = label;
    b.append(im, cap);
    b.addEventListener('click', () => {
      const fx = ctx.get();
      if (key === 'none') return ctx.set({ sharpen: 0, smooth: 0 });
      ctx.set({ [key]: fx[key] > 0 ? 0 : FX_ON_DEFAULT });
    });
    looks.appendChild(b);
    thumbs.push({ key, b, im });
  }
  const rows = {};
  const mk = (key, label, tip) => {
    const lab = document.createElement('label');
    lab.className = 'crop-row';
    lab.title = tip;
    const t = document.createElement('span');
    t.className = 'crop-lab';
    t.textContent = label;
    const rng = document.createElement('input');
    rng.type = 'range';
    rng.className = 'crop-range';
    const r = B.FX_RANGE[key];
    rng.min = String(r[0]);
    rng.max = String(r[1]);
    rng.step = '5';
    const out = document.createElement('output');
    out.className = 'crop-out';
    rng.addEventListener('input', () => ctx.set({ [key]: Number(rng.value) }));
    lab.append(t, rng, out);
    host.appendChild(lab);
    rows[key] = { rng, out, lab };
  };
  host.appendChild(looks);
  mk('sharpen', '또렷하게', '0 이면 끔 — 작아서 흐릿한 인장을 또렷하게');
  mk('smooth', '매끈하게', '0 이면 끔 — 계단처럼 도드라진 픽셀 누르기');
  host.__paint = () => {
    const fx = ctx.get();
    const src = ctx.sample();
    // 미리보기: 원본 · 또렷하게만 · 매끈하게만 (둘 다 켜면 두 칸이 같이 켜져 보인다)
    const one = (key) =>
      key === 'none'
        ? { sharpen: 0, smooth: 0 }
        : { sharpen: 0, smooth: 0, [key]: fx[key] > 0 ? fx[key] : FX_ON_DEFAULT };
    const list = [];
    for (const t of thumbs) list.push(one(t.key));
    list.push(fx);
    ensureFxDefs(list);
    for (const t of thumbs) {
      const on = t.key === 'none' ? fx.sharpen === 0 && fx.smooth === 0 : fx[t.key] > 0;
      t.b.classList.toggle('on', on);
      if (src && t.im.getAttribute('src') !== src) t.im.src = src;
      t.im.style.display = src ? '' : 'none';
      const id = B.fxId(one(t.key));
      t.im.style.filter = id ? 'url(#' + id + ')' : '';
    }
    for (const [k, r] of Object.entries(rows)) {
      r.rng.value = String(fx[k]);
      r.out.textContent = fx[k] ? fx[k] + '%' : '끔';
      r.lab.classList.toggle('off', !fx[k]);
    }
  };
  host.__paint();
  return host.__paint;
}
const paintFxUi = (host) => host && host.__paint && host.__paint();

// 화면 쪽 효과 필터 정의 — 미리보기에 쓰는 것만 만들어 둔다
let fxDefIds = '';
function ensureFxDefs(list) {
  if (!B.fxFilter) return;
  let box = document.getElementById('cst-sharp-defs');
  if (!box) {
    box = document.createElement('div');
    box.id = 'cst-sharp-defs';
    box.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden';
    document.body.appendChild(box);
  }
  const want = new Map();
  for (const fx of list || []) {
    const id = B.fxId(fx);
    if (id && !want.has(id)) want.set(id, fx);
  }
  // 캐릭터 · 전체 기본값에 쓰이는 것도 함께
  for (const fx of [B.effectiveFx(s, null), ...Object.values(s.charAvatar || {}).map((a) => B.effectiveFx(s, a))]) {
    const id = B.fxId(fx);
    if (id && !want.has(id)) want.set(id, fx);
  }
  const ids = [...want.keys()].sort().join(',');
  if (ids === fxDefIds) return;
  fxDefIds = ids;
  box.innerHTML =
    '<svg width="0" height="0" aria-hidden="true" style="position:absolute;width:0;height:0;overflow:hidden">' +
    [...want.values()].map(B.fxFilter).join('') +
    '</svg>';
}

// 스튜디오 화면 쪽에도 같은 선명하게 필터를 한 번 넣어 둔다 (조절 칸 미리보기용)


// 선명하게 토글을 바꾸면 열려 있는 조절 칸도 다시 그린다
function repaintCharCrop() {
  const panel = document.querySelector('.char-crop-panel');
  if (!panel) return;
  const name = panel.dataset.name;
  const row = panel.previousElementSibling;
  const btn = row && row.querySelector('.char-crop');
  if (!name || !btn) return;
  panel.remove(); // 전체 기본값이 바뀌었으니 이 캐릭터 값으로 다시 연다
  openCharCrop(name, row, btn);
}

// 캐릭터 줄 아래에 펼쳐지는 조절 칸 (미리보기 휠 · 드래그 + 슬라이더).
// 조절하는 동안에는 이 칸의 미리보기만 움직이고, [적용]을 눌러야 로그 미리보기에 반영한다
// (슬라이더를 움직일 때마다 큰 미리보기를 다시 그리면 깜빡여서 쓰기 어렵다).
function openCharCrop(name, row, btn) {
  const open = row.nextElementSibling;
  if (open && open.classList.contains('char-crop-panel')) {
    const same = open.dataset.name === name;
    open.remove();
    if (same) return;
  }
  for (const p of $('charRows').querySelectorAll('.char-crop-panel')) p.remove();
  const box = document.createElement('div');
  box.className = 'char-crop-panel';
  box.dataset.name = name;

  const icons = charIconList(name);
  let shown = charMainIcon(name) || icons[0] || '';
  let v = charAvatarValue(name);

  const prev = document.createElement('div');
  prev.className = 'crop-prev';
  prev.title = '휠: 확대 · 끌기: 위치';
  const img = document.createElement('img');
  img.alt = '';
  img.src = shown;
  prev.appendChild(img);
  if (!shown) prev.classList.add('empty');

  // 표정 목록 — 같은 확대 · 위치로 다른 표정도 확인
  const faces = document.createElement('div');
  faces.className = 'crop-faces';
  for (const u of icons) {
    const f = document.createElement('button');
    f.type = 'button';
    f.className = 'crop-face' + (u === shown ? ' on' : '');
    f.title = '이 표정으로 확인하기';
    const fi = document.createElement('img');
    fi.alt = '';
    fi.src = u;
    f.appendChild(fi);
    f.addEventListener('click', () => {
      shown = u;
      img.src = u;
      for (const x of faces.children) x.classList.toggle('on', x === f);
      paint();
    });
    faces.appendChild(f);
  }

  const main = document.createElement('div');
  main.className = 'crop-main';
  main.append(prev, faces);

  const ctrls = document.createElement('div');
  ctrls.className = 'crop-ctrls';
  const rows = {};
  const mkRow = (key, label, min, max) => {
    const lab = document.createElement('label');
    lab.className = 'crop-row';
    const t = document.createElement('span');
    t.className = 'crop-lab';
    t.textContent = label;
    const rng = document.createElement('input');
    rng.type = 'range';
    rng.min = String(min);
    rng.max = String(max);
    rng.step = '1';
    rng.className = 'crop-range';
    const out = document.createElement('output');
    out.className = 'crop-out';
    rng.addEventListener('input', () => {
      v[key] = Number(rng.value);
      paint();
    });
    lab.append(t, rng, out);
    ctrls.appendChild(lab);
    rows[key] = { rng, out };
  };
  mkRow('zoom', '확대', 100, 400);
  mkRow('x', '가로', 0, 100);
  mkRow('y', '세로', 0, 100);

  // 이 캐릭터만의 보정 (전체 기본값을 덮어쓴다) — 효과 미리보기 + 세기 · 밝기 · 대비 · 채도
  const fxRow = document.createElement('div');
  fxRow.className = 'crop-fx';
  buildFxUi(fxRow, {
    get: () => v.fx,
    set: (patch) => {
      v.fx = B.normFx({ ...v.fx, ...patch }, v.fx);
      paint();
    },
    sample: () => shown,
  });

  const btns = document.createElement('div');
  btns.className = 'crop-btns';
  const applyBtn = document.createElement('button');
  applyBtn.type = 'button';
  applyBtn.className = 'st-btn st-mini';
  applyBtn.textContent = '적용';
  applyBtn.title = '이 캐릭터의 모든 표정에 지금 확대 · 위치를 적용합니다';
  applyBtn.addEventListener('click', () => commit());
  const resetBtn = document.createElement('button');
  resetBtn.type = 'button';
  resetBtn.className = 'st-btn ghost st-mini';
  resetBtn.textContent = '기본값으로';
  resetBtn.addEventListener('click', () => {
    clearCharAvatar(name);
    v = { ...AVATAR_DEF, fx: fxDefault() };
    btn.classList.remove('on');
    paint();
    queueRender();
  });
  const closeBtn = document.createElement('button');
  closeBtn.type = 'button';
  closeBtn.className = 'st-btn ghost st-mini';
  closeBtn.textContent = '닫기';
  closeBtn.addEventListener('click', () => box.remove());
  btns.append(applyBtn, resetBtn, closeBtn);

  const help = document.createElement('div');
  help.className = 'st-desc';
  help.textContent = '미리보기를 끌어 옮기고 휠로 확대한 뒤 [적용]을 누르면 그 캐릭터의 모든 표정에 반영됩니다.';

  box.append(main, ctrls, fxRow, btns, help);
  row.after(box);

  // 이 칸의 미리보기 · 슬라이더만 갱신 (로그 미리보기는 건드리지 않는다)
  function paint() {
    v.zoom = Math.max(100, Math.min(400, Math.round(v.zoom)));
    v.x = Math.max(0, Math.min(100, Math.round(v.x)));
    v.y = Math.max(0, Math.min(100, Math.round(v.y)));
    for (const [k, r] of Object.entries(rows)) {
      r.rng.value = String(v[k]);
      r.out.textContent = v[k] + '%';
    }
    paintFxUi(fxRow);
    // 저장 파일과 같은 계산 (보정까지 그대로)
    ensureFxDefs([v.fx]);
    img.setAttribute('style', B.avatarStyle({ charAvatar: { [name]: v } }, { name }));
    const now = charAvatarValue(name);
    const same =
      hasCharAvatar(name) &&
      ['zoom', 'x', 'y'].every((k) => now[k] === v[k]) &&
      Object.keys(B.FX_RANGE).concat('look').every((k) => now.fx[k] === v.fx[k]);
    applyBtn.disabled = !!same;
    applyBtn.textContent = same ? '적용됨' : '적용';
  }
  function commit() {
    setCharAvatar(name, v);
    btn.classList.add('on');
    paint();
    queueRender();
  }
  paint();

  prev.addEventListener(
    'wheel',
    (e) => {
      e.preventDefault();
      v.zoom += -Math.sign(e.deltaY) * 8;
      paint();
    },
    { passive: false }
  );
  // 끄는 만큼만 움직이게 — 마우스가 움직인 픽셀을 '칸 밖으로 나간 그림 길이'로 나눠 %로 바꾼다.
  // (칸 너비로 나누면 조금만 끌어도 휙 움직인다. 확대를 많이 할수록 더 촘촘하게 움직인다)
  function dragRange() {
    const bw = prev.clientWidth || 96;
    const bh = prev.clientHeight || 96;
    const nw = img.naturalWidth || bw;
    const nh = img.naturalHeight || bh;
    const base = Math.max(bw / nw, bh / nh) * (Math.max(100, v.zoom) / 100);
    // 그림이 칸보다 큰 만큼이 움직일 수 있는 거리다 (거의 같으면 칸 크기로)
    return {
      x: Math.max(24, nw * base - bw),
      y: Math.max(24, nh * base - bh),
    };
  }
  let drag = null;
  prev.addEventListener('pointerdown', (e) => {
    drag = { x: e.clientX, y: e.clientY, px: v.x, py: v.y, r: dragRange() };
    prev.setPointerCapture(e.pointerId);
  });
  prev.addEventListener('pointermove', (e) => {
    if (!drag) return;
    // 그림을 잡아끄는 방향으로 움직이게
    v.x = drag.px - ((e.clientX - drag.x) / drag.r.x) * 100;
    v.y = drag.py - ((e.clientY - drag.y) / drag.r.y) * 100;
    paint();
  });
  const endDrag = () => (drag = null);
  prev.addEventListener('pointerup', endDrag);
  prev.addEventListener('pointercancel', endDrag);
}

// 그 캐릭터가 지금 쓰는 인장 (가장 많이 쓰인 것)
function charMainIcon(name) {
  const cnt = new Map();
  for (const m of data.messages) {
    if (m.divider || m.sys || m.name !== name || !m.imgUrl) continue;
    cnt.set(m.imgUrl, (cnt.get(m.imgUrl) || 0) + 1);
  }
  let best = '';
  let bestN = 0;
  for (const [u, n] of cnt) if (n > bestN) [best, bestN] = [u, n];
  return best;
}

// 인장 고르기 — 클릭: 내 PC 파일, Shift+클릭: 주소 입력
let iconTargetChar = '';
async function pickIcon(ev, onPicked) {
  if (ev.shiftKey || ev.type === 'contextmenu') {
    let url = null;
    try {
      url = prompt('인장으로 쓸 이미지 주소 (비우면 인장 지우기)', '');
    } catch (_) {
      $('srcInfo').textContent = '이 화면에서는 주소 입력창을 열 수 없습니다 — [이미지 보강]의 URL 칸을 써 주세요.';
      return;
    }
    if (url === null) return;
    const u = url.trim();
    if (u && !/^(https?:|data:)/i.test(u)) {
      $('srcInfo').textContent = 'http(s) 주소나 data URL 만 넣을 수 있습니다.';
      return;
    }
    onPicked(u);
    return;
  }
  iconPickedCb = onPicked;
  $('charIconInput').click();
}

let iconPickedCb = null;
$('charIconInput').addEventListener('change', async () => {
  const file = $('charIconInput').files[0];
  $('charIconInput').value = '';
  const cb = iconPickedCb;
  iconPickedCb = null;
  if (!file || !cb) return;
  try {
    cb(await fileToDataUrl(file, 256, 'image/webp', 0.85));
  } catch (e) {
    $('srcInfo').textContent = '이미지를 읽지 못했습니다: ' + e.message;
  }
});

// 대사 편집기의 인장 단추
const onMeIcon = (ev) => {
  ev.preventDefault();
  pickIcon(ev, (url) => {
    editingIcon = url;
    paintMeIcon();
  });
};
$('meIcon').addEventListener('click', onMeIcon);
$('meIcon').addEventListener('contextmenu', onMeIcon); // 우클릭 = 주소 입력

function renderCharRows() {
  const box = $('charRows');
  box.innerHTML = '';
  const counts = new Map();
  for (const m of data.messages) {
    if (m.divider || m.sys) continue; // 시스템 메시지는 캐릭터가 아니다
    counts.set(m.name, (counts.get(m.name) || 0) + 1);
  }
  if (!counts.size) {
    box.appendChild(Object.assign(document.createElement('div'), { className: 'st-desc', textContent: '캐릭터가 없습니다.' }));
    return;
  }
  const sorted = [...counts.entries()].sort((a, b) => b[1] - a[1]);
  for (const [name, cnt] of sorted) {
    const row = document.createElement('div');
    row.className = 'char-row';
    const inp = document.createElement('input');
    inp.type = 'text';
    inp.className = 'tname-input';
    inp.value = name;
    inp.title = '이름 수정 (이 캐릭터의 모든 메시지에 적용)';
    inp.addEventListener('change', () => {
      const newName = inp.value.trim();
      if (!newName || newName === name) {
        inp.value = name;
        return;
      }
      pushUndo('이름 바꾸기');
      for (const m of data.messages) {
        if (!m.divider && m.name === name) m.name = newName;
      }
      // 인장 확대 · 위치도 새 이름으로 옮긴다
      if (s.charAvatar && s.charAvatar[name] && !s.charAvatar[newName]) {
        s.charAvatar[newName] = s.charAvatar[name];
        delete s.charAvatar[name];
        saveLogSettings(s);
      }
      renderCharRows();
      renderImgFix();
      renderPreview();
    });
    const cntEl = document.createElement('span');
    cntEl.className = 'st-desc';
    cntEl.textContent = `${cnt}개`;

    // 인장 일괄 변경
    const icon = charMainIcon(name);
    const icBtn = document.createElement('button');
    icBtn.type = 'button';
    icBtn.className = 'char-ic' + (icon ? ' has-img' : '');
    icBtn.title = '인장 일괄 변경 — 클릭: 파일 고르기 · 우클릭(또는 Shift+클릭): 주소 입력 (빈 주소로 지우기)';
    icBtn.innerHTML = typeof faIcon === 'function' ? faIcon('avatar') : '';
    if (icon) icBtn.style.backgroundImage = `url("${icon.replace(/"/g, '%22')}")`;
    const onIcon = (ev) => {
      ev.preventDefault();
      pickIcon(ev, (url) => applyIconToChar(name, url));
    };
    icBtn.addEventListener('click', onIcon);
    icBtn.addEventListener('contextmenu', onIcon); // 우클릭 = 주소 입력

    // 인장 확대 · 위치 — 이 캐릭터의 모든 표정에 같이 적용
    const cropBtn = document.createElement('button');
    cropBtn.type = 'button';
    cropBtn.className = 'char-crop' + (hasCharAvatar(name) ? ' on' : '');
    cropBtn.textContent = '⤢';
    cropBtn.title = '인장 확대 · 위치 맞추기 (이 캐릭터의 모든 표정에 같이 적용)';
    cropBtn.disabled = !icon;
    cropBtn.addEventListener('click', () => openCharCrop(name, row, cropBtn));

    // 이름 색 — 쓰이고 있는 색 전부
    const colors = document.createElement('span');
    colors.className = 'char-colors';
    const list = charColorList(name);
    for (let i = 0; i < list.length; i++) {
      const { color, count } = list[i];
      const chip = document.createElement('span');
      chip.className = 'cchip';
      if (color === NO_COLOR) {
        const none = document.createElement('span');
        none.className = 'cnone';
        none.title = `색 없음 (${count}개) — ✕ 로 다음 색에 합치기`;
        chip.appendChild(none);
      } else {
        const pick = document.createElement('input');
        pick.type = 'color';
        pick.className = 'circle';
        pick.value = color;
        pick.title = `${color} (${count}개) — 바꾸면 이 색을 쓰던 대사에 모두 적용`;
        pick.addEventListener('change', () => {
          pushUndo('이름 색');
          for (const m of data.messages) {
            if (m.divider || m.sys || m.name !== name) continue;
            if (isColorOf(m, color)) m.color = pick.value;
          }
          renderCharRows();
          renderPreview();
        });
        chip.appendChild(pick);
      }
      if (list.length > 1) {
        const x = document.createElement('button');
        x.type = 'button';
        x.className = 'cx';
        x.textContent = '✕';
        const next = list[i + 1] || list[i - 1];
        x.title = `이 색 지우기 — ${next.color === NO_COLOR ? '색 없음' : next.color} 으로 합칩니다`;
        x.addEventListener('click', () => mergeCharColor(name, list, i));
        chip.appendChild(x);
      }
      colors.appendChild(chip);
    }

    row.append(inp, cntEl, icBtn, cropBtn, colors);
    box.appendChild(row);
  }
}
