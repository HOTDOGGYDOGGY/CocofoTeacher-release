// 코코포리아 선생님 — 자동 업데이트
//
// 크롬 확장은 자기 폴더에 파일을 쓸 수 없다. 그래서 사용자가 파일 시스템 접근 권한으로
// "설치 폴더"를 한 번 지정해 주면, 그 뒤로는 이 화면에서
//   새 버전 zip 내려받기 → 그 자리에서 풀기 → 폴더에 덮어쓰기 → chrome.runtime.reload()
// 까지 버튼 한 번으로 끝낸다. (폴더 핸들은 IndexedDB 에 담아 다음에도 쓴다)
//
// 채널은 폴더의 에디션을 따른다 — 섞이지 않게.
//   public   : 공개 배포본 → 릴리즈 저장소의 version.json + zip
//   personal : 개인용 → 비공개 소스 저장소를 GitHub API 로 (팝업 설정에 저장한 토큰 사용).
//              zip 대신 파일 목록(git tree)을 받아 바뀐 파일만 내려받는다 (codeload 는 CORS 가 막혀 있다)
//   dev      : 배포용 개발 → 로컬 빌드(node build-dist.js)라 여기서 건드리지 않는다

const UPDATE_INFO_URL = 'https://raw.githubusercontent.com/HOTDOGGYDOGGY/CocofoTeacher-release/main/version.json';
const THEMES = ['dark', 'light', 'mono', 'retro'];
// 개인용 소스 저장소 (개인용 edition.js 에만 있다 — 배포본에는 없다)
const PERSONAL_REPO = window.CST_SOURCE_REPO || '';
const SRC_API = PERSONAL_REPO
  ? PERSONAL_REPO.replace(/^https:\/\/github\.com\//, 'https://api.github.com/repos/').replace(/\/$/, '')
  : '';
// 개인용은 저장소 전체가 아니라 확장이 쓰는 것만 받는다 (dist·backup·문서·빌드 스크립트 제외)
const SYNC_ROOTS = [
  'manifest.json',
  'background.js',
  'content/',
  'lib/',
  'popup/',
  'studio/',
  'manager/',
  'update/',
  'chargen/',
  'icons/',
  'fonts/',
  'sounds/',
];

const $ = (id) => document.getElementById(id);
const getSync = (defs) => new Promise((r) => chrome.storage.sync.get(defs, (d) => r(chrome.runtime.lastError ? defs : d)));
const setLocal = (o) => new Promise((r) => chrome.storage.local.set(o, () => r(!chrome.runtime.lastError)));

let latest = null; // version.json 의 dist 정보
let dirHandle = null;
let edVer = ''; // 지금 확장이 내세우는 버전 (미리보기면 그 에디션의 버전)
let folderInfo = null; // 지정한 폴더의 { name, version } — 버전 비교의 기준

// ---------- 화면 ----------
function normalizeHex(v) {
  const s = String(v || '').trim();
  return /^#[0-9a-fA-F]{6}$/.test(s) ? s : '';
}

async function applyTheme() {
  const s = await getSync({ theme: 'dark', accentColor: '' });
  const theme = THEMES.includes(s.theme) ? s.theme : 'dark';
  for (const t of THEMES) document.body.classList.toggle('theme-' + t, theme === t && t !== 'dark');
  const a = normalizeHex(s.accentColor);
  if (a) document.body.style.setProperty('--accent', a);
}

let logLines = [];
function log(text, cls) {
  logLines.push(cls ? `<span class="${cls}">${text}</span>` : text);
  $('log').innerHTML = logLines.join('<br>');
}
function logClear() {
  logLines = [];
  $('log').innerHTML = '';
}

// ---------- 버전 ----------
function verCmp(a, b) {
  const pa = String(a || '').split('.').map((n) => parseInt(n, 10) || 0);
  const pb = String(b || '').split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

// ---------- 지금 이 확장의 에디션 ----------
// 개인용에서 '에디션 보기'로 배포용/배포용 개발을 미리 볼 수 있다 (lib/edition.js).
// 그때는 팝업과 마찬가지로 그 에디션의 이름·버전으로 보여야 한다 —
// 개인용 manifest 버전(13.x)을 배포본 버전(1.x)과 비교하면 말이 안 된다.
const ED_LABEL = { personal: '개인용', dev: '배포용 개발', public: '배포본' };
let distVersions = null; // lib/versions.json (개인용에만 있다)

// 개발판은 공개판보다 앞서 있는 로컬 빌드라, 공개판과 버전을 비교해 봐야 의미가 없다.
// (공개판이 아직 커밋 전이면 개발판이 더 높고, 배포 뒤에는 개발판이 낮아진다)
// 그래서 개발판은 자기 채널 없이 "여기서 갱신하지 않는다"고만 알려 준다.
function runningEdition() {
  if (window.CST_PREVIEW) return window.CST_PREVIEW_KIND === 'distdev' ? 'dev' : 'public';
  if (!window.CST_LITE) return 'personal';
  return /배포용 개발/.test(chrome.runtime.getManifest().name || '') ? 'dev' : 'public';
}

async function loadDistVersions() {
  if (distVersions) return distVersions;
  try {
    const res = await fetch(chrome.runtime.getURL('lib/versions.json'));
    const j = await res.json();
    if (j && j.dist) distVersions = j;
  } catch (_) {}
  return distVersions;
}

// 지금 확장이 스스로 내세우는 버전 (미리보기면 그 에디션의 버전)
async function editionVersion() {
  const mv = chrome.runtime.getManifest().version;
  if (!window.CST_PREVIEW) return mv;
  const v = await loadDistVersions();
  if (!v) return mv;
  return (window.CST_PREVIEW_KIND === 'dist' ? v.dist : v.distDev) || mv;
}

// 지금 어느 채널로 볼 것인가 — 폴더를 지정했으면 그 폴더의 에디션, 아니면 지금 에디션
function currentChannel() {
  if (folderInfo && folderInfo.channel) return folderInfo.channel;
  return runningEdition();
}


const getSrcCfg = () =>
  new Promise((r) =>
    chrome.storage.local.get({ srcRepoToken: '', srcRepoBranch: 'main' }, (d) =>
      r({ token: String((d && d.srcRepoToken) || '').trim(), branch: String((d && d.srcRepoBranch) || 'main').trim() || 'main' })
    )
  );

function ghHeaders(token, accept) {
  const h = { Accept: accept || 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28' };
  if (token) h.Authorization = 'Bearer ' + token;
  return h;
}

// 개인용 최신 = 소스 저장소 브랜치의 manifest.json 버전
async function fetchPersonalLatest() {
  const cfg = await getSrcCfg();
  if (!cfg.token) throw new Error('소스 저장소 토큰이 없습니다 (팝업 설정 → 업데이트 → 소스 저장소 확인)');
  const res = await fetch(`${SRC_API}/contents/manifest.json?ref=${encodeURIComponent(cfg.branch)}`, {
    headers: ghHeaders(cfg.token, 'application/vnd.github.raw+json'),
    cache: 'no-store',
  });
  if (!res.ok) throw new Error('소스 저장소를 읽지 못했습니다 (HTTP ' + res.status + ')');
  const man = await res.json();
  if (!man || !man.version) throw new Error('소스 저장소 manifest 에 버전이 없습니다');
  return { version: man.version, branch: cfg.branch, personal: true };
}

async function loadLatest() {
  $('verLine').textContent = '확인 중…';
  $('notes').classList.add('hidden');
  if (!edVer) edVer = await editionVersion();
  const ch = currentChannel();
  const base = (folderInfo && folderInfo.version) || edVer;
  const where = folderInfo ? '설치' : '지금 확장';
  // 배포용 개발은 로컬 빌드다 — 원격 채널 대신 '내 폴더에 새로 빌드된 것이 있는가' 를 본다
  if (ch === 'dev') {
    latest = null;
    let disk = '';
    try {
      const res = await fetch(chrome.runtime.getURL('manifest.json') + '?t=' + Date.now(), { cache: 'no-store' });
      disk = String(((await res.json()) || {}).version || '');
    } catch (_) {}
    const newer = disk && verCmp(disk, base) > 0;
    $('verLine').innerHTML = newer
      ? `${where} v${base} (배포용 개발) → <b>새 빌드 v${disk}</b> 가 폴더에 있습니다 — [확장 새로고침]`
      : `${where} <b>v${base}</b> (배포용 개발) · 최신 빌드입니다 (<code>node build-dist.js</code> 로 갱신)`;
    $('reloadBtn').classList.toggle('hidden', !newer);
    refreshGo();
    return;
  }
  const what = ch === 'personal' ? '소스 저장소' : '배포본';
  try {
    if (ch === 'personal') {
      latest = await fetchPersonalLatest();
    } else {
      const res = await fetch(UPDATE_INFO_URL, { cache: 'no-store' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const j = await res.json();
      latest = j && j.dist ? { ...j.dist, changelog: j.changelog || [] } : null;
      if (!latest) throw new Error('version.json 을 읽지 못했습니다');
    }
  } catch (e) {
    latest = null;
    $('verLine').innerHTML = `${where} <b>v${base}</b> · ${what} 최신 버전을 확인하지 못했습니다 (${e.message})`;
    refreshGo();
    return;
  }
  const newer = verCmp(latest.version, base) > 0;
  $('verLine').innerHTML = newer
    ? `${where} v${base} → ${what} 새 버전 <b>v${latest.version}</b>${latest.branch ? ` (${latest.branch})` : ''}`
    : `${where} <b>v${base}</b> · 최신입니다 (${what} v${latest.version})`;
  if (!folderInfo) $('verLine').innerHTML += ' — 폴더를 지정하면 그 폴더 기준으로 다시 봅니다.';
  const entry = (latest.changelog || []).find((c) => c.v === latest.version) || {};
  // groups [{title, items}] 가 있으면 제목 줄을 끼워 묶어 보여 준다
  const sections =
    Array.isArray(entry.groups) && entry.groups.length
      ? entry.groups.map((g) => ({ title: String((g && g.title) || ''), items: (g && g.items) || [] }))
      : [{ title: '', items: entry.items || [] }];
  const ul = $('notes');
  ul.innerHTML = '';
  if (newer && sections.some((s) => s.items.length)) {
    for (const sec of sections) {
      if (!sec.items.length) continue;
      if (sec.title) {
        const t = document.createElement('li');
        t.className = 'upd-notes-group';
        t.textContent = sec.title;
        ul.appendChild(t);
      }
      for (const it of sec.items) {
        const li = document.createElement('li');
        li.textContent = it;
        ul.appendChild(li);
      }
    }
    ul.classList.remove('hidden');
  } else {
    ul.classList.add('hidden');
  }
  refreshGo();
}

// ---------- 설치 폴더 (IndexedDB 에 핸들 보관) ----------
function idb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open('cst-update', 1);
    req.onupgradeneeded = () => req.result.createObjectStore('handles');
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function idbGet(key) {
  const db = await idb();
  return new Promise((resolve) => {
    const tx = db.transaction('handles', 'readonly').objectStore('handles').get(key);
    tx.onsuccess = () => resolve(tx.result || null);
    tx.onerror = () => resolve(null);
  });
}

async function idbPut(key, val) {
  const db = await idb();
  return new Promise((resolve) => {
    const tx = db.transaction('handles', 'readwrite').objectStore('handles').put(val, key);
    tx.onsuccess = () => resolve(true);
    tx.onerror = () => resolve(false);
  });
}

// 고른 폴더가 어느 에디션의 설치 폴더인지 본다. 채널(받아올 곳)은 여기서 정해진다.
//   public   : manifest name 이 정확히 '코코포리아 선생님' → 릴리즈 zip
//   personal : '(개인용)' → 비공개 소스 저장소 (토큰 필요)
//   dev      : '(배포용 개발)' → 여기서 갱신하지 않는다 (node build-dist.js)
// 반환: { ok, name, version, channel } 또는 { ok:false, why }
const PUBLIC_NAME = '코코포리아 선생님';

function channelOf(name) {
  const n = String(name || '').trim();
  if (/개인용/.test(n)) return 'personal';
  if (/배포용 개발/.test(n)) return 'dev';
  return n === PUBLIC_NAME ? 'public' : '';
}

async function hasEntry(dir, name, kind) {
  try {
    if (kind === 'dir') await dir.getDirectoryHandle(name);
    else await dir.getFileHandle(name);
    return true;
  } catch (_) {
    return false;
  }
}

async function inspectFolder(dir) {
  let manifest = null;
  try {
    const fh = await dir.getFileHandle('manifest.json');
    manifest = JSON.parse(await (await fh.getFile()).text());
  } catch (_) {
    return { ok: false, why: '이 폴더에는 manifest.json 이 없습니다. 크롬에 로드한 확장 폴더를 골라 주세요.' };
  }
  const name = String(manifest.name || '');
  const channel = channelOf(name);
  if (!/코코포리아 선생님/.test(name) || !channel) {
    return { ok: false, why: `이 확장의 설치 폴더가 아닙니다 (${name || '이름 없음'}).` };
  }
  if (channel === 'dev') {
    return { ok: false, why: '배포용 개발 폴더입니다. 개발판은 node build-dist.js 로 갱신하세요 (공개 배포본으로 덮으면 개발판이 사라집니다).' };
  }
  if (channel === 'personal' && !SRC_API) {
    return { ok: false, why: '개인용 폴더는 개인용 확장에서 열어 주세요 (배포본에는 소스 저장소 주소가 없습니다).' };
  }
  // 공개 배포본 폴더에 빌드 스크립트가 있으면 소스 폴더를 잘못 고른 것
  if (channel === 'public' && (await hasEntry(dir, 'build-dist.js'))) {
    return { ok: false, why: '소스 저장소 폴더로 보입니다. 크롬에 로드한 배포본 폴더를 골라 주세요.' };
  }
  return { ok: true, name, version: manifest.version, channel };
}

function showFolder(info) {
  if (!info) {
    $('folderLine').textContent = '아직 지정하지 않았습니다.';
    $('forgetBtn').classList.add('hidden');
    return;
  }
  $('folderLine').textContent = `${info.dirName} · ${info.name} v${info.version}`;
  $('forgetBtn').classList.remove('hidden');
}

async function loadSavedFolder() {
  const h = await idbGet('extDir');
  if (!h) return showFolder(null);
  dirHandle = h;
  // 권한은 브라우저를 다시 켜면 'prompt' 로 돌아간다 — 업데이트를 누를 때 다시 묻는다
  let name = '';
  let version = '';
  try {
    const perm = await h.queryPermission({ mode: 'readwrite' });
    if (perm === 'granted') {
      const got = await inspectFolder(h);
      name = got.name || '';
      version = got.version || '';
      folderInfo = got.ok ? { name, version, channel: got.channel } : null;
    }
  } catch (_) {}
  showFolder({ dirName: h.name, name: name || '(허가 필요)', version: version || '?' });
  refreshGo();
}

function refreshGo() {
  // 비교 기준은 "덮어쓸 폴더"의 버전. 폴더를 아직 안 골랐으면 지금 에디션의 버전.
  const ch = currentChannel();
  const base = (folderInfo && folderInfo.version) || edVer;
  const newer = !!latest && verCmp(latest.version, base) > 0;
  // 받아올 곳이 준비돼 있는가 — 공개는 zip 주소, 개인용은 소스 저장소 주소, 개발판은 없음
  const source = ch === 'dev' ? false : ch === 'personal' ? !!SRC_API : !!(latest && latest.zip);
  // 새 버전일 때만 덮어쓴다 — 안 그러면 개발판(1.1.32)을 공개판(1.1)으로 되돌리는 사고가 난다
  $('goBtn').disabled = !(dirHandle && latest && source && newer);
  $('goBtn').textContent = newer
    ? `v${base} → v${latest.version} 로 업데이트`
    : ch === 'dev'
      ? '개발판은 여기서 갱신하지 않습니다'
      : latest
        ? `받을 새 버전이 없습니다 (${folderInfo ? '설치' : '지금'} v${base} · 최신 v${latest.version})`
        : '최신 버전을 확인하지 못했습니다';
}

// ---------- 덮어쓰기 ----------
async function ensurePermission(dir) {
  if ((await dir.queryPermission({ mode: 'readwrite' })) === 'granted') return true;
  return (await dir.requestPermission({ mode: 'readwrite' })) === 'granted';
}

// zip 안 경로대로 폴더를 만들어 가며 쓴다
async function writeEntry(dir, path, bytes) {
  const parts = path.split('/').filter((p) => p && p !== '.' && p !== '..');
  const fileName = parts.pop();
  let cur = dir;
  for (const p of parts) cur = await cur.getDirectoryHandle(p, { create: true });
  const fh = await cur.getFileHandle(fileName, { create: true });
  const w = await fh.createWritable();
  await w.write(bytes);
  await w.close();
}

// ---------- 공개 배포본: zip 하나를 풀어 통째로 덮어쓴다 ----------
async function applyPublicZip(before) {
  log('새 버전 내려받는 중…');
  const res = await fetch(latest.zip, { cache: 'no-store' });
  if (!res.ok) throw new Error('내려받기 실패 (HTTP ' + res.status + ')');
  const buf = await res.arrayBuffer();
  log(`받음 — ${Math.round(buf.byteLength / 1024).toLocaleString()}KB`);

  const entries = await window.CSTUnzip.unzip(buf);
  const mf = entries.find((e) => e.name === 'manifest.json');
  if (!mf) throw new Error('zip 안에 manifest.json 이 없습니다');
  const newManifest = JSON.parse(new TextDecoder('utf-8').decode(mf.bytes));
  checkSwap(before, newManifest);
  log(`풀었습니다 — 파일 ${entries.length}개 · ${newManifest.name} v${newManifest.version}`);

  let done = 0;
  for (const e of entries) {
    await writeEntry(dirHandle, e.name, e.bytes);
    done++;
    if (done % 10 === 0 || done === entries.length) log(`덮어쓰는 중… ${done}/${entries.length}`);
  }
  dropProgressLines();
  log(`<b>덮어쓰기 완료 — 파일 ${entries.length}개</b>`);
  return newManifest.version;
}

// ---------- 개인용: 소스 저장소에서 바뀐 파일만 ----------
// zip(codeload)은 브라우저에서 CORS 로 막히므로 git tree + blob API 를 쓴다.
// 파일마다 git 이 쓰는 sha1 을 직접 계산해 같은 것은 건너뛴다 (대부분은 몇 개만 바뀐다).
async function gitBlobSha(bytes) {
  const head = new TextEncoder().encode(`blob ${bytes.length}\0`);
  const all = new Uint8Array(head.length + bytes.length);
  all.set(head, 0);
  all.set(bytes, head.length);
  const digest = await crypto.subtle.digest('SHA-1', all);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function readLocal(dir, path) {
  const parts = path.split('/');
  const fileName = parts.pop();
  let cur = dir;
  try {
    for (const p of parts) cur = await cur.getDirectoryHandle(p);
    const fh = await cur.getFileHandle(fileName);
    return new Uint8Array(await (await fh.getFile()).arrayBuffer());
  } catch (_) {
    return null;
  }
}

async function applyPersonalRepo(before) {
  const cfg = await getSrcCfg();
  if (!cfg.token) throw new Error('소스 저장소 토큰이 없습니다 (팝업 설정 → 업데이트 → 소스 저장소 확인)');
  if (await hasEntry(dirHandle, '.git', 'dir')) {
    const go = confirm(
      'git 작업 폴더입니다.\n\n' +
        '커밋하지 않은 변경은 저장소 내용으로 덮어써집니다.\n' +
        '계속할까요? (평소에는 git pull 을 쓰는 편이 안전합니다)'
    );
    if (!go) throw new Error('취소했습니다');
  }
  log(`소스 저장소 파일 목록 읽는 중… (${cfg.branch})`);
  const res = await fetch(`${SRC_API}/git/trees/${encodeURIComponent(cfg.branch)}?recursive=1`, {
    headers: ghHeaders(cfg.token),
    cache: 'no-store',
  });
  if (!res.ok) throw new Error('파일 목록을 읽지 못했습니다 (HTTP ' + res.status + ')');
  const tree = await res.json();
  if (tree.truncated) log('저장소가 커서 목록이 잘렸습니다 — 일부 파일이 빠질 수 있습니다.', 'upd-warn');
  const wanted = (tree.tree || []).filter(
    (n) => n.type === 'blob' && SYNC_ROOTS.some((r) => (r.endsWith('/') ? n.path.startsWith(r) : n.path === r))
  );
  if (!wanted.length) throw new Error('받을 파일을 찾지 못했습니다');

  // 새 manifest 를 먼저 확인해 에디션·버전을 검사한다 (덮어쓰기 전에)
  const mfNode = wanted.find((n) => n.path === 'manifest.json');
  if (!mfNode) throw new Error('저장소에 manifest.json 이 없습니다');
  const mfBytes = await fetchBlob(mfNode.sha, cfg.token);
  const newManifest = JSON.parse(new TextDecoder('utf-8').decode(mfBytes));
  checkSwap(before, newManifest);
  log(`파일 ${wanted.length}개 확인 — ${newManifest.name} v${newManifest.version}`);

  let changed = 0;
  let same = 0;
  let done = 0;
  for (const n of wanted) {
    const local = await readLocal(dirHandle, n.path);
    if (local && (await gitBlobSha(local)) === n.sha) {
      same++;
    } else {
      const bytes = n.path === 'manifest.json' ? mfBytes : await fetchBlob(n.sha, cfg.token);
      await writeEntry(dirHandle, n.path, bytes);
      changed++;
    }
    done++;
    if (done % 10 === 0 || done === wanted.length) log(`맞추는 중… ${done}/${wanted.length} (바뀐 파일 ${changed}개)`);
  }
  dropProgressLines();
  log(`<b>업데이트 완료 — 바뀐 파일 ${changed}개 · 그대로 ${same}개</b>`);
  log('저장소에서 지워진 파일은 그대로 남습니다 (필요하면 직접 지워 주세요).', 'upd-warn');
  return newManifest.version;
}

async function fetchBlob(sha, token) {
  const r = await fetch(`${SRC_API}/git/blobs/${sha}`, {
    headers: ghHeaders(token, 'application/vnd.github.raw'),
    cache: 'no-store',
  });
  if (!r.ok) throw new Error('파일을 받지 못했습니다 (HTTP ' + r.status + ')');
  return new Uint8Array(await r.arrayBuffer());
}

// 에디션이 뒤바뀌거나 버전이 내려가는 것을 막는다
function checkSwap(before, newManifest) {
  if (String(newManifest.name || '').trim() !== String(before.name || '').trim()) {
    throw new Error(`에디션이 다릅니다 — 폴더는 "${before.name}", 받은 것은 "${newManifest.name}"`);
  }
  if (verCmp(newManifest.version, before.version) <= 0) {
    throw new Error(`설치된 v${before.version} 이 받은 v${newManifest.version} 보다 최신이거나 같습니다`);
  }
}

function dropProgressLines() {
  logLines = logLines.filter((l) => !/(덮어쓰는 중…|맞추는 중…)/.test(l));
}

async function doUpdate() {
  logClear();
  $('goBtn').disabled = true;
  try {
    if (!(await ensurePermission(dirHandle))) {
      log('폴더 사용 허가가 없어 멈췄습니다. [지금 업데이트]를 다시 눌러 허가해 주세요.', 'upd-bad');
      return;
    }
    const before = await inspectFolder(dirHandle);
    if (!before.ok) {
      log(before.why, 'upd-bad');
      return;
    }
    log(`설치 폴더 확인 — ${before.name} v${before.version}`);
    const version =
      before.channel === 'personal' ? await applyPersonalRepo(before) : await applyPublicZip(before);
    folderInfo = { name: before.name, version, channel: before.channel };
    showFolder({ dirName: dirHandle.name, name: before.name, version });
    await setLocal({ updSelfApplied: { version, at: Date.now() } });
    log('[확장 새로고침]을 누르면 새 버전으로 다시 시작합니다. 확장이 다시 뜨면서 이 탭은 닫힙니다.');
    $('reloadBtn').classList.remove('hidden');
  } catch (e) {
    log('실패: ' + e.message, 'upd-bad');
    log('그래도 안 되면 파일을 직접 받아 폴더에 덮어써 주세요.', 'upd-warn');
  } finally {
    refreshGo();
  }
}

// ---------- 버튼 ----------
$('recheckBtn').addEventListener('click', loadLatest);

$('pickBtn').addEventListener('click', async () => {
  if (!window.showDirectoryPicker) {
    log('이 브라우저는 폴더 지정을 지원하지 않습니다. zip 을 직접 받아 덮어써 주세요.', 'upd-bad');
    return;
  }
  let dir;
  try {
    dir = await window.showDirectoryPicker({ mode: 'readwrite', id: 'cst-ext-dir' });
  } catch (_) {
    return; // 사용자가 취소
  }
  const got = await inspectFolder(dir);
  if (!got.ok) {
    logClear();
    log(got.why, 'upd-bad');
    return;
  }
  dirHandle = dir;
  folderInfo = { name: got.name, version: got.version, channel: got.channel };
  await idbPut('extDir', dir);
  showFolder({ dirName: dir.name, name: got.name, version: got.version });
  logClear();
  log(`설치 폴더를 기억했습니다 — ${dir.name} (${got.channel === 'personal' ? '개인용' : '공개 배포본'})`);
  if (got.channel === 'personal' && (await hasEntry(dir, '.git', 'dir'))) {
    log('git 작업 폴더입니다 — 커밋하지 않은 변경은 덮어써집니다. 업데이트 전에 한 번 더 물어봅니다.', 'upd-warn');
  }
  await loadLatest(); // 채널이 바뀌었으니 최신 정보도 그 채널로 다시
});

$('forgetBtn').addEventListener('click', async () => {
  dirHandle = null;
  folderInfo = null;
  await idbPut('extDir', null);
  showFolder(null);
  refreshGo();
});

// 설치 폴더 열기 — 확장은 자기 폴더 경로를 알 수 없어 탐색기를 바로 열지 못한다.
// 대신 크롬 확장 관리 화면에서 이 확장의 세부정보를 연다. 거기 '소스' 아래 폴더 경로를 누르면 탐색기에서 열린다.
// 지정한 폴더가 지금 이 확장과 다른 에디션이면(개인용에서 배포본 폴더를 갱신하는 경우) 확장 목록을 연다.
function installedEdition() {
  if (!window.CST_LITE || window.CST_PREVIEW) return 'personal';
  return /배포용 개발/.test(chrome.runtime.getManifest().name || '') ? 'dev' : 'public';
}
$('openDirBtn').addEventListener('click', () => {
  const self = !folderInfo || folderInfo.channel === installedEdition();
  chrome.tabs.create({ url: self ? `chrome://extensions/?id=${chrome.runtime.id}` : 'chrome://extensions/' });
  logClear();
  log(
    self
      ? '확장 관리 화면에서 소스 아래 폴더 경로를 누르면 탐색기에서 설치 폴더가 열립니다.'
      : `지정한 폴더는 다른 확장(${folderInfo.name})입니다. 확장 관리 화면에서 그 확장의 [세부정보] → 소스 아래 폴더 경로를 누르세요.`
  );
});

$('goBtn').addEventListener('click', doUpdate);
$('reloadBtn').addEventListener('click', () => chrome.runtime.reload());

(async () => {
  await applyTheme();
  edVer = await editionVersion();
  // 방금 자기 자신을 덮어쓰고 다시 시작한 경우 결과를 알려 준다
  chrome.storage.local.get({ updSelfApplied: null }, (d) => {
    const a = d && d.updSelfApplied;
    if (a && a.version === edVer) {
      log(`<b>v${a.version} 로 업데이트되었습니다.</b>`);
      chrome.storage.local.set({ updSelfApplied: null });
    }
  });
  await loadSavedFolder();
  await loadLatest();
})();
