const $ = (id) => document.getElementById(id);

const input = $('input');
const clearBtn = $('clearBtn');
const charCount = $('charCount');
const checkBtn = $('checkBtn');
const spinner = $('spinner');
const btnLabel = checkBtn.querySelector('.btn-label');
const result = $('result');
const resultCount = $('resultCount');
const errorList = $('errorList');
const copyBtn = $('copyBtn');
const tip = $('tip');
const liveToggle = $('liveToggle');
const mainView = $('mainView');
const settingsView = $('settingsView');
const settingsBtn = $('settingsBtn');
const footNote = $('footNote');

const DEFAULTS = {
  engine: 'daum',
  liveCheck: false,
  debounceMs: 1500,
  contextMenu: true,
  excluded: '',
  userDict: [],
  userDictOn: true,
  ignoreWords: [], // 검사 제외 단어 — 이 단어들의 오류는 아예 안 잡는다
  ignoreGroupDefault: true, // '묶어서' 를 기본으로 켜 둘지 (한 번 정하면 계속 그 방식)
  liveEngine: '', // 실시간 검사 전용 엔진 ('' = 위 검사 엔진과 동일)
  autoCopy: false,
  underlineOn: true,
  underlineColor: '#e5484d',
  underlineStyle: 'wavy',
};

const ENGINE_LABEL = {
  daum: '다음',
  naver: '네이버',
  saramin: '사람인',
  incruit: '인크루트',
  compare: '비교',
};

let checking = false;
let lastCorrections = [];
let autoCopyOn = false;

// 미리보기(비확장 환경)에서도 레이아웃 확인이 가능하도록 가드
const EXT = typeof chrome !== 'undefined' && chrome.storage && chrome.runtime;

// 스킨 부팅: storage 왕복(비동기)을 기다리면 라이트·레트로 사용자는 팝업이 매번
// 다크로 번쩍였다가 바뀐다(FOUC). 지난번 스킨을 localStorage에 미러해 두고
// 스크립트 파싱 시점(첫 페인트 전)에 동기로 입힌다. 정본은 여전히 storage.sync.
try {
  const boot = JSON.parse(localStorage.getItem('cstSkinBoot') || 'null');
  if (boot) {
    if (['light', 'mono', 'retro'].includes(boot.theme)) document.body.classList.add('theme-' + boot.theme);
    if (boot.design === 'rail') document.body.classList.add('design-rail');
    if (/^#[0-9a-f]{6}$/i.test(boot.accent || '')) document.body.style.setProperty('--accent', boot.accent);
  }
} catch (_) {}

// ---------- 버전 표시 ----------
// 에디션 미리보기 중이면 그 에디션의 버전으로 보여준다 (아래 loadDistVersions 이후 한 번 더 갱신)
if (EXT && chrome.runtime.getManifest) {
  $('version').textContent = 'v' + chrome.runtime.getManifest().version;
}

// Daum/Naver/개인사전 오류 유형 → 색상 카테고리
function catOf(errType) {
  if (errType === 'space') return 'space';
  if (errType === 'spell' || errType === 'space_spell') return 'spell';
  if (errType === 'doubt') return 'doubt';
  if (errType === 'user') return 'user';
  return 'stat';
}

// ---------- 입력 ----------
function updateMeta() {
  const len = input.value.length;
  charCount.textContent = `${len.toLocaleString()}자`;
  if (len > 1000) {
    charCount.innerHTML = `${len.toLocaleString()}자 <span class="split-hint">· 자동 분할 검사</span>`;
  }
}

input.addEventListener('input', updateMeta);

clearBtn.addEventListener('click', () => {
  input.value = '';
  updateMeta();
  resetResult();
  input.focus();
});

function resetResult() {
  result.innerHTML = '<span class="result-placeholder">검사 결과가 여기에 표시됩니다.</span>';
  resultCount.classList.add('hidden');
  copyBtn.classList.add('hidden');
  errorList.classList.add('hidden');
  errorList.innerHTML = '';
  mainView.classList.remove('with-list');
  lastCorrections = [];
  hideTip();
}

function showTip(message, kind) {
  tip.textContent = message;
  tip.className = `tip ${kind}`;
}

function hideTip() {
  tip.className = 'tip hidden';
}

// ---------- 검사 ----------
async function runCheck() {
  const text = input.value;
  if (!text.trim() || checking) return;

  checking = true;
  checkBtn.disabled = true;
  spinner.classList.remove('hidden');
  btnLabel.textContent = '검사 중';
  hideTip();

  let res;
  try {
    res = await chrome.runtime.sendMessage({ type: 'CHECK', text, source: 'popup' });
  } catch (_) {
    res = null;
  }

  checking = false;
  checkBtn.disabled = false;
  spinner.classList.add('hidden');
  btnLabel.textContent = '검사하기';

  if (!res || !res.ok) {
    resetResult();
    showTip((res && res.error) || '검사에 실패했습니다.', 'error');
    return;
  }

  renderResult(text, res.corrections);
  saveHistory(text, res.corrections, res.engine || 'daum');
  if (autoCopyOn) {
    doCopy('교정 결과가 자동으로 복사되었습니다 ✓');
  }
}

checkBtn.addEventListener('click', runCheck);
input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) runCheck();
});

// ---------- 교정 결과 렌더링 ----------
function renderResult(text, corrections) {
  result.innerHTML = '';
  errorList.innerHTML = '';
  errorList.classList.add('hidden');
  mainView.classList.remove('with-list');
  copyBtn.classList.remove('hidden');
  resultCount.classList.remove('hidden');
  lastCorrections = corrections;

  if (!corrections.length) {
    result.appendChild(document.createTextNode(text));
    resultCount.textContent = '오류 없음 ✓';
    resultCount.classList.add('ok');
    return;
  }

  resultCount.classList.remove('ok');
  resultCount.textContent = `오류 ${corrections.length}개 ▾`;

  // 토큰의 모든 등장 위치를 찾고, 겹치지 않게 왼쪽부터 선택
  const occs = [];
  for (const c of corrections) {
    if (!c.token || c.token === c.suggestion) continue;
    let idx = 0;
    for (;;) {
      idx = text.indexOf(c.token, idx);
      if (idx === -1) break;
      occs.push({ start: idx, end: idx + c.token.length, c });
      idx += c.token.length;
    }
  }
  occs.sort((a, b) => a.start - b.start || (b.end - b.start) - (a.end - a.start));

  let pos = 0;
  const chosen = [];
  for (const o of occs) {
    if (o.start >= pos) {
      chosen.push(o);
      pos = o.end;
    }
  }

  pos = 0;
  corrections.forEach((c, i) => (c._idx = i));
  for (const o of chosen) {
    if (o.start > pos) {
      result.appendChild(document.createTextNode(text.slice(pos, o.start)));
    }
    const span = document.createElement('span');
    span.className = `tok tok-${catOf(o.c.errType)}`;
    span.textContent = o.c.suggestion;
    span.dataset.original = o.c.token;
    span.dataset.suggestion = o.c.suggestion;
    span.dataset.idx = o.c._idx;
    span.title = `원문: ${o.c.token} (클릭하면 대치어·도움말 보기)`;
    result.appendChild(span);
    pos = o.end;
  }
  if (pos < text.length) {
    result.appendChild(document.createTextNode(text.slice(pos)));
  }

  buildErrorList(corrections);
}

// ---------- 오류 상세 목록 ----------
function buildErrorList(corrections) {
  errorList.innerHTML = '';
  for (const c of corrections) {
    const row = document.createElement('div');
    row.className = 'err-row';

    const dot = document.createElement('span');
    dot.className = `err-dot ${catOf(c.errType)}`;

    const before = document.createElement('span');
    before.className = 'err-before';
    before.textContent = c.token;

    const arrow = document.createElement('span');
    arrow.className = 'err-arrow';
    arrow.textContent = '→';

    const after = document.createElement('span');
    after.className = 'err-after';
    after.textContent = c.suggestion;

    const info = document.createElement('span');
    info.className = 'err-info';
    info.textContent = c.info ? c.info.split('\n')[0] : '';
    if (c.info) row.title = c.info;

    row.append(dot, before, arrow, after, info);
    row.addEventListener('click', () => {
      const span = flashToken(c._idx);
      if (span) openDetail(span);
    });
    errorList.appendChild(row);
  }
}

resultCount.addEventListener('click', () => {
  if (resultCount.classList.contains('ok') || !lastCorrections.length) return;
  const opened = !errorList.classList.toggle('hidden');
  mainView.classList.toggle('with-list', opened);
  resultCount.textContent = `오류 ${lastCorrections.length}개 ${opened ? '▴' : '▾'}`;
});

// 목록 클릭 → 본문에서 해당 토큰 강조
function flashToken(idx) {
  const span = result.querySelector(`.tok[data-idx="${idx}"]`);
  if (!span) return null;
  span.scrollIntoView({ behavior: 'smooth', block: 'center' });
  span.classList.add('flash');
  setTimeout(() => span.classList.remove('flash'), 1200);
  return span;
}

// ---------- 오류 단어 상세 카드 ----------
const detailOverlay = $('detailOverlay');
const detailClose = $('detailClose');
const detailDot = $('detailDot');
const detailToken = $('detailToken');
const candList = $('candList');
const candInput = $('candInput');
const candApply = $('candApply');
const detailInfo = $('detailInfo');
const detailRevert = $('detailRevert');
let detailSpan = null;

function openDetail(span) {
  const c = lastCorrections[Number(span.dataset.idx)];
  if (!c) return;
  detailSpan = span;

  detailDot.className = `err-dot ${catOf(c.errType)}`;
  detailToken.textContent = c.token;
  detailInfo.textContent = c.info || '';
  candInput.value = '';

  candList.innerHTML = '';
  const cands = c.cands && c.cands.length ? c.cands : [c.suggestion];
  const current = span.classList.contains('off') ? null : span.textContent;
  for (const cand of cands) {
    const b = document.createElement('button');
    b.className = 'cand-item' + (cand === current ? ' selected' : '');
    b.textContent = cand;
    b.addEventListener('click', () => applyCand(cand));
    candList.appendChild(b);
  }

  updateDetailIgnoreHint();
  detailOverlay.classList.remove('hidden');
}

function closeDetail() {
  detailOverlay.classList.add('hidden');
  detailSpan = null;
}

function applyCand(text) {
  if (!detailSpan || !text) return;
  detailSpan.classList.remove('off');
  detailSpan.textContent = text;
  detailSpan.dataset.suggestion = text;
  closeDetail();
}

detailClose.addEventListener('click', closeDetail);
detailOverlay.addEventListener('click', (e) => {
  if (e.target === detailOverlay) closeDetail();
});
detailRevert.addEventListener('click', () => {
  if (detailSpan) {
    detailSpan.classList.add('off');
    detailSpan.textContent = detailSpan.dataset.original;
  }
  closeDetail();
});

// 매번 원문 유지 — 이 단어를 검사 제외 목록에 넣는다.
// 지금 화면에 같은 단어가 20군데 잡혀 있어도 한 번에 전부 원문으로 돌아가고,
// 다음 검사부터는 아예 오류로 잡히지 않는다 (설정 > 검사 제외 단어에서 해제).
// [묶어서] 를 켜 두면 조사만 다른 말(별명은·별명이·별명의 …)까지 함께 제외한다.
let detailGroupOn = true; // 기본은 묶어서 (설정 불러오면 저장값으로 맞춘다)
const detailIgnoreGroup = $('detailIgnoreGroup');

detailIgnoreGroup.addEventListener('click', () => {
  setGroupDefault(!detailGroupOn);
  updateDetailIgnoreHint();
});

// 묶었을 때 무엇이 함께 빠지는지 상세 카드에서 미리 알려준다
function updateDetailIgnoreHint() {
  const token = detailSpan ? detailSpan.dataset.original : '';
  const btn = $('detailIgnore');
  if (!token) {
    btn.textContent = '매번 원문 유지';
    return;
  }
  // 지금 화면에서 몇 군데가 한 번에 정리되는지 미리 알려준다
  const probe = CSTIgnore.matcher([{ w: detailGroupOn ? CSTIgnore.stemOf(token) : token, group: detailGroupOn }]);
  let n = 0;
  for (const sp of result.querySelectorAll('.tok')) {
    if (!sp.classList.contains('off') && probe(sp.dataset.original)) n++;
  }
  btn.textContent = n > 1 ? `매번 원문 유지 (${n}군데)` : '매번 원문 유지';
  detailIgnoreGroup.title = detailGroupOn
    ? CSTIgnore.examples(CSTIgnore.stemOf(token)).join(' · ') + ' … 가 함께 제외됩니다'
    : '조사만 다른 말(별명은·별명이·별명의 …)까지 묶어서 제외합니다';
}

$('detailIgnore').addEventListener('click', () => {
  if (!detailSpan) return closeDetail();
  const token = detailSpan.dataset.original;
  const group = detailGroupOn;
  closeDetail();
  if (!token) return;
  // 묶을 때는 조사를 뗀 말을 기준으로 등록한다 ('별명의' → '별명')
  const word = group ? CSTIgnore.stemOf(token) : token;
  addIgnoreEntry(word, group);
});

// 결과 화면에서 제외된 단어들을 전부 원문으로 되돌리고 오류 목록·개수도 다시 센다
function revertIgnoredInResult() {
  const isIgnored = CSTIgnore.matcher(ignoreWords);
  let n = 0;
  for (const span of result.querySelectorAll('.tok')) {
    const orig = span.dataset.original;
    if (!isIgnored(orig) || span.classList.contains('off')) continue;
    span.classList.add('off');
    span.textContent = orig;
    n++;
  }
  for (const c of lastCorrections) if (isIgnored(c.token)) c._ignored = true;
  const live = lastCorrections.filter((c) => !c._ignored);
  buildErrorList(live);
  if (live.length) {
    resultCount.classList.remove('ok');
    resultCount.textContent = `오류 ${live.length}개 ${errorList.classList.contains('hidden') ? '▾' : '▴'}`;
  } else if (lastCorrections.length) {
    resultCount.textContent = '오류 없음 ✓';
    resultCount.classList.add('ok');
    errorList.classList.add('hidden');
    mainView.classList.remove('with-list');
  }
  if (n > 1) showIgnoreNote(`${n}군데를 모두 원문으로 두었습니다`, 'ok');
}

// 결과 화면 아래 안내줄을 잠깐 바꿔 알린다 (별도 토스트 UI 없이)
function toastLike(text) {
  const prev = footNote.textContent;
  footNote.textContent = text;
  setTimeout(() => (footNote.textContent = prev), 2000);
}
candApply.addEventListener('click', () => applyCand(candInput.value.trim()));
candInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') applyCand(candInput.value.trim());
});

// 색칠된 단어 클릭 → 상세 카드 (대치어 선택·직접 수정·원문 유지)
result.addEventListener('click', (e) => {
  const span = e.target.closest('.tok');
  if (!span) return;
  openDetail(span);
});

// ---------- 복사 ----------
async function doCopy(message) {
  try {
    await navigator.clipboard.writeText(result.textContent);
  } catch (_) {
    return;
  }
  copyBtn.classList.add('copied');
  const prev = footNote.textContent;
  footNote.textContent = message;
  setTimeout(() => {
    copyBtn.classList.remove('copied');
    footNote.textContent = prev;
  }, 1500);
}

copyBtn.addEventListener('click', () => doCopy('교정 결과가 클립보드에 복사되었습니다 ✓'));

// ---------- 검사 기록 (최근 10건, storage.local) ----------
const HISTORY_MAX = 10;

function saveHistory(text, corrections, engine) {
  if (!EXT) return;
  chrome.storage.local.get({ history: [] }, ({ history }) => {
    history.unshift({
      at: Date.now(),
      engine,
      text: text.slice(0, 3000),
      corrections,
    });
    chrome.storage.local.set({ history: history.slice(0, HISTORY_MAX) });
  });
}

function fmtTime(ts) {
  const d = new Date(ts);
  const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getMonth() + 1)}.${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

function renderHistory() {
  const list = $('historyList');
  list.innerHTML = '';
  if (!EXT) return;
  chrome.storage.local.get({ history: [] }, ({ history }) => {
    if (!history.length) {
      const empty = document.createElement('div');
      empty.className = 'hist-empty';
      empty.textContent = '아직 검사 기록이 없습니다.';
      list.appendChild(empty);
      return;
    }
    history.forEach((h, i) => {
      const row = document.createElement('div');
      row.className = 'hist-row';

      const meta = document.createElement('div');
      meta.className = 'hist-meta';

      const time = document.createElement('span');
      time.textContent = fmtTime(h.at);

      const eng = document.createElement('span');
      eng.className = 'hist-engine';
      eng.textContent = ENGINE_LABEL[h.engine] || h.engine;

      const count = document.createElement('span');
      const n = (h.corrections || []).length;
      count.className = 'hist-count' + (n ? '' : ' ok');
      count.textContent = n ? `오류 ${n}개` : '오류 없음';

      const del = document.createElement('button');
      del.className = 'hist-del';
      del.textContent = '✕';
      del.title = '삭제';
      del.addEventListener('click', (e) => {
        e.stopPropagation();
        chrome.storage.local.get({ history: [] }, ({ history: cur }) => {
          cur.splice(i, 1);
          chrome.storage.local.set({ history: cur }, renderHistory);
        });
      });

      meta.append(time, eng, count, del);

      const preview = document.createElement('div');
      preview.className = 'hist-preview';
      preview.textContent = h.text.slice(0, 60);

      row.append(meta, preview);
      row.addEventListener('click', () => {
        input.value = h.text;
        updateMeta();
        showView('main');
        renderResult(h.text, h.corrections || []);
      });
      list.appendChild(row);
    });
  });
}

$('historyClear').addEventListener('click', () => {
  if (!EXT) return;
  chrome.storage.local.set({ history: [] }, renderHistory);
});

// ---------- 설정 ----------
const setLive = $('setLive');
const setDebounce = $('setDebounce');
const setMenu = $('setMenu');
const setExcluded = $('setExcluded');
// 저장 안내는 설정 카드 안이 아니라 하단 왼쪽 안내줄에 띄운다.
// 기존 코드가 setSaved.textContent / classList 를 그대로 쓰므로 같은 모양의 대역을 둔다.
const savedNote = {
  set textContent(v) {
    footNote.textContent = v;
  },
  get textContent() {
    return footNote.textContent;
  },
  classList: {
    add: (c) => footNote.classList.add(c),
    remove: (c) => footNote.classList.remove(c),
  },
};
const setSaved = savedNote;
const engineRadios = [...document.querySelectorAll('input[name="engine"]')];

// 맞춤법 설정은 local을 정본으로 두고 sync에 미러링한다.
// chrome.storage.sync는 분당 120회·시간당 1800회 쓰기 제한이 있고 초과하면 조용히 실패해서,
// "저장되었습니다"가 뜬 뒤에도 값이 되돌아가는 문제가 있었다. local은 그 제한이 없다.
function applySettings(s) {
  liveToggle.checked = s.liveCheck;
  setLive.checked = s.liveCheck;
  setDebounce.value = String(s.debounceMs);
  setMenu.checked = s.contextMenu;
  setExcluded.value = s.excluded;
  for (const r of engineRadios) r.checked = r.value === s.engine;
  setDictOn.checked = s.userDictOn;
  setAutoCopy.checked = s.autoCopy;
  autoCopyOn = s.autoCopy;
  setUnderline.checked = s.underlineOn;
  ulColor = s.underlineColor;
  ulStyle = s.underlineStyle;
  refreshUnderlineUI();
  userDict = Array.isArray(s.userDict) ? s.userDict : [];
  ignoreWords = CSTIgnore.dedupe(Array.isArray(s.ignoreWords) ? s.ignoreWords : []);
  addGroupOn = s.ignoreGroupDefault !== false;
  detailGroupOn = addGroupOn;
  ignoreGroupBtn.classList.toggle('active', addGroupOn);
  detailIgnoreGroup.classList.toggle('active', detailGroupOn);
  renderIgnore();
  setLiveEngine.value = s.liveEngine || '';
  renderDict();
}

function loadSettings() {
  if (!EXT) return;
  // sync·local을 병렬로 읽는다 (직렬 중첩이면 왕복 지연이 합산된다)
  const pSync = new Promise((r) => chrome.storage.sync.get(DEFAULTS, (sv) => r(chrome.runtime.lastError ? null : sv)));
  const pLocal = new Promise((r) =>
    chrome.storage.local.get(Object.keys(DEFAULTS), (lc) => r(chrome.runtime.lastError ? null : lc))
  );
  Promise.all([pSync, pLocal]).then(([sv, lc]) => {
    const s = sv ? { ...DEFAULTS, ...sv } : { ...DEFAULTS };
    // local에 값이 있으면 그것이 이 기기의 확정값
    if (lc) {
      for (const k of Object.keys(DEFAULTS)) if (lc[k] !== undefined) s[k] = lc[k];
    }
    applySettings(s);
  });
}

function save(partial) {
  if (!EXT) return;
  chrome.storage.local.set(partial, () => {
    const err = chrome.runtime.lastError;
    if (err) {
      setSaved.textContent = '저장 실패: ' + err.message;
      setSaved.classList.add('flash');
      return;
    }
    setSaved.textContent = '저장되었습니다 ✓';
    setSaved.classList.add('flash');
    setTimeout(() => {
      restoreFootNote();
      setSaved.classList.remove('flash');
    }, 1200);
    // 다른 기기 동기화는 덤 — 할당량 초과로 실패해도 이 기기 동작에는 영향 없음
    try {
      chrome.storage.sync.set(partial, () => void chrome.runtime.lastError);
    } catch (_) {}
  });
}

liveToggle.addEventListener('change', () => {
  setLive.checked = liveToggle.checked;
  save({ liveCheck: liveToggle.checked });
});

setLive.addEventListener('change', () => {
  liveToggle.checked = setLive.checked;
  save({ liveCheck: setLive.checked });
});

setDebounce.addEventListener('change', () => save({ debounceMs: Number(setDebounce.value) }));
setMenu.addEventListener('change', () => save({ contextMenu: setMenu.checked }));

const setAutoCopy = $('setAutoCopy');
setAutoCopy.addEventListener('change', () => {
  autoCopyOn = setAutoCopy.checked;
  save({ autoCopy: setAutoCopy.checked });
});

// ---------- 오류 밑줄 설정 ----------
const setUnderline = $('setUnderline');
const ulOpts = $('ulOpts');
const ulCustom = $('ulCustom');
const ulPreview = $('ulPreview');
const swatches = [...document.querySelectorAll('.swatch[data-color]')];
const ulStyles = [...document.querySelectorAll('.ul-style')];
let ulColor = DEFAULTS.underlineColor;
let ulStyle = DEFAULTS.underlineStyle;

function refreshUnderlineUI() {
  ulOpts.classList.toggle('disabled', !setUnderline.checked);
  const preset = swatches.some((s) => s.dataset.color === ulColor);
  for (const s of swatches) s.classList.toggle('selected', s.dataset.color === ulColor);
  document.querySelector('.swatch-custom').classList.toggle('selected', !preset);
  if (!preset) ulCustom.value = ulColor;
  for (const b of ulStyles) b.classList.toggle('selected', b.dataset.style === ulStyle);
  ulPreview.style.textDecoration = setUnderline.checked
    ? `underline ${ulStyle} ${ulColor} 2px`
    : 'none';
}

setUnderline.addEventListener('change', () => {
  save({ underlineOn: setUnderline.checked });
  refreshUnderlineUI();
});

for (const s of swatches) {
  s.addEventListener('click', () => {
    ulColor = s.dataset.color;
    save({ underlineColor: ulColor });
    refreshUnderlineUI();
  });
}

ulCustom.addEventListener('input', () => {
  ulColor = ulCustom.value;
  save({ underlineColor: ulColor });
  refreshUnderlineUI();
});

for (const b of ulStyles) {
  b.addEventListener('click', () => {
    ulStyle = b.dataset.style;
    save({ underlineStyle: ulStyle });
    refreshUnderlineUI();
  });
}

let excludedTimer = 0;
setExcluded.addEventListener('input', () => {
  clearTimeout(excludedTimer);
  excludedTimer = setTimeout(() => save({ excluded: setExcluded.value }), 500);
});

for (const r of engineRadios) {
  r.addEventListener('change', () => {
    if (r.checked) save({ engine: r.value });
  });
}

// ---------- 개인 사전 ----------
const setDictOn = $('setDictOn');
const dictList = $('dictList');
const dictFrom = $('dictFrom');
const dictTo = $('dictTo');
const dictAddBtn = $('dictAddBtn');
let userDict = [];
let ignoreWords = [];

const setLiveEngine = $('setLiveEngine');
setLiveEngine.addEventListener('change', () => save({ liveEngine: setLiveEngine.value }));

// ---------- 검사 제외 단어 ----------
const ignoreList = $('ignoreList');

const ignoreExpanded = new Set(); // 미리보기를 펼쳐 둔 항목

// 이미 있는 항목을 가리켜 보여준다 (왜 추가가 안 되는지 바로 알 수 있게)
function flashIgnoreRow(word) {
  for (const row of ignoreList.querySelectorAll('.ignore-row')) {
    if (row.querySelector('.dict-from').textContent !== word) continue;
    row.classList.add('flash');
    row.scrollIntoView({ block: 'nearest' });
    setTimeout(() => row.classList.remove('flash'), 1400);
  }
}

function renderIgnore() {
  ignoreList.innerHTML = '';
  const items = CSTIgnore.normalize(ignoreWords);
  if (!items.length) {
    const empty = document.createElement('div');
    empty.className = 'dict-empty';
    empty.textContent = '제외 단어가 없습니다. 결과 화면에서 [매번 원문 유지]를 누르면 여기 쌓입니다.';
    ignoreList.appendChild(empty);
    return;
  }
  items.forEach((it, i) => {
    const row = document.createElement('div');
    row.className = 'dict-row ignore-row';

    const w = document.createElement('span');
    w.className = 'dict-from';
    w.textContent = it.w;

    // 묶음 토글 — 켜면 조사만 다른 말까지 함께 제외되고, 무엇이 걸리는지 아래에 보여준다
    const grp = document.createElement('button');
    grp.className = 'seg-btn' + (it.group ? ' active' : '');
    grp.textContent = '묶어서';
    grp.title = it.group ? '조사가 붙은 말까지 제외 중 (눌러서 끄기)' : '조사가 붙은 말까지 함께 제외';
    grp.addEventListener('click', () => {
      const before = it.w;
      const list = CSTIgnore.normalize(ignoreWords);
      const target = list.find((e) => e.w === before);
      if (!target) return;
      const on = !target.group;
      // 묶을 때는 조사를 뗀 말이 기준이 되어야 한다 ('닉이' 를 묶으면 '닉').
      // 겹치는 항목 합치기는 dedupe 에 맡긴다 (직접 splice 하면 인덱스가 밀린다)
      if (on) target.w = CSTIgnore.stemOf(before);
      target.group = on;
      ignoreWords = CSTIgnore.dedupe(list);
      save({ ignoreWords });
      renderIgnore();
      if (!on) return;
      revertIgnoredInResult(); // 화면에 있는 변형들도 바로 정리
      showIgnoreNote(
        target.w === before
          ? `"${before}" 을(를) 묶음으로 바꿨습니다 — 조사가 붙은 말도 함께 제외됩니다`
          : `"${before}" → "${target.w}" 묶음으로 바꿨습니다`,
        'ok'
      );
    });

    const del = document.createElement('button');
    del.className = 'dict-del';
    del.textContent = '✕';
    del.title = '제외 해제';
    del.addEventListener('click', () => {
      items.splice(i, 1);
      ignoreWords = CSTIgnore.dedupe(items);
      save({ ignoreWords });
      renderIgnore();
    });

    row.append(w, grp, del);
    ignoreList.appendChild(row);

    if (it.group) {
      // 미리보기 — 눌러서 전체 목록 펼치기/접기 (판정은 이보다 넓다)
      const pv = document.createElement('button');
      pv.type = 'button';
      pv.className = 'ignore-preview';
      const paint = () => {
        const open = ignoreExpanded.has(it.w);
        pv.textContent = open
          ? CSTIgnore.examplesAll(it.w).join(' · ') + ' ▴ 접기'
          : CSTIgnore.examples(it.w).join(' · ') + ' … 더 보기';
        pv.title = open ? '눌러서 접기' : '눌러서 제외되는 말 전부 보기';
      };
      paint();
      pv.addEventListener('click', () => {
        if (ignoreExpanded.has(it.w)) ignoreExpanded.delete(it.w);
        else ignoreExpanded.add(it.w);
        paint();
      });
      ignoreList.appendChild(pv);
    }
  });

  // 한 번에 비우기 (되돌릴 수 없으니 확인 후)
  const foot = document.createElement('div');
  foot.className = 'ignore-foot';
  const cnt = document.createElement('span');
  cnt.textContent = `${items.length}개 제외 중`;
  const clear = document.createElement('button');
  clear.className = 'dict-del';
  clear.textContent = '전체 지우기';
  clear.title = '제외 단어를 모두 없앱니다';
  clear.addEventListener('click', () => {
    if (!confirm(`검사 제외 단어 ${items.length}개를 모두 지울까요?`)) return;
    ignoreWords = [];
    save({ ignoreWords });
    renderIgnore();
  });
  foot.append(cnt, clear);
  ignoreList.appendChild(foot);
}

// 추가 줄의 '묶어서' 토글 + 무엇이 제외될지 미리보기
let addGroupOn = true;
let addPreviewOpen = false;
const ignoreGroupBtn = $('ignoreGroupBtn');
const ignorePreview = $('ignorePreview');

function refreshAddPreview() {
  const w = $('ignoreInput').value.trim();
  if (!addGroupOn || !w) {
    ignorePreview.classList.add('hidden');
    return;
  }
  const stem = CSTIgnore.stemOf(w);
  const head = stem !== w ? `"${stem}" 기준 · ` : '';
  ignorePreview.textContent = addPreviewOpen
    ? head + CSTIgnore.examplesAll(stem).join(' · ') + ' ▴ 접기'
    : head + CSTIgnore.examples(stem).join(' · ') + ' … 더 보기';
  ignorePreview.title = addPreviewOpen ? '눌러서 접기' : '눌러서 제외되는 말 전부 보기';
  ignorePreview.classList.remove('hidden');
}

ignoreGroupBtn.addEventListener('click', () => {
  setGroupDefault(!addGroupOn);
  refreshAddPreview();
});

// 상세 카드와 설정의 [묶어서] 는 같은 선택을 쓴다 — 매번 켜 주지 않아도 되게
function setGroupDefault(on) {
  addGroupOn = on;
  detailGroupOn = on;
  ignoreGroupBtn.classList.toggle('active', on);
  detailIgnoreGroup.classList.toggle('active', on);
  save({ ignoreGroupDefault: on });
}
$('ignoreInput').addEventListener('input', refreshAddPreview);
ignorePreview.addEventListener('click', () => {
  addPreviewOpen = !addPreviewOpen;
  refreshAddPreview();
});

$('ignoreAddBtn').addEventListener('click', () => {
  const w = $('ignoreInput').value.trim();
  if (!w) return;
  addIgnoreEntry(w, addGroupOn);
  $('ignoreInput').value = '';
  refreshAddPreview();
});

// 제외 목록에 한 줄 추가 (이미 있으면 묶음 여부만 갱신)
function addIgnoreEntry(rawWord, group) {
  const word = String(rawWord || '').trim();
  if (!word) return;
  // 묶음이면 조사를 뗀 말로 등록한다 ('닉이' 로 묶으면 '닉' 기준이라야
  // 닉은·닉을·닉의 까지 걸린다. 안 그러면 '닉이는' 같은 말만 걸려 쓸모가 없다)
  const w = group ? CSTIgnore.stemOf(word) : word;
  const items = CSTIgnore.normalize(ignoreWords);
  const same = items.find((e) => e.w === w);

  // 같은 말이 이미 있는 경우 — 이번에 묶어 달라는 뜻이면 막지 말고 묶음으로 바꿔 준다
  if (same) {
    if (group && !same.group) {
      same.group = true;
      ignoreWords = CSTIgnore.dedupe(items);
      save({ ignoreWords });
      renderIgnore();
      revertIgnoredInResult();
      showIgnoreNote(`"${w}" 을(를) 묶음으로 바꿨습니다 — 조사가 붙은 말도 함께 제외됩니다`, 'ok');
      flashIgnoreRow(w);
      return;
    }
    showIgnoreNote(
      same.group ? `"${word}" 은(는) 이미 "${w}"(묶음) 으로 제외 중입니다` : `"${word}" 은(는) 이미 목록에 있습니다`,
      'warn'
    );
    flashIgnoreRow(w);
    return;
  }

  // 다른 묶음이 이미 덮고 있으면 한 줄 더 만들지 않는다 — 무엇 때문인지 짚어 준다
  const by = CSTIgnore.coveredBy(ignoreWords, w);
  if (by) {
    showIgnoreNote(`"${word}" 은(는) "${by.w}"(묶음) 에 포함되어 이미 제외 중입니다`, 'warn');
    flashIgnoreRow(by.w);
    return;
  }

  items.push({ w, group: !!group });
  ignoreWords = CSTIgnore.dedupe(items);
  save({ ignoreWords });
  renderIgnore();
  revertIgnoredInResult();
  showIgnoreNote(group && w !== word ? `"${word}" → "${w}" 묶음으로 추가했습니다` : `"${w}" 을(를) 추가했습니다`, 'ok');
}

// 검사 제외 단어 칸 안에서 결과를 알린다 — 잠깐 떴다가 스르륵 사라진다.
// (설정 화면 밖에서 누른 경우도 있으니 하단 안내줄에도 같이 띄운다)
let ignoreNoteTimer = 0;
let ignoreFadeTimer = 0;
function showIgnoreNote(text, kind) {
  const el = $('ignoreNote');
  clearTimeout(ignoreNoteTimer);
  clearTimeout(ignoreFadeTimer);
  el.textContent = text;
  el.className = 'ignore-note ' + (kind === 'warn' ? 'warn' : 'ok');
  ignoreFadeTimer = setTimeout(() => el.classList.add('fade'), 2600);
  ignoreNoteTimer = setTimeout(() => el.classList.add('hidden'), 3200);
  toastLike(text);
}
$('ignoreInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') $('ignoreAddBtn').click();
});

function renderDict() {
  dictList.innerHTML = '';
  if (!userDict.length) {
    const empty = document.createElement('div');
    empty.className = 'dict-empty';
    empty.textContent = '등록된 단어가 없습니다. 아래에서 추가해 보세요.';
    dictList.appendChild(empty);
    return;
  }
  userDict.forEach((entry, i) => {
    const row = document.createElement('div');
    row.className = 'dict-row';

    const from = document.createElement('span');
    from.className = 'dict-from';
    from.textContent = entry.from;

    const arrow = document.createElement('span');
    arrow.className = 'err-arrow';
    arrow.textContent = '→';

    const to = document.createElement('span');
    to.className = 'dict-to';
    to.textContent = entry.to;

    const del = document.createElement('button');
    del.className = 'dict-del';
    del.textContent = '✕';
    del.title = '삭제';
    del.addEventListener('click', () => {
      userDict.splice(i, 1);
      save({ userDict });
      renderDict();
    });

    row.append(from, arrow, to, del);
    dictList.appendChild(row);
  });
}

function addDictEntry() {
  const from = dictFrom.value.trim();
  const to = dictTo.value.trim();
  if (!from || !to || from === to) return;
  // 같은 '틀린 표현'이 이미 있으면 교체
  const existing = userDict.findIndex((e) => e.from === from);
  if (existing !== -1) userDict.splice(existing, 1);
  userDict.unshift({ from, to });
  save({ userDict });
  renderDict();
  dictFrom.value = '';
  dictTo.value = '';
  dictFrom.focus();
}

dictAddBtn.addEventListener('click', addDictEntry);
dictTo.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') addDictEntry();
});
dictFrom.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') dictTo.focus();
});

setDictOn.addEventListener('change', () => save({ userDictOn: setDictOn.checked }));

// 개인 사전 내보내기/가져오기 (JSON)
$('dictExport').addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(userDict, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'textdoctor-dict.json';
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});

$('dictImport').addEventListener('click', () => $('dictFile').click());

$('dictFile').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  try {
    const data = JSON.parse(await file.text());
    if (!Array.isArray(data)) throw new Error('형식 오류');
    let added = 0;
    for (const entry of data) {
      const from = String(entry.from || '').trim();
      const to = String(entry.to || '').trim();
      if (!from || !to || from === to) continue;
      const existing = userDict.findIndex((d) => d.from === from);
      if (existing !== -1) userDict.splice(existing, 1);
      userDict.push({ from, to });
      added++;
    }
    save({ userDict });
    renderDict();
    setSaved.textContent = `${added}개 단어를 가져왔습니다 ✓`;
    setSaved.classList.add('flash');
    setTimeout(() => {
      restoreFootNote();
      setSaved.classList.remove('flash');
    }, 2000);
  } catch (_) {
    setSaved.textContent = '가져오기 실패 — JSON 형식을 확인해 주세요 ([{"from":"...","to":"..."}])';
    setTimeout(restoreFootNote, 2500);
  }
});

// ---------- 화면 전환 (검사 / 설정 / 기록) ----------
const historyView = $('historyView');
const historyBtn = $('historyBtn');
let currentView = 'main';

// 잠깐 띄운 안내를 지금 화면 기본 문구로 되돌린다
function restoreFootNote() {
  if (currentTab === 'cocofo') footNote.textContent = cocoSubView === 'settings' ? TAB_NOTES.cocoset : TAB_NOTES.cocofo;
  else footNote.textContent = FOOT_NOTES[currentView] || FOOT_NOTES.main;
}

const FOOT_NOTES = {
  main: '색칠된 단어를 누르면 대치어와 도움말을 볼 수 있어요.',
  settings: '변경 사항은 즉시 저장됩니다.',
  history: '기록을 클릭하면 그 검사 결과를 다시 볼 수 있어요.',
};

function showView(name) {
  if (currentTab !== 'spell') showTab('spell', false);
  currentView = name;
  const ul = document.getElementById('updLogView');
  if (ul) ul.classList.add('hidden'); // 업데이트 내역 화면은 다른 화면으로 가면 닫힌다
  mainView.classList.toggle('hidden', name !== 'main');
  settingsView.classList.toggle('hidden', name !== 'settings');
  historyView.classList.toggle('hidden', name !== 'history');
  settingsBtn.classList.toggle('active', name === 'settings');
  historyBtn.classList.toggle('active', name === 'history');
  footNote.textContent = FOOT_NOTES[name];
  if (name === 'history') renderHistory();
  // 테마 설정 그룹을 맞춤법 설정에도 표시 (하나뿐인 DOM을 화면 간 이동)
  if (name === 'settings' && typeof placeThemeGroup === 'function') placeThemeGroup('spell');
}

// ---------- 다시 그려도 보던 화면으로 (에디션 전환·설정 초기화) ----------
// 팝업을 location.reload() 하면 늘 첫 화면으로 돌아가 버린다. 보던 설정 화면과
// 스크롤 위치를 잠깐 적어 두었다가 다시 뜰 때 그대로 되돌린다.
// (팝업을 새로 열었을 때 엉뚱하게 설정이 열리지 않도록 8초 안에 다시 뜬 경우만 쓴다)
const RESUME_KEY = 'cstPopupResume';

function settingsBox() {
  return currentTab === 'cocofo' ? $('cocoSetView') : settingsView;
}

function savePopupResume() {
  try {
    const box = settingsBox();
    localStorage.setItem(
      RESUME_KEY,
      JSON.stringify({ tab: currentTab, view: currentView, coco: cocoSubView, scroll: box ? box.scrollTop : 0, at: Date.now() })
    );
  } catch (_) {}
}

function restorePopupResume() {
  let r = null;
  try {
    const raw = localStorage.getItem(RESUME_KEY);
    localStorage.removeItem(RESUME_KEY);
    r = raw ? JSON.parse(raw) : null;
  } catch (_) {}
  if (!r || Date.now() - (r.at || 0) > 8000) return;
  if (r.tab === 'cocofo') {
    cocoSubView = r.coco === 'settings' ? 'settings' : 'main';
    showTab('cocofo', false);
  } else if (r.view === 'settings' || r.view === 'history') {
    showView(r.view);
  }
  if (r.scroll) {
    const box = settingsBox();
    if (box) requestAnimationFrame(() => (box.scrollTop = r.scroll));
  }
}

settingsBtn.addEventListener('click', () => {
  // 코코포리아 탭에서는 코코포 설정을, 맞춤법 탭에서는 맞춤법 설정을 연다
  if (currentTab === 'cocofo') {
    toggleCocoSettings();
    return;
  }
  showView(currentTab === 'spell' && currentView === 'settings' ? 'main' : 'settings');
});

historyBtn.addEventListener('click', () => {
  showView(currentTab === 'spell' && currentView === 'history' ? 'main' : 'history');
});

// ---------- 상단 탭 (맞춤법 검사 / 코코포리아) ----------
const cocofoView = $('cocofoView');
const cocoSetView = $('cocoSetView');
const topTabs = [...document.querySelectorAll('.top-tab')];
let currentTab = 'spell';
let cocoSubView = 'main'; // 'main' | 'settings'

const TAB_NOTES = {
  cocofo: '방 카드 클릭 = 새 탭 이동 · 책갈피 = 저장 · 연필 = 메모',
  cocoset: '변경 사항은 즉시 저장됩니다. 코코포리아 탭은 새로고침해 주세요.',
};

function refreshFooterButtons() {
  historyBtn.classList.toggle('hidden', currentTab !== 'spell');
  if (currentTab === 'cocofo') {
    settingsBtn.classList.toggle('active', cocoSubView === 'settings');
  }
}

function showTab(tab, refreshSpellView = true) {
  currentTab = tab;
  const ulv = document.getElementById('updLogView');
  if (ulv) ulv.classList.add('hidden');
  for (const b of topTabs) b.classList.toggle('active', b.dataset.tab === tab);
  // 실시간 검사 토글은 맞춤법 탭 전용
  const lt = document.querySelector('.live-toggle');
  if (lt) lt.classList.toggle('hidden', tab !== 'spell');
  if (tab === 'spell') {
    cocofoView.classList.add('hidden');
    cocoSetView.classList.add('hidden');
    if (refreshSpellView) showView('main');
  } else {
    mainView.classList.add('hidden');
    settingsView.classList.add('hidden');
    historyView.classList.add('hidden');
    settingsBtn.classList.remove('active');
    historyBtn.classList.remove('active');
    cocofoView.classList.toggle('hidden', cocoSubView !== 'main');
    cocoSetView.classList.toggle('hidden', cocoSubView !== 'settings');
    footNote.textContent = cocoSubView === 'settings' ? TAB_NOTES.cocoset : TAB_NOTES.cocofo;
    if (cocoSubView === 'main') renderCocofo();
    else loadCocoSettings();
  }
  refreshFooterButtons();
}

function toggleCocoSettings() {
  cocoSubView = cocoSubView === 'settings' ? 'main' : 'settings';
  showTab('cocofo', false);
}

for (const b of topTabs) {
  b.addEventListener('click', () => {
    // 설정을 보던 중이면 다른 탭으로 넘어가도 설정이 열린 채 유지 (매번 두 번 누르지 않게)
    const inSettings = currentTab === 'spell' ? currentView === 'settings' : cocoSubView === 'settings';
    if (b.dataset.tab === 'cocofo') {
      cocoSubView = inSettings ? 'settings' : 'main';
      showTab('cocofo');
    } else {
      showTab('spell', false);
      showView(inSettings ? 'settings' : 'main');
    }
  });
}

// ---------- 공통: 코코포 데이터/유틸 ----------
const COCO_DEFAULT_CHARS = [
  '「', '」', '『', '』', '【', '】', '〈', '〉', '《', '》', '〔', '〕',
  '…', '‥', '―', '─', '·', '、', '。', '♥', '♡', '☆', '★',
  '※', '○', '●', '◎', '◇', '◆', '□', '■', '△', '▲', '▽', '▼',
  '→', '←', '↑', '↓', '↔', '♪', '♬', '♩', '〓', '§', '¶', '†', '‡',
];
const COCO_DEFAULT_RULES = [
  { from: '...', to: '…' },
  { from: '--', to: '―' },
];

const getLocal = (defs) => new Promise((r) => (EXT ? chrome.storage.local.get(defs, r) : r(defs)));
const setLocalP = (obj) => new Promise((r) => (EXT ? chrome.storage.local.set(obj, r) : r()));
const getSyncP = (defs) => new Promise((r) => (EXT ? chrome.storage.sync.get(defs, r) : r(defs)));

function normalizeHex(v) {
  let s = String(v || '').trim();
  if (!s) return '';
  if (!s.startsWith('#')) s = '#' + s;
  if (/^#[0-9a-fA-F]{3}$/.test(s)) s = '#' + [...s.slice(1)].map((c) => c + c).join('');
  return /^#[0-9a-fA-F]{6}$/.test(s) ? s.toLowerCase() : '';
}

function darkenHex(hex, amt = 0.15) {
  const h = normalizeHex(hex);
  if (!h) return hex;
  const n = parseInt(h.slice(1), 16);
  const f = (v) => Math.max(0, Math.round(v * (1 - amt)));
  return (
    '#' +
    [f((n >> 16) & 255), f((n >> 8) & 255), f(n & 255)]
      .map((v) => v.toString(16).padStart(2, '0'))
      .join('')
  );
}

function hexToSoft(hex, alpha = 0.15) {
  const h = normalizeHex(hex);
  if (!h) return '';
  const n = parseInt(h.slice(1), 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${alpha})`;
}

function fmtDateShort(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  const day0 = new Date();
  day0.setHours(0, 0, 0, 0);
  if (ts >= day0.getTime()) return '오늘';
  if (ts >= day0.getTime() - 86400000) return '어제';
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}.${p(d.getMonth() + 1)}.${p(d.getDate())}`;
}

// ---------- 충돌 확장프로그램 감지 ----------
const KNOWN_CONFLICTS = [
  { re: /국어\s*선생님|textdoctor/i, why: '맞춤법 검사 기능 전부가 이 확장에 이미 들어있어요' },
  { re: /만두/i, why: '채팅 알림·방문 기록·헬퍼 패널이 중복돼요' },
  { re: /클로버/i, why: '스탠딩 패널 기능이 중복돼요' },
  { re: /ccfolia\s*css|css\s*adjuster|스탠딩\s*사이즈|사이즈\s*조절/i, why: '스탠딩 사이즈 조절이 중복돼요 (사이즈 탭에 내장됨)' },
  { re: /할렐|야르미/i, why: '스탠딩/저널 변경 기능이 중복돼요' },
  { re: /특수문자.*팔레트|팔레트.*특수문자/i, why: '특수문자 팔레트가 중복돼요' },
  { re: /text\s*expander|auto\s*text|텍스트\s*대치/i, why: '텍스트 대치가 중복돼요' },
];
const MAYBE_CONFLICT_RE = /ccfolia|cocofo|코코포/i;

async function checkConflicts() {
  if (!EXT || !chrome.management || !chrome.management.getAll) return;
  let all;
  try {
    all = await chrome.management.getAll();
  } catch (_) {
    return;
  }
  const { conflictDismissed } = await getSyncP({ conflictDismissed: [] });
  const dismissed = new Set(conflictDismissed || []);
  const selfId = chrome.runtime.id;

  const must = [];
  const maybe = [];
  for (const ext of all) {
    if (ext.id === selfId || !ext.enabled || ext.type !== 'extension') continue;
    const hay = ext.name + ' ' + (ext.description || '');
    const hit = KNOWN_CONFLICTS.find((k) => k.re.test(hay));
    if (hit) must.push({ ext, why: hit.why });
    else if (MAYBE_CONFLICT_RE.test(hay)) maybe.push({ ext, why: '코코포리아 관련 확장으로 보여요 — 기능이 겹치면 꺼주세요' });
  }

  const visibleMust = must.filter((e) => !dismissed.has(e.ext.id));
  const visibleMaybe = maybe.filter((e) => !dismissed.has(e.ext.id));
  const banner = $('conflictBanner');
  if (!visibleMust.length && !visibleMaybe.length) {
    banner.classList.add('hidden');
    return;
  }

  function fillGroup(groupId, items) {
    const group = $(groupId);
    const rows = group.querySelector('.conflict-rows');
    rows.innerHTML = '';
    group.classList.toggle('hidden', !items.length);
    for (const { ext, why } of items) {
      const row = document.createElement('div');
      row.className = 'conflict-row';
      const name = document.createElement('span');
      name.className = 'conflict-name';
      name.textContent = ext.name;
      name.title = why;
      const off = document.createElement('button');
      off.className = 'conflict-off';
      off.textContent = '끄기';
      off.title = why;
      off.addEventListener('click', async () => {
        try {
          await chrome.management.setEnabled(ext.id, false);
          off.textContent = '꺼짐 ✓';
          off.disabled = true;
          name.style.textDecoration = 'line-through';
          name.style.opacity = '0.6';
        } catch (_) {
          off.textContent = '실패';
        }
      });
      row.append(name, off);
      rows.appendChild(row);
    }
  }

  fillGroup('conflictMust', visibleMust);
  fillGroup('conflictMaybe', visibleMaybe);
  banner.classList.remove('hidden');

  $('conflictDismiss').onclick = () => {
    const ids = [...dismissed, ...visibleMust.map((e) => e.ext.id), ...visibleMaybe.map((e) => e.ext.id)];
    chrome.storage.sync.set({ conflictDismissed: [...new Set(ids)] });
    banner.classList.add('hidden');
  };
}

// ---------- 새 버전 확인 (개인용·배포본 공통) ----------
// 사이드로드 확장은 크롬이 자동 업데이트를 못 하므로, 릴리즈 레포의 version.json 을
// 하루 몇 번 확인해 새 버전이면 배너로 안내한다. 실패는 조용히 무시 (다음 확인 때 재시도).
// 채널: 배포본은 dist(공개 zip), 개인용은 full(비공개 소스 레포 페이지 — 본인 계정으로 열람).
const UPDATE_INFO_URL = 'https://raw.githubusercontent.com/HOTDOGGYDOGGY/CocofoTeacher-release/main/version.json';
// 개인용은 소스 저장소에서 직접 갱신한다 (주소는 lib/edition.js — 배포본에는 들어가지 않는다)
const PERSONAL_REPO = window.CST_SOURCE_REPO || '';
// v12.1: 개인용도 새 버전을 확인한다 — 비공개 소스 저장소의 manifest.json 을 GitHub API 로 읽는다 (토큰 필요, 이 기기 local 에만 저장)
const SRC_API = PERSONAL_REPO ? PERSONAL_REPO.replace(/^https:\/\/github\.com\//, 'https://api.github.com/repos/').replace(/\/$/, '') : '';
// 배포본처럼 동작하는가 (진짜 배포본 + 개인용의 배포용 미리보기) — 버전 비교·배너는 이 기준
const ACTS_DIST = !!window.CST_LITE;
const IS_REAL_DIST = ACTS_DIST && !window.CST_PREVIEW;
// 진짜로 지금 돌아가는 빌드가 무엇인가 — 매니페스트 이름이 정답이다
// (배포용 개발 빌드도 CST_LITE 이므로 LITE 만 보면 공개 배포본과 구분되지 않는다)
const REAL_KIND = !window.CST_LITE
  ? 'full'
  : /배포용 개발/.test((chrome.runtime.getManifest && chrome.runtime.getManifest().name) || '')
    ? 'distdev'
    : 'dist';
// 화면에 내세울 에디션 (미리보기 중이면 그 에디션)
const CUR_KIND = window.CST_PREVIEW ? window.CST_PREVIEW_KIND : REAL_KIND;
// 개발판은 공개판보다 늘 앞서 있는 로컬 빌드다 — 공개 채널을 따라가면
// '뒤처진 공개판'과 비교하게 되어 안내가 의미 없다. 그래서 배너 없이 사실만 알려 준다.
const IS_DEV_BUILD = CUR_KIND === 'distdev';

// 미리보기에서는 그 에디션의 버전으로 흉내 낸다 (원본: lib/versions.json)
let distVersions = null;
async function loadDistVersions() {
  if (distVersions) return distVersions;
  try {
    const res = await fetch(chrome.runtime.getURL('lib/versions.json'));
    distVersions = await res.json();
  } catch (_) {
    distVersions = {};
  }
  return distVersions;
}

// 지금 에디션이 내세우는 버전 (미리보기면 흉내 내는 쪽 버전)
function curVersion() {
  const mv = chrome.runtime.getManifest().version;
  if (!window.CST_PREVIEW || !distVersions) return mv;
  return (window.CST_PREVIEW_KIND === 'dist' ? distVersions.dist : distVersions.distDev) || mv;
}

const ED_LABEL = { full: '개인용', distdev: '배포용 개발', dist: '배포용' };
// 각 에디션의 실제 manifest name (build-dist.js 와 같은 값)
const ED_NAME = {
  full: '코코포리아 선생님 (개인용)',
  distdev: '코코포리아 선생님 (배포용 개발)',
  dist: '코코포리아 선생님',
};
const UPDATE_CHECK_EVERY = 6 * 60 * 60 * 1000; // 6시간
const UPDATE_SNOOZE = 24 * 60 * 60 * 1000; // '나중에' 누르면 하루 뒤 다시

// "1.10" > "1.9" 가 되도록 숫자 조각으로 비교
function verCmp(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d;
  }
  return 0;
}

// 릴리즈 레포에서 이 에디션 채널의 최신 정보를 가져온다 (실패 시 throw)
// 전체 변경 이력(changelog)도 같이 실어 보낸다 — 배너에서 "이번에 바뀐 것"을 보여주는 데 쓴다
async function fetchUpdateInfo() {
  const res = await fetch(UPDATE_INFO_URL, { cache: 'no-store' });
  if (!res.ok) throw new Error('http ' + res.status);
  const j = await res.json();
  if (!j || !j.dist || !j.dist.version) return null;
  return { ...j.dist, changelog: Array.isArray(j.changelog) ? j.changelog : null };
}

// 내역 항목의 버전 번호 (공개 배포 버전이 기준, 개인용 소스 버전은 있으면 그것)
function relVer(entry) {
  return ACTS_DIST ? entry.v : entry.src || entry.v;
}

// 릴리즈 한 개의 내역 묶음 — groups [{title, items}] 가 있으면 제목별로, 없으면 제목 없는 한 묶음
function sectionsOf(e) {
  const strs = (a) => (Array.isArray(a) ? a.filter((x) => typeof x === 'string' && x.trim()) : []);
  if (Array.isArray(e.groups) && e.groups.length) {
    return e.groups.map((g) => ({ title: String((g && g.title) || ''), items: strs(g && g.items) })).filter((g) => g.items.length);
  }
  return [{ title: '', items: strs(e.items) }];
}

// 내역 묶음을 그린다: 제목(있으면) + 목록
function renderSections(box, sections, listClass, titleClass) {
  for (const sec of sections) {
    if (!sec.items.length) continue;
    if (sec.title) box.appendChild(Object.assign(document.createElement('div'), { className: titleClass, textContent: sec.title }));
    const ul = document.createElement('ul');
    ul.className = listClass;
    for (const it of sec.items) {
      const li = document.createElement('li');
      li.textContent = it;
      ul.appendChild(li);
    }
    box.appendChild(ul);
  }
}

// 지금 버전보다 새 릴리즈들의 내역 묶음만 모은다 (여러 버전을 건너뛰었으면 전부)
function newerSections(changelog, cur) {
  if (!Array.isArray(changelog)) return [];
  const out = [];
  for (const e of changelog) {
    if (e.dev) continue;
    const v = relVer(e);
    if (!v || verCmp(v, cur) <= 0) continue;
    out.push(...sectionsOf(e));
  }
  return out;
}

// 링크가 실제로 살아 있는지 (raw 직링크라 리다이렉트 없이 확인된다)
async function fileExists(url) {
  if (!url) return false;
  try {
    const res = await fetch(url, { method: 'HEAD', cache: 'no-store' });
    return res.ok;
  } catch (_) {
    return false; // 네트워크·CORS 문제 — 저장소 페이지로 보낸다
  }
}

// ---------- 로컬 빌드 갱신 (개인용 · 배포용 개발) ----------
// 확장을 새로 빌드하거나 소스를 고쳐 버전을 올리면, 크롬은 [새로고침] 하기 전까지 옛 코드를 돌린다.
// 디스크의 manifest.json 을 다시 읽어 지금 돌아가는 버전과 다르면 "새 빌드가 준비됐다"고 알린다.
// (공개 배포본은 원격 채널을 쓰므로 이 검사를 하지 않는다)
async function diskVersion() {
  const res = await fetch(chrome.runtime.getURL('manifest.json') + '?t=' + Date.now(), { cache: 'no-store' });
  if (!res.ok) throw new Error('http ' + res.status);
  const m = await res.json();
  return String(m.version || '');
}

function showBuildBanner(v) {
  const banner = $('updateBanner');
  if (!banner) return;
  $('updateVer').textContent = 'v' + chrome.runtime.getManifest().version + ' → v' + v;
  // 제목 글자만 바꾼다 (아이콘·버전 span 은 그대로)
  const title = banner.querySelector('.update-title');
  for (const node of title.childNodes) {
    if (node.nodeType === 3 && node.textContent.trim()) node.textContent = '새 빌드가 준비됐어요 — ';
  }
  $('updateNotes').classList.add('hidden');
  const hint = banner.querySelector('.update-hint');
  if (hint) hint.textContent = '새로 빌드된 파일이 폴더에 있습니다. [확장 새로고침]을 누르면 그 버전으로 다시 시작합니다.';
  $('updateGet').classList.add('hidden');
  $('updateAuto').classList.add('hidden');
  $('updateReload').classList.remove('hidden');
  $('updateReload').onclick = () => chrome.runtime.reload();
  $('updateLater').onclick = () => {
    chrome.storage.local.set({ buildSnooze: v });
    banner.classList.remove('show');
    banner.classList.add('hidden');
  };
  banner.classList.remove('hidden');
  banner.classList.add('show');
}

// 새 빌드가 있으면 배너를 띄운다. 반환: 디스크 버전 (실패하면 '')
async function checkBuildUpdate(force) {
  try {
    const v = await diskVersion();
    const cur = chrome.runtime.getManifest().version;
    if (!v || verCmp(v, cur) <= 0) return v;
    const { buildSnooze } = await getLocal({ buildSnooze: '' });
    if (force || buildSnooze !== v) showBuildBanner(v);
    return v;
  } catch (_) {
    return '';
  }
}

function showUpdateBanner(latest) {
  const cur = curVersion();
  $('updateVer').textContent = 'v' + cur + ' → v' + latest.version;
  const notes = $('updateNotes');
  const sections = newerSections(latest.changelog, cur);
  const count = sections.reduce((n, s) => n + s.items.length, 0);
  notes.innerHTML = '';
  if (count) {
    renderSections(notes, sections, 'update-notes-list', 'update-notes-group');
  } else if (latest.notes) {
    notes.textContent = latest.notes;
  }
  notes.classList.toggle('hidden', !count && !latest.notes);
  const banner = $('updateBanner');
  banner.classList.remove('hidden');

  // 받기 직전에 한 번 더 확인한다 — 릴리즈가 내려갔거나 파일이 바뀌었으면
  // 빈 링크로 새 탭을 열지 않고 저장소 페이지로 보낸다 (예전에 404 페이지가 뜨던 문제)
  $('updateGet').onclick = async () => {
    const btn = $('updateGet');
    const hint = document.querySelector('#updateBanner .update-hint');
    const hintText = hint ? hint.textContent : '';
    const label = btn.textContent;
    btn.disabled = true;
    btn.textContent = '확인 중…';
    try {
      const fresh = await fetchUpdateInfo().catch(() => null);
      const info = fresh && fresh.version ? fresh : latest;
      if (fresh) chrome.storage.local.set({ updLastCheck: Date.now(), updLatest: fresh });

      // 그 사이 내려간 버전이면 (배포자가 롤백) 배너를 닫고 이유를 알려준다
      if (fresh && verCmp(fresh.version, curVersion()) <= 0) {
        if (hint) hint.textContent = `안내가 취소되었습니다 — 지금은 v${fresh.version} 이 최신입니다.`;
        setTimeout(() => banner.classList.add('hidden'), 2500);
        return;
      }
      const ok = await fileExists(info.zip);
      if (!ok && hint) hint.textContent = '받을 파일을 찾지 못해 저장소 페이지를 엽니다. 잠시 후 다시 시도해 주세요.';
      const url = ok ? info.zip : info.page;
      if (url) chrome.tabs.create({ url });
    } finally {
      btn.disabled = false;
      btn.textContent = label;
      if (hint && hint.textContent === '확인 중…') hint.textContent = hintText;
    }
  };
  $('updateLater').onclick = () => {
    chrome.storage.local.set({ updSnooze: Date.now() + UPDATE_SNOOZE });
    banner.classList.add('hidden');
  };
}

// ---------- 개인용: 소스 저장소 새 버전 확인 ----------
async function getSrcCfg() {
  const d = await getLocal({ srcRepoToken: '', srcRepoBranch: 'main' });
  return { token: String(d.srcRepoToken || '').trim(), branch: String(d.srcRepoBranch || 'main').trim() || 'main' };
}

// 소스 저장소의 manifest.json 버전 + 마지막 커밋 한 줄. 실패 시 throw ('http 401' 등)
async function fetchSourceInfo(cfg) {
  if (!SRC_API) throw new Error('no repo');
  const headers = { Accept: 'application/vnd.github.raw+json', 'X-GitHub-Api-Version': '2022-11-28' };
  if (cfg.token) headers.Authorization = 'Bearer ' + cfg.token;
  const ref = encodeURIComponent(cfg.branch);
  const res = await fetch(`${SRC_API}/contents/manifest.json?ref=${ref}`, { headers, cache: 'no-store' });
  if (!res.ok) throw new Error('http ' + res.status);
  const man = await res.json();
  if (!man || !man.version) return null;
  let notes = '';
  let at = '';
  try {
    const r2 = await fetch(`${SRC_API}/commits?sha=${ref}&per_page=1`, {
      headers: { ...headers, Accept: 'application/vnd.github+json' },
      cache: 'no-store',
    });
    if (r2.ok) {
      const arr = await r2.json();
      const c = Array.isArray(arr) && arr[0] && arr[0].commit;
      if (c) {
        notes = String(c.message || '').split('\n')[0].slice(0, 140);
        at = (c.committer && c.committer.date) || (c.author && c.author.date) || '';
      }
    }
  } catch (_) {}
  return { version: man.version, notes, at, branch: cfg.branch, page: `${PERSONAL_REPO}/tree/${cfg.branch}`, source: true };
}

function srcErrorText(err) {
  const m = String((err && err.message) || '').match(/^http (\d+)/);
  if (!m) return '확인 실패. 네트워크 상태를 확인해 주세요.';
  if (m[1] === '401') return '토큰이 잘못됐거나 만료됐습니다 (401).';
  if (m[1] === '403') return '토큰에 이 저장소 읽기 권한이 없거나 요청 한도에 걸렸습니다 (403).';
  if (m[1] === '404') return '저장소·브랜치를 찾지 못했습니다 (404). 비공개 저장소는 토큰이 있어야 보입니다.';
  return `확인 실패 (HTTP ${m[1]}).`;
}

// 소스 배너: zip 이 아니라 git pull 안내. 배포본 배너 요소를 같이 쓴다
function showSourceBanner(info) {
  const cur = curVersion();
  $('updateVer').textContent = `v${cur} → v${info.version} (${info.branch})`;
  const notes = $('updateNotes');
  notes.innerHTML = '';
  if (info.notes) {
    const d = document.createElement('div');
    d.textContent = (info.at ? info.at.slice(0, 10) + ' · ' : '') + info.notes;
    notes.appendChild(d);
  }
  notes.classList.toggle('hidden', !info.notes);
  const hint = document.querySelector('#updateBanner .update-hint');
  if (hint) hint.textContent = `소스 저장소에 새 버전이 있습니다. 로컬 폴더에서 git pull (브랜치 ${info.branch}) 한 뒤 chrome://extensions 에서 새로고침(⟳)하세요.`;
  const banner = $('updateBanner');
  banner.classList.remove('hidden');
  $('updateGet').textContent = '저장소 열기';
  $('updateGet').onclick = () => chrome.tabs.create({ url: info.page || PERSONAL_REPO });
  $('updateLater').onclick = () => {
    chrome.storage.local.set({ srcUpdSnooze: Date.now() + UPDATE_SNOOZE });
    banner.classList.add('hidden');
  };
}

async function checkSourceUpdate(force) {
  const cfg = await getSrcCfg();
  if (!cfg.token && !force) return; // 토큰 없이는 비공개 저장소를 못 읽는다 — 조용히 넘어감
  const { updNotify } = await getSyncP({ updNotify: true });
  if (updNotify === false && !force) return;
  const now = Date.now();
  const st = await getLocal({ srcUpdLastCheck: 0, srcUpdLatest: null, srcUpdSnooze: 0 });
  let latest = st.srcUpdLatest;
  if (force || now - st.srcUpdLastCheck > UPDATE_CHECK_EVERY) {
    latest = await fetchSourceInfo(cfg); // force 면 실패를 호출자가 보여준다
    chrome.storage.local.set({ srcUpdLastCheck: now, srcUpdLatest: latest });
  }
  if (!latest || !latest.version) return latest;
  if (verCmp(latest.version, curVersion()) > 0 && (force || now >= st.srcUpdSnooze)) showSourceBanner(latest);
  return latest;
}

async function checkUpdate() {
  if (!EXT) return;
  // 개인용·개발판은 '내 폴더에 새 빌드가 있는가' 를 먼저 본다 (버전을 올려 빌드했는데 옛 코드가 돌고 있는 경우)
  if (REAL_KIND !== 'dist' && (await checkBuildUpdate(false)) && !$('updateBanner').classList.contains('hidden')) return;
  if (IS_DEV_BUILD) return; // 개발판은 공개 채널을 따라가지 않는다 (공개판이 뒤처져 있다)
  if (!ACTS_DIST) {
    // 개인용: 소스 저장소(비공개)의 manifest 버전을 토큰으로 읽는다
    try {
      await checkSourceUpdate(false);
    } catch (_) {
      /* 다음에 다시 */
    }
    return;
  }
  await loadDistVersions();
  const { updNotify } = await getSyncP({ updNotify: true });
  if (updNotify === false) return; // 알림 꺼짐 — 수동 [지금 확인]만 동작
  const now = Date.now();
  const st = await getLocal({ updLastCheck: 0, updLatest: null, updSnooze: 0 });
  let latest = st.updLatest;
  let fetchedNow = false;

  if (now - st.updLastCheck > UPDATE_CHECK_EVERY) {
    try {
      latest = await fetchUpdateInfo();
      fetchedNow = true;
    } catch (_) {
      /* 오프라인 등 — 다음에 다시 */
    }
    chrome.storage.local.set({ updLastCheck: now, updLatest: latest });
  }

  const cur = curVersion();
  if (!latest || !latest.version || verCmp(latest.version, cur) <= 0) return;
  if (now < st.updSnooze) return;

  // 배너를 띄우기 전엔 캐시를 믿지 않는다 — 릴리즈가 되돌려졌으면(예: 1.2 → 1.1)
  // 캐시된 죽은 zip 링크로 6시간 동안 잘못 안내하게 된다. 확인 실패 시에만 캐시 사용.
  if (!fetchedNow) {
    try {
      latest = await fetchUpdateInfo();
      chrome.storage.local.set({ updLastCheck: Date.now(), updLatest: latest });
      if (!latest || !latest.version || verCmp(latest.version, cur) <= 0) return;
    } catch (_) {
      /* 오프라인 — 캐시로라도 안내 */
    }
  }
  showUpdateBanner(latest);
}

// ---------- 업데이트 설정 그룹 (맞춤법/코코포 설정 공통) ----------
if (EXT && chrome.runtime.getManifest) {
  const showVer = async () => {
    if (window.CST_PREVIEW) await loadDistVersions();
    const kind = CUR_KIND;
    // 그 에디션이 실제로 쓰는 이름·버전 그대로 (미리보기 표식은 전환 스위치 옆에만)
    const full = ED_NAME[kind] + ' v' + curVersion();
    $('updCurVer').textContent = full + (window.CST_PREVIEW ? ' · 미리보기 중' : '');
    $('version').textContent = 'v' + curVersion(); // 팝업 상단 버전도 그 에디션 것으로
    $('brandTitle').textContent = ED_NAME[kind]; // 상단 이름도 매니페스트 이름 그대로
    document.title = ED_NAME[kind];
    // 툴바 아이콘 툴팁까지 그 에디션 것으로 (실제 매니페스트의 default_title 과 같은 값)
    try {
      if (chrome.action && chrome.action.setTitle) chrome.action.setTitle({ title: ED_NAME[kind] });
    } catch (_) {}
  };
  showVer();
}

// ---------- 에디션 보기 전환 (개인용 전용) ----------
// 확장을 개인용·배포용-개발·배포용으로 여러 개 깔지 않고, 이 확장 안에서 배포본 화면을 본다.
// 실제 dist 빌드에서는 이 항목 자체가 없다 (전환할 이유가 없다).
if (IS_REAL_DIST) {
  $('editionRow').classList.add('hidden');
} else {
  const curEd = window.CST_PREVIEW ? window.CST_PREVIEW_KIND : 'full';
  for (const b of document.querySelectorAll('#editionSeg .seg-btn')) {
    b.classList.toggle('active', b.dataset.ed === curEd);
    b.addEventListener('click', () => {
      if (b.dataset.ed === curEd) return;
      try {
        if (b.dataset.ed === 'full') localStorage.removeItem('cstEditionPreview');
        else localStorage.setItem('cstEditionPreview', b.dataset.ed);
      } catch (_) {}
      // 방 안 패널·스튜디오도 같은 값을 보도록 저장 (거기서는 storage 를 비동기로 읽는다)
      if (EXT) chrome.storage.local.set({ editionPreview: b.dataset.ed });
      savePopupResume(); // 보던 설정 화면 그대로 돌아오게
      location.reload(); // 팝업을 그 에디션으로 다시 그린다
    });
  }
}
getSyncP({ updNotify: true, updAutoReload: true }).then((s) => {
  $('setUpdNotify').checked = s.updNotify !== false;
  $('setUpdReload').checked = s.updAutoReload !== false;
});
$('setUpdReload').addEventListener('change', () => {
  chrome.storage.sync.set({ updAutoReload: $('setUpdReload').checked });
});
// 소스 저장소 토큰·브랜치 (개인용 전용 — 배포본·미리보기에서는 숨김)
if ($('srcUpdRow')) {
  if (ACTS_DIST || !SRC_API) $('srcUpdRow').classList.add('hidden');
  else {
    getSrcCfg().then((cfg) => {
      $('srcToken').value = cfg.token;
      $('srcBranch').value = cfg.branch;
      $('srcNote').textContent = cfg.token ? '토큰 저장됨 — 6시간마다 소스 저장소를 확인합니다.' : '토큰이 없으면 자동 확인은 쉽니다. [지금 확인]으로 수동 확인만 됩니다.';
    });
    $('srcSaveBtn').addEventListener('click', async () => {
      const token = $('srcToken').value.trim();
      const branch = $('srcBranch').value.trim() || 'main';
      await new Promise((r) => chrome.storage.local.set({ srcRepoToken: token, srcRepoBranch: branch, srcUpdLastCheck: 0, srcUpdSnooze: 0 }, r));
      $('srcNote').textContent = '저장 중… 확인해 봅니다.';
      try {
        const info = await fetchSourceInfo({ token, branch });
        $('srcNote').textContent = info ? `연결 확인 — ${branch} 최신 v${info.version}${info.notes ? ' · ' + info.notes : ''}` : '읽었지만 manifest 버전이 없습니다.';
        chrome.storage.local.set({ srcUpdLastCheck: Date.now(), srcUpdLatest: info });
        if (info && verCmp(info.version, curVersion()) > 0) showSourceBanner(info);
      } catch (err) {
        $('srcNote').textContent = srcErrorText(err);
      }
    });
  }
}
$('setUpdNotify').addEventListener('change', () => {
  const on = $('setUpdNotify').checked;
  chrome.storage.sync.set({ updNotify: on });
  if (!on) $('updateBanner').classList.add('hidden');
});
// ---------- 업데이트 내역 화면 ----------
// 내역 원본은 확장에 같이 담긴 lib/changelog.json (오프라인에서도 보인다).
// 릴리즈 레포의 version.json 에 더 새로운 내역이 있으면 그것을 얹는다.
const updLogView = $('updLogView');
let updLogReturn = null;
let changelogCache = null;

async function loadChangelog() {
  if (changelogCache) return changelogCache;
  try {
    const res = await fetch(chrome.runtime.getURL('lib/changelog.json'));
    const j = await res.json();
    changelogCache = Array.isArray(j.releases) ? j.releases : [];
  } catch (_) {
    changelogCache = [];
  }
  return changelogCache;
}

async function renderUpdLog() {
  const box = $('updLogList');
  box.innerHTML = '';
  await loadDistVersions();
  let list = await loadChangelog();
  // 배포 에디션(미리보기 포함)에서는 배포된 것만 — 작업 중(dev) 항목은 배포본에 없다
  // 준비 중(dev) 항목은 공개 배포본에서만 감춘다 — 개발판은 다음 배포를 미리 보는 자리라 그대로 보여 준다
  if (REAL_KIND === 'dist' && !window.CST_PREVIEW) list = list.filter((e) => !e.dev);

  // 서버 쪽에 더 새로운 릴리즈가 있으면 앞에 붙인다 (내 빌드보다 최신인 것만)
  try {
    const st = await getLocal({ updLatest: null });
    const remote = st.updLatest && Array.isArray(st.updLatest.changelog) ? st.updLatest.changelog : null;
    if (remote) {
      const have = new Set(list.map((e) => relVer(e)).filter(Boolean));
      const extra = remote.filter((e) => !e.dev && relVer(e) && !have.has(relVer(e)));
      if (extra.length) list = [...extra, ...list];
    }
  } catch (_) {}

  if (!list.length) {
    box.appendChild(Object.assign(document.createElement('div'), { className: 'set-desc', textContent: '내역을 불러오지 못했습니다.' }));
    return;
  }

  const cur = EXT && chrome.runtime.getManifest ? curVersion() : '';
  for (const e of list) {
    const v = relVer(e);
    const card = document.createElement('div');
    card.className = 'updlog-item';

    const head = document.createElement('div');
    head.className = 'updlog-head';
    const ver = document.createElement('span');
    ver.className = 'updlog-ver';
    ver.textContent = e.dev ? '준비 중' : 'v' + v;
    head.appendChild(ver);
    if (!e.dev && v && cur && verCmp(v, cur) === 0) {
      const tag = document.createElement('span');
      tag.className = 'updlog-cur';
      tag.textContent = '지금 쓰는 버전';
      head.appendChild(tag);
    }
    if (e.date) {
      const d = document.createElement('span');
      d.className = 'updlog-date';
      d.textContent = e.date;
      head.appendChild(d);
    }
    card.appendChild(head);

    renderSections(card, sectionsOf(e), 'updlog-items', 'updlog-group');
    box.appendChild(card);
  }
}

function openUpdLog() {
  updLogReturn = { tab: currentTab, view: currentView, coco: cocoSubView };
  for (const v of [mainView, settingsView, historyView, cocofoView, cocoSetView]) v.classList.add('hidden');
  updLogView.classList.remove('hidden');
  footNote.textContent = '새 버전이 나오면 이 목록 맨 위에 추가됩니다.';
  renderUpdLog();
}

function closeUpdLog() {
  updLogView.classList.add('hidden');
  const r = updLogReturn || { tab: 'spell', view: 'settings', coco: 'settings' };
  if (r.tab === 'spell') {
    showTab('spell', false);
    showView(r.view);
  } else {
    cocoSubView = r.coco;
    showTab('cocofo', false);
  }
}

$('updLogBtn').addEventListener('click', openUpdLog);
$('updLogBack').addEventListener('click', closeUpdLog);

$('updCheckBtn').addEventListener('click', async () => {
  const out = $('updResult');
  out.className = 'upd-result';
  out.textContent = '확인 중…';
  try {
    await loadDistVersions();
    const latest = await fetchUpdateInfo();
    chrome.storage.local.set({ updLastCheck: Date.now(), updLatest: latest });
    const cur = curVersion();
    if (IS_DEV_BUILD) {
      // 개발판은 공개 채널 대신 '내 폴더의 새 빌드' 를 본다
      const v = await checkBuildUpdate(true);
      out.className = v && verCmp(v, cur) > 0 ? 'upd-result new' : 'upd-result ok';
      out.textContent =
        v && verCmp(v, cur) > 0
          ? `새 빌드 v${v} 가 준비됐습니다 — [확장 새로고침]을 누르세요. · 공개 배포본 v${latest ? latest.version : '?'}`
          : `최신 빌드입니다 (배포용 개발 v${cur}) · 공개 배포본 v${latest ? latest.version : '?'}`;
      return;
    }
    if (!ACTS_DIST) {
      // 개인용: 소스 저장소 버전 비교 (토큰) + 공개 배포본 버전도 같이
      const distTxt = `공개 배포본 v${latest ? latest.version : '?'}`;
      // 소스를 고쳐 버전을 올렸는데 아직 옛 코드가 돌고 있는 경우부터 알린다
      const built = await checkBuildUpdate(true);
      if (built && verCmp(built, cur) > 0) {
        out.className = 'upd-result new';
        out.textContent = `새 빌드 v${built} 가 준비됐습니다 — [확장 새로고침]을 누르세요. · ${distTxt}`;
        return;
      }
      try {
        const src = await checkSourceUpdate(true);
        if (src && verCmp(src.version, cur) > 0) {
          out.className = 'upd-result new';
          out.textContent = `소스 저장소에 새 버전 v${src.version} (${src.branch}) — git pull 하세요. · ${distTxt}`;
        } else {
          out.className = 'upd-result ok';
          out.textContent = `소스 최신 (v${cur}${src && src.branch ? ' · ' + src.branch : ''}) · ${distTxt}`;
        }
      } catch (err) {
        out.className = 'upd-result err';
        const cfg = await getSrcCfg();
        out.textContent = (cfg.token ? '' : '토큰이 없어 소스 저장소를 못 읽습니다. 아래에 토큰을 저장하세요. ') + srcErrorText(err) + ` · ${distTxt}`;
      }
      return;
    }
    if (latest && verCmp(latest.version, cur) > 0) {
      out.className = 'upd-result new';
      out.textContent = `새 버전 v${latest.version} 이 나왔습니다!`;
      chrome.storage.local.set({ updSnooze: 0 });
      showUpdateBanner(latest);
    } else {
      out.className = 'upd-result ok';
      out.textContent = '최신 버전입니다 ✓';
    }
  } catch (err) {
    out.className = 'upd-result err';
    // 404 = 릴리스 저장소가 비공개거나 version.json 이 없음 (네트워크 문제가 아니다 — 2026-09 실제로 겪음)
    const m = String((err && err.message) || '').match(/^http (\d+)/);
    out.textContent = !m
      ? '확인 실패. 네트워크 상태를 확인해 주세요.'
      : m[1] === '404'
        ? '확인 실패 (404) — 릴리스 저장소가 비공개이거나 version.json 이 없습니다. 배포자에게 알려주세요.'
        : `확인 실패 (HTTP ${m[1]}) — 잠시 후 다시 시도해 주세요.`;
  }
});

// ---------- 설정 초기화 (맞춤법만 / 코코포리아만 / 둘 다) ----------
// 개인 사전(userDict)·검사 기록·방 기록·메모 같은 "데이터"는 건드리지 않는다.
const SPELL_RESET_KEYS = Object.keys(DEFAULTS).filter((k) => k !== 'userDict' && k !== 'ignoreWords');
const COCO_RESET_KEYS = [
  'theme', 'accentColor', 'uiDesign', 'helpOn',
  'ccfNotify', 'notifySound', 'notifyDesktop', 'notifyTabs', 'notifyMention', 'notifyMentionWords', 'notifyMentionMyChars',
  'ccfPanel', 'ccfHome', 'ccfReplaceOn',
  'replaceRules', 'replaceSites', 'specialChars',
  'cocofoOrder', 'noticePos', 'noticeFont',
  'standingThumb', 'standingCols', 'standingCss', 'standingAtPrefix', 'wardrobeLayout', 'standingHideOutfit', 'standingSharpen',
  'standingSort', 'standingSortReverse', 'standingColsFixed', 'standingFollowSpeaker', 'standingSaveAllChars', 'standingThumbPerOutfit',
];

// 저장한 "내용"은 설정과 따로 둔다 — 토글을 켰을 때만 함께 지운다.
// 로그 스튜디오(logSettings·프리셋·배경 이미지·수집한 로그)는 어느 쪽이든 건드리지 않는다.
const SPELL_DATA_KEYS = ['userDict', 'ignoreWords', 'history'];
const COCO_DATA_KEYS = ['rooms', 'savedRoomOrder', 'charColors'];

// 방별 자동 백업은 방마다 키가 따로다 (autoBackupData_<방ID>)
function roomBackupKeys(all) {
  return Object.keys(all || {}).filter((k) => k === 'autoBackupData' || k.startsWith('autoBackupData_'));
}

async function resetSettings(keys, dataKeys, label) {
  if (!EXT) return;
  const withData = $('resetData').checked;
  const msg = withData
    ? `${label} 설정을 기본값으로 되돌리고, 저장한 내용도 지울까요?

` +
      `설정 + ${label === '코코포리아' ? '방 기록·메모·캐릭터 색상' : label === '맞춤법 검사' ? '개인 사전·검사 제외 단어·검사 기록' : '개인 사전·검사 제외 단어·검사 기록·방 기록·메모'}
` +
      `(로그 스튜디오 설정과 수집한 로그는 그대로 둡니다)

되돌릴 수 없습니다.`
    : `${label} 설정을 기본값으로 되돌릴까요?
(개인 사전·검사 제외 단어·검사 기록·방 기록·메모와 로그 스튜디오는 그대로 둡니다)`;
  if (!confirm(msg)) return;

  let all = [...keys];
  if (withData) {
    all = all.concat(dataKeys);
    if (dataKeys.includes('rooms')) {
      // 방 자동 백업본도 방 기록과 함께 지운다
      const stored = await new Promise((r) => chrome.storage.local.get(null, (d) => r(chrome.runtime.lastError ? {} : d)));
      all = all.concat(roomBackupKeys(stored));
      // 방마다 따로 둔 캐릭터 기록(스탠딩 · 시트 …)도
      all = all.concat(Object.keys(stored).filter((k) => k.startsWith('roomChars:')));
    }
  }
  chrome.storage.local.remove(all, () => {
    chrome.storage.sync.remove(all, () => {
      savePopupResume(); // 초기화 뒤에도 설정 화면에 그대로 있게
      location.reload(); // 기본값으로 다시 그린다
    });
  });
}

$('resetSpellBtn').addEventListener('click', () => resetSettings(SPELL_RESET_KEYS, SPELL_DATA_KEYS, '맞춤법 검사'));
$('resetCocoBtn').addEventListener('click', () => resetSettings(COCO_RESET_KEYS, COCO_DATA_KEYS, '코코포리아'));
$('resetAllBtn').addEventListener('click', () =>
  resetSettings(
    [...SPELL_RESET_KEYS, ...COCO_RESET_KEYS, 'updNotify', 'updAutoReload'],
    [...SPELL_DATA_KEYS, ...COCO_DATA_KEYS],
    '맞춤법 검사·코코포리아 모두'
  )
);

// ---------- 코코포리아 탭: 섹션 접기 + 순서 ----------
const SEC_NAMES = { tools: '도구', rooms: '방 기록', split: '화면 분할', colors: '캐릭터 색상' };
// 배포본(dist)에는 화면 분할 섹션이 없다 (lib/edition.js)
const SEC_DEFAULT = window.CST_LITE ? ['tools', 'rooms', 'colors'] : ['tools', 'rooms', 'split', 'colors'];
let secOrderState = [...SEC_DEFAULT];
let secCollapsed = {};

// 예전에 저장된 순서에는 '도구'가 없다. 빠진 것은 뒤에 붙이고 모르는 것은 버린다.
function normalizeSecOrder(saved) {
  const out = Array.isArray(saved) ? saved.filter((k) => SEC_DEFAULT.includes(k)) : [];
  for (const k of SEC_DEFAULT) if (!out.includes(k)) out.push(k);
  return out;
}

function applySectionLayout() {
  // 순서
  const secs = {};
  cocofoView.querySelectorAll('.coco-sec').forEach((s) => (secs[s.dataset.sec] = s));
  for (const key of secOrderState) {
    if (secs[key]) cocofoView.appendChild(secs[key]);
  }
  // 접기 상태
  cocofoView.querySelectorAll('.coco-sec').forEach((s) => {
    s.classList.toggle('collapsed', !!secCollapsed[s.dataset.sec]);
  });
}

function toggleSection(sec) {
  const key = sec.dataset.sec;
  secCollapsed[key] = !secCollapsed[key];
  sec.classList.toggle('collapsed', secCollapsed[key]);
  if (EXT) chrome.storage.sync.set({ cocofoCollapsed: secCollapsed });
}

cocofoView.querySelectorAll('.sec-collapse').forEach((btn) => {
  btn.addEventListener('click', () => toggleSection(btn.closest('.coco-sec')));
});

// 섹션 제목 클릭으로도 접기/펼치기
cocofoView.querySelectorAll('.coco-sec .settings-title').forEach((title) => {
  title.classList.add('sec-title-clickable');
  title.addEventListener('click', () => toggleSection(title.closest('.coco-sec')));
});

// ---------- 코코포리아 탭: 방 기록 ----------
let roomSubTab = 'recent'; // 'recent' | 'saved'
let roomView = 'thumb'; // 'thumb' | 'list'

document.querySelectorAll('.room-subtab').forEach((b) => {
  b.addEventListener('click', () => {
    roomSubTab = b.dataset.sub;
    document.querySelectorAll('.room-subtab').forEach((x) => x.classList.toggle('active', x === b));
    renderRooms();
  });
});

$('roomViewToggle').addEventListener('click', () => {
  roomView = roomView === 'thumb' ? 'list' : 'thumb';
  if (EXT) chrome.storage.sync.set({ roomView });
  renderRooms();
});

function openExtPage(path) {
  if (EXT && chrome.tabs) chrome.tabs.create({ url: chrome.runtime.getURL(path) });
}

$('openStudio').addEventListener('click', () => openExtPage('studio/studio.html'));
$('openManager').addEventListener('click', () => openExtPage('manager/manager.html'));
$('openChargen').addEventListener('click', () => openExtPage('chargen/chargen.html'));
// 세션 관리자의 '전체 백업 · 복원' 화면으로 바로 들어간다
$('openBackup').addEventListener('click', () => openExtPage('manager/manager.html#backup'));

// 자동 업데이트 — 배포본 zip 을 설치 폴더에 덮어쓰는 화면.
// 개인용에서도 열 수 있게 둔다 (개인용은 소스로 갱신하지만, 로드해 둔 배포본 폴더는 여기서 갱신한다).
// 화면 자체가 개인용 폴더·소스 폴더는 거부하므로 잘못 덮어쓸 일은 없다.
$('autoUpdBtn').addEventListener('click', () => openExtPage('update/update.html'));
// 설치 폴더 열기 — 확장은 자기 폴더 경로를 몰라 탐색기를 바로 못 연다. 확장 관리 화면의 이 확장 세부정보에서 '소스' 경로를 누르면 열린다
$('autoUpdDirBtn').addEventListener('click', () => {
  if (EXT && chrome.tabs) chrome.tabs.create({ url: `chrome://extensions/?id=${chrome.runtime.id}` });
});
$('updateAuto').addEventListener('click', () => openExtPage('update/update.html'));
$('autoUpdRow').classList.remove('hidden');
if (ACTS_DIST && !IS_DEV_BUILD) $('updateAuto').classList.remove('hidden'); // 개발판에는 배너가 없다

// 배포본(dist)에는 캐릭터 생성기 · 전체 백업 · 화면 분할 · 로그 수집이 없다 (lib/edition.js)
if (window.CST_LITE) {
  $('openChargen').classList.add('hidden');
  $('openBackup').classList.add('hidden');
  // 수집 기능이 없으니 스튜디오는 '코코포리아가 내보낸 파일'을 다루는 도구로 안내한다
  const studioDesc = document.querySelector('#openStudio .tool-desc');
  if (studioDesc) studioDesc.textContent = '내보낸 로그 꾸미고 저장';
  const splitSec = document.querySelector('.coco-sec[data-sec="split"]');
  if (splitSec) splitSec.classList.add('hidden');
}

async function toggleBookmark(roomId) {
  const { rooms, savedRoomOrder } = await getLocal({ rooms: {}, savedRoomOrder: [] });
  if (!rooms[roomId]) return;
  const on = !rooms[roomId].favorite;
  rooms[roomId].favorite = on;
  let order = savedRoomOrder.filter((id) => id !== roomId);
  if (on) order.push(roomId);
  await setLocalP({ rooms, savedRoomOrder: order });
  renderRooms();
}

async function renderRooms() {
  const { rooms, savedRoomOrder } = await getLocal({ rooms: {}, savedRoomOrder: [] });
  const grid = $('roomGrid');
  grid.innerHTML = '';
  grid.classList.toggle('list-mode', roomView === 'list');
  $('roomViewToggle').innerHTML =
    roomView === 'thumb' ? faIcon('list') + ' 리스트로' : faIcon('grid') + ' 썸네일로';

  let entries;
  if (roomSubTab === 'recent') {
    entries = Object.entries(rooms || {}).sort((a, b) => (b[1].lastVisit || 0) - (a[1].lastVisit || 0));
  } else {
    const ordered = savedRoomOrder.filter((id) => rooms[id] && rooms[id].favorite);
    const orderedSet = new Set(ordered);
    for (const [id, r] of Object.entries(rooms || {})) {
      if (r.favorite && !orderedSet.has(id)) ordered.push(id);
    }
    entries = ordered.map((id) => [id, rooms[id]]);
  }

  if (!entries.length) {
    const empty = document.createElement('div');
    empty.className = 'room-empty';
    empty.textContent =
      roomSubTab === 'recent'
        ? '아직 방문한 방이 없습니다. 코코포리아 방에 들어가면 자동으로 기록돼요.'
        : '저장된 방이 없습니다. 방의 책갈피 버튼을 누르면 여기 저장돼요.';
    grid.appendChild(empty);
    return;
  }

  entries.forEach(([roomId, room], idx) => {
    grid.appendChild(roomItem(roomId, room, idx, entries));
  });
}

function roomItem(roomId, room, idx, entries) {
  const isList = roomView === 'list';
  const card = document.createElement('div');
  card.className = isList ? 'room-row' : 'room-card';
  card.title = room.name || roomId;

  const thumb = document.createElement('div');
  thumb.className = isList ? 'room-row-thumb' : 'room-thumb';
  if (room.thumb) {
    const img = document.createElement('img');
    img.loading = 'lazy'; // 방이 많아도 화면에 든 카드만 썸네일 요청
    img.decoding = 'async';
    img.src = room.thumb;
    img.addEventListener('error', () => {
      img.remove();
      thumb.innerHTML = faIcon('dice');
    });
    thumb.appendChild(img);
  } else {
    thumb.innerHTML = faIcon('dice');
  }

  const name = document.createElement('span');
  name.className = 'room-name';
  name.textContent = room.name || '이름 없는 방';

  const date = document.createElement('span');
  date.className = 'room-date';
  date.textContent = fmtDateShort(room.lastVisit);

  const bk = document.createElement('button');
  bk.className = (isList ? 'room-row-btn' : 'room-fav') + (room.favorite ? ' on' : '');
  bk.innerHTML = faIcon('bookmark');
  bk.title = room.favorite ? '저장 해제' : '저장된 방에 추가 (책갈피)';
  bk.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleBookmark(roomId);
  });

  const del = document.createElement('button');
  del.className = isList ? 'room-row-btn' : 'room-del';
  del.innerHTML = faIcon('xmark');
  del.title = '기록 삭제';
  del.addEventListener('click', async (e) => {
    e.stopPropagation();
    if (!confirm(`"${room.name || roomId}" 기록을 삭제할까요?\n(저장된 스탠딩·메모도 함께 삭제됩니다)`)) return;
    const { savedRoomOrder } = await getLocal({ savedRoomOrder: [] });
    await globalThis.CSTRoomStore.removeRoom(roomId, { savedRoomOrder: savedRoomOrder.filter((id) => id !== roomId) });
    renderRooms();
  });

  const memoBtn = document.createElement('button');
  memoBtn.className = (isList ? 'room-row-btn' : 'room-memo-btn') + (room.memo ? ' has-memo' : '');
  memoBtn.innerHTML = faIcon('pen');
  memoBtn.title = '방 메모 편집';
  // 호버하면 읽기용으로 자동 펼침, 클릭(또는 연필 버튼)하면 편집 모드
  const memoView = document.createElement('div');
  memoView.className = 'room-memoview' + (room.memo ? '' : ' memo-none');
  const memoText = document.createElement('div');
  memoText.className = 'room-memotext';
  memoText.textContent = room.memo || '';
  memoView.appendChild(memoText);

  function openMemoEditor() {
    if (card.classList.contains('memo-editing')) return;
    card.classList.add('memo-editing');
    memoView.innerHTML = '';
    const ta = document.createElement('textarea');
    ta.placeholder = '이 방 메모 (자동 저장)';
    ta.value = room.memo || '';
    const saved = document.createElement('div');
    saved.className = 'room-memo-saved';
    let t = 0;
    ta.addEventListener('input', () => {
      clearTimeout(t);
      saved.textContent = '입력 중…';
      t = setTimeout(async () => {
        const { rooms: cur } = await getLocal({ rooms: {} });
        if (cur[roomId]) {
          cur[roomId].memo = ta.value;
          await setLocalP({ rooms: cur });
        }
        room.memo = ta.value;
        memoBtn.classList.toggle('has-memo', !!ta.value);
        saved.textContent = '저장됨 ✓';
      }, 500);
    });
    ta.addEventListener('blur', () => {
      setTimeout(() => {
        card.classList.remove('memo-editing');
        memoView.innerHTML = '';
        memoText.textContent = room.memo || '';
        memoView.appendChild(memoText);
        memoView.classList.toggle('memo-none', !room.memo);
      }, 150);
    });
    ta.addEventListener('click', (ev) => ev.stopPropagation());
    memoView.append(ta, saved);
    ta.focus();
  }

  memoView.addEventListener('click', (ev) => {
    ev.stopPropagation();
    openMemoEditor();
  });
  memoBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    openMemoEditor();
  });
  card.appendChild(memoView);

  if (isList) {
    card.append(thumb, name, date, memoBtn, bk, del);
  } else {
    card.append(thumb, name, date, bk, del, memoBtn);
  }

  card.addEventListener('click', () => {
    const url = room.url || 'https://ccfolia.com/rooms/' + roomId;
    if (EXT && chrome.tabs) chrome.tabs.create({ url });
    else window.open(url);
  });

  // 저장된 방: 드래그로 순서 변경
  if (roomSubTab === 'saved') {
    card.draggable = true;
    card.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('text/plain', String(idx));
      card.classList.add('dragging');
    });
    card.addEventListener('dragend', () => card.classList.remove('dragging'));
    card.addEventListener('dragover', (e) => {
      e.preventDefault();
      card.classList.add('dragover');
    });
    card.addEventListener('dragleave', () => card.classList.remove('dragover'));
    card.addEventListener('drop', async (e) => {
      e.preventDefault();
      card.classList.remove('dragover');
      const fromIdx = Number(e.dataTransfer.getData('text/plain'));
      if (Number.isNaN(fromIdx) || fromIdx === idx) return;
      const order = entries.map(([id]) => id);
      const [moved] = order.splice(fromIdx, 1);
      order.splice(idx, 0, moved);
      await setLocalP({ savedRoomOrder: order });
      renderRooms();
    });
  }

  return card;
}

// ---------- 코코포리아 탭: 화면 분할 (같은 방 멀티 창) ----------
let splitTarget = null; // { tabId } | { url }

async function renderSplitTarget() {
  const box = $('splitTarget');
  box.innerHTML = '';
  splitTarget = null;

  let openTabs = [];
  if (EXT && chrome.tabs) {
    try {
      openTabs = await chrome.tabs.query({
        url: ['https://ccfolia.com/rooms/*', 'https://*.ccfolia.com/rooms/*'],
      });
    } catch (_) {}
  }
  const { rooms } = await getLocal({ rooms: {} });
  const recent = Object.entries(rooms || {})
    .sort((a, b) => (b[1].lastVisit || 0) - (a[1].lastVisit || 0))
    .slice(0, 8);

  function addOption(value, labelText, thumbUrl, checked) {
    const label = document.createElement('label');
    label.className = 'split-room';
    const rb = document.createElement('input');
    rb.type = 'radio';
    rb.name = 'splitTarget';
    rb.checked = !!checked;
    rb.addEventListener('change', () => {
      if (rb.checked) {
        splitTarget = value;
        updateSplitButtons();
      }
    });
    if (checked) splitTarget = value;
    const name = document.createElement('span');
    name.className = 'split-room-name';
    name.textContent = labelText;
    if (thumbUrl) {
      const img = document.createElement('img');
      img.className = 'room-mini-thumb';
      img.src = thumbUrl;
      img.addEventListener('error', () => (img.style.visibility = 'hidden'));
      label.append(rb, img, name);
    } else {
      label.append(rb, name);
    }
    box.appendChild(label);
  }

  let first = true;
  for (const tab of openTabs) {
    addOption({ tabId: tab.id }, '(열린 탭) ' + (tab.title || tab.url), null, first && tab.active);
    first = false;
  }
  for (const [roomId, room] of recent) {
    const url = room.url || 'https://ccfolia.com/rooms/' + roomId;
    // 이미 열린 탭과 같은 방은 중복 표시하지 않음
    if (openTabs.some((t) => (t.url || '').startsWith(url))) continue;
    addOption({ url }, room.name || '이름 없는 방', room.thumb || null, false);
  }

  if (!box.children.length) {
    const empty = document.createElement('div');
    empty.className = 'dict-empty';
    empty.textContent = '분할할 방이 없습니다. 코코포리아 방을 열어두거나 방문 기록을 만들어 주세요.';
    box.appendChild(empty);
  }

  // 라디오 하나라도 선택돼 있지 않으면 첫 항목 선택
  if (!splitTarget && box.querySelector('input[type="radio"]')) {
    const firstRb = box.querySelector('input[type="radio"]');
    firstRb.checked = true;
    firstRb.dispatchEvent(new Event('change'));
  }
  updateSplitButtons();
}

function updateSplitButtons() {
  document.querySelectorAll('.split-count-btn').forEach((b) => (b.disabled = !splitTarget));
}

document.querySelectorAll('.split-count-btn').forEach((b) => {
  b.addEventListener('click', async () => {
    if (!EXT || !splitTarget) return;
    await chrome.runtime.sendMessage({
      type: 'SPLIT_SAME',
      target: splitTarget,
      count: Number(b.dataset.n),
      screen: {
        availLeft: window.screen.availLeft || 0,
        availTop: window.screen.availTop || 0,
        availWidth: window.screen.availWidth,
        availHeight: window.screen.availHeight,
      },
    });
    window.close();
  });
});

// ---------- 코코포리아 탭: 캐릭터 색상 ----------
async function renderColors() {
  const { charColors } = await getLocal({ charColors: {} });
  const rows = $('colorRows');
  rows.innerHTML = '';
  const names = Object.keys(charColors || {});
  if (!names.length) {
    const empty = document.createElement('div');
    empty.className = 'dict-empty';
    empty.textContent = '저장된 색상이 없습니다. 위에서 캐릭터 이름과 색상을 입력해 저장하세요.';
    rows.appendChild(empty);
  }
  for (const n of names) {
    const row = document.createElement('div');
    row.className = 'color-row';
    row.title = '클릭하면 색상 코드를 복사합니다.';
    const chip = document.createElement('span');
    chip.className = 'color-chip';
    chip.style.background = charColors[n];
    const label = document.createElement('span');
    label.className = 'color-name';
    label.textContent = n;
    const hex = document.createElement('span');
    hex.className = 'color-hex';
    hex.textContent = charColors[n];
    const del = document.createElement('button');
    del.className = 'dict-del';
    del.textContent = '✕';
    del.title = '삭제';
    del.addEventListener('click', async (e) => {
      e.stopPropagation();
      const { charColors: cc } = await getLocal({ charColors: {} });
      delete cc[n];
      await setLocalP({ charColors: cc });
      renderColors();
    });
    row.append(chip, label, hex, del);
    row.addEventListener('click', () => {
      navigator.clipboard && navigator.clipboard.writeText(charColors[n]).catch(() => {});
    });
    rows.appendChild(row);
  }
}

$('colorPick').addEventListener('input', () => ($('colorHex').value = $('colorPick').value));
$('colorHex').addEventListener('input', () => {
  const h = normalizeHex($('colorHex').value);
  if (h) $('colorPick').value = h;
});
$('colorAddBtn').addEventListener('click', async () => {
  const nm = $('colorName').value.trim();
  const hx = normalizeHex($('colorHex').value) || normalizeHex($('colorPick').value);
  if (!nm || !hx) return;
  const { charColors: cc } = await getLocal({ charColors: {} });
  cc[nm] = hx;
  await setLocalP({ charColors: cc });
  $('colorName').value = '';
  $('colorHex').value = '';
  renderColors();
});

// ---------- 코코포리아 탭 전체 렌더 ----------
async function renderCocofo() {
  const s = await getSyncP({ roomView: 'thumb', cocofoOrder: SEC_DEFAULT, cocofoCollapsed: {} });
  roomView = s.roomView === 'list' ? 'list' : 'thumb';
  secOrderState = normalizeSecOrder(s.cocofoOrder);
  secCollapsed = s.cocofoCollapsed || {};
  applySectionLayout();
  renderRooms();
  renderSplitTarget();
  renderColors();
}

// ---------- 테마 그룹 DOM 이동 (맞춤법 설정 ↔ 코코포 설정 양쪽에 표시) ----------
const themeGroupEl = $('themeGroup');
const spellThemeMount = $('spellThemeMount');
const themeGroupHome = document.createComment('theme-home');
if (themeGroupEl && themeGroupEl.parentElement) {
  themeGroupEl.parentElement.insertBefore(themeGroupHome, themeGroupEl);
}
// 업데이트·설정 초기화 그룹도 같은 방식으로 두 설정 화면을 오간다 (항상 맨 아래)
const updateGroupEl = $('updateGroup');
const spellUpdateMount = $('spellUpdateMount');
const updateGroupHome = document.createComment('update-home');
if (updateGroupEl && updateGroupEl.parentElement) {
  updateGroupEl.parentElement.insertBefore(updateGroupHome, updateGroupEl);
}
const resetGroupEl = $('resetGroup');
const spellResetMount = $('spellResetMount');
const resetGroupHome = document.createComment('reset-home');
if (resetGroupEl && resetGroupEl.parentElement) {
  resetGroupEl.parentElement.insertBefore(resetGroupHome, resetGroupEl);
}

function placeThemeGroup(where) {
  if (!themeGroupEl) return;
  if (where === 'spell' && spellThemeMount) {
    spellThemeMount.appendChild(themeGroupEl);
    if (updateGroupEl && spellUpdateMount) spellUpdateMount.appendChild(updateGroupEl);
    if (resetGroupEl && spellResetMount) spellResetMount.appendChild(resetGroupEl);
  } else {
    if (themeGroupHome.parentNode) {
      themeGroupHome.parentNode.insertBefore(themeGroupEl, themeGroupHome.nextSibling);
    }
    if (updateGroupEl && updateGroupHome.parentNode) {
      updateGroupHome.parentNode.insertBefore(updateGroupEl, updateGroupHome.nextSibling);
    }
    if (resetGroupEl && resetGroupHome.parentNode) {
      resetGroupHome.parentNode.insertBefore(resetGroupEl, resetGroupHome.nextSibling);
    }
  }
}

// ---------- 테마 (4종 + 포인트색) ----------
const THEMES = ['dark', 'light', 'mono', 'retro'];
const THEME_DEFAULT_ACCENT = {
  dark: '#e05252',
  light: '#d94848',
  mono: '#e8e8ec',
  retro: '#c94434',
};
let curTheme = 'dark';
let curAccent = '';

function applyThemeUI() {
  for (const t of THEMES) document.body.classList.toggle('theme-' + t, curTheme === t && t !== 'dark');
  const a = normalizeHex(curAccent);
  if (a) {
    document.body.style.setProperty('--accent', a);
    document.body.style.setProperty('--accent-dark', darkenHex(a));
    document.body.style.setProperty('--accent-soft', hexToSoft(a));
  } else {
    document.body.style.removeProperty('--accent');
    document.body.style.removeProperty('--accent-dark');
    document.body.style.removeProperty('--accent-soft');
  }
  document
    .querySelectorAll('.theme-btn')
    .forEach((b) => b.classList.toggle('selected', b.dataset.theme === curTheme));
  saveSkinBoot();
  const pick = $('accentPick');
  if (pick) {
    pick.value = a || THEME_DEFAULT_ACCENT[curTheme] || '#e05252';
    $('accentCode').textContent = a ? a + ' (커스텀)' : '테마 기본색';
  }
}

document.querySelectorAll('.theme-btn').forEach((b) => {
  b.addEventListener('click', () => {
    curTheme = b.dataset.theme;
    applyThemeUI();
    saveCoco({ theme: curTheme });
  });
});

// ---------- 디자인 (기본 / 디자인 2 = 왼쪽 세로 레일) ----------
// 팝업과 방 안 헬퍼 패널이 같은 값을 본다.
const DESIGNS = ['basic', 'rail'];
let curDesign = 'basic';

function applyDesignUI() {
  document.body.classList.toggle('design-rail', curDesign === 'rail');
  document
    .querySelectorAll('.design-btn[data-design]') // 옷장 보기 단추는 따로 칠한다
    .forEach((b) => b.classList.toggle('active', b.dataset.design === curDesign));
  saveSkinBoot();
}

// 다음 팝업의 FOUC 방지용 미러 (맨 위 부팅 스니펫이 읽는다)
function saveSkinBoot() {
  try {
    localStorage.setItem('cstSkinBoot', JSON.stringify({ theme: curTheme, accent: normalizeHex(curAccent), design: curDesign }));
  } catch (_) {}
}

document.querySelectorAll('.design-btn[data-design]').forEach((b) => {
  b.addEventListener('click', () => {
    curDesign = b.dataset.design;
    applyDesignUI();
    saveCoco({ uiDesign: curDesign });
  });
});


$('accentPick').addEventListener('input', () => {
  curAccent = $('accentPick').value;
  applyThemeUI();
});
$('accentPick').addEventListener('change', () => {
  saveCoco({ accentColor: curAccent });
});
$('accentReset').addEventListener('click', () => {
  curAccent = '';
  applyThemeUI();
  saveCoco({ accentColor: '' });
});

// ---------- 코코포 설정 ----------
const cocoSetSaved = savedNote;
let cocoRules = [];
let editingRule = -1; // 지금 고치고 있는 대치 규칙 (없으면 -1)

function cocoFlash(msg) {
  cocoSetSaved.textContent = msg || '저장되었습니다 ✓';
  cocoSetSaved.classList.add('flash');
  setTimeout(() => {
    restoreFootNote();
    cocoSetSaved.classList.remove('flash');
  }, 1200);
}

function saveCoco(partial) {
  if (!EXT) return;
  chrome.storage.sync.set(partial, cocoFlash);
}

// 섹션 순서: 위아래 버튼 대신 드래그로 (행을 잡아 끌면 자리가 바뀐다)
function renderSecOrder() {
  const box = $('secOrder');
  box.innerHTML = '';
  secOrderState.forEach((key, i) => {
    const row = document.createElement('div');
    row.className = 'sec-order-row';
    row.draggable = true;
    row.dataset.key = key;
    const grip = document.createElement('span');
    grip.className = 'sec-order-grip';
    grip.textContent = '⠿';
    const name = document.createElement('span');
    name.className = 'sec-order-name';
    name.textContent = `${i + 1}. ${SEC_NAMES[key] || key}`;
    row.append(grip, name);
    row.addEventListener('dragstart', (e) => {
      row.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
      try { e.dataTransfer.setData('text/plain', key); } catch (_) {}
    });
    row.addEventListener('dragend', () => {
      row.classList.remove('dragging');
      const next = [...box.querySelectorAll('.sec-order-row')].map((r) => r.dataset.key);
      if (next.join() !== secOrderState.join()) {
        secOrderState = next;
        saveCoco({ cocofoOrder: secOrderState });
        applySectionLayout();
      }
      renderSecOrder(); // 번호 다시 매기기
    });
    box.appendChild(row);
  });
  if (!box.__cstDragBound) {
    box.__cstDragBound = true;
    box.addEventListener('dragover', (e) => {
      e.preventDefault();
      const dragging = box.querySelector('.sec-order-row.dragging');
      if (!dragging) return;
      const rows = [...box.querySelectorAll('.sec-order-row:not(.dragging)')];
      const after = rows.find((r) => e.clientY < r.getBoundingClientRect().top + r.offsetHeight / 2);
      if (after) box.insertBefore(dragging, after);
      else box.appendChild(dragging);
    });
  }
}

async function loadCocoSettings() {
  placeThemeGroup('coco'); // 테마 그룹을 코코포 설정 자리로 복귀
  const s = await getSyncP({
    theme: 'dark',
    accentColor: '',
    ccfNotify: true,
    notifySound: true,
    notifyDesktop: false,
    notifyTabs: [],
    notifyMention: false,
    notifyMentionWords: [],
    notifyMentionMyChars: true,
    ccfPanel: true,
    ccfHome: true,
    ccfReplaceOn: true,
    replaceRules: COCO_DEFAULT_RULES,
    replaceSites: [],
    specialChars: COCO_DEFAULT_CHARS,
    cocofoOrder: SEC_DEFAULT,
    uiDesign: 'basic',
    helpOn: true,
  });
  applyHelpOn(s.helpOn !== false);
  curTheme = THEMES.includes(s.theme) ? s.theme : 'dark';
  curAccent = s.accentColor || '';
  curDesign = DESIGNS.includes(s.uiDesign) ? s.uiDesign : 'basic';
  applyThemeUI();
  applyDesignUI();
  secOrderState = normalizeSecOrder(s.cocofoOrder);
  renderSecOrder();
  $('setNotify').checked = s.ccfNotify !== false;
  $('setNotifySound').checked = s.notifySound !== false;
  $('setNotifyDesktop').checked = !!s.notifyDesktop;
  $('setNotifyTabs').value = (Array.isArray(s.notifyTabs) ? s.notifyTabs : []).join(', ');
  $('setNotifyMention').checked = !!s.notifyMention;
  $('setNotifyWords').value = (Array.isArray(s.notifyMentionWords) ? s.notifyMentionWords : []).join(', ');
  $('setNotifyMyChars').checked = s.notifyMentionMyChars !== false;
  syncNotifyOpts();
  if (s.notifyDesktop) verifyNotifyPermission();
  $('setPanel').checked = s.ccfPanel !== false;
  $('setHome').checked = s.ccfHome !== false;
  $('setReplace').checked = s.ccfReplaceOn !== false;
  $('setReplaceSites').value = (s.replaceSites || []).join('\n');
  $('setChars').value = (s.specialChars || COCO_DEFAULT_CHARS).join(' ');
  cocoRules = Array.isArray(s.replaceRules) ? s.replaceRules : COCO_DEFAULT_RULES;
  renderRules();
}

$('setNotify').addEventListener('change', () => {
  saveCoco({ ccfNotify: $('setNotify').checked });
  syncNotifyOpts();
});

// ---- 알림 세부 옵션 (v12.0) ----
function syncNotifyOpts() {
  $('notifyOpts').classList.toggle('hidden', !$('setNotify').checked);
  $('notifyMentionOpts').classList.toggle('hidden', !$('setNotifyMention').checked);
  // 언급으로 볼 단어가 하나도 없으면 이 필터는 아무 것도 거르지 못한다 — 그 사실을 알려 준다
  const note = $('notifyMentionNote');
  if (!note) return;
  const hasWords = splitList($('setNotifyWords').value).length > 0;
  const useMine = $('setNotifyMyChars').checked;
  let text = '';
  if (!hasWords && !useMine) text = '언급으로 볼 단어가 없습니다 — 지금은 모든 새 채팅에 알립니다.';
  else if (!hasWords) text = '내 캐릭터 이름으로만 판단합니다. 아직 캐릭터를 못 찾은 방에서는 모든 새 채팅에 알립니다.';
  note.textContent = text;
  note.classList.toggle('hidden', !text);
}

function splitList(v) {
  return String(v || '')
    .split(/[,\n，]+/)
    .map((x) => x.trim())
    .filter(Boolean);
}

// 데스크톱 알림은 optional 권한 — 켜는 순간(사용자 클릭) 요청해야 한다
async function verifyNotifyPermission() {
  if (!EXT || !chrome.permissions) return true;
  try {
    const has = await chrome.permissions.contains({ permissions: ['notifications'] });
    const note = $('notifyPermNote');
    if (!has) {
      note.textContent = '데스크톱 알림 권한이 꺼져 있어요. 스위치를 껐다 다시 켜면 권한을 물어봅니다.';
      note.classList.remove('hidden');
    } else {
      note.classList.add('hidden');
    }
    return has;
  } catch (_) {
    return false;
  }
}

$('setNotifySound').addEventListener('change', () => saveCoco({ notifySound: $('setNotifySound').checked }));
$('setNotifyDesktop').addEventListener('change', async () => {
  const on = $('setNotifyDesktop').checked;
  const note = $('notifyPermNote');
  if (on && EXT && chrome.permissions) {
    let granted = false;
    try {
      granted = await chrome.permissions.request({ permissions: ['notifications'] });
    } catch (err) {
      note.textContent = '권한 요청 실패: ' + String((err && err.message) || err);
      note.classList.remove('hidden');
    }
    if (!granted) {
      $('setNotifyDesktop').checked = false;
      saveCoco({ notifyDesktop: false });
      note.textContent = '권한을 허용하지 않아 데스크톱 알림을 켜지 못했어요.';
      note.classList.remove('hidden');
      return;
    }
    note.classList.add('hidden');
  }
  saveCoco({ notifyDesktop: on });
});
let notifyTabsTimer = 0;
$('setNotifyTabs').addEventListener('input', () => {
  clearTimeout(notifyTabsTimer);
  notifyTabsTimer = setTimeout(() => saveCoco({ notifyTabs: splitList($('setNotifyTabs').value) }), 500);
});
$('setNotifyMention').addEventListener('change', () => {
  saveCoco({ notifyMention: $('setNotifyMention').checked });
  syncNotifyOpts();
});
let notifyWordsTimer = 0;
$('setNotifyWords').addEventListener('input', () => {
  clearTimeout(notifyWordsTimer);
  notifyWordsTimer = setTimeout(() => saveCoco({ notifyMentionWords: splitList($('setNotifyWords').value) }), 500);
  syncNotifyOpts();
});
$('setNotifyMyChars').addEventListener('change', () => {
  saveCoco({ notifyMentionMyChars: $('setNotifyMyChars').checked });
  syncNotifyOpts();
});
$('setPanel').addEventListener('change', () => saveCoco({ ccfPanel: $('setPanel').checked }));
$('setHome').addEventListener('change', () => saveCoco({ ccfHome: $('setHome').checked }));
// 고정 메모 위치·글자 크기 설정은 방 안 패널의 메모 탭으로 이동 (v9.2)
$('setReplace').addEventListener('change', () => saveCoco({ ccfReplaceOn: $('setReplace').checked }));
// 설명 표시 — 맞춤법 설정과 코코포리아 설정 어디서 켜고 꺼도 같은 값을 쓴다
function applyHelpOn(on, save) {
  $('setHelpOn').checked = on;
  $('setHelpOnSpell').checked = on;
  document.body.classList.toggle('help-off', !on);
  if (save) saveCoco({ helpOn: on });
}

$('setHelpOn').addEventListener('change', () => applyHelpOn($('setHelpOn').checked, true));
$('setHelpOnSpell').addEventListener('change', () => applyHelpOn($('setHelpOnSpell').checked, true));

let sitesTimer = 0;
$('setReplaceSites').addEventListener('input', () => {
  clearTimeout(sitesTimer);
  sitesTimer = setTimeout(() => {
    const sites = $('setReplaceSites')
      .value.split('\n')
      .map((s) => s.trim())
      .filter(Boolean);
    saveCoco({ replaceSites: sites });
  }, 500);
});

let charsTimer = 0;
$('setChars').addEventListener('input', () => {
  clearTimeout(charsTimer);
  charsTimer = setTimeout(() => {
    const chars = $('setChars').value.split(/\s+/).filter(Boolean);
    saveCoco({ specialChars: chars });
  }, 500);
});

$('charsReset').addEventListener('click', () => {
  $('setChars').value = COCO_DEFAULT_CHARS.join(' ');
  saveCoco({ specialChars: COCO_DEFAULT_CHARS });
});

// 규칙 종류: plain(일반) | regex(정규식) | snippet(스니펫)
const RULE_KIND_LABEL = { plain: '일반', regex: '정규식', snippet: '스니펫' };
const RULE_HINTS = {
  plain: '입력한 글자가 그대로 바뀝니다. 예: ... → …',
  regex: '글자 모양으로 찾아 바꿉니다. \\d=숫자 한 글자, +=하나 이상, ( )로 묶으면 $1 $2로 다시 씁니다. 예: (\\d+)d(\\d+) → $1D$2 (3d6 → 3D6)',
  snippet: ';약어를 치고 스페이스나 Tab을 누르면 펼쳐집니다 (여러 줄 가능). {날짜}→2026.09.15 {시간}→21:07 {요일}→월. 예: ;kp → 【KP】',
};
const RULE_PLACEHOLDER = {
  plain: ['입력 (예: ...)', '변환 (예: …)'],
  regex: ['패턴 (예: (\\d+)d(\\d+))', '치환 (예: $1D$2)'],
  snippet: ['약어 (예: ;kp)', '펼칠 문장 (Shift+Enter로 줄바꿈)'],
};

function ruleKindOf(r) {
  return r && (r.kind === 'regex' || r.kind === 'snippet') ? r.kind : 'plain';
}

function updateRuleHint() {
  const k = $('ruleKind').value;
  $('ruleHint').textContent = RULE_HINTS[k] || '';
  $('ruleFrom').placeholder = RULE_PLACEHOLDER[k][0];
  $('ruleTo').placeholder = RULE_PLACEHOLDER[k][1];
}
$('ruleKind').addEventListener('change', () => {
  testEdited = false; // 종류를 바꾸면 시험 문장도 그 종류에 맞게 다시 채운다
  updateRuleHint();
  updateRulePreview();
});
$('ruleFrom').addEventListener('input', updateRulePreview);
$('ruleTo').addEventListener('input', updateRulePreview);
$('ruleTest').addEventListener('input', () => {
  testEdited = true;
  updateRulePreview();
});
updateRuleHint();

// ---------- 대치 규칙 미리보기 ----------
// 지금 적고 있는 규칙이 실제로 어떻게 바뀌는지 아래에 바로 보여 준다.
// 판정은 방 안에서 도는 content/replace.js 와 같은 규칙으로 맞춘다
// (스니펫은 ;약어 뒤에 스페이스, 정규식은 커서 앞부분에 적용).
function expandSnippetPreview(to) {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  const WEEK = ['일', '월', '화', '수', '목', '금', '토'];
  return String(to)
    .replace(/\{날짜\}/g, `${d.getFullYear()}.${p(d.getMonth() + 1)}.${p(d.getDate())}`)
    .replace(/\{시간\}/g, `${p(d.getHours())}:${p(d.getMinutes())}`)
    .replace(/\{요일\}/g, WEEK[d.getDay()]);
}

// 시험 문장에 규칙 하나를 적용해 본다. 반환: { out, hit }
function applyRulePreview(kind, from, to, text) {
  if (!from) return { out: text, hit: false };
  if (kind === 'snippet') {
    // ";kp " 처럼 약어 뒤에 공백이 있을 때 펼친다 (앞은 문장 처음이거나 공백)
    const re = new RegExp('(^|\\s)' + from.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(?=\\s|$)');
    const m = text.match(re);
    if (!m) return { out: text, hit: false };
    return { out: text.replace(re, (all, pre) => pre + expandSnippetPreview(to)), hit: true };
  }
  if (kind === 'regex') {
    let re;
    try {
      re = new RegExp('(?:' + from + ')$');
    } catch (_) {
      return { out: text, hit: false, bad: true };
    }
    if (!re.test(text)) return { out: text, hit: false };
    const out = text.replace(re, to);
    return { out, hit: out !== text };
  }
  if (!text.includes(from)) return { out: text, hit: false };
  return { out: text.split(from).join(to), hit: true };
}

// 시험 문장 기본값 — 종류·입력에 맞춰 알아서 채워 준다
function defaultTestText(kind, from) {
  if (!from) return '';
  if (kind === 'snippet') return from + ' ';
  if (kind === 'regex') {
    const guess = from
      .replace(/\((.*?)\)/g, '$1')
      .replace(/\\d\+/g, '3')
      .replace(/\\d/g, '6')
      .replace(/\{\d+,?\d*\}/g, '')
      .replace(/[+*?^$]/g, '');
    return guess;
  }
  return from;
}

let testEdited = false;

function updateRulePreview() {
  const box = $('rulePreview');
  if (!box) return;
  const kind = $('ruleKind').value;
  const from = $('ruleFrom').value;
  const to = $('ruleTo').value;
  const test = $('ruleTest');
  if (!testEdited) test.value = defaultTestText(kind, from);
  test.placeholder = kind === 'snippet' ? '예: 안녕 ' + (from || ';kp') + ' ' : '여기에 쳐 보세요';
  const r = applyRulePreview(kind, from, to, test.value);
  const out = $('ruleTestOut');
  out.classList.toggle('miss', !r.hit);
  out.textContent = !from || !to
    ? '규칙을 채우면 결과가 여기에 보입니다.'
    : r.bad
      ? '정규식을 아직 읽을 수 없습니다.'
      : r.hit
        ? r.out
        : '이 문장에는 걸리지 않습니다.';
}

// 자주 쓰는 규칙 — 고르면 아래 입력칸에 채워진다 (바로 [추가] 하거나 고쳐서 써도 된다).
// 정규식·스니펫을 글로 설명하는 것보다 예시를 만져 보는 쪽이 빠르다.
const RULE_SAMPLES = [
  ['plain', '...', '…', '점 세 개를 말줄임표로'],
  ['plain', '--', '—', '하이픈 두 개를 대시로'],
  ['regex', 'ㅋ{4,}', 'ㅋㅋㅋ', 'ㅋ 을 4번 이상 치면 3번으로 정리'],
  ['regex', 'ㅎ{4,}', 'ㅎㅎㅎ', 'ㅎ 을 4번 이상 치면 3번으로 정리'],
  ['regex', '~{2,}', '〜', '물결 여러 개를 하나로'],
  ['regex', '(\\d+)d(\\d+)', '$1D$2', '3d6 → 3D6 (주사위 대문자로)'],
  ['regex', 'ccb(\\d+)', 'CCB<=$1', 'ccb60 → CCB<=60'],
  ['regex', '  +', ' ', '공백 여러 칸을 한 칸으로'],
  ['snippet', ';kp', '【KP】', '【KP】 말머리'],
  ['snippet', ';pc', '【PC】', '【PC】 말머리'],
  ['snippet', ';날', '오늘은 {날짜} {요일}요일입니다.', '{날짜}·{요일} 예시'],
  ['snippet', ';시작', '━━━━━━━━━━\n{날짜} {요일}요일 {시간} 세션 시작\n━━━━━━━━━━', '여러 줄 + 날짜·시간'],
];

function fillRuleSamples() {
  const sel = $('ruleSample');
  if (!sel) return;
  for (const [kind, from, to, why] of RULE_SAMPLES) {
    const o = document.createElement('option');
    o.value = JSON.stringify({ kind, from, to });
    o.textContent = `[${RULE_KIND_LABEL[kind] || '일반'}] ${from} → ${to.replace(/\n/g, ' ⏎ ')} · ${why}`;
    sel.appendChild(o);
  }
  sel.addEventListener('change', () => {
    if (!sel.value) return;
    let v = null;
    try {
      v = JSON.parse(sel.value);
    } catch (_) {}
    sel.value = '';
    if (!v) return;
    $('ruleKind').value = v.kind;
    updateRuleHint();
    $('ruleFrom').value = v.from;
    $('ruleTo').value = v.to;
    autoSizeRuleTo();
    testEdited = false;
    updateRulePreview();
    $('ruleHint').textContent = '예시를 채웠습니다 — 아래 미리보기로 확인하고 [추가] 하세요.';
    $('ruleTo').focus();
  });
}

// 규칙 수정 — 아래 입력칸으로 불러와 고친 뒤 제자리에 다시 넣는다 (상태는 위에서 선언)

function autoSizeRuleTo() {
  const ta = $('ruleTo');
  const lines = Math.min(6, Math.max(1, String(ta.value || '').split('\n').length));
  ta.rows = lines;
}

function startEditRule(i) {
  const r = cocoRules[i];
  if (!r) return;
  editingRule = i;
  $('ruleKind').value = ruleKindOf(r);
  updateRuleHint();
  $('ruleFrom').value = r.from;
  $('ruleTo').value = String(r.to == null ? '' : r.to); // 여러 줄은 여러 줄 그대로 보여 준다
  autoSizeRuleTo();
  updateRulePreview();
  $('ruleAddBtn').textContent = '수정';
  $('ruleCancelBtn').classList.remove('hidden');
  $('ruleHint').textContent = `"${r.from}" 규칙을 고치는 중 — [수정]을 누르면 그 자리에 저장됩니다.`;
  renderRules();
  $('ruleFrom').focus();
}

function endEditRule() {
  editingRule = -1;
  $('ruleAddBtn').textContent = '추가';
  $('ruleCancelBtn').classList.add('hidden');
  $('ruleFrom').value = '';
  $('ruleTo').value = '';
  autoSizeRuleTo();
  testEdited = false;
  updateRuleHint();
  updateRulePreview();
  renderRules();
}

$('ruleCancelBtn').addEventListener('click', endEditRule);
$('ruleTo').addEventListener('input', autoSizeRuleTo);

function renderRules() {
  const rows = $('ruleRows');
  rows.innerHTML = '';
  if (!cocoRules.length) {
    const empty = document.createElement('div');
    empty.className = 'dict-empty';
    empty.textContent = '규칙이 없습니다. 아래에서 추가해 보세요.';
    rows.appendChild(empty);
    return;
  }
  cocoRules.forEach((r, i) => {
    const kind = ruleKindOf(r);
    const row = document.createElement('div');
    row.className = 'dict-row rule-row';
    if (kind !== 'plain') {
      const badge = document.createElement('span');
      badge.className = 'rule-kind rule-kind-' + kind;
      badge.textContent = RULE_KIND_LABEL[kind];
      row.appendChild(badge);
    }
    const from = document.createElement('span');
    from.className = 'dict-from';
    from.style.textDecoration = 'none';
    from.textContent = r.from;
    from.title = r.from;
    const arrow = document.createElement('span');
    arrow.className = 'err-arrow';
    arrow.textContent = '→';
    const to = document.createElement('span');
    to.className = 'dict-to';
    const toText = String(r.to == null ? '' : r.to);
    to.textContent = toText.length > 40 ? toText.slice(0, 40).replace(/\n/g, ' ⏎ ') + '…' : toText.replace(/\n/g, ' ⏎ ');
    to.title = toText;
    const edit = document.createElement('button');
    edit.className = 'dict-del rule-edit';
    edit.textContent = '✎';
    edit.title = '수정 (아래 칸으로 불러옵니다)';
    edit.addEventListener('click', () => startEditRule(i));
    const del = document.createElement('button');
    del.className = 'dict-del';
    del.textContent = '✕';
    del.title = '삭제';
    del.addEventListener('click', () => {
      cocoRules.splice(i, 1);
      if (editingRule === i) endEditRule();
      else {
        if (editingRule > i) editingRule--;
        saveCoco({ replaceRules: cocoRules });
        renderRules();
      }
      saveCoco({ replaceRules: cocoRules });
    });
    if (i === editingRule) row.classList.add('rule-row-editing');
    row.append(from, arrow, to, edit, del);
    rows.appendChild(row);
  });
}

function addRule() {
  const kind = $('ruleKind').value;
  const from = kind === 'snippet' ? $('ruleFrom').value.trim() : $('ruleFrom').value;
  const to = $('ruleTo').value;
  if (!from || !to || (kind === 'plain' && from === to)) return;
  if (kind === 'regex') {
    try {
      new RegExp('(?:' + from + ')$');
    } catch (err) {
      $('ruleHint').textContent = '정규식 오류: ' + String((err && err.message) || err);
      return;
    }
  }
  if (kind === 'snippet' && /\s/.test(from)) {
    $('ruleHint').textContent = '스니펫 약어에는 공백을 넣을 수 없어요. (예: ;kp)';
    return;
  }
  const rule = { from, to };
  if (kind !== 'plain') rule.kind = kind;
  if (editingRule >= 0 && cocoRules[editingRule]) {
    // 수정: 자리를 지킨 채 바꾼다 (같은 내용의 다른 규칙이 있으면 그것만 지운다)
    const dup = cocoRules.findIndex((r, n) => n !== editingRule && r.from === from && ruleKindOf(r) === kind);
    cocoRules[editingRule] = rule;
    if (dup !== -1) cocoRules.splice(dup, 1);
    saveCoco({ replaceRules: cocoRules });
    const note = `"${from}" 규칙을 고쳤습니다.`;
    endEditRule();
    $('ruleHint').textContent = note;
    return;
  }
  const existing = cocoRules.findIndex((r) => r.from === from && ruleKindOf(r) === kind);
  if (existing !== -1) cocoRules.splice(existing, 1);
  cocoRules.unshift(rule);
  saveCoco({ replaceRules: cocoRules });
  renderRules();
  updateRuleHint();
  $('ruleFrom').value = '';
  $('ruleTo').value = '';
  autoSizeRuleTo();
  testEdited = false;
  updateRulePreview();
  $('ruleFrom').focus();
}

$('ruleAddBtn').addEventListener('click', addRule);
$('ruleTo').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    addRule();
  }
});
$('ruleFrom').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') $('ruleTo').focus();
});

// ---------- 허용 사이트 (optional_host_permissions, v12.0) ----------
// 콘텐트 스크립트는 코코포리아에만 기본 주입되고, 다른 사이트는 여기서 허용해야 들어간다.
const STATIC_SITE_ORIGINS = [
  'https://ccfolia.com/*',
  'https://*.ccfolia.com/*',
  'https://dic.daum.net/*',
  'https://m.search.naver.com/*',
  'https://search.naver.com/*',
  'https://www.saramin.co.kr/*',
  'https://m.incruit.com/*',
];
const ALL_SITES = ['http://*/*', 'https://*/*'];

function siteHostFromInput(v) {
  let t = String(v || '').trim().toLowerCase();
  if (!t) return '';
  t = t.replace(/^[a-z]+:\/\//, '').replace(/^\*\./, '').replace(/\/.*$/, '').replace(/:\d+$/, '');
  if (!/^[a-z0-9.-]+\.[a-z0-9-]+$/.test(t)) return '';
  return t;
}

function siteOriginsFor(host) {
  return [`*://${host}/*`, `*://*.${host}/*`];
}

function siteLabel(origin) {
  if (ALL_SITES.includes(origin) || origin === '<all_urls>') return '모든 사이트';
  const m = origin.match(/^\*?[a-z]*:?\/\/(\*\.)?([^/]+)\//);
  return m ? (m[1] ? '*.' : '') + m[2] : origin;
}

async function renderSites() {
  const rows = $('siteRows');
  if (!rows) return;
  rows.innerHTML = '';
  if (!EXT || !chrome.permissions) {
    rows.appendChild(Object.assign(document.createElement('div'), { className: 'dict-empty', textContent: '확장 환경에서만 볼 수 있어요.' }));
    return;
  }
  let all;
  try {
    all = await chrome.permissions.getAll();
  } catch (_) {
    return;
  }
  const origins = (all.origins || []).filter((o) => !STATIC_SITE_ORIGINS.includes(o));
  const hasAll = origins.some((o) => ALL_SITES.includes(o) || o === '<all_urls>');
  $('siteAllBtn').classList.toggle('hidden', hasAll);
  $('siteAllOffBtn').classList.toggle('hidden', !hasAll);
  // 같은 호스트의 두 패턴(host, *.host)은 한 줄로
  const groups = new Map();
  for (const o of origins) {
    const key = ALL_SITES.includes(o) || o === '<all_urls>' ? '모든 사이트' : siteLabel(o).replace(/^\*\./, '');
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(o);
  }
  if (!groups.size) {
    rows.appendChild(Object.assign(document.createElement('div'), { className: 'dict-empty', textContent: '허용한 사이트가 없어요. 지금은 코코포리아에서만 동작합니다.' }));
    return;
  }
  for (const [label, list] of groups) {
    const row = document.createElement('div');
    row.className = 'dict-row';
    const name = document.createElement('span');
    name.className = 'dict-from';
    name.style.textDecoration = 'none';
    name.textContent = label;
    name.title = list.join('\n');
    const del = document.createElement('button');
    del.className = 'dict-del';
    del.textContent = '✕';
    del.title = '허용 해제';
    del.addEventListener('click', async () => {
      try {
        await chrome.permissions.remove({ origins: list });
        chrome.runtime.sendMessage({ type: 'SYNC_SITE_SCRIPTS' }, () => void chrome.runtime.lastError);
      } catch (err) {
        $('siteNote').textContent = '해제 실패: ' + String((err && err.message) || err);
      }
      renderSites();
    });
    row.append(name, del);
    rows.appendChild(row);
  }
}

async function requestSites(origins, label) {
  if (!EXT || !chrome.permissions) return;
  const note = $('siteNote');
  try {
    const ok = await chrome.permissions.request({ origins });
    if (ok) {
      note.textContent = `${label} 허용됨. 이미 열려 있는 탭은 새로고침해야 적용돼요.`;
      chrome.runtime.sendMessage({ type: 'SYNC_SITE_SCRIPTS' }, () => void chrome.runtime.lastError);
    } else {
      note.textContent = '허용하지 않았어요.';
    }
  } catch (err) {
    note.textContent = '권한 요청 실패: ' + String((err && err.message) || err);
  }
  renderSites();
}

if ($('siteAddBtn')) {
  $('siteAddBtn').addEventListener('click', () => {
    const host = siteHostFromInput($('siteInput').value);
    if (!host) {
      $('siteNote').textContent = '주소 형식을 확인해 주세요. (예: docs.google.com)';
      return;
    }
    $('siteInput').value = '';
    requestSites(siteOriginsFor(host), host);
  });
  $('siteInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') $('siteAddBtn').click();
  });
  $('siteAllBtn').addEventListener('click', () => requestSites(ALL_SITES, '모든 사이트'));
  $('siteAllOffBtn').addEventListener('click', async () => {
    try {
      await chrome.permissions.remove({ origins: ALL_SITES });
      chrome.runtime.sendMessage({ type: 'SYNC_SITE_SCRIPTS' }, () => void chrome.runtime.lastError);
      $('siteNote').textContent = '모든 사이트 허용을 해제했어요. 개별 사이트는 그대로 남습니다.';
    } catch (err) {
      $('siteNote').textContent = '해제 실패: ' + String((err && err.message) || err);
    }
    renderSites();
  });
  renderSites();
}

// ---------- SVG 아이콘 주입 (lib/icons.js) ----------
(function injectStaticIcons() {
  if (typeof faIcon !== 'function') return;
  const THEME_ICONS = { dark: 'moon', light: 'sun', mono: 'half', retro: 'gamepad' };
  document.querySelectorAll('.theme-btn').forEach((b) => {
    const ic = THEME_ICONS[b.dataset.theme];
    if (ic) b.innerHTML = faIcon(ic) + ' ' + b.textContent.trim();
  });
  const warn = document.querySelector('.conflict-title-ic');
  if (warn) warn.innerHTML = faIcon('warning');
  const upd = document.querySelector('.update-title-ic');
  if (upd) upd.innerHTML = faIcon('up');
  document.querySelectorAll('.io-ic').forEach((sp) => {
    sp.innerHTML = faIcon(sp.dataset.ic === 'up' ? 'up' : 'down');
  });
})();

// ---------- 초기화 ----------
// 팝업을 열 때마다 저장된 맞춤법 설정을 화면에 다시 채운다.
// (이 호출이 빠져 있어서 실시간 검사 토글·엔진·사전이 매번 기본값으로 보였다)
loadSettings();

getSyncP({ theme: 'dark', accentColor: '', uiDesign: 'basic', helpOn: true }).then((s) => {
  curTheme = THEMES.includes(s.theme) ? s.theme : 'dark';
  curAccent = s.accentColor || '';
  curDesign = DESIGNS.includes(s.uiDesign) ? s.uiDesign : 'basic';
  applyThemeUI();
  applyDesignUI();
  applyHelpOn(s.helpOn !== false); // 코코포리아 설정을 안 열어도 맞춤법 쪽 토글이 맞게 뜨도록
});
checkConflicts();
restorePopupResume(); // 에디션 전환·초기화로 다시 그린 경우 보던 화면 복구
checkUpdate();

fillRuleSamples(); // 자주 쓰는 규칙 목록 (정의가 모두 끝난 뒤에)
updateRulePreview();
