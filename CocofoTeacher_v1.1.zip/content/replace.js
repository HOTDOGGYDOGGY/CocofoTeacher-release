// 코코포리아 선생님 — 텍스트 대치 (예: "..." → "…")
// ccfolia.com 에서는 항상 동작, 그 외에는 설정의 허용 사이트 목록에 있어야 동작.
(() => {
  if (window.__cocofoReplaceLoaded) return;
  window.__cocofoReplaceLoaded = true;

  const EXT = typeof chrome !== 'undefined' && chrome.storage && chrome.runtime;
  if (!EXT) return;

  // 광고·트래커용 초소형 iframe에서는 아무것도 하지 않는다 (<all_urls> × all_frames)
  try {
    if (window.self !== window.top && (innerWidth < 50 || innerHeight < 50)) return;
  } catch (_) {}

  const DEFAULT_RULES = [
    { from: '...', to: '…' },
    { from: '--', to: '―' },
  ];

  let enabled = true;
  let rules = DEFAULT_RULES;
  let siteAllowed = false;
  let applying = false; // 우리 스스로 발생시킨 input 이벤트 무시용

  function hostAllowed(sites) {
    const host = location.hostname;
    if (/(^|\.)ccfolia\.com$/.test(host)) return true;
    return (sites || []).some((s) => {
      const t = String(s).trim().toLowerCase();
      return t && (host === t || host.endsWith('.' + t));
    });
  }

  function loadSettings() {
    if (!(chrome.runtime && chrome.runtime.id)) return;
    chrome.storage.sync.get(
      { ccfReplaceOn: true, replaceRules: DEFAULT_RULES, replaceSites: [] },
      (s) => {
        enabled = s.ccfReplaceOn !== false;
        rules = Array.isArray(s.replaceRules) && s.replaceRules.length ? s.replaceRules : [];
        siteAllowed = hostAllowed(s.replaceSites);
      }
    );
  }

  loadSettings();
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync') return;
    if (changes.ccfReplaceOn || changes.replaceRules || changes.replaceSites) loadSettings();
  });

  // 커서 직전 문자열이 rule.from 으로 끝나면 치환
  function tryReplace(el) {
    const pos = el.selectionStart;
    if (pos == null) return;
    const val = el.value;
    for (const r of rules) {
      const from = String(r.from || '');
      const to = String(r.to || '');
      if (!from || !to || from === to) continue;
      if (pos >= from.length && val.slice(pos - from.length, pos) === from) {
        // "...." 처럼 규칙보다 긴 반복 입력 중이면 잠시 보류 (다음 입력에서 판단)
        const next = val.slice(pos, pos + 1);
        if (next && from.endsWith(next)) continue;
        const newVal = val.slice(0, pos - from.length) + to + val.slice(pos);
        const newPos = pos - from.length + to.length;
        applying = true;
        try {
          const proto =
            el instanceof HTMLTextAreaElement
              ? HTMLTextAreaElement.prototype
              : HTMLInputElement.prototype;
          const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
          setter.call(el, newVal); // React 등 프레임워크 상태 반영
          el.setSelectionRange(newPos, newPos);
          el.dispatchEvent(new Event('input', { bubbles: true }));
        } finally {
          applying = false;
        }
        return;
      }
    }
  }

  document.addEventListener(
    'input',
    (e) => {
      if (applying || !enabled || !siteAllowed) return;
      const el = e.target;
      if (!el) return;
      const isText =
        el instanceof HTMLTextAreaElement ||
        (el instanceof HTMLInputElement &&
          ['text', 'search', 'url', 'tel', ''].includes(el.type || ''));
      if (!isText) return;
      // IME 조합 중에는 건드리지 않음 (한글 입력 깨짐 방지)
      if (e.isComposing) return;
      tryReplace(el);
    },
    true
  );
})();
