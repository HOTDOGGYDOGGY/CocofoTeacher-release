// 코코포리아 선생님 — 로그 백업 (수집 트리거 + kkul-log 연동)
// HTML 생성은 lib/logbuild.js(window.CSTLogBuild)가 담당.
// 수집 결과는 background 응답 채널이 아니라 페이지의 CustomEvent('cst-log-done')로 받는다
// — MV3 서비스워커가 수 분짜리 수집 도중 죽어도 결과 전달이 끊기지 않음.
(() => {
  if (window.__cstLogLoaded) return;
  window.__cstLogLoaded = true;

  const EXT = typeof chrome !== 'undefined' && chrome.storage && chrome.runtime;
  if (!EXT) return;


  // 확장을 새로고침하면 남아 있던 이 스크립트의 chrome.* 연결이 끊긴다
  // ("Extension context invalidated"). 호출 전에 살아 있는지 확인한다.
  function extAlive() {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (_) {
      return false;
    }
  }

  const B = () => window.CSTLogBuild;

  window.CSTLog = {
    get DEFAULT_SETTINGS() {
      return B() ? B().DEFAULT_SETTINGS : {};
    },

    // 수집: 주입만 background에 요청하고, 결과는 cst-log-done 이벤트로 수신
    // Promise<{messages, tabSwitchFailed, tabNames}>
    collect(opts, onProgress) {
      return new Promise((resolve, reject) => {
        let finished = false;
        const cleanup = () => {
          window.removeEventListener('cst-log-progress', onProg);
          window.removeEventListener('cst-log-done', onDone);
          clearTimeout(timeout);
        };
        const onProg = (e) => {
          try {
            const d = JSON.parse(e.detail);
            if (onProgress) onProgress(d);
          } catch (_) {}
        };
        const onDone = (e) => {
          if (finished) return;
          finished = true;
          cleanup();
          let r = null;
          try {
            r = JSON.parse(e.detail);
          } catch (_) {}
          if (r && r.ok) {
            resolve({
              messages: r.messages || [],
              tabSwitchFailed: !!r.tabSwitchFailed,
              tabNames: r.tabNames || [],
            });
          } else {
            reject(new Error((r && r.error) || '수집 실패'));
          }
        };
        // 30분 안전장치
        const timeout = setTimeout(() => {
          if (finished) return;
          finished = true;
          cleanup();
          reject(new Error('수집 시간이 너무 오래 걸려 중단했습니다 (30분 초과).'));
        }, 30 * 60 * 1000);

        window.addEventListener('cst-log-progress', onProg);
        window.addEventListener('cst-log-done', onDone);

        // background에는 "수집기 주입"만 요청 — 응답은 주입 성공 여부만 (즉시 옴)
        chrome.runtime.sendMessage({ type: 'COLLECT_LOG', opts }, (res) => {
          if (finished) return;
          if (chrome.runtime.lastError) {
            finished = true;
            cleanup();
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          if (!res || !res.ok) {
            finished = true;
            cleanup();
            reject(new Error((res && res.error) || '수집기 주입 실패'));
          }
          // res.ok === true → 주입 성공, 이제 cst-log-done을 기다린다
        });
      });
    },

    exportHtml(messages, settings, roomName) {
      if (!B()) throw new Error('로그 빌더가 로드되지 않았습니다. 페이지를 새로고침해 주세요.');
      return B().exportAll(messages, settings, roomName);
    },

    // 수집 결과를 로그 스튜디오에서 쓸 수 있게 저장
    saveCollection(roomId, roomName, messages, tabNames) {
      return new Promise((r) => {
        if (!extAlive()) return r(false);
        try {
          chrome.storage.local.set(
            { lastLogCollection: { roomId, roomName, at: Date.now(), messages, tabNames } },
            () => r(!chrome.runtime.lastError)
          );
        } catch (_) {
          r(false);
        }
      });
    },

    kkulMessagesJson(messages) {
      return JSON.stringify({
        kind: 'messages',
        data: messages.map((m, i) => ({
          name: m.name,
          tab: m.tab || '',
          text: m.text,
          imgUrl: m.imgUrl || '',
          idx: i,
          ts: m.ts || '',
          exact: m.exact || null,
          now: Date.now(),
        })),
      });
    },

    kkulCharacterJson(charName, standings) {
      return JSON.stringify({
        kind: 'character',
        data: {
          name: charName,
          iconUrl: null,
          faces: (standings || []).map((s) => ({
            label: s.label.startsWith('@') ? s.label : '@' + s.label,
            iconUrl: s.img || '',
          })),
        },
      });
    },
  };

  // ---------- 자동 백업 ----------
  // 전체 수집은 채팅창을 끝까지 스크롤하므로 플레이 중에 돌리면 방해가 된다.
  // 자동 백업은 "지금 화면에 떠 있는 것만" 조용히 훑어서 방별로 쌓아둔다.
  // 세션 내내 읽으며 진행하면 자연스레 전부 모이고, 브라우저가 죽어도 남는다.
  const AUTO_MAX = 30000; // 방 하나에 쌓아둘 최대 메시지 수
  const roomId = (location.pathname.match(/\/rooms\/([^/?#]+)/) || [])[1] || '';

  function msgKey(m) {
    return (m.tab || '') + '\x1f' + (m.name || '') + '\x1f' + (m.text || '') + '\x1f' + (m.exact || m.ts || '');
  }

  function snapshotOnce() {
    return new Promise((resolve) => {
      if (!extAlive()) return resolve(null);
      try {
        chrome.runtime.sendMessage({ type: 'SNAPSHOT_LOG' }, (res) => {
          if (chrome.runtime.lastError) return resolve(null);
          resolve(res && res.ok ? res.messages || [] : null);
        });
      } catch (_) {
        resolve(null);
      }
    });
  }

  // v9.6: 방별 분리 키(autoBackupData_<roomId>) — 예전에는 모든 방을 한 키에 담아
  // 5분마다 다른 방 수 MB까지 통째로 읽고 다시 썼다. 옛 통합 키의 이 방 몫은 1회 이관.
  const AB_KEY = 'autoBackupData_' + roomId;

  async function autoBackupTick() {
    if (!roomId || !extAlive()) return;
    if (document.hidden) return; // 다른 탭을 보고 있으면 굳이 건드리지 않는다
    const fresh = await snapshotOnce();
    if (!fresh || !fresh.length) return;

    const store = await new Promise((r) => {
      try {
        chrome.storage.local.get({ [AB_KEY]: null, autoBackupData: {}, rooms: {} }, (d) => r(chrome.runtime.lastError ? null : d));
      } catch (_) {
        r(null);
      }
    });
    if (!store) return;

    let cur = store[AB_KEY];
    const legacyAll = store.autoBackupData || {};
    let migrated = false;
    if (legacyAll[roomId]) {
      if (!cur) cur = legacyAll[roomId];
      delete legacyAll[roomId];
      migrated = true;
    }
    if (!cur) cur = { messages: [], at: 0 };

    const seen = new Set(cur.messages.map(msgKey));
    let added = 0;
    for (const m of fresh) {
      const k = msgKey(m);
      if (seen.has(k)) continue;
      seen.add(k);
      cur.messages.push(m);
      added++;
    }
    if (!added && !migrated) return;

    // 오래된 것부터 잘라낸다 (수집 순서 = 대체로 시간순)
    if (cur.messages.length > AUTO_MAX) cur.messages = cur.messages.slice(-AUTO_MAX);
    cur.at = Date.now();
    cur.roomName = ((store.rooms || {})[roomId] || {}).name || cur.roomName || '코코포리아';
    try {
      chrome.storage.local.set({ [AB_KEY]: cur });
      if (migrated) chrome.storage.local.set({ autoBackupData: legacyAll });
    } catch (_) {}
    try {
      window.dispatchEvent(new CustomEvent('cst-autobackup', { detail: JSON.stringify({ added, total: cur.messages.length }) }));
    } catch (_) {}
  }

  let autoTimer = null;

  function startAutoBackup(minutes) {
    stopAutoBackup();
    const ms = Math.max(1, Number(minutes) || 5) * 60 * 1000;
    autoTimer = setInterval(autoBackupTick, ms);
    setTimeout(autoBackupTick, 5000); // 켜자마자 한 번 (방에 들어온 직후 화면부터 잡아둔다)
  }

  function stopAutoBackup() {
    if (autoTimer) clearInterval(autoTimer);
    autoTimer = null;
  }

  window.CSTLog.autoBackup = {
    start: startAutoBackup,
    stop: stopAutoBackup,
    tick: autoBackupTick,
    get running() {
      return !!autoTimer;
    },
    roomId,
  };

  // 저장된 설정대로 자동 시작 / 설정이 바뀌면 곧바로 반영
  function applyAutoSetting(cfg) {
    if (cfg && cfg.on) startAutoBackup(cfg.minutes);
    else stopAutoBackup();
  }

  // 배포본(dist)에는 자동 백업이 없다 — 설정이 남아 있어도 돌리지 않는다 (lib/edition.js)
  if (window.CST_LITE) return;
  try {
    chrome.storage.local.get({ autoBackup: { on: false, minutes: 5 }, editionPreview: 'full' }, (d) => {
      if (chrome.runtime.lastError) return;
      // 개인용의 배포용/배포용-개발 미리보기 — 배포본처럼 자동 백업 없음
      if (d.editionPreview === 'dist' || d.editionPreview === 'distdev') return;
      applyAutoSetting(d.autoBackup);
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || !changes.autoBackup) return;
      applyAutoSetting(changes.autoBackup.newValue);
    });
  } catch (_) {}
})();
