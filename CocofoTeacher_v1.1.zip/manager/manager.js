// 코코포리아 선생님 — 세션 관리자
const $ = (id) => document.getElementById(id);
const EXT = typeof chrome !== 'undefined' && chrome.storage && chrome.runtime;

const THEMES = ['dark', 'light', 'mono', 'retro'];

const getLocal = (defs) => new Promise((r) => (EXT ? chrome.storage.local.get(defs, r) : r(defs)));
const setLocal = (obj) => new Promise((r) => (EXT ? chrome.storage.local.set(obj, r) : r()));
const getSync = (defs) => new Promise((r) => (EXT ? chrome.storage.sync.get(defs, r) : r(defs)));

let selectedRoom = null; // roomId | '__colors__'

function normalizeHex(v) {
  let s = String(v || '').trim();
  if (!s) return '';
  if (!s.startsWith('#')) s = '#' + s;
  return /^#[0-9a-fA-F]{6}$/.test(s) ? s.toLowerCase() : '';
}

function darkenHex(hex, amt = 0.15) {
  const h = normalizeHex(hex);
  if (!h) return hex;
  const n = parseInt(h.slice(1), 16);
  const f = (v) => Math.max(0, Math.round(v * (1 - amt)));
  return (
    '#' +
    [f((n >> 16) & 255), f((n >> 8) & 255), f(n & 255)]
      .map((v) => v.toString(16).padStart(2, '0'))
      .join('')
  );
}

async function applyTheme() {
  const s = await getSync({ theme: 'dark', accentColor: '' });
  const theme = THEMES.includes(s.theme) ? s.theme : 'dark';
  for (const t of THEMES) document.body.classList.toggle('theme-' + t, theme === t && t !== 'dark');
  const a = normalizeHex(s.accentColor);
  if (a) {
    document.body.style.setProperty('--accent', a);
    document.body.style.setProperty('--accent-dark', darkenHex(a));
  }
}

function fmtDate(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}.${p(d.getMonth() + 1)}.${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}

// ---------- 방 목록 ----------
async function renderRoomList() {
  const { rooms } = await getLocal({ rooms: {} });
  const list = $('roomList');
  list.innerHTML = '';
  const entries = Object.entries(rooms || {}).sort(
    (a, b) => (b[1].lastVisit || 0) - (a[1].lastVisit || 0)
  );
  if (!entries.length) {
    list.appendChild(el('div', 'mgr-empty', '저장된 방이 없습니다.'));
    return;
  }
  for (const [roomId, room] of entries) {
    const btn = el('button', 'mgr-room-item' + (selectedRoom === roomId ? ' on' : ''));
    if (room.favorite && typeof faIcon === 'function') {
      const ic = el('span', 'mgr-bk-ic');
      ic.innerHTML = faIcon('bookmark');
      btn.appendChild(ic);
    }
    btn.append(
      document.createTextNode(room.name || '이름 없는 방'),
      el('span', 'mgr-room-date', fmtDate(room.lastVisit))
    );
    btn.addEventListener('click', () => {
      selectedRoom = roomId;
      renderRoomList();
      renderDetail();
    });
    list.appendChild(btn);
  }
}

// ---------- 상세 ----------
async function renderDetail() {
  const detail = $('detail');
  detail.innerHTML = '';

  if (selectedRoom === '__colors__') {
    renderGlobalColors(detail);
    return;
  }

  if (selectedRoom === '__backup__') {
    await renderBackup(detail);
    return;
  }

  const { rooms } = await getLocal({ rooms: {} });
  const room = rooms[selectedRoom];
  if (!room) {
    detail.appendChild(el('div', 'mgr-empty', '왼쪽에서 방을 선택하세요.'));
    return;
  }
  const roomId = selectedRoom;

  // ----- 방 정보 -----
  const top = el('div', 'mgr-card');
  const topRow = el('div', 'mgr-room-top');
  const thumb = el('div', 'mgr-room-thumb');
  if (room.thumb) {
    const img = document.createElement('img');
    img.src = room.thumb;
    img.addEventListener('error', () => {
      img.remove();
      thumb.innerHTML = typeof faIcon === 'function' ? faIcon('dice') : '?';
    });
    thumb.appendChild(img);
  } else {
    thumb.innerHTML = typeof faIcon === 'function' ? faIcon('dice') : '?';
  }
  const info = el('div', 'mgr-room-info');
  info.appendChild(el('div', 'mgr-room-name', room.name || '이름 없는 방'));
  info.appendChild(
    el('div', 'mgr-room-meta', `마지막 방문: ${fmtDate(room.lastVisit)}${room.favorite ? ' · 저장된 방' : ''}`)
  );
  const openBtn = el('button', 'mgr-btn', '방 열기');
  openBtn.addEventListener('click', () => {
    const url = room.url || 'https://ccfolia.com/rooms/' + roomId;
    if (EXT && chrome.tabs) chrome.tabs.create({ url });
    else window.open(url);
  });
  const delRoomBtn = el('button', 'mgr-btn danger', '이 방 데이터 전체 삭제');
  delRoomBtn.style.marginLeft = '8px';
  delRoomBtn.addEventListener('click', async () => {
    if (!confirm(`"${room.name || roomId}"의 모든 데이터(메모·스탠딩·색상·방문 기록)를 삭제할까요?`)) return;
    const { rooms: cur, savedRoomOrder } = await getLocal({ rooms: {}, savedRoomOrder: [] });
    delete cur[roomId];
    await setLocal({ rooms: cur, savedRoomOrder: (savedRoomOrder || []).filter((id) => id !== roomId) });
    selectedRoom = null;
    renderRoomList();
    renderDetail();
  });
  info.append(openBtn, delRoomBtn);
  topRow.append(thumb, info);
  top.appendChild(topRow);
  detail.appendChild(top);

  // ----- 누적 통계 (로그 백업 기준) -----
  const sessions = room.sessions || [];
  if (sessions.length) {
    const statCard = el('div', 'mgr-card');
    const st = el('div', 'mgr-card-title');
    st.innerHTML = titleIcon('grid') + '누적 통계';
    st.appendChild(el('span', 'count', `백업 ${sessions.length}회`));
    statCard.appendChild(st);
    const totalMsg = sessions.reduce((a, x) => a + (x.count || 0), 0);
    // v4.1 이전 기록은 첫 대사~마지막 대사를 통째로 잰 값이라 쉬는 시간이 섞여 있다.
    // 두 방식을 섞어 합치면 숫자가 부풀어 보이므로 나눠서 보여준다.
    const netList = sessions.filter((x) => x.netTime);
    const oldList = sessions.filter((x) => !x.netTime);
    const sum = (list) => list.reduce((a, x) => a + (x.durationMs || 0), 0);
    const fmtDur = (ms) => {
      const h = Math.floor(ms / 3600000);
      const m2 = Math.round((ms % 3600000) / 60000);
      return `${h ? h + '시간 ' : ''}${m2}분`;
    };
    statCard.appendChild(
      el('div', 'mgr-room-meta', `총 메시지 ${totalMsg.toLocaleString()}개 · 플레이 ${fmtDur(sum(netList))} (쉬는 시간 제외, ${netList.length}회)`)
    );
    if (oldList.length) {
      const warn = el(
        'div',
        'mgr-room-meta',
        `옛 방식 기록 ${oldList.length}회: ${fmtDur(sum(oldList))} — 쉬는 시간이 포함된 값이라 따로 표시합니다.`
      );
      warn.style.opacity = '.75';
      const dropBtn = el('button', 'mgr-btn', '옛 기록 지우기');
      dropBtn.style.marginTop = '6px';
      dropBtn.title = '쉬는 시간이 포함된 예전 기록만 삭제합니다 (메시지 수 통계도 함께 사라집니다)';
      dropBtn.addEventListener('click', async () => {
        if (!confirm(`쉬는 시간이 포함된 예전 기록 ${oldList.length}개를 지울까요?`)) return;
        const { rooms: cur } = await getLocal({ rooms: {} });
        if (cur[roomId]) {
          cur[roomId].sessions = (cur[roomId].sessions || []).filter((x) => x.netTime);
          await setLocal({ rooms: cur });
        }
        renderDetail();
      });
      statCard.append(warn, dropBtn);
    }
    for (let i = sessions.length - 1; i >= 0 && i >= sessions.length - 10; i--) {
      const sess = sessions[i];
      const row = el('div', 'mgr-row');
      const d = new Date(sess.at);
      const pad = (n) => String(n).padStart(2, '0');
      row.appendChild(el('span', 'name', `${d.getFullYear()}.${pad(d.getMonth() + 1)}.${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`));
      row.appendChild(
        el(
          'span',
          'sub',
          `${sess.count}개 · ${Math.round((sess.durationMs || 0) / 60000)}분${sess.netTime ? '' : '(쉬는 시간 포함)'} · 탭 ${sess.tabs || 1}개`
        )
      );
      const del = el('button', 'del', '✕');
      del.title = '이 기록 삭제';
      const idx = i;
      del.addEventListener('click', async () => {
        const { rooms: cur } = await getLocal({ rooms: {} });
        if (cur[roomId] && cur[roomId].sessions) {
          cur[roomId].sessions.splice(idx, 1);
          await setLocal({ rooms: cur });
        }
        renderDetail();
      });
      row.appendChild(del);
      statCard.appendChild(row);
    }
    detail.appendChild(statCard);
  }

  // ----- 메모 (방 공지 + 세션 메모) -----
  const memoCard = el('div', 'mgr-card');
  const memoTitle = el('div', 'mgr-card-title');
  memoTitle.innerHTML = titleIcon('pen') + '방 공지';
  memoTitle.appendChild(el('span', 'count', '방 화면 상단에 고정'));
  memoCard.appendChild(memoTitle);
  const memo = el('textarea', 'mgr-memo');
  memo.placeholder = '방 공지 (자동 저장 — 방 화면 상단·홈 호버뷰에 표시)';
  memo.value = room.memo || '';
  const saved = el('div', 'mgr-memo-saved', '');
  let t = 0;
  memo.addEventListener('input', () => {
    clearTimeout(t);
    saved.textContent = '입력 중…';
    t = setTimeout(async () => {
      const { rooms: cur } = await getLocal({ rooms: {} });
      if (cur[roomId]) {
        cur[roomId].memo = memo.value;
        await setLocal({ rooms: cur });
      }
      saved.textContent = '저장됨 ✓';
    }, 500);
  });
  memoCard.append(memo, saved);
  detail.appendChild(memoCard);

  // ----- 세션 메모 (패널에서 추가한 것들) -----
  const memosCard = el('div', 'mgr-card');
  const memosTitle = el('div', 'mgr-card-title');
  memosTitle.innerHTML = titleIcon('pen') + '세션 메모';
  const memosList = Array.isArray(room.memos) ? room.memos : [];
  memosTitle.appendChild(el('span', 'count', `${memosList.length}개`));
  memosCard.appendChild(memosTitle);
  if (!memosList.length) {
    memosCard.appendChild(el('div', 'mgr-empty', '세션 메모가 없습니다. 방 패널의 메모 탭에서 추가할 수 있어요.'));
  }
  for (const mo of memosList) {
    const box = el('div', 'mgr-memo-box');
    const head = el('div', 'mgr-row');
    const md = new Date(mo.at || Date.now());
    const mpad = (n) => String(n).padStart(2, '0');
    head.appendChild(
      el('span', 'sub', `${md.getFullYear()}.${mpad(md.getMonth() + 1)}.${mpad(md.getDate())} ${mpad(md.getHours())}:${mpad(md.getMinutes())}`)
    );
    const delBtn = el('button', 'del', '✕');
    delBtn.title = '이 메모 삭제';
    delBtn.addEventListener('click', async () => {
      const { rooms: cur } = await getLocal({ rooms: {} });
      if (cur[roomId]) {
        cur[roomId].memos = (cur[roomId].memos || []).filter((x) => x.id !== mo.id);
        await setLocal({ rooms: cur });
      }
      renderDetail();
    });
    head.appendChild(delBtn);
    const ta = el('textarea', 'mgr-memo mgr-memo-mini');
    ta.value = mo.text || '';
    ta.placeholder = '메모 내용 (자동 저장)';
    const sv = el('div', 'mgr-memo-saved', '');
    let t2 = 0;
    ta.addEventListener('input', () => {
      clearTimeout(t2);
      sv.textContent = '입력 중…';
      t2 = setTimeout(async () => {
        const { rooms: cur } = await getLocal({ rooms: {} });
        const hit = cur[roomId] && (cur[roomId].memos || []).find((x) => x.id === mo.id);
        if (hit) {
          hit.text = ta.value;
          await setLocal({ rooms: cur });
        }
        sv.textContent = '저장됨 ✓';
      }, 500);
    });
    box.append(head, ta, sv);
    memosCard.appendChild(box);
  }
  const addMemoBtn = el('button', 'mgr-btn', '+ 새 세션 메모');
  addMemoBtn.addEventListener('click', async () => {
    const { rooms: cur } = await getLocal({ rooms: {} });
    if (cur[roomId]) {
      cur[roomId].memos = cur[roomId].memos || [];
      cur[roomId].memos.unshift({ id: Date.now() + '_' + Math.random().toString(36).slice(2, 7), text: '', at: Date.now() });
      await setLocal({ rooms: cur });
    }
    renderDetail();
  });
  memosCard.appendChild(addMemoBtn);
  detail.appendChild(memosCard);

  // ----- 스탠딩 -----
  const standCard = el('div', 'mgr-card');
  const standings = room.standings || {};
  const charNames = Object.keys(standings);
  const title = el('div', 'mgr-card-title');
  title.innerHTML = titleIcon('image') + '저장된 스탠딩';
  title.appendChild(el('span', 'count', `캐릭터 ${charNames.length}명`));
  standCard.appendChild(title);
  if (!charNames.length) {
    standCard.appendChild(el('div', 'mgr-empty', '저장된 스탠딩이 없습니다.'));
  }
  for (const name of charNames) {
    const row = el('div', 'mgr-row');
    const nm = el('span', 'name', name);
    const sub = el('span', 'sub', `${standings[name].length}개`);
    const del = el('button', 'del', '✕');
    del.title = '이 캐릭터의 스탠딩 삭제';
    del.addEventListener('click', async () => {
      if (!confirm(`"${name}"의 스탠딩 ${standings[name].length}개를 삭제할까요?`)) return;
      const { rooms: cur } = await getLocal({ rooms: {} });
      if (cur[roomId]) {
        delete cur[roomId].standings[name];
        if (cur[roomId].standingOrder) delete cur[roomId].standingOrder[name];
        await setLocal({ rooms: cur });
      }
      renderDetail();
    });
    row.append(nm, sub, del);
    standCard.appendChild(row);
    const thumbs = el('div', 'mgr-standing-thumbs');
    for (const s of standings[name].slice(0, 14)) {
      if (!s.img) continue;
      const im = document.createElement('img');
      im.src = s.img;
      im.title = s.label;
      im.addEventListener('error', () => im.remove());
      thumbs.appendChild(im);
    }
    if (thumbs.children.length) standCard.appendChild(thumbs);
  }
  detail.appendChild(standCard);

  // ----- 이 방 전용 색상 -----
  const colorCard = el('div', 'mgr-card');
  const roomColors = room.charColors || {};
  const colorNames = Object.keys(roomColors);
  const ctitle = el('div', 'mgr-card-title');
  ctitle.innerHTML = titleIcon('palette') + '이 방 전용 색상';
  ctitle.appendChild(el('span', 'count', `${colorNames.length}개`));
  colorCard.appendChild(ctitle);
  if (!colorNames.length) {
    colorCard.appendChild(el('div', 'mgr-empty', '이 방 전용으로 저장된 색상이 없습니다.'));
  }
  for (const name of colorNames) {
    const row = el('div', 'mgr-row');
    const chip = el('span', 'mgr-chip');
    chip.style.background = roomColors[name];
    const nm = el('span', 'name', name);
    const sub = el('span', 'sub', roomColors[name]);
    const del = el('button', 'del', '✕');
    del.addEventListener('click', async () => {
      const { rooms: cur } = await getLocal({ rooms: {} });
      if (cur[roomId] && cur[roomId].charColors) {
        delete cur[roomId].charColors[name];
        await setLocal({ rooms: cur });
      }
      renderDetail();
    });
    row.append(chip, nm, sub, del);
    colorCard.appendChild(row);
  }
  detail.appendChild(colorCard);
}

// ---------- 전역 색상 ----------
async function renderGlobalColors(detail) {
  const { charColors } = await getLocal({ charColors: {} });
  const card = el('div', 'mgr-card');
  const names = Object.keys(charColors || {});
  const title = el('div', 'mgr-card-title');
  title.innerHTML = titleIcon('palette') + '캐릭터 색상 (모든 방 공통)';
  title.appendChild(el('span', 'count', `${names.length}개`));
  card.appendChild(title);
  if (!names.length) {
    card.appendChild(el('div', 'mgr-empty', '저장된 색상이 없습니다.'));
  }
  for (const name of names) {
    const row = el('div', 'mgr-row');
    const chip = el('span', 'mgr-chip');
    chip.style.background = charColors[name];
    const nm = el('span', 'name', name);
    const sub = el('span', 'sub', charColors[name]);
    const del = el('button', 'del', '✕');
    del.addEventListener('click', async () => {
      const { charColors: cc } = await getLocal({ charColors: {} });
      delete cc[name];
      await setLocal({ charColors: cc });
      renderDetail();
    });
    row.append(chip, nm, sub, del);
    card.appendChild(row);
  }
  detail.appendChild(card);
}

// ---------- 전체 백업 · 복원 ----------
// 저장소를 통째로 파일 하나에 담고, 그 파일로 되돌린다.
// 수집한 로그·자동 백업본은 크기가 커서 기본으로는 빼고, 원하면 넣는다.
const HEAVY_KEYS = ['lastLogCollection', 'autoBackupData'];
// v9.6부터 자동 백업본은 방별 분리 키(autoBackupData_<roomId>)에 담긴다
const isHeavyKey = (k) => HEAVY_KEYS.includes(k) || k.startsWith('autoBackupData_');

function getAll(areaName) {
  return new Promise((r) => {
    if (!EXT) return r({});
    try {
      chrome.storage[areaName].get(null, (d) => r(chrome.runtime.lastError ? {} : d || {}));
    } catch (_) {
      r({});
    }
  });
}

function setMany(areaName, obj) {
  return new Promise((r) => {
    if (!EXT) return r();
    try {
      chrome.storage[areaName].set(obj, () => r());
    } catch (_) {
      r();
    }
  });
}

function fmtBytes(n) {
  if (n < 1024) return n + 'B';
  if (n < 1024 * 1024) return (n / 1024).toFixed(1) + 'KB';
  return (n / 1048576).toFixed(1) + 'MB';
}

async function renderBackup(detail) {
  const local = await getAll('local');
  const sync = await getAll('sync');

  const card = el('div', 'mgr-card');
  const title = el('div', 'mgr-card-title');
  title.innerHTML = titleIcon('folder') + '전체 백업 · 복원';
  card.appendChild(title);
  card.appendChild(
    el(
      'div',
      'mgr-room-meta',
      '방 기록·메모·스탠딩·캐릭터 시트·체크리스트·색상·로그 설정·저장한 스타일까지 파일 하나에 담습니다.'
    )
  );

  // 무엇이 얼마나 들어 있는지
  const rooms = local.rooms || {};
  const sizeOf = (v) => {
    try {
      return JSON.stringify(v || null).length;
    } catch (_) {
      return 0;
    }
  };
  const lines = [
    `방 ${Object.keys(rooms).length}개`,
    `저장한 스타일 ${(local.logPresets || []).length}개`,
    `캐릭터 색상 ${Object.keys(local.charColors || {}).length}개`,
  ];
  card.appendChild(el('div', 'mgr-room-meta', lines.join(' · ')));

  const heavySize = Object.keys(local).reduce((a, k) => a + (isHeavyKey(k) ? sizeOf(local[k]) : 0), 0);

  const optWrap = el('div', 'mgr-row');
  const cb = document.createElement('input');
  cb.type = 'checkbox';
  cb.id = 'bkHeavy';
  cb.style.marginRight = '6px';
  const lab = document.createElement('label');
  lab.htmlFor = 'bkHeavy';
  lab.textContent = `수집한 로그·자동 백업본도 함께 담기 (약 ${fmtBytes(heavySize)})`;
  lab.style.cursor = 'pointer';
  optWrap.append(cb, lab);
  card.appendChild(optWrap);

  const expBtn = el('button', 'mgr-btn', '파일로 저장');
  expBtn.style.marginTop = '8px';
  expBtn.addEventListener('click', () => {
    const outLocal = { ...local };
    if (!cb.checked) for (const k of Object.keys(outLocal)) if (isHeavyKey(k)) delete outLocal[k];
    const payload = {
      kind: 'cst-full-backup',
      version: 1,
      at: Date.now(),
      appVersion: (EXT && chrome.runtime.getManifest && chrome.runtime.getManifest().version) || '',
      local: outLocal,
      sync,
    };
    const json = JSON.stringify(payload);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const d = new Date();
    const p2 = (n) => String(n).padStart(2, '0');
    const a = document.createElement('a');
    a.href = url;
    a.download = `코코포선생님_전체백업_${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    info.textContent = `저장했습니다 (${fmtBytes(json.length)})`;
  });

  const impBtn = el('button', 'mgr-btn', '파일에서 되돌리기');
  impBtn.style.marginLeft = '8px';
  impBtn.addEventListener('click', () => $('backupFileInput').click());

  const btnRow = el('div', '');
  btnRow.append(expBtn, impBtn);
  card.appendChild(btnRow);

  const info = el('div', 'mgr-room-meta', '');
  info.style.marginTop = '8px';
  card.appendChild(info);
  backupInfo = info;

  card.appendChild(
    el(
      'div',
      'mgr-room-meta',
      '되돌릴 때는 [합치기]와 [통째로 덮어쓰기] 중에서 고릅니다. 합치기는 파일에 없는 방을 그대로 두고, 덮어쓰기는 지금 것을 모두 버립니다.'
    )
  );

  detail.appendChild(card);
}

let backupInfo = null;

$('backupBtn').addEventListener('click', () => {
  selectedRoom = '__backup__';
  renderRoomList();
  renderDetail();
});

$('backupFileInput').addEventListener('change', async () => {
  const file = $('backupFileInput').files[0];
  $('backupFileInput').value = '';
  if (!file) return;
  const say = (m) => backupInfo && (backupInfo.textContent = m);
  let payload;
  try {
    payload = JSON.parse(await file.text());
  } catch (_) {
    return say('읽지 못했습니다 — JSON 파일이 아닙니다.');
  }
  if (!payload || payload.kind !== 'cst-full-backup' || !payload.local) {
    return say('코코포 선생님 전체 백업 파일이 아닙니다.');
  }
  const inRooms = Object.keys(payload.local.rooms || {}).length;
  const merge = confirm(
    `백업 파일: 방 ${inRooms}개\n\n` +
      '[확인] 합치기 — 파일에 없는 방은 그대로 두고 겹치는 것만 파일 내용으로 바꿉니다\n' +
      '[취소] 다음 물음에서 통째로 덮어쓸지 고릅니다'
  );

  if (!merge) {
    const wipe = confirm('지금 저장된 내용을 모두 버리고 파일 내용으로 통째로 바꿀까요?\n되돌릴 수 없습니다.');
    if (!wipe) return say('되돌리기를 그만뒀습니다.');
    try {
      await new Promise((r) => chrome.storage.local.clear(r));
      await new Promise((r) => chrome.storage.sync.clear(r));
    } catch (_) {}
    await setMany('local', payload.local);
    if (payload.sync) await setMany('sync', payload.sync);
    // 화면을 새로 그린 뒤에 알려야 안내가 지워지지 않는다
    renderRoomList();
    await renderDetail();
    say(`통째로 되돌렸습니다 — 방 ${inRooms}개`);
    return;
  }

  const cur = await getAll('local');
  const next = { ...cur, ...payload.local };
  next.rooms = { ...(cur.rooms || {}), ...(payload.local.rooms || {}) };
  if (cur.charColors || payload.local.charColors) {
    next.charColors = { ...(cur.charColors || {}), ...(payload.local.charColors || {}) };
  }
  await setMany('local', next);
  if (payload.sync) await setMany('sync', { ...(await getAll('sync')), ...payload.sync });
  renderRoomList();
  await renderDetail();
  say(`합쳤습니다 — 방 ${Object.keys(next.rooms).length}개`);
});

$('globalColorsBtn').addEventListener('click', () => {
  selectedRoom = '__colors__';
  renderRoomList();
  renderDetail();
});

// 이모지 → SVG 아이콘 치환
(function initIcons() {
  if (typeof faIcon !== 'function') return;
  document.querySelectorAll('.ic[data-ic]').forEach((sp) => (sp.innerHTML = faIcon(sp.dataset.ic)));
})();

function titleIcon(name) {
  return typeof faIcon === 'function' ? faIcon(name) + ' ' : '';
}

// 팝업의 [전체 백업] 버튼은 #backup을 붙여 들어온다.
// 배포본(dist)에는 전체 백업·복원이 없다 (lib/edition.js)
const LITE = !!window.CST_LITE;
if (LITE) $('backupBtn').style.display = 'none';
if (!LITE && location.hash === '#backup') selectedRoom = '__backup__';

applyTheme();
renderRoomList();
renderDetail();
