import { spellCheck, ENGINES } from './lib/spellcheck.js';
import './lib/ignore.js'; // globalThis.CSTIgnore — 검사 제외 단어 판정 (팝업과 같은 규칙)

const DEFAULTS = {
  engine: 'daum',
  liveCheck: false,
  debounceMs: 1500,
  contextMenu: true,
  excluded: '',
  userDict: [], // [{ from, to }]
  userDictOn: true,
  ignoreWords: [], // 검사 제외 단어 (팝업 '매번 원문 유지' 로 쌓인다)
  liveEngine: '', // 실시간 검사 전용 엔진 ('' = engine 과 동일)
};

// 설정 정본은 popup/spell.js와 동일하게 "sync 로드 → local로 덮어쓰기" 병합.
// (예전엔 sync만 읽어서, sync 쓰기가 한도로 조용히 실패하면 팝업·밑줄은 새 설정,
//  우클릭 교정·실시간 검사는 옛 설정으로 갈라지는 버그가 있었다)
// 매 검사마다 storage 왕복하지 않게 캐시하고, onChanged에서 무효화한다.
let settingsCache = null;

async function getSettings() {
  if (settingsCache) return settingsCache;
  const sv = await chrome.storage.sync.get(DEFAULTS);
  const lc = await chrome.storage.local.get(Object.keys(DEFAULTS));
  const s = { ...DEFAULTS, ...sv };
  for (const k of Object.keys(DEFAULTS)) if (lc[k] !== undefined) s[k] = lc[k];
  settingsCache = s;
  return s;
}

// ---- 결과 캐시 (동일 텍스트 반복 요청 방지) ----
const CACHE_TTL = 30 * 1000;
const CACHE_MAX = 20;
const cache = new Map(); // key -> { at, result }

function cacheGet(key) {
  const hit = cache.get(key);
  if (!hit) return null;
  if (Date.now() - hit.at > CACHE_TTL) {
    cache.delete(key);
    return null;
  }
  return hit.result;
}

function cachePut(key, result) {
  cache.set(key, { at: Date.now(), result });
  if (cache.size > CACHE_MAX) {
    cache.delete(cache.keys().next().value);
  }
}

// 개인 사전 교정을 엔진 결과 앞에 병합 (같은 토큰은 개인 사전이 우선)
function mergeUserDict(corrections, text, userDict) {
  const userCorr = [];
  for (const entry of userDict) {
    const from = (entry.from || '').trim();
    const to = (entry.to || '').trim();
    if (!from || !to || from === to || !text.includes(from)) continue;
    userCorr.push({
      errType: 'user',
      token: from,
      suggestion: to,
      cands: [to],
      context: '',
      info: '개인 사전에 등록된 교정입니다.',
    });
  }
  if (!userCorr.length) return corrections;
  const userTokens = new Set(userCorr.map((c) => c.token));
  return [...userCorr, ...corrections.filter((c) => !userTokens.has(c.token))];
}

// 비교 모드: 모든 엔진을 동시에 돌려 토큰 기준으로 결과 통합
const ENGINE_LABEL = { daum: '다음', naver: '네이버', saramin: '사람인', incruit: '인크루트' };

async function compareCheck(text) {
  // 사람인·인크루트는 같은 부산대 엔진 → 비교에는 사람인만 사용
  const keys = ['daum', 'naver', 'saramin'];
  const settled = await Promise.allSettled(keys.map((k) => spellCheck(text, k)));

  const byToken = new Map();
  const okEngines = [];
  settled.forEach((r, i) => {
    if (r.status !== 'fulfilled') return;
    okEngines.push(ENGINE_LABEL[keys[i]]);
    for (const c of r.value.corrections) {
      const item = byToken.get(c.token);
      if (!item) {
        byToken.set(c.token, {
          ...c,
          cands: [...(c.cands && c.cands.length ? c.cands : [c.suggestion])],
          engines: [ENGINE_LABEL[keys[i]]],
        });
      } else {
        item.engines.push(ENGINE_LABEL[keys[i]]);
        for (const cd of c.cands && c.cands.length ? c.cands : [c.suggestion]) {
          if (!item.cands.includes(cd)) item.cands.push(cd);
        }
        if (!item.info && c.info) item.info = c.info;
      }
    }
  });

  if (!okEngines.length) throw new Error('ALL_ENGINES_FAILED');

  // 정렬 비교자 안에서 매번 원문 전체를 스캔하지 않게 위치를 미리 계산해 둔다
  const posOf = new Map();
  for (const tk of byToken.keys()) posOf.set(tk, text.indexOf(tk));
  const corrections = [...byToken.values()]
    .sort((a, b) => posOf.get(a.token) - posOf.get(b.token))
    .map((c) => ({
      ...c,
      info: `발견한 엔진: ${c.engines.join(' · ')}` + (c.info ? '\n\n' + c.info : ''),
    }));

  return { corrections, compared: okEngines };
}

async function doCheck(text, source) {
  const settings = await getSettings();
  // 고른 엔진은 팝업·우클릭 어디서나 그대로 쓴다. 실시간 검사만 따로 지정할 수 있다
  // (빠른 엔진으로 두거나, 반대로 비교 모드로 꼼꼼히 보고 싶을 때).
  // (비교 모드는 세 엔진을 동시에 던지므로 가장 느린 하나만큼만 걸린다)
  let engine = source === 'live' && settings.liveEngine ? settings.liveEngine : settings.engine;
  if (engine !== 'compare' && !ENGINES[engine]) engine = 'daum';

  const key = `${engine}\n${text}`;
  let result = cacheGet(key);
  if (!result) {
    result = engine === 'compare' ? await compareCheck(text) : await spellCheck(text, engine);
    cachePut(key, result);
  }
  const out = { ...result, engine };
  if (settings.userDictOn && Array.isArray(settings.userDict) && settings.userDict.length) {
    out.corrections = mergeUserDict(result.corrections, text, settings.userDict);
  }
  // 검사 제외 단어는 마지막에 걸러낸다 — 캐시된 결과에도 최신 목록이 바로 적용되고,
  // 같은 단어가 본문에 몇 번 나오든 한 번에 전부 빠진다 (개인 사전 교정은 사용자가
  // 직접 넣은 것이므로 제외 목록보다 우선).
  const ignore = Array.isArray(settings.ignoreWords) ? settings.ignoreWords : [];
  if (ignore.length && globalThis.CSTIgnore) {
    const isIgnored = globalThis.CSTIgnore.matcher(ignore);
    out.corrections = out.corrections.filter((c) => c.errType === 'user' || !isIgnored(c.token));
  }
  return out;
}

function errorMessage(err) {
  const msg = String((err && err.message) || err);
  if (msg.includes('FORMAT_CHANGED')) {
    return '검사 서비스의 응답 형식이 바뀌어 결과를 읽지 못했습니다. 설정에서 다른 엔진으로 바꿔보세요.';
  }
  if (msg.includes('NAVER_KEY_FAILED')) {
    return '네이버 검사 키를 가져오지 못했습니다. 설정에서 다음 엔진으로 바꿔보세요.';
  }
  if (msg.includes('ALL_ENGINES_FAILED')) {
    return '모든 엔진 검사에 실패했습니다. 네트워크를 확인해 주세요.';
  }
  if (msg.includes('HTTP_403') || msg.includes('HTTP_429')) {
    return '요청이 너무 많습니다. 잠시 후 다시 시도해 주세요.';
  }
  if (msg.includes('HTTP_')) {
    return `검사 서버 오류가 발생했습니다. (${msg.replace('HTTP_', 'HTTP ')})`;
  }
  return '검사 서버에 연결하지 못했습니다. 네트워크를 확인해 주세요.';
}

// ---- 메시지 라우터 ----
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'CHECK') {
    doCheck(msg.text, msg.source)
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((err) => sendResponse({ ok: false, error: errorMessage(err) }));
    return true; // async
  }
  if (msg && msg.type === 'COLLECT_LOG') {
    // MAIN 월드에 수집기를 "주입만" 하고 바로 응답한다.
    // 수집 결과는 페이지의 CustomEvent('cst-log-done')로 전달되므로
    // 수 분짜리 수집 동안 응답 채널을 열어둘 필요가 없다 (서비스워커 종료 무관).
    const tabId = sender && sender.tab && sender.tab.id;
    if (!tabId) {
      sendResponse({ ok: false, error: 'no tab' });
      return false;
    }
    chrome.scripting
      .executeScript({
        target: { tabId },
        world: 'MAIN',
        func: pageLogCollector,
        args: [msg.opts || {}],
      })
      .then(() => sendResponse({ ok: true, started: true }))
      .catch((err) => sendResponse({ ok: false, error: String(err && err.message) }));
    return true; // async (주입 완료까지만 대기 — 수 초 내)
  }
  if (msg && msg.type === 'SNAPSHOT_LOG') {
    // 자동 백업용 — 스크롤도 탭 전환도 하지 않고 지금 화면에 떠 있는 것만 훑는다.
    // 즉시 끝나므로 응답 채널로 바로 돌려준다.
    const tabId = sender && sender.tab && sender.tab.id;
    if (!tabId) {
      sendResponse({ ok: false, error: 'no tab' });
      return false;
    }
    chrome.scripting
      .executeScript({
        target: { tabId },
        world: 'MAIN',
        func: pageLogCollector,
        args: [{ snapshot: true }],
      })
      .then((res) => {
        const r = res && res[0] && res[0].result;
        sendResponse(r && typeof r === 'object' ? r : { ok: false, error: '스냅샷 실패' });
      })
      .catch((err) => sendResponse({ ok: false, error: String(err && err.message) }));
    return true; // async
  }
  if (msg && msg.type === 'OPEN_STUDIO') {
    chrome.tabs.create({ url: chrome.runtime.getURL('studio/studio.html') });
    sendResponse({ ok: true });
    return false;
  }
  if (msg && msg.type === 'CAPTURE_VISIBLE') {
    // 방 화면 캡처: 보이는 탭을 PNG로 찍어 dataURL 반환 (자르기는 콘텐트 스크립트가 담당)
    const windowId = sender && sender.tab && sender.tab.windowId;
    chrome.tabs
      .captureVisibleTab(windowId, { format: 'png' })
      .then((dataUrl) => sendResponse({ ok: true, dataUrl }))
      .catch((err) => sendResponse({ ok: false, error: String(err && err.message) }));
    return true; // async
  }
  if (msg && msg.type === 'GET_STREAM_ID') {
    // 매끄러운 GIF용 — 탭 영상 스트림 ID를 발급한다.
    // captureVisibleTab은 초당 2번으로 묶여 있어서 그것만으로는 프레임을 잘게 못 딴다.
    const tabId = sender && sender.tab && sender.tab.id;
    if (tabId == null || !chrome.tabCapture || !chrome.tabCapture.getMediaStreamId) {
      sendResponse({ ok: false, error: '이 브라우저에서는 탭 영상 캡처를 쓸 수 없습니다.' });
      return false;
    }
    try {
      chrome.tabCapture.getMediaStreamId({ targetTabId: tabId, consumerTabId: tabId }, (streamId) => {
        if (chrome.runtime.lastError || !streamId) {
          sendResponse({ ok: false, error: (chrome.runtime.lastError && chrome.runtime.lastError.message) || '스트림 발급 실패' });
          return;
        }
        sendResponse({ ok: true, streamId });
      });
    } catch (err) {
      sendResponse({ ok: false, error: String((err && err.message) || err) });
    }
    return true; // async
  }
  if (msg && msg.type === 'GET_ZOOM') {
    const tabId = sender && sender.tab && sender.tab.id;
    if (tabId == null) {
      sendResponse({ ok: false });
      return false;
    }
    chrome.tabs
      .getZoom(tabId)
      .then((factor) => sendResponse({ ok: true, factor }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (msg && msg.type === 'SET_ZOOM') {
    // 고배율 캡처용 — 잠깐 확대했다가 원래대로 되돌린다
    const tabId = sender && sender.tab && sender.tab.id;
    if (tabId == null) {
      sendResponse({ ok: false });
      return false;
    }
    chrome.tabs
      .setZoom(tabId, msg.factor)
      .then(() => sendResponse({ ok: true }))
      .catch((err) => sendResponse({ ok: false, error: String(err && err.message) }));
    return true;
  }
  if (msg && msg.type === 'OPEN_CHARGEN') {
    chrome.tabs.create({ url: chrome.runtime.getURL('chargen/chargen.html') });
    sendResponse({ ok: true });
    return false;
  }
  if (msg && msg.type === 'OPEN_MANAGER') {
    // 콘텐트 스크립트(웹페이지)에서는 chrome-extension:// 페이지를 직접 열 수 없어 백그라운드가 대신 연다
    chrome.tabs.create({ url: chrome.runtime.getURL('manager/manager.html') });
    sendResponse({ ok: true });
    return false;
  }
  if (msg && msg.type === 'SPLIT_SAME') {
    splitSameRoom(msg.target, msg.count, msg.screen)
      .then(() => sendResponse({ ok: true }))
      .catch((err) => sendResponse({ ok: false, error: String(err && err.message) }));
    return true; // async
  }
  return false;
});

// ---- 로그 수집기 (MAIN 월드에서 실행) ----
// v2.3: 결과를 응답 채널 대신 CustomEvent('cst-log-done')로 전달 (fire-and-forget)
//       — 서비스워커가 수집 도중 죽어도 결과가 끊기지 않는다.
//       적응형 대기(로딩이 빠르면 즉시 다음 스텝)로 수집 속도 개선.
function pageLogCollector(opts) {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const report = (phase, count, tab) => {
    try {
      window.dispatchEvent(
        new CustomEvent('cst-log-progress', { detail: JSON.stringify({ phase, count, tab }) })
      );
    } catch (_) {}
  };
  const finish = (result) => {
    try {
      window.dispatchEvent(new CustomEvent('cst-log-done', { detail: JSON.stringify(result) }));
    } catch (_) {}
  };

  function chatItems() {
    return [...document.querySelectorAll('[data-index]')].filter((it) =>
      it.querySelector('.MuiListItemText-primary')
    );
  }

  function maxChatIdx() {
    let max = null;
    for (const it of chatItems()) {
      const v = parseInt(it.dataset.index);
      if (!isNaN(v) && (max == null || v > max)) max = v;
    }
    return max;
  }

  function findScroller() {
    const explicit = [...document.querySelectorAll('[data-virtuoso-scroller="true"]')];
    let best = null;
    let bestCount = 0;
    for (const sc of explicit) {
      const cnt = [...sc.querySelectorAll('[data-index]')].filter((it) =>
        it.querySelector('.MuiListItemText-primary')
      ).length;
      if (cnt > bestCount) {
        best = sc;
        bestCount = cnt;
      }
    }
    if (best) return best;

    const items = chatItems();
    for (const it of items.slice(0, 3)) {
      let p = it.parentElement;
      while (p && p !== document.body) {
        if (p.scrollHeight > p.clientHeight + 20) {
          const st = getComputedStyle(p);
          if (/(auto|scroll|overlay)/.test(st.overflowY)) return p;
        }
        p = p.parentElement;
      }
    }
    return null;
  }

  // 탭 라벨에서 안읽음 배지 숫자(.MuiBadge-badge) 등을 제거한 순수 이름
  function cleanTabName(tabEl) {
    try {
      const clone = tabEl.cloneNode(true);
      clone.querySelectorAll('.MuiBadge-badge, svg').forEach((x) => x.remove());
      const nm = (clone.textContent || '').trim();
      if (nm) return nm;
    } catch (_) {}
    return (tabEl.textContent || '').trim();
  }

  function findChatTabs() {
    const input = document.querySelector('div[class*="MuiInputBase-root"] textarea');
    const starts = [];
    if (input) starts.push(input);
    const scroller = findScroller();
    if (scroller) starts.push(scroller);
    for (const start of starts) {
      let el = start;
      for (let i = 0; i < 12 && el; i++) {
        if (el.querySelector) {
          let tl = el.querySelector('[role="tablist"]');
          if (!tl) tl = el.querySelector('.MuiTabs-root');
          if (tl) {
            const tabs = [...tl.querySelectorAll('[role="tab"], .MuiTab-root')].filter(
              (t) => (t.textContent || '').trim()
            );
            if (tabs.length >= 2) return tabs;
          }
        }
        el = el.parentElement;
      }
    }
    return [];
  }

  function viewSignature() {
    const its = chatItems();
    if (!its.length) return 'empty';
    const f = its[0];
    const l = its[its.length - 1];
    return (
      its.length +
      '|' +
      (f.textContent || '').slice(0, 60) +
      '|' +
      (l.textContent || '').slice(0, 60)
    );
  }

  function clickLikeUser(el2) {
    for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) {
      try {
        el2.dispatchEvent(
          new MouseEvent(type, { bubbles: true, cancelable: true, view: window, buttons: 1 })
        );
      } catch (_) {}
    }
  }

  function rgbToHex(rgb) {
    const m = String(rgb).match(/rgba?\((\d+)[,\s]+(\d+)[,\s]+(\d+)/);
    if (!m) return '';
    return (
      '#' + [m[1], m[2], m[3]].map((n) => Number(n).toString(16).padStart(2, '0')).join('')
    );
  }

  function decodeText(rawHtml) {
    return rawHtml
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<[^>]+>/g, '')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/&nbsp;/g, ' ')
      .replace(/&#(\d+);/g, (_, n) => {
        try { return String.fromCodePoint(parseInt(n)); } catch (_) { return ''; }
      })
      .replace(/&#x([0-9a-fA-F]+);/g, (_, h) => {
        try { return String.fromCodePoint(parseInt(h, 16)); } catch (_) { return ''; }
      })
      .trim();
  }

  // 리액트 fiber에서 메시지의 실제 작성 시각(초 단위 정확)을 캐낸다.
  // 코코포리아 구조 (2026-08 확인): <div data-index> 껍데기 바로 아래의 메시지 컴포넌트가
  // props로는 messageId만 받고, 메시지 객체({text, createdAt(ms), ...})는
  // useSelector 훅 상태({current:{hasValue,value}})로 들고 있다.
  // 그래서 껍데기에서 위로 올라가면 절대 못 찾고 — "안쪽 본문 노드에서 위로" 올라가며
  // 각 컴포넌트의 훅 상태를 뒤지다가 [data-index]에 닿으면 멈춰야 한다.
  // (그 위는 목록이 공유하는 영역이라 남의 시각을 집는 사고가 난다)
  // 채점: 같은 객체에 이 메시지 본문이 있으면 +2, messageId를 받은 컴포넌트면 +1.
  function extractExactTs(item, msgText, innerEl) {
    const MIN = 1262304000000; // 2010년 — 이보다 이르면 쓰레기 값
    const MAX = Date.now() + 172800000;
    const firstLine = (msgText || '').split('\n')[0].trim();

    function toMs(vv) {
      if (vv == null) return null;
      if (typeof vv === 'number') {
        if (vv > 1e14) return Math.floor(vv / 1000); // 마이크로초
        if (vv > 1e12) return vv; // 밀리초
        if (vv > 1e9) return vv * 1000; // 초
        return null;
      }
      if (vv instanceof Date) return vv.getTime();
      if (typeof vv === 'string') {
        if (!/^\d{4}-\d{2}-\d{2}/.test(vv)) return null;
        const t = Date.parse(vv);
        return isNaN(t) ? null : t;
      }
      if (typeof vv === 'object') {
        if (typeof vv.toDate === 'function') {
          try { return vv.toDate().getTime(); } catch (_) {}
        }
        const sec = vv.seconds != null ? vv.seconds : vv._seconds;
        if (typeof sec === 'number') {
          return sec * 1000 + Math.floor((vv.nanoseconds || vv._nanoseconds || 0) / 1e6);
        }
      }
      return null;
    }

    let bestTs = null;
    let bestScore = -1;

    // 후보 객체를 얕게(3단계) 훑어 createdAt 계열 키를 찾고 본문 일치로 채점
    function consider(root, bonus) {
      const stack = [[root, 0]];
      const seen = new Set();
      let n = 0;
      while (stack.length && n < 120) {
        const pair = stack.shift();
        const ob = pair[0];
        const d = pair[1];
        n++;
        if (!ob || typeof ob !== 'object' || seen.has(ob) || d > 3) continue;
        seen.add(ob);
        if (Array.isArray(ob) || ob.nodeType || ob.$$typeof) continue;
        let ts = null;
        let textMatch = false;
        // for..in은 프로토타입 체인까지 열거한다 — own key만 보면 방문 수가 크게 준다
        for (const kk of Object.keys(ob)) {
          let vv;
          try { vv = ob[kk]; } catch (_) { continue; }
          if (vv == null) continue;
          if (/^(createdAt|created|timestamp|sentAt|postedAt)$/i.test(kk)) {
            const t = toMs(vv);
            if (t && t > MIN && t < MAX && ts == null) ts = t;
          } else if (typeof vv === 'string') {
            // 주사위 대사는 화면 표기와 내부 text가 다를 수 있어 양방향 접두 비교
            if (firstLine && !textMatch && /^(text|body|content|message|value)$/i.test(kk)) {
              const s = vv.trim().split('\n')[0].trim();
              if (s && (s.indexOf(firstLine) === 0 || firstLine.indexOf(s) === 0)) textMatch = true;
            }
          } else if (typeof vv === 'object') {
            stack.push([vv, d + 1]);
          }
        }
        if (ts != null) {
          const score = (textMatch ? 2 : 0) + bonus;
          // 본문도 messageId도 없는 객체(방·유저 문서 등)의 createdAt은 남의 시각이다 — 버린다
          if (score > 0 && score > bestScore) {
            bestScore = score;
            bestTs = ts;
          }
        }
      }
    }

    try {
      const inner =
        innerEl ||
        item.querySelector('.MuiListItemText-secondary') ||
        item.querySelector('.MuiListItemText-primary') ||
        item;
      const fk = Object.keys(inner).filter((k) => k.indexOf('__react') === 0);
      for (let fi = 0; fi < fk.length; fi++) {
        let node = inner[fk[fi]];
        let dep = 0;
        while (node && dep < 20) {
          const pr = node.memoizedProps;
          const bonus = pr && typeof pr === 'object' && typeof pr.messageId === 'string' ? 1 : 0;
          if (pr && typeof pr === 'object') consider(pr, bonus);
          // 함수형 컴포넌트의 훅 체인 — useSelector 캐시가 여기 있다
          let hook = node.memoizedState;
          let hn = 0;
          while (hook && typeof hook === 'object' && hn < 40) {
            const hs = hook.memoizedState;
            if (hs != null && typeof hs === 'object') consider(hs, bonus);
            hook = hook.next;
            hn++;
          }
          if (node.stateNode === item) break; // [data-index] 껍데기 도달 — 그 위는 공유 영역
          node = node.return;
          dep++;
        }
      }
    } catch (_) {}
    return bestTs;
  }

  // DOM 노드 -> { html, tab, text, ts }
  // html이 그대로면 이전 스텝에서 이미 처리한 항목 — decode·fiber 탐색·키 조립을 전부 건너뛴다.
  // (스크롤 스텝마다 화면의 ~30개를 다시 훑는데, 그중 신규는 몇 개뿐이다)
  const exactMemo = new WeakMap();

  // /system 명령 등 이름·인장 없이 본문만 뜨는 줄을 시스템 메시지로 수집
  function collectSystem(item, collected, activeTabName, tabOrder) {
    // 입력줄·탭바·버튼 줄 오검출 방지 — 순수 글자 줄만 받는다
    if (item.querySelector('input, textarea, button, [role="tab"], [role="tablist"]')) return;
    // 본문 컨테이너: 글자가 있는 외길 자식으로 내려간 가장 안쪽 요소 (fiber 탐색 시작점)
    let el = item;
    for (let d = 0; d < 30; d++) {
      const kids = [...el.children].filter((c) => (c.textContent || '').trim());
      if (kids.length !== 1) break;
      el = kids[0];
    }
    const rawHtml = el.innerHTML || '';
    const memo = exactMemo.get(item);
    if (memo && memo.html === rawHtml && memo.tab === activeTabName) return;

    const clone = el.cloneNode(true);
    clone.querySelectorAll('img, svg, .MuiBadge-badge').forEach((x) => x.remove());
    const text = decodeText(clone.innerHTML || '');
    if (!text) {
      exactMemo.set(item, { html: rawHtml, tab: activeTabName, text: '', ts: null });
      return;
    }

    let exactTs;
    if (memo && memo.text === text) {
      exactTs = memo.ts;
    } else {
      exactTs = extractExactTs(item, text, el);
    }
    exactMemo.set(item, { html: rawHtml, tab: activeTabName, text, ts: exactTs });

    const tab = activeTabName || '';
    const key = 'SYS\x1F' + tab + '\x1F' + text + '\x1F' + (exactTs || '');
    if (collected.has(key)) return;

    let color = '';
    try {
      color = rgbToHex(getComputedStyle(el).color) || '';
    } catch (_) {}
    collected.set(key, {
      name: '',
      sys: true,
      tab,
      text,
      imgUrl: '',
      objFit: '',
      objPos: '',
      ts: '',
      exact: exactTs,
      color,
      tabOrder: tabOrder || 0,
      seq: collected.size,
    });
  }

  function collectVisible(collected, activeTabName, tabOrder, knownScroller) {
    // 이름 줄이 없는 시스템 항목까지 훑어야 하므로 채팅 스크롤러 안의 전 항목을 본다
    // (문서 전체의 [data-index]는 다른 가상 목록까지 집을 수 있어 스크롤러로 한정)
    // findScroller()는 문서 전체를 훑는 비싼 탐색이라, scrollPass가 이미 아는 것을 넘겨받는다
    const scroller = knownScroller || findScroller();
    const items = scroller ? [...scroller.querySelectorAll('[data-index]')] : chatItems();
    items.forEach((item) => {
      const idx = item.dataset.index;
      if (idx == null) return;
      const av = item.querySelector('.MuiListItemAvatar-root img');
      const nm = item.querySelector('.MuiListItemText-primary');
      const tx = item.querySelector('.MuiListItemText-secondary');
      if (!nm || !tx) {
        collectSystem(item, collected, activeTabName, tabOrder);
        return;
      }
      // 이전 스텝과 내용이 같은 노드면 통째로 건너뛴다 (decode·fiber·키 조립 전부 절약)
      const rawHtml = tx.innerHTML || '';
      const memo = exactMemo.get(item);
      if (memo && memo.html === rawHtml && memo.tab === activeTabName) return;

      const nameNode = nm.firstChild;
      const rawName = (nameNode && nameNode.nodeType === 3 ? nameNode.textContent : nm.textContent || '').trim();

      const tsEl = nm.querySelector('span.MuiTypography-caption,span,time,small');
      let tsRaw = tsEl ? (tsEl.getAttribute('datetime') || tsEl.textContent || '') : '';
      tsRaw = tsRaw.replace(/^[\s \-–]+/, '').replace(/[\s ]+$/, '').trim();

      const text = decodeText(rawHtml);
      if (!rawName || !text) {
        exactMemo.set(item, { html: rawHtml, tab: activeTabName, text: '', ts: null });
        return;
      }
      // fiber 탐색은 비싸다 — 같은 DOM 노드가 같은 본문을 보이고 있으면 지난 결과를 쓴다
      // (가상 스크롤이 노드를 재활용해 다른 대사를 그릴 수 있으므로 본문까지 맞아야 한다)
      let exactTs;
      if (memo && memo.text === text) {
        exactTs = memo.ts;
      } else {
        exactTs = extractExactTs(item, text);
      }
      exactMemo.set(item, { html: rawHtml, tab: activeTabName, text, ts: exactTs });

      let tab = '';
      let name = rawName;
      const m = rawName.match(/^\[([^\]]+)\]\s*(.+)$/);
      if (m) {
        tab = m[1].trim();
        name = m[2].trim();
      } else if (activeTabName) {
        tab = activeTabName;
      }

      const key = tab + '\x1F' + name + '\x1F' + text + '\x1F' + (exactTs || tsRaw);
      if (collected.has(key)) return;

      let imgUrl = av && av.src ? av.src : '';
      if (!/^https?:/i.test(imgUrl)) imgUrl = '';

      let objFit = '';
      let objPos = '';
      if (av) {
        try {
          const cs = getComputedStyle(av);
          objFit = cs.objectFit || '';
          objPos = cs.objectPosition || '';
        } catch (_) {}
      }

      const color = rgbToHex(getComputedStyle(nm).color) || '';
      collected.set(key, {
        name,
        tab,
        text,
        imgUrl,
        objFit,
        objPos,
        ts: tsRaw,
        exact: exactTs,
        color,
        tabOrder: tabOrder || 0,
        seq: collected.size,
      });
    });
  }

  async function scrollPass(collected, activeTabName, tabOrder) {
    const scroller = findScroller();
    if (!scroller) {
      collectVisible(collected, activeTabName, tabOrder);
      report('noscroll', collected.size, activeTabName);
      return;
    }

    // 1) 맨 위까지 올리기 — 수집은 하지 않음. 로딩이 감지되는 즉시 다음 스텝 (적응형 대기)
    // 폴링 간격 150ms → 60ms: 변화를 더 빨리 알아채고, 종료 판정(stable>=3)은 그대로.
    let stable = 0;
    let lastHeight = scroller.scrollHeight;
    for (let guard = 0; guard < 3000; guard++) {
      if (window.__cstAbort) return;
      scroller.scrollTop = 0;
      let changed = false;
      for (let w = 0; w < 10; w++) {
        await sleep(60); // 변화 감지 즉시 진행, 최대 600ms 대기
        if (scroller.scrollHeight !== lastHeight) {
          changed = true;
          break;
        }
      }
      lastHeight = scroller.scrollHeight;
      const loaded = maxChatIdx();
      report('up', loaded == null ? 0 : loaded + 1, activeTabName);
      if (!changed && scroller.scrollTop <= 1) {
        if (++stable >= 3) break;
      } else {
        stable = 0;
      }
    }
    scroller.scrollTop = 0;
    await sleep(300);

    // 2) 아래로 단계 스크롤하며 수집 (위→아래 = 시간순)
    // 고정 180ms 대기가 수집 총시간을 지배했다 (5천 건 ≈ 800스텝 × 180ms ≈ 2분 30초).
    // → 스크롤 후 화면 서명이 바뀔 때까지만 짧게 폴링 (보통 60~120ms, 최대 240ms).
    //   렌더가 느린 스텝은 예전과 같은 수준으로 기다리므로 놓치는 메시지는 없다.
    stable = 0;
    let prevCount = collected.size;
    for (let guard = 0; guard < 4000; guard++) {
      if (window.__cstAbort) return;
      collectVisible(collected, activeTabName, tabOrder, scroller);
      report('down', collected.size, activeTabName);
      const atBottom = scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 4;
      if (collected.size === prevCount && atBottom) {
        if (++stable >= 3) break;
      } else {
        stable = 0;
      }
      prevCount = collected.size;
      const beforeSig = viewSignature();
      scroller.scrollTop += Math.max(150, Math.floor(scroller.clientHeight * 0.85));
      for (let w = 0; w < 4; w++) {
        await sleep(60);
        if (viewSignature() !== beforeSig) break;
      }
    }
  }

  // 지금 선택돼 있는 채팅 탭 이름 (스냅샷용)
  function currentTab() {
    try {
      const tabs = findChatTabs();
      const i = tabs.findIndex((t) => t.getAttribute && t.getAttribute('aria-selected') === 'true');
      return i >= 0 ? { name: cleanTabName(tabs[i]), order: i } : { name: '', order: 0 };
    } catch (_) {
      return { name: '', order: 0 };
    }
  }

  // ---- 자동 백업 스냅샷: 화면을 건드리지 않고 보이는 것만 즉시 반환 ----
  if (opts && opts.snapshot) {
    if (window.__cstCollecting) return { ok: false, error: 'busy' };
    try {
      const collected = new Map();
      const t = currentTab();
      collectVisible(collected, t.name, t.order);
      return { ok: true, messages: [...collected.values()], tab: t.name };
    } catch (err) {
      return { ok: false, error: String((err && err.message) || err) };
    }
  }

  // ---- 실행 (fire-and-forget: 결과는 cst-log-done 이벤트로) ----
  if (window.__cstCollecting) {
    finish({ ok: false, error: '이미 수집이 진행 중입니다. 끝날 때까지 기다려 주세요.' });
    return true;
  }
  window.__cstCollecting = true;
  // 패널의 [수집 중지] 버튼
  window.__cstAbort = false;
  const onAbort = () => (window.__cstAbort = true);
  window.addEventListener('cst-log-abort', onAbort);

  (async () => {
    let result;
    try {
      if (!chatItems().length) {
        result = { ok: false, error: '채팅 메시지를 찾을 수 없습니다. 코코포리아 방 화면에서 실행해주세요.' };
      } else {
        const collected = new Map();
        const tabs = opts.allTabs ? findChatTabs() : [];
        let tabSwitchFailed = false;
        const tabNames = [];

        if (tabs.length >= 2) {
          for (let i = 0; i < tabs.length; i++) {
            if (window.__cstAbort) break;
            const tabName = cleanTabName(tabs[i]);
            report('tab', collected.size, tabName);
            const sigBefore = viewSignature();
            clickLikeUser(tabs[i]);
            await sleep(1000);
            const sigAfter = viewSignature();
            const selected =
              tabs[i].getAttribute && tabs[i].getAttribute('aria-selected') === 'true';
            if (i > 0 && sigBefore === sigAfter && !selected) {
              tabSwitchFailed = true;
              report('tabfail', collected.size, tabName);
              break;
            }
            tabNames.push(tabName);
            await scrollPass(collected, tabName, i);
          }
          try { clickLikeUser(tabs[0]); } catch (_) {}
          if (tabSwitchFailed && collected.size === 0) {
            await scrollPass(collected, '', 0);
          }
        } else {
          if (opts.allTabs) report('onetab', 0, '');
          await scrollPass(collected, '', 0);
        }

        const arr = [...collected.values()];
        report('done', arr.length, '');
        result = { ok: true, messages: arr, tabSwitchFailed, tabNames, aborted: !!window.__cstAbort };
      }
    } catch (err) {
      result = { ok: false, error: String((err && err.message) || err) };
    }
    window.__cstCollecting = false;
    window.removeEventListener('cst-log-abort', onAbort);
    finish(result);
  })();

  return true; // executeScript는 즉시 끝난다
}

// ---- 화면 분할: 같은 방을 여러 창으로 열어 격자 배치 ----
// 한 방의 채팅 탭(메인/정보/잡담…)을 창마다 따로 띄워 보는 용도.
// target: { tabId } (열려 있는 방 탭 — 그 창을 첫 슬롯으로 이동) 또는 { url }
// count: 2~9, screen: { availLeft, availTop, availWidth, availHeight }
async function splitSameRoom(target, count, screen) {
  const n = Math.min(Math.max(Number(count) || 2, 1), 9);
  const L = screen.availLeft || 0;
  const T = screen.availTop || 0;
  const W = screen.availWidth || 1920;
  const H = screen.availHeight || 1080;

  // 격자 계산: 2=좌우, 3=좌1+우2, 4=2×2, 5~6=3×2, 7~9=3×3
  let rects = [];
  if (n === 3) {
    const half = (v) => Math.floor(v / 2);
    rects = [
      { left: L, top: T, width: half(W), height: H },
      { left: L + half(W), top: T, width: W - half(W), height: half(H) },
      { left: L + half(W), top: T + half(H), width: W - half(W), height: H - half(H) },
    ];
  } else {
    const cols = n <= 2 ? n : n <= 4 ? 2 : 3;
    const rows = Math.ceil(n / cols);
    const cw = Math.floor(W / cols);
    const rh = Math.floor(H / rows);
    for (let i = 0; i < n; i++) {
      const c = i % cols;
      const r = Math.floor(i / cols);
      rects.push({
        left: L + c * cw,
        top: T + r * rh,
        width: c === cols - 1 ? W - cw * (cols - 1) : cw,
        height: r === rows - 1 ? H - rh * (rows - 1) : rh,
      });
    }
  }

  // 대상 방의 roomId 추출 → 채팅 전용 화면(/chat)만 새 창으로 연다.
  // 원래 방 탭은 그대로 둔다.
  let url = target.url;
  if (target.tabId != null) {
    const tab = await chrome.tabs.get(target.tabId).catch(() => null);
    if (tab) url = tab.url;
  }
  const m = String(url || '').match(/\/rooms\/([^/?#]+)/);
  if (!m) throw new Error('방 주소를 인식하지 못했습니다.');
  const chatUrl = 'https://ccfolia.com/rooms/' + m[1] + '/chat';

  for (let i = 0; i < n; i++) {
    await chrome.windows.create({
      url: chatUrl,
      left: rects[i].left,
      top: rects[i].top,
      width: rects[i].width,
      height: rects[i].height,
      focused: i === n - 1,
    });
  }
}

// ---- 콘텐트 스크립트 주입 (설치/업데이트 직후 이미 열려 있던 탭 대응) ----
async function injectIntoTab(tabId, frameId) {
  const target =
    frameId != null ? { tabId, frameIds: [frameId] } : { tabId, allFrames: true };
  await chrome.scripting.insertCSS({ target, files: ['content/spell.css'] });
  await chrome.scripting.executeScript({
    target,
    files: ['content/spell.js', 'content/replace.js'],
  });
}

chrome.runtime.onInstalled.addListener(async () => {
  await refreshContextMenu();
  // 이미 열려 있는 탭에도 주입 (chrome:// 등 불가한 탭은 무시)
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });
  for (const tab of tabs) {
    if (tab.id == null) continue;
    injectIntoTab(tab.id).catch(() => {});
  }
});

// ---- 우클릭 메뉴: 선택 영역 즉시 교정 ----
const MENU_ID = 'textdoctor-correct-selection';

function refreshContextMenu() {
  return new Promise((resolve) => {
    chrome.contextMenus.removeAll(async () => {
      const { contextMenu } = await getSettings();
      if (contextMenu) {
        chrome.contextMenus.create(
          {
            id: MENU_ID,
            title: '맞춤법 검사 후 자동 교정',
            contexts: ['selection'],
          },
          () => void chrome.runtime.lastError
        );
      }
      resolve();
    });
  });
}

chrome.storage.onChanged.addListener((changes, area) => {
  // 맞춤법 설정 캐시 무효화 (sync·local 어느 쪽이 바뀌어도)
  if (Object.keys(DEFAULTS).some((k) => k in changes)) settingsCache = null;
  if (area === 'sync' && changes.contextMenu) refreshContextMenu();
});

function sendToTab(tabId, frameId, message) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, { frameId: frameId || 0 }, (res) => {
      if (chrome.runtime.lastError) resolve({ delivered: false });
      else resolve({ delivered: true, res });
    });
  });
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== MENU_ID || !tab || tab.id == null) return;
  const msg = { type: 'CONTEXT_CORRECT' };
  let r = await sendToTab(tab.id, info.frameId, msg);
  if (!r.delivered) {
    // 콘텐트 스크립트가 없는 탭(설치 전에 연 탭 등) → 주입 후 재시도
    try {
      await injectIntoTab(tab.id, info.frameId);
      await sendToTab(tab.id, info.frameId, msg);
    } catch (_) {
      // chrome:// 웹스토어 등 주입 불가 페이지
    }
  }
});
