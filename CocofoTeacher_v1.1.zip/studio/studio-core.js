// 코코포리아 선생님 — 로그 스튜디오
// 파일이 하나로 너무 커져서 역할별로 나눴다. studio.html이 이 순서대로 읽어 들인다.
//   core → settings → edit → main

// [core] 저장소 helper · 상태 · 예시 데이터 · 공용 위젯 · 프리셋 픽커
// 코코포리아 선생님 — 로그 스튜디오 (미리보기 + 상세 설정)
const $ = (id) => document.getElementById(id);
const B = window.CSTLogBuild;

const THEMES = ['dark', 'light', 'mono', 'retro'];

// chrome 객체가 있어도 확장 컨텍스트가 아니면(미리보기 등) 기본값으로 폴백
function hasStorage() {
  try {
    return !!(typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync && chrome.storage.local);
  } catch (_) {
    return false;
  }
}

const getLocal = (defs) =>
  new Promise((r) => {
    if (!hasStorage()) return r(defs);
    try {
      chrome.storage.local.get(defs, (d) => r(chrome.runtime && chrome.runtime.lastError ? defs : d));
    } catch (_) {
      r(defs);
    }
  });
const setLocal = (obj) =>
  new Promise((r) => {
    if (!hasStorage()) return r();
    try {
      chrome.storage.local.set(obj, () => r());
    } catch (_) {
      r();
    }
  });
const getSync = (defs) =>
  new Promise((r) => {
    if (!hasStorage()) return r(defs);
    try {
      chrome.storage.sync.get(defs, (d) => r(chrome.runtime && chrome.runtime.lastError ? defs : d));
    } catch (_) {
      r(defs);
    }
  });
const setSync = (obj) =>
  new Promise((r) => {
    if (!hasStorage()) return r();
    try {
      chrome.storage.sync.set(obj, () => r());
    } catch (_) {
      r();
    }
  });

// 로그 설정은 local을 정본으로 둔다.
// sync는 항목당 8KB 한도가 있어 설정이 커지면 조용히 저장에 실패한다.
// (sync에도 함께 써서 다른 기기에서 처음 열 때 값을 물려받게만 한다)
async function loadLogSettings() {
  const lc = await getLocal({ logSettings: null });
  if (lc && lc.logSettings) return lc.logSettings;
  const sv = await getSync({ logSettings: null });
  return sv ? sv.logSettings : null;
}

async function saveLogSettings(v) {
  await setLocal({ logSettings: v });
  try {
    await setSync({ logSettings: v }); // 실패해도 무시 (한도 초과 등)
  } catch (_) {}
}

// 예시 데이터 — 사용자의 실제 "예시방" 백업본 기반
const CDN = 'https://storage.ccfolia-cdn.net/users/Cwx76zlSUqg7jST19jJyO8b9N7J3/files/';
const IMG_WINDOW = CDN + 'b9697da1431b618940901d28283719ff3846940b1b2c0e2cb4f9f1bcad13d4dd?t=1786186595212';
const IMG_WINDOW2 = CDN + '8e02d21898cbaca48e6359236fde20e7ba43a5ea7923e0477e3e5c1ddca7c9b0?t=1786186629448';
const IMG_GM = CDN + '48da9160e13147bae6c4fde774ea597461c164bfb0d6b3608f3cd1863800433f?t=1786186696528';
const IMG_TDC = CDN + '732129a9762bc88c71c86176270c33e33f388be24f38227177de7dc62a80d4de?t=1786186640257';
const OP = { objFit: 'cover', objPos: '50% 0%' };
const T0 = 1786186020000; // 20:07 기준
const SAMPLE = [
  { name: 'WINDOW', tab: '메인', text: '간단하게 백업하는 코코포리아 로그!', imgUrl: IMG_WINDOW, ...OP, tabOrder: 0, seq: 0, ts: '今日 20:07', exact: T0, color: '#4caf50' },
  { name: 'WINDOW', tab: '메인', text: '이제 클릭 몇 번으로 예쁘게 저장할 수 있다', imgUrl: IMG_WINDOW, ...OP, tabOrder: 0, seq: 1, ts: '今日 20:07', exact: T0 + 10000, color: '#4caf50' },
  { name: 'GM', tab: '메인', text: '「탭별로 양식 지정이 가능합니다.」', imgUrl: IMG_GM, ...OP, tabOrder: 0, seq: 2, ts: '今日 20:07', exact: T0 + 20000, color: '#888888' },
  { name: 'TWO DOOR CINEMA', tab: '메인', text: 'CCB<=60 【행운】 (1D100<=60) ＞ 6 ＞ 스페셜', imgUrl: IMG_TDC, ...OP, tabOrder: 0, seq: 3, ts: '今日 20:07', exact: T0 + 30000, color: '#3f51b5' },
  { name: 'WINDOW', tab: '메인', text: 'CCB<=40 【회피】 (1D100<=40) ＞ 97 ＞ 펌블', imgUrl: IMG_WINDOW, ...OP, tabOrder: 0, seq: 4, ts: '今日 20:07', exact: T0 + 40000, color: '#4caf50' },
  { name: 'GM', tab: '정보', text: '정보 탭은 강조 표시로 눈에 띄게', imgUrl: IMG_GM, ...OP, tabOrder: 1, seq: 0, ts: '今日 20:08', exact: T0 + 60000, color: '#888888' },
  { name: 'TWO DOOR CINEMA', tab: '잡담', text: '잡담 탭은 흐리게 처리 가능 [편집 완료]', imgUrl: IMG_TDC, ...OP, tabOrder: 2, seq: 0, ts: '今日 20:08', exact: T0 + 70000, color: '#3f51b5' },
  { name: 'WINDOW', tab: '잡담', text: '연속 대사 묶기도 지원', imgUrl: IMG_WINDOW, ...OP, tabOrder: 2, seq: 1, ts: '今日 20:08', exact: T0 + 80000, color: '#4caf50' },
  { name: 'WINDOW', tab: '잡담', text: '이렇게!', imgUrl: IMG_WINDOW, ...OP, tabOrder: 2, seq: 2, ts: '今日 20:08', exact: T0 + 90000, color: '#4caf50' },
  { name: 'WINDOW', tab: '메인', text: '[편집 완료]', imgUrl: IMG_WINDOW, ...OP, tabOrder: 0, seq: 5, ts: '今日 20:11', exact: T0 + 240000, color: '#4caf50' },
  { name: '', sys: true, tab: '메인', text: '/system 명령으로 보낸 시스템 안내문은 이렇게 표시됩니다.', imgUrl: '', objFit: '', objPos: '', tabOrder: 0, seq: 6, ts: '', exact: T0 + 245000, color: '#888888' },
  { name: 'WINDOW', tab: '메인', text: '스탠딩 변경 예시.', imgUrl: IMG_WINDOW2, ...OP, tabOrder: 0, seq: 7, ts: '今日 20:11', exact: T0 + 250000, color: '#4caf50' },
  { name: 'WINDOW', tab: '메인', text: '테스트 끝…….', imgUrl: IMG_WINDOW2, ...OP, tabOrder: 0, seq: 8, ts: '今日 20:11', exact: T0 + 260000, color: '#4caf50' },
];

let s = B.normalizeSettings(null);
let data = null; // { roomName, messages, tabNames }
let renderTimer = 0;
let bgImage = ''; // logBgImage (local storage) 메모리 캐시
let headerImage = ''; // logHeaderImage — 세션 카드 이미지
let collectedAt = Date.now(); // 수집 시점 (상대 시각 역산 기준)
let tsFormat = 'auto'; // 시각 표시 형식
let editMode = false; // 미리보기에서 대사 편집
let editingId = null; // 편집 중인 메시지 __id
let midSeq = 0;
const brokenUrls = new Set(); // 검사에서 깨진 것으로 판정된 URL

function normalizeHex(v) {
  let x = String(v || '').trim();
  if (!x) return '';
  if (!x.startsWith('#')) x = '#' + x;
  return /^#[0-9a-fA-F]{6}$/.test(x) ? x.toLowerCase() : '';
}

async function applyPageTheme() {
  const t = await getSync({ theme: 'dark', accentColor: '', uiDesign: 'basic', helpOn: true });
  const theme = THEMES.includes(t.theme) ? t.theme : 'dark';
  for (const th of THEMES) document.body.classList.toggle('theme-' + th, theme === th && th !== 'dark');
  const a = normalizeHex(t.accentColor);
  if (a) document.body.style.setProperty('--accent', a);
  // 세로 디자인: 미리보기가 위, 편집판이 아래로 가는 상하 배치
  document.body.classList.toggle('design-rail', t.uiDesign === 'rail');
  // '설명 표시' 꺼짐 → ? 안내 버튼 숨김 (팝업 설정과 같은 sync 값)
  document.body.classList.toggle('help-off', t.helpOn === false);
}

// ---------- ? 안내 툴팁 ----------
// CSS ::after 로는 스크롤 패널(.st-side) 밖으로 못 삐져나와 잘렸다.
// body에 fixed로 띄우고, 기본은 버튼 위쪽 — 자리가 없으면 아래로.
(() => {
  let tipEl = null;
  const hideTip = () => {
    if (tipEl) tipEl.remove();
    tipEl = null;
  };
  const showTip = (btn) => {
    hideTip();
    const text = btn.dataset.tip;
    if (!text) return;
    tipEl = document.createElement('div');
    tipEl.className = 'st-tip';
    tipEl.textContent = text;
    document.body.appendChild(tipEl);
    const r = btn.getBoundingClientRect();
    const tw = tipEl.offsetWidth;
    const th = tipEl.offsetHeight;
    const left = Math.min(Math.max(8, r.left + r.width / 2 - tw / 2), innerWidth - tw - 8);
    let top = r.top - th - 6;
    if (top < 8) top = r.bottom + 6;
    tipEl.style.left = left + 'px';
    tipEl.style.top = top + 'px';
  };
  document.addEventListener('mouseover', (e) => {
    const btn = e.target.closest && e.target.closest('.st-help');
    if (btn) showTip(btn);
    else hideTip();
  });
  document.addEventListener('focusin', (e) => {
    const btn = e.target.closest && e.target.closest('.st-help');
    if (btn) showTip(btn);
  });
  document.addEventListener('focusout', hideTip);
  document.addEventListener('scroll', hideTip, true);
})();

// 편집에서 행을 되짚기 위한 안정된 식별자
// 메시지를 복사해 붙이면 __id까지 따라와 겹칠 수 있다.
// 겹친 id는 새로 발급한다 — 안 그러면 하나를 지울 때 엉뚱한 것까지 같이 지워진다.
function assignIds(list) {
  const seen = new Set();
  for (const m of list) {
    if (!m.__id || seen.has(m.__id)) m.__id = 'm' + midSeq++;
    seen.add(m.__id);
  }
  return list;
}

function findMsg(id) {
  return data.messages.find((m) => m.__id === id);
}

function tabNamesOf() {
  const names = [];
  for (const m of data.messages) {
    if (m.divider) continue;
    const t = m.tab || '메인';
    if (!names.includes(t)) names.push(t);
  }
  return names;
}

// ---------- 공용 위젯: 세그먼트 버튼 ----------
function mkSeg(options, getCur, onChange) {
  const wrap = document.createElement('span');
  wrap.className = 'seg';
  const paint = () => {
    const cur = getCur();
    [...wrap.children].forEach((b) => b.classList.toggle('on', b.dataset.v === cur));
  };
  for (const [v, label] of options) {
    const b = document.createElement('button');
    b.type = 'button';
    b.dataset.v = v;
    b.textContent = label;
    b.addEventListener('click', () => {
      onChange(v);
      paint();
    });
    wrap.appendChild(b);
  }
  paint();
  wrap.repaint = paint;
  return wrap;
}

// ---------- 프리셋 픽커 (미니 미리보기 드롭다운) ----------
const presetPop = () => $('presetPop');

function previewRowHtml(mode, key) {
  // 미니어처 가짜 메시지 행 — studio.css의 .pv-* 클래스가 프리셋 모양을 축소 재현
  if (mode === 'row') {
    return `<div class="pv-row pv-r-${key}"><span class="pv-ic"></span><span class="pv-body"><span class="pv-nm">PC1</span><span class="pv-tx">1D100 ＞ 6 성공</span></span></div>`;
  }
  if (mode === 'tabbadge') {
    const label = key === 'bracket' ? '[메인]' : '메인';
    return `<div class="pv-row"><span class="pv-ic"></span><span class="pv-body"><span class="pv-nm">이름<span class="pv-tab pv-tb-${key}">${label}</span></span><span class="pv-tx">대사 한 줄</span></span></div>`;
  }
  if (mode === 'tabsec') {
    return `<div class="pv-sec-wrap"><div class="pv-sec pv-ts-${key}"><span>메인</span></div><div class="pv-row"><span class="pv-ic"></span><span class="pv-body"><span class="pv-nm">이름</span></span></div></div>`;
  }
  if (mode === 'sys') {
    return `<div class="pv-sys pv-sy-${key}"><span class="pv-sys-in"><span class="pv-sys-tx">시스템 안내문</span></span></div>`;
  }
  if (mode === 'header') {
    return `<div class="pv-hd pv-hd-${key}"><span class="pv-hd-t">제목</span><span class="pv-hd-s">부제목</span></div>`;
  }
  if (mode === 'headerimg') {
    return `<div class="pv-hdimg pv-hdi-${key}"></div>`;
  }
  if (mode === 'role') {
    return `<div class="pv-role"><span class="pv-role-${key}">KP</span> 수해</div>`;
  }
  const cls = mode === 'normal' ? 'pv-n-' + key : mode === 'emph' ? 'pv-e-' + key : 'pv-d-' + key;
  return `<div class="pv-row ${cls}"><span class="pv-ic"></span><span class="pv-body"><span class="pv-nm">이름</span><span class="pv-tx">대사가 이렇게 보여요</span></span></div>`;
}

function openPresetPicker(anchor, mode, current, onPick, opts) {
  const pop = presetPop();
  pop.innerHTML = '';
  // 드롭다운 맨 위에서 모드(기본/강조/흐리게)를 바로 바꿀 수 있다
  if (opts && opts.modes) {
    const bar = document.createElement('div');
    bar.className = 'preset-modebar';
    for (const [v, label] of opts.modes) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'preset-mode' + (v === opts.currentMode ? ' on' : '');
      b.textContent = label;
      b.addEventListener('click', (e) => {
        e.stopPropagation();
        closePresetPicker();
        opts.onMode(v);
      });
      bar.appendChild(b);
    }
    pop.appendChild(bar);
  }
  const metas = B.PRESET_META[mode] || [];
  for (const [key, label] of metas) {
    const item = document.createElement('button');
    item.type = 'button';
    item.className = 'preset-item' + (key === current ? ' on' : '');
    item.innerHTML = `<span class="pi-label">${label}</span>${previewRowHtml(mode, key)}`;
    item.addEventListener('click', () => {
      closePresetPicker();
      onPick(key);
    });
    pop.appendChild(item);
  }
  const r = anchor.getBoundingClientRect();
  pop.classList.remove('hidden');
  const pw = 240;
  let left = Math.min(r.left, innerWidth - pw - 12);
  pop.style.left = left + 'px';
  const ph = pop.offsetHeight;
  pop.style.top = (r.bottom + ph + 8 > innerHeight ? Math.max(8, r.top - ph - 4) : r.bottom + 4) + 'px';
  setTimeout(() => {
    const close = (e) => {
      if (!pop.contains(e.target)) closePresetPicker();
    };
    pop._closer = close;
    document.addEventListener('pointerdown', close);
  }, 0);
}

function closePresetPicker() {
  const pop = presetPop();
  pop.classList.add('hidden');
  if (pop._closer) {
    document.removeEventListener('pointerdown', pop._closer);
    pop._closer = null;
  }
}

function presetLabel(mode, key) {
  const found = (B.PRESET_META[mode] || []).find(([k]) => k === key);
  return found ? found[1] : key || '기본';
}

// 버튼 안에 고른 디자인의 미니 미리보기까지 함께 보여준다 (드롭다운에 뜨는 것과 같은 것)
function mkPresetBtn(mode, getCur, onPick) {
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'preset-btn preset-btn-wide';
  const paint = () => {
    const key = getCur();
    btn.innerHTML = `<span class="pb-label">${presetLabel(mode, key)}</span>${previewRowHtml(mode, key)}`;
  };
  paint();
  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    openPresetPicker(btn, mode, getCur(), (key) => {
      onPick(key);
      paint();
    });
  });
  return btn;
}
