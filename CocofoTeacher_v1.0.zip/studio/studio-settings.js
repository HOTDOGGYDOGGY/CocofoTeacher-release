// [settings] 탭별 스타일 · 설정 폼 · 머리말
// ---------- 탭별 스타일 UI ----------
function defaultPresetOf(mode) {
  return mode === 'emph' ? 'bar' : mode === 'dim' ? 'fade' : 'basic';
}

function renderTabStyles() {
  const box = $('tabStyleRows');
  box.innerHTML = '';
  const names = tabNamesOf();
  if (!names.length) {
    const d = document.createElement('div');
    d.className = 'st-desc';
    d.textContent = '탭이 없습니다.';
    box.appendChild(d);
    return;
  }
  names.forEach((name, i) => {
    const st = (s.tabStyles && s.tabStyles[name]) || { mode: 'normal', preset: '', color: '' };
    const row = document.createElement('div');
    row.className = 'tab-style-row';

    // 포함 체크 (해제 = 숨김) — 탭 필터
    const inc = document.createElement('input');
    inc.type = 'checkbox';
    inc.title = '이 탭 포함/제외';
    inc.checked = st.mode !== 'hide';

    // 탭 이름 수정 가능 ('메인0' 같이 잘못 수집된 이름 교정)
    const label = document.createElement('input');
    label.type = 'text';
    label.className = 'tname-input';
    label.value = name;
    label.title = '탭 이름 수정 (수정하면 이 탭의 모든 메시지에 적용)';
    label.addEventListener('change', () => {
      const newName = label.value.trim();
      if (!newName || newName === name) {
        label.value = name;
        return;
      }
      for (const m of data.messages) {
        if (m.tab === name) m.tab = newName;
      }
      if (s.tabStyles && s.tabStyles[name]) {
        s.tabStyles[newName] = s.tabStyles[name];
        delete s.tabStyles[name];
      }
      renderTabStyles();
      renderBadgeOnlyRows();
      renderPreview();
      renderImgFix();
    });

    let lastMode = st.mode === 'hide' ? 'normal' : st.mode;
    const sel = document.createElement('select');
    for (const [v, t] of [
      ['normal', '기본'],
      ['emph', '강조'],
      ['dim', '흐리게'],
    ]) {
      const o = document.createElement('option');
      o.value = v;
      o.textContent = t;
      if (lastMode === v) o.selected = true;
      sel.appendChild(o);
    }
    sel.disabled = st.mode === 'hide';

    const curStyle = () => (s.tabStyles && s.tabStyles[name]) || { mode: 'normal', preset: '', color: '' };
    const presetBtn = document.createElement('button');
    presetBtn.type = 'button';
    presetBtn.className = 'preset-btn';
    presetBtn.title = '이 탭의 디자인 프리셋 선택';
    const openPicker = () => {
      const mode = sel.value === 'emph' ? 'emph' : sel.value === 'dim' ? 'dim' : 'normal';
      openPresetPicker(
        presetBtn,
        mode,
        curStyle().preset || defaultPresetOf(sel.value),
        (key) => {
          s.tabStyles = s.tabStyles || {};
          s.tabStyles[name] = { mode: inc.checked ? sel.value : 'hide', preset: key, color: pick.value };
          paintPresetBtn();
          paintIc();
          updateConsoleRow();
          queueRender();
        },
        {
          // 드롭다운 안에서 기본/강조/흐리게를 바로 전환 (스크롤이 길어지지 않게)
          modes: [
            ['normal', '기본'],
            ['emph', '강조'],
            ['dim', '흐리게'],
          ],
          currentMode: mode,
          onMode: (mv) => {
            sel.value = mv;
            update();
            openPicker();
          },
        }
      );
    };
    presetBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      openPicker();
    });

    const pick = document.createElement('input');
    pick.type = 'color';
    pick.className = 'circle';
    pick.title = '탭 배지/강조 색';
    pick.value = normalizeHex(st.color) || B.TAB_PALETTE[i % B.TAB_PALETTE.length];

    const MODE_LABEL = { normal: '기본', emph: '강조', dim: '흐리게' };
    function paintPresetBtn() {
      const mode = sel.value === 'emph' ? 'emph' : sel.value === 'dim' ? 'dim' : 'normal';
      const key = curStyle().preset || defaultPresetOf(sel.value);
      presetBtn.innerHTML =
        `<span class="pb-label">${MODE_LABEL[mode]} · ${presetLabel(mode, key)}</span>` + previewRowHtml(mode, key);
    }
    presetBtn.classList.add('preset-btn-wide');
    paintPresetBtn();

    // 인장 숨김 — 작은 아이콘 버튼 (켜면 인장이 사라진다)
    const icWrap = document.createElement('button');
    icWrap.type = 'button';
    icWrap.className = 'ic-btn';
    let icOn = false;
    const paintIc = () => {
      const cur = curStyle();
      const mode = sel.value === 'emph' ? 'emph' : sel.value === 'dim' ? 'dim' : 'normal';
      const def = B.PRESET_HIDES_ICON[mode] || [];
      icOn =
        typeof cur.hideIcon === 'boolean'
          ? cur.hideIcon
          : def.includes(cur.preset || defaultPresetOf(sel.value));
      icWrap.innerHTML = typeof faIcon === 'function' ? faIcon('image') : '□';
      icWrap.classList.toggle('off', icOn);
      icWrap.title = icOn ? '인장 숨김 — 눌러서 다시 표시' : '인장 표시 중 — 눌러서 숨기기';
    };
    paintIc();
    icWrap.addEventListener('click', () => {
      s.tabStyles = s.tabStyles || {};
      const cur = curStyle();
      s.tabStyles[name] = { ...cur, mode: inc.checked ? sel.value : 'hide', color: pick.value, hideIcon: !icOn };
      paintIc();
      queueRender();
    });

    const update = () => {
      s.tabStyles = s.tabStyles || {};
      const prev = curStyle();
      // 모드가 바뀌면 프리셋은 그 모드의 기본값으로 초기화
      const preset = prev.mode === sel.value ? prev.preset : '';
      s.tabStyles[name] = { mode: inc.checked ? sel.value : 'hide', preset, color: pick.value };
      sel.disabled = !inc.checked;
      paintPresetBtn();
      paintIc();
      updateConsoleRow();
      queueRender();
    };
    inc.addEventListener('change', update);
    sel.addEventListener('change', update);
    pick.addEventListener('input', update);
    sel.classList.add('cst-hidden-sel'); // 모드는 프리셋 픽커 안에서 고른다
    const top = document.createElement('div');
    top.className = 'tab-style-top';
    top.append(inc, label);
    const bottom = document.createElement('div');
    bottom.className = 'tab-style-bottom';
    bottom.append(sel, presetBtn);
    top.append(icWrap, pick);
    row.append(top, bottom);
    box.appendChild(row);
  });
}

// ---------- 설정 그룹 접기 ----------
function bindGroupFolding() {
  const saved = (() => {
    try {
      return JSON.parse(localStorage.getItem('cstStudioFolds') || '{}');
    } catch (_) {
      return {};
    }
  })();
  for (const title of document.querySelectorAll('.st-group-fold')) {
    const group = title.closest('.st-group');
    const gid = title.dataset.g;
    const apply = () => {
      const folded = !!saved[gid];
      group.classList.toggle('folded', folded);
      title.dataset.folded = folded ? '1' : '0';
    };
    apply();
    title.addEventListener('click', (e) => {
      if (e.target.closest('button, input, label, select')) return;
      saved[gid] = !saved[gid];
      try {
        localStorage.setItem('cstStudioFolds', JSON.stringify(saved));
      } catch (_) {}
      apply();
    });
  }
}

// ---------- 설정 폼 바인딩 ----------
function bindForm() {
  const map = [
    ['sFont', 'font', 'value'],
    ['sFontSize', 'fontSize', 'number'],
    ['sLineHeight', 'lineHeight', 'number'],
    ['sImgSize', 'imgSize', 'number'],
    ['sImgShape', 'imgShape', 'value'],
    ['sSaveMode', 'saveMode', 'value'],
    ['sSplit', 'split', 'number'],
    ['sGroupSame', 'groupSame', 'checked'],
    ['sCompat', 'ccfoliaCompat', 'checked'],
    ['sTabBadgeFirst', 'tabBadgeFirstOnly', 'checked'],
  ];
  for (const [id, key, kind] of map) {
    const el = $(id);
    if (kind === 'checked') el.checked = !!s[key];
    else el.value = String(s[key]);
    el.addEventListener(kind === 'checked' ? 'change' : 'input', () => {
      s[key] = kind === 'checked' ? el.checked : kind === 'number' ? Number(el.value) : el.value;
      queueRender();
    });
  }

  // ---- 테마 스와치 ----
  renderThemeSwatches();

  // ---- image 테마 옵션 ----
  $('bgImagePickBtn').addEventListener('click', () => $('bgImageInput').click());
  $('bgImageInput').addEventListener('change', async () => {
    const file = $('bgImageInput').files[0];
    $('bgImageInput').value = '';
    if (!file) return;
    try {
      const dataUrl = await fileToDataUrl(file, 1920, 'image/jpeg', 0.85);
      bgImage = dataUrl;
      await setLocal({ logBgImage: dataUrl });
      updateBgImageInfo();
      queueRender();
    } catch (e) {
      $('bgImageInfo').textContent = '이미지를 읽지 못했습니다: ' + e.message;
    }
  });
  $('bgImageClearBtn').addEventListener('click', async () => {
    bgImage = '';
    await setLocal({ logBgImage: '' });
    updateBgImageInfo();
    queueRender();
  });
  $('bgLayoutSeg').appendChild(
    mkSeg(
      [
        ['panel', '가운데 카드'],
        ['full', '꽉 채움'],
      ],
      () => s.bgLayout,
      (v) => {
        s.bgLayout = v;
        queueRender();
      }
    )
  );
  $('bgToneSeg').appendChild(
    mkSeg(
      [
        ['dark', '어둡게'],
        ['light', '밝게'],
      ],
      () => s.bgTone,
      (v) => {
        s.bgTone = v;
        queueRender();
      }
    )
  );
  const ovIn = $('sBgOverlay');
  ovIn.value = Math.round((s.bgOverlay || 0.6) * 100);
  $('bgOverlayOut').textContent = ovIn.value + '%';
  ovIn.addEventListener('input', () => {
    s.bgOverlay = Number(ovIn.value) / 100;
    $('bgOverlayOut').textContent = ovIn.value + '%';
    queueRender();
  });
  const blIn = $('sBgBlur');
  blIn.value = s.bgBlur;
  $('bgBlurOut').textContent = blIn.value + 'px';
  blIn.addEventListener('input', () => {
    s.bgBlur = Number(blIn.value);
    $('bgBlurOut').textContent = blIn.value + 'px';
    queueRender();
  });
  updateBgImageInfo();

  // ---- 주사위 색 ----
  $('diceColorSeg').appendChild(
    mkSeg(
      [
        ['off', '안함'],
        ['all', '모든 주사위'],
        ['judge', '성공/실패'],
      ],
      () => s.diceColor.mode,
      (v) => {
        s.diceColor.mode = v;
        updateDiceRows();
        queueRender();
      }
    )
  );
  for (const [id, key] of [['sDiceAll', 'all'], ['sDiceSuccess', 'success'], ['sDiceFail', 'fail']]) {
    const el = $(id);
    el.value = s.diceColor[key];
    el.addEventListener('input', () => {
      s.diceColor[key] = el.value;
      queueRender();
    });
  }
  updateDiceRows();

  // 콘솔 배경
  $('consoleBgSeg').appendChild(
    mkSeg(
      [
        ['dark', '어둡게'],
        ['light', '밝게'],
        ['custom', '색 지정'],
      ],
      () => s.consoleBg,
      (v) => {
        s.consoleBg = v;
        updateConsoleRow();
        queueRender();
      }
    )
  );
  $('sConsoleColor').value = normalizeHex(s.consoleColor) || '#2a2a2a';
  $('sConsoleColor').addEventListener('input', () => {
    s.consoleColor = $('sConsoleColor').value;
    queueRender();
  });

  // Roll20 판정표 조절
  for (const [id, key, outId, unit, max] of [
    ['sR20Width', 'r20Width', 'r20WidthOut', 'px', 520],
    ['sR20Radius', 'r20Radius', 'r20RadiusOut', 'px', 20],
  ]) {
    const el = $(id);
    el.value = s[key];
    $(outId).textContent = s[key] + unit;
    el.addEventListener('input', () => {
      s[key] = Number(el.value);
      $(outId).textContent = s[key] + unit;
      queueRender();
    });
  }
  $('r20BorderSeg').appendChild(
    mkSeg(
      [
        ['off', '없음'],
        ['on', '있음'],
      ],
      () => (s.r20Border ? 'on' : 'off'),
      (v) => {
        s.r20Border = v === 'on' ? $('sR20Border').value : '';
        $('sR20Border').classList.toggle('hidden', v !== 'on');
        queueRender();
      }
    )
  );
  $('sR20Border').value = normalizeHex(s.r20Border) || '#556677';
  $('sR20Border').classList.toggle('hidden', !s.r20Border);
  $('sR20Border').addEventListener('input', () => {
    s.r20Border = $('sR20Border').value;
    queueRender();
  });
  updateConsoleRow();

  // ---- 주사위/명령어 행 스타일 ----
  $('rowPresetPick').appendChild(
    mkPresetBtn('row', () => s.rowPreset || 'plain', (key) => {
      s.rowPreset = key;
      updateConsoleRow();
      queueRender();
    })
  );

  // ---- 탭 이름 표시 방식 + 모양 프리셋 ----
  $('tabBadgeSeg').appendChild(
    mkSeg(
      [
        ['off', '비표시'],
        ['each', '메시지'],
        ['section', '탭'],
      ],
      () => s.tabBadge,
      (v) => {
        s.tabBadge = v;
        updateTabBadgeRows();
        renderBadgeOnlyRows();
        queueRender();
      }
    )
  );
  $('tabBadgePick').appendChild(
    mkPresetBtn('tabbadge', () => s.tabBadgePreset || 'pill', (key) => {
      s.tabBadgePreset = key;
      updateTabBadgeRows();
      queueRender();
    })
  );
  $('tabSecPick').appendChild(
    mkPresetBtn('tabsec', () => s.tabSecPreset || 'plain', (key) => {
      s.tabSecPreset = key;
      updateTabBadgeRows();
      queueRender();
    })
  );
  updateTabBadgeRows();

  // ---- 맨 위 머리말 ----
  bindHeaderForm();

  // ---- 프로그램 스킨 (테마·디자인) — 팝업 설정과 같은 sync 값 ----
  bindAppSkin();

  // ---- 시각 표시 (기준 날짜 · 형식) ----
  const baseIn = $('tsBase');
  const d0 = new Date(collectedAt);
  const pad2 = (n) => String(n).padStart(2, '0');
  baseIn.value = `${d0.getFullYear()}-${pad2(d0.getMonth() + 1)}-${pad2(d0.getDate())}`;
  baseIn.addEventListener('change', () => {
    const v = baseIn.value;
    if (!v) return;
    const [y, mo, dd] = v.split('-').map(Number);
    // 기준 날짜의 그날 늦은 시각을 기준으로 삼는다 (그날 대사가 미래로 밀리지 않게)
    collectedAt = new Date(y, mo - 1, dd, 23, 59).getTime();
    relocalize();
  });
  $('tsToday').addEventListener('click', () => {
    const now = new Date();
    baseIn.value = `${now.getFullYear()}-${pad2(now.getMonth() + 1)}-${pad2(now.getDate())}`;
    baseIn.dispatchEvent(new Event('change'));
  });
  // 자동 / 지정 / 없음 — 지정이면 년도·월.일·시:분을 토글로 조합한다
  const tsParts = { y: false, d: false, t: true };
  const tsPartDefs = [
    ['t', '시:분'],
    ['d', '월.일'],
    ['y', '년도'],
  ];
  const tsMode = () => (tsFormat === 'auto' ? 'auto' : tsFormat === 'none' ? 'none' : 'pick');
  const syncTsPick = () => {
    const sel = ['y', 'd', 't'].filter((k) => tsParts[k]);
    tsFormat = sel.length ? 'pick:' + sel.join(',') : 'pick:'; // 다 끄면 빈 표시
    relocalize();
  };
  const partsBox = $('tsParts');
  for (const [key, label] of tsPartDefs) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'seg-chip' + (tsParts[key] ? ' on' : '');
    b.textContent = label;
    b.addEventListener('click', () => {
      tsParts[key] = !tsParts[key];
      b.classList.toggle('on', tsParts[key]);
      syncTsPick();
    });
    partsBox.appendChild(b);
  }
  $('tsFormatSeg').appendChild(
    mkSeg(
      [
        ['auto', '자동'],
        ['pick', '지정'],
        ['none', '없음'],
      ],
      tsMode,
      (v) => {
        $('tsPartsRow').classList.toggle('hidden', v !== 'pick');
        if (v === 'pick') {
          syncTsPick();
        } else {
          tsFormat = v;
          relocalize();
        }
      }
    )
  );
  updateTsInfo();

  // ---- 미리보기 보기 방식 (합본 시간순 / 탭별) ----
  $('previewModeSeg').appendChild(
    mkSeg(
      [
        ['merged', '합본(시간순)'],
        ['perTab', '탭별'],
      ],
      () => previewMode,
      (v) => {
        previewMode = v;
        renderPreview();
      }
    )
  );

  // ---- 탭 배지 모서리 · 구분선 상자 옵션 ----
  const badgeRadIn = $('sTabBadgeRadius');
  badgeRadIn.value = s.tabBadgeRadius;
  const badgeRadText = () => (s.tabBadgeRadius >= 99 ? '알약' : s.tabBadgeRadius + 'px');
  $('tabBadgeRadiusOut').textContent = badgeRadText();
  badgeRadIn.addEventListener('input', () => {
    s.tabBadgeRadius = Number(badgeRadIn.value);
    $('tabBadgeRadiusOut').textContent = badgeRadText();
    queueRender();
  });

  $('vnBorderSeg').appendChild(
    mkSeg(
      [
        ['accent', '포인트색'],
        ['plain', '차분하게'],
        ['custom', '지정'],
      ],
      () => s.vnBorder || 'accent',
      (v) => {
        s.vnBorder = v;
        $('sVnBorderColor').classList.toggle('hidden', v !== 'custom');
        queueRender();
      }
    )
  );
  $('sVnBorderColor').value = normalizeHex(s.vnBorderColor) || '#5b8def';
  $('sVnBorderColor').classList.toggle('hidden', (s.vnBorder || 'accent') !== 'custom');
  $('sVnBorderColor').addEventListener('input', () => {
    s.vnBorderColor = $('sVnBorderColor').value;
    s.vnBorder = 'custom';
    queueRender();
  });

  $('tabBadgeFillSeg').appendChild(
    mkSeg(
      [
        ['accent', '포인트색'],
        ['custom', '지정'],
      ],
      () => s.tabBadgeFill || 'accent',
      (v) => {
        s.tabBadgeFill = v;
        $('sTabBadgeColor').classList.toggle('hidden', v !== 'custom');
        queueRender();
      }
    )
  );
  $('sTabBadgeColor').value = normalizeHex(s.tabBadgeColor) || '#3a3a41';
  $('sTabBadgeColor').classList.toggle('hidden', (s.tabBadgeFill || 'accent') !== 'custom');
  $('sTabBadgeColor').addEventListener('input', () => {
    s.tabBadgeColor = $('sTabBadgeColor').value;
    s.tabBadgeFill = 'custom';
    queueRender();
  });

  // ---- 출력 필터 (3단) ----
  renderFilterRows();

  // ---- 스타일 초기화 ----
  $('resetStyleBtn').addEventListener('click', async () => {
    if (!confirm('로그 스타일 설정을 전부 기본값으로 되돌릴까요? (수집본·스탠딩은 그대로)')) return;
    s = B.normalizeSettings(null);
    await saveLogSettings(s);
    location.reload();
  });
}

// ---------- 맨 위 머리말 (제목/부제목/설명 + 세션 카드 이미지) ----------
// 프로그램 스킨: 팝업·방 안 패널·스튜디오가 같이 보는 sync 값 (theme / uiDesign)
async function bindAppSkin() {
  const cur = await getSync({ theme: 'dark', uiDesign: 'basic' });
  let theme = THEMES.includes(cur.theme) ? cur.theme : 'dark';
  let design = cur.uiDesign === 'rail' ? 'rail' : 'basic';
  const save = (patch) => setSync(patch);
  const THEME_LABEL = { dark: '다크', light: '라이트', mono: '모노', retro: '레트로' };
  $('appThemeSeg').appendChild(
    mkSeg(
      THEMES.map((t) => [t, THEME_LABEL[t] || t]),
      () => theme,
      (v) => {
        theme = v;
        save({ theme: v });
        applyPageTheme();
      }
    )
  );
  $('appDesignSeg').appendChild(
    mkSeg(
      [
        ['basic', '기본'],
        ['rail', '세로'],
      ],
      () => design,
      (v) => {
        design = v;
        save({ uiDesign: v });
      }
    )
  );
}

function bindHeaderForm() {
  const H = s.header;

  // 머리말 표시/숨김 — 출력 필터·주사위 색과 같은 알약 토글로 통일
  $('hShowSeg').appendChild(
    mkSeg(
      [
        ['on', '표시'],
        ['off', '숨김'],
      ],
      () => (s.showTitle === false ? 'off' : 'on'),
      (v) => {
        s.showTitle = v === 'on';
        queueRender();
      }
    )
  );

  // 제목은 방 이름을 미리 채워 시작한다. 지우면 제목 줄 자체가 사라진다.
  if (H.title === '' && !H.__titleTouched && data) {
    H.title = data.roomName || '';
    H.__titleTouched = true;
  }
  const texts = [
    ['hTitle', 'title'],
    ['hSub', 'sub'],
    ['hDesc', 'desc'],
  ];
  for (const [id, key] of texts) {
    const el = $(id);
    el.value = H[key] || '';
    el.addEventListener('input', () => {
      H[key] = el.value;
      queueRender();
    });
  }
  const colors = [
    ['hTitleColor', 'titleColor', '#e8e8e8'],
    ['hSubColor', 'subColor', '#9a9a9a'],
    ['hDescColor', 'descColor', '#9a9a9a'],
  ];
  for (const [id, key, def] of colors) {
    const el = $(id);
    el.value = normalizeHex(H[key]) || def;
    el.addEventListener('input', () => {
      H[key] = el.value;
      queueRender();
    });
  }
  $('hAlignSeg').appendChild(
    mkSeg(
      [
        ['left', '왼쪽'],
        ['center', '가운데'],
        ['right', '오른쪽'],
      ],
      () => H.align,
      (v) => {
        H.align = v;
        queueRender();
      }
    )
  );
  $('hPresetPick').appendChild(
    mkPresetBtn('header', () => H.preset || 'line', (key) => {
      H.preset = key;
      updateHeaderRows();
      queueRender();
    })
  );
  $('hColorModeSeg').appendChild(
    mkSeg(
      [
        ['title', '제목색'],
        ['theme', '테마색'],
        ['custom', '지정'],
      ],
      () => H.colorMode || 'title',
      (v) => {
        H.colorMode = v;
        $('hBgColor').classList.toggle('hidden', v !== 'custom');
        queueRender();
      }
    )
  );
  $('hBgColor').value = normalizeHex(H.bgColor) || '#2c2c2c';
  $('hBgColor').classList.toggle('hidden', (H.colorMode || 'title') !== 'custom');
  $('hBgColor').addEventListener('input', () => {
    H.bgColor = $('hBgColor').value;
    H.colorMode = 'custom';
    queueRender();
  });
  updateHeaderRows();
  const radIn = $('hRadius');
  radIn.value = H.radius;
  $('hRadiusOut').textContent = H.radius + 'px';
  radIn.addEventListener('input', () => {
    H.radius = Number(radIn.value);
    $('hRadiusOut').textContent = H.radius + 'px';
    queueRender();
  });

  // 세션 카드 이미지
  $('hImgPickBtn').addEventListener('click', () => $('hImgInput').click());
  $('hImgInput').addEventListener('change', async () => {
    const file = $('hImgInput').files[0];
    $('hImgInput').value = '';
    if (!file) return;
    try {
      headerImage = await fileToDataUrl(file, 1400, 'image/jpeg', 0.88);
      await setLocal({ logHeaderImage: headerImage });
      updateHeaderImgInfo();
      queueRender();
    } catch (e) {
      $('hImgInfo').textContent = '이미지를 읽지 못했습니다: ' + e.message;
    }
  });
  $('hImgClearBtn').addEventListener('click', async () => {
    headerImage = '';
    await setLocal({ logHeaderImage: '' });
    updateHeaderImgInfo();
    queueRender();
  });
  const wIn = $('hImgWidth');
  wIn.value = H.imgWidth;
  $('hImgWidthOut').textContent = H.imgWidth + '%';
  wIn.addEventListener('input', () => {
    H.imgWidth = Number(wIn.value);
    $('hImgWidthOut').textContent = H.imgWidth + '%';
    queueRender();
  });
  $('hImgAlignSeg').appendChild(
    mkSeg(
      [
        ['left', '왼쪽'],
        ['center', '가운데'],
        ['right', '오른쪽'],
      ],
      () => H.imgAlign,
      (v) => {
        H.imgAlign = v;
        queueRender();
      }
    )
  );
  // 글자 크기·행간
  const sizeRows = [
    ['hTitleSize', 'titleSize', 'hTitleSizeOut', 'em'],
    ['hSubSize', 'subSize', 'hSubSizeOut', 'em'],
    ['hDescSize', 'descSize', 'hDescSizeOut', 'em'],
    ['hLineHeight', 'lineHeight', 'hLineHeightOut', ''],
    ['hGap', 'gap', 'hGapOut', 'px'],
    ['hRolePadX', 'rolePadX', 'hRolePadXOut', 'px'],
    ['hRolePadY', 'rolePadY', 'hRolePadYOut', 'px'],
  ];
  for (const [id, key, outId, unit] of sizeRows) {
    const el = $(id);
    el.value = H[key];
    $(outId).textContent = H[key] + unit;
    el.addEventListener('input', () => {
      H[key] = Number(el.value);
      $(outId).textContent = H[key] + unit;
      queueRender();
    });
  }

  // 역할 알약 (GM/KP/PL/KPC/PC)
  $('hRoleChips').checked = H.roleChips !== false;
  $('hRoleChips').addEventListener('change', () => {
    H.roleChips = $('hRoleChips').checked;
    queueRender();
  });
  $('hRolePick').appendChild(
    mkPresetBtn('role', () => H.roleStyle || 'pill', (key) => {
      H.roleStyle = key;
      queueRender();
    })
  );

  const roleBox = $('hRoleColors');
  roleBox.innerHTML = '';
  for (const role of ['GM', 'KP', 'PL', 'KPC', 'PC']) {
    const row = document.createElement('div');
    row.className = 'st-row';
    const lab = document.createElement('span');
    lab.textContent = role;
    const pick = document.createElement('input');
    pick.type = 'color';
    pick.className = 'circle';
    pick.value = normalizeHex((H.roleColors || {})[role]) || '#888888';
    pick.addEventListener('input', () => {
      H.roleColors = { ...(H.roleColors || {}), [role]: pick.value };
      queueRender();
    });
    row.append(lab, pick);
    roleBox.appendChild(row);
  }

  const imgRadIn = $('hImgRadius');
  const curRad = typeof H.imgRadius === 'number' ? H.imgRadius : H.imgRadius === 'circle' ? 50 : H.imgRadius === 'square' ? 0 : 10;
  H.imgRadius = curRad;
  imgRadIn.value = curRad;
  $('hImgRadiusOut').textContent = curRad + (curRad >= 50 ? '% (원형)' : 'px');
  imgRadIn.addEventListener('input', () => {
    H.imgRadius = Number(imgRadIn.value);
    $('hImgRadiusOut').textContent = H.imgRadius + (H.imgRadius >= 50 ? '% (원형)' : 'px');
    queueRender();
  });
  updateHeaderImgInfo();
}

// 모서리 둥글기는 박스 디자인에서만 쓰인다
function updateHeaderRows() {
  const preset = (s.header.preset || 'line');
  const row = $('hRadius').closest('.st-row');
  if (row) row.classList.toggle('hidden', preset !== 'box' && preset !== 'band');
}

function updateHeaderImgInfo() {
  $('hImgInfo').textContent = headerImage
    ? `이미지 등록됨 (${Math.round(headerImage.length / 1024)}KB) — 저장 시 HTML에 내장됩니다`
    : '이미지가 없습니다. 세션 배너·표지를 넣어보세요.';
}

function renderThemeSwatches() {
  const box = $('themeSwatches');
  box.innerHTML = '';
  const items = [
    ['dark', '#2c2c2c', '기본(다크)'],
    ['gray', '#ebebeb', '그레이'],
    ['white', '#ffffff', '화이트'],
  ];
  const paint = () => {
    [...box.querySelectorAll('.sw')].forEach((b) => b.classList.toggle('on', b.dataset.v === s.theme));
    $('imageThemeOpts').classList.toggle('hidden', s.theme !== 'image');
  };
  for (const [v, color, title] of items) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'sw';
    b.dataset.v = v;
    b.title = title;
    b.style.background = color;
    b.addEventListener('click', () => {
      s.theme = v;
      paint();
      queueRender();
    });
    box.appendChild(b);
  }
  // 직접 지정: 색 스와치 자체가 컬러 피커
  const customWrap = document.createElement('span');
  customWrap.className = 'sw sw-custom';
  customWrap.dataset.v = 'custom';
  customWrap.title = '직접 지정 (클릭해서 색 선택)';
  const customIn = document.createElement('input');
  customIn.type = 'color';
  customIn.value = normalizeHex(s.customBg) || '#2c2c2c';
  customWrap.style.background = customIn.value;
  customIn.addEventListener('click', () => {
    s.theme = 'custom';
    paint();
    queueRender();
  });
  customIn.addEventListener('input', () => {
    s.theme = 'custom';
    s.customBg = customIn.value;
    customWrap.style.background = customIn.value;
    paint();
    queueRender();
  });
  customWrap.appendChild(customIn);
  box.appendChild(customWrap);
  // 배경 이미지 테마
  const imgB = document.createElement('button');
  imgB.type = 'button';
  imgB.className = 'sw sw-img';
  imgB.dataset.v = 'image';
  imgB.title = '배경 이미지 (채팅창이 반투명하게 떠 있는 스타일)';
  imgB.innerHTML = window.faIcon ? window.faIcon('image') : 'BG';
  imgB.addEventListener('click', () => {
    s.theme = 'image';
    paint();
    queueRender();
  });
  box.appendChild(imgB);
  paint();
}

function updateBgImageInfo() {
  $('bgImageInfo').textContent = bgImage
    ? `배경 이미지 등록됨 (${Math.round(bgImage.length / 1024)}KB) — 저장 시 HTML에 내장됩니다`
    : '배경 이미지가 없습니다. [파일 선택]으로 넣어주세요.';
}

function updateTabBadgeRows() {
  const off = s.tabBadge === 'off';
  const isEach = s.tabBadge === 'each';
  const isSec = s.tabBadge === 'section';
  $('tabBadgePresetRow').classList.toggle('hidden', !isEach);
  $('tabBadgeFirstRow').classList.toggle('hidden', !isEach);
  // 모서리는 테두리·채움 배지에서만 의미가 있다
  // 기본·상자는 메시지든 탭이든 같은 설정(모서리·색)을 쓴다
  const shape = isEach ? s.tabBadgePreset || 'pill' : isSec ? s.tabSecPreset || 'plain' : '';
  const isOutline = shape === 'pill' || shape === 'plain';
  const isBox = shape === 'box';
  $('tabBadgeRadiusRow').classList.toggle('hidden', off || (!isOutline && !isBox));
  $('tabBadgeFillRow').classList.toggle('hidden', off || !isBox);
  $('tabSecPresetRow').classList.toggle('hidden', !isSec);
  // 표시할 탭은 메시지·탭 두 방식 모두에서 고를 수 있다
  $('tabBadgeOnlyRow').classList.toggle('hidden', off);
  $('tabBadgeOnlyNote').classList.toggle('hidden', off);
}

// '특정 탭'일 때 어떤 탭에만 이름을 붙일지 고른다
function renderBadgeOnlyRows() {
  const box = $('tabBadgeOnly');
  if (!box || !data) return;
  box.innerHTML = '';
  if (s.tabBadge === 'off') return;
  const picked = Array.isArray(s.tabBadgeOnly) ? s.tabBadgeOnly : [];
  const names = tabNamesOf();
  if (!names.length) {
    const d = document.createElement('span');
    d.className = 'st-desc';
    d.textContent = '탭이 없습니다 (탭이 하나뿐인 로그).';
    box.appendChild(d);
    return;
  }
  for (const name of names) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'seg-chip' + (picked.includes(name) ? ' on' : '');
    b.textContent = name;
    b.addEventListener('click', () => {
      const cur = Array.isArray(s.tabBadgeOnly) ? [...s.tabBadgeOnly] : [];
      const i = cur.indexOf(name);
      if (i === -1) cur.push(name);
      else cur.splice(i, 1);
      s.tabBadgeOnly = cur;
      b.classList.toggle('on', cur.includes(name));
      queueRender();
    });
    box.appendChild(b);
  }
}

function updateDiceRows() {
  const mode = s.diceColor.mode;
  $('diceColorRow').classList.toggle('hidden', mode === 'off');
  // 성공/실패 칸은 그 모드일 때만
  for (const el of document.querySelectorAll('.dc-judge')) {
    el.classList.toggle('hidden', mode !== 'judge');
  }
}

function updateVnRow() {
  const usesVn = Object.values(s.tabStyles || {}).some(
    (t) => t && t.mode === 'emph' && (t.preset || 'banner') === 'vn'
  );
  $('vnBorderRow').classList.toggle('hidden', !usesVn);
}

function updateConsoleRow() {
  updateVnRow();
  const rp = s.rowPreset || 'plain';
  $('consoleBgRow').classList.toggle('hidden', rp !== 'console');
  $('sConsoleColor').classList.toggle('hidden', s.consoleBg !== 'custom');
  $('r20Opts').classList.toggle('hidden', rp !== 'roll20');
}

function renderFilterRows() {
  const box = $('filterRows');
  box.innerHTML = '';
  const counts = data ? B.countFiltered(data.messages, s) : { empty: 0, dice: 0, cmd: 0, edited: 0 };
  const items = [
    ['empty', '빈 대사 행'],
    ['dice', '주사위 행'],
    ['cmd', '명령어 행'],
    ['edited', '[편집 완료] 문구'],
  ];
  for (const [key, label] of items) {
    const row = document.createElement('div');
    row.className = 'st-row';
    const sp = document.createElement('span');
    sp.textContent = label;
    if (key === 'edited') sp.title = '비표시/삭제 선택 시 대사에 붙은 "[편집 완료]" 문구를 지우고, 그 문구만 있는 행은 제외합니다';
    row.appendChild(sp);
    const cnt = document.createElement('span');
    cnt.className = 'st-desc filter-count';
    const paint = () => {
      const n = counts[key] || 0;
      const mode = s.rowFilters[key];
      cnt.textContent = !n ? '0건' : mode === 'del' ? `${n}건 삭제됨` : mode === 'hide' ? `${n}건 숨김` : `${n}건`;
      cnt.classList.toggle('on', n > 0 && mode !== 'show');
    };
    row.appendChild(
      mkSeg(
        [
          ['show', '표시'],
          ['hide', '비표시'],
          ['del', '삭제'],
        ],
        () => s.rowFilters[key],
        (v) => {
          s.rowFilters[key] = v;
          paint();
          queueRender();
        }
      )
    );
    paint();
    box.appendChild(row);
    const cntRow = document.createElement('div');
    cntRow.className = 'filter-count-row';
    cntRow.appendChild(cnt);
    box.appendChild(cntRow);
  }
}
