// [edit] 미리보기 렌더 · 대사 편집 · 캐릭터 목록
// ---------- 미리보기 (로그 / 통계) ----------
let statsMode = false;
let previewAll = false;
let previewMode = 'merged'; // merged(시간순 합본) | perTab(탭별)
let previewFontCss = null; // kopub 로컬 폰트 (미리보기용 URL 참조)

function buildPreviewSettings() {
  const sPrev = { ...s };
  if (s.font === 'kopub' && previewFontCss != null) sPrev.__fontCss = previewFontCss;
  if (s.theme === 'image') sPrev.__bgImage = bgImage || '';
  sPrev.__headerImage = headerImage || '';
  sPrev.__editable = editMode;
  sPrev.__preview = true; // 인라인 onerror 대신 리스너로 (CSP)
  return sPrev;
}

// 미리보기를 다시 그려도 보던 위치를 유지한다 (설정 하나 바꿀 때마다 맨 위로 튀지 않게)
function setPreviewHtml(html) {
  const fr = $('preview');
  let keep = 0;
  try {
    const w = fr.contentWindow;
    const d = fr.contentDocument;
    keep = (w && w.scrollY) || (d && d.documentElement && d.documentElement.scrollTop) || 0;
  } catch (_) {}
  fr.addEventListener(
    'load',
    () => {
      try {
        if (keep) fr.contentWindow.scrollTo(0, keep);
      } catch (_) {}
      // 깨진 인장 숨기기 — 저장 파일의 인라인 onerror 역할을 미리보기에서는 여기서 한다.
      // 이미지마다 리스너를 달지 않고 문서에 캡처 리스너 하나 (error 는 버블되지 않는다).
      try {
        const d = fr.contentDocument;
        const hideBroken = (im) => {
          if (im && im.tagName === 'IMG' && im.classList.contains('ic')) im.style.visibility = 'hidden';
        };
        d.addEventListener('error', (e) => hideBroken(e.target), true);
        // load 이전에 이미 실패한 것들은 한 번 훑는다
        for (const im of d.querySelectorAll('img.ic')) if (im.complete && im.naturalWidth === 0) hideBroken(im);
      } catch (_) {}
      bindPreviewEditing();
    },
    { once: true }
  );
  fr.srcdoc = html;
}

function renderPreview() {
  if (statsMode) {
    $('previewInfo').textContent = ` — ${data.roomName} 통계`;
    setPreviewHtml(B.buildStatsHtml(data.messages, data.roomName, collectedAt));
    return;
  }
  const kept = B.applyDeletions(data.messages, s);
  const filtered = B.fixImageUrls(B.applyFilters([...kept], s));
  let msgs;
  if (previewMode === 'perTab') {
    // 저장 방식 '탭별 파일'과 같은 순서 — 탭 안에서는 수집 순서 그대로
    const byTab = new Map();
    for (const m of filtered) {
      const t = m.divider ? '' : m.tab || '메인';
      if (!byTab.has(t)) byTab.set(t, []);
      byTab.get(t).push(m);
    }
    msgs = [];
    for (const [t, list] of byTab) {
      list.sort((a, b) => (a.tabOrder || 0) - (b.tabOrder || 0) || (a.seq || 0) - (b.seq || 0));
      if (t) msgs.push({ divider: true, text: t });
      msgs.push(...list);
    }
  } else {
    msgs = B.sortForMerge(filtered);
  }
  const slice = previewAll ? msgs : msgs.slice(0, 120);
  const shown = msgs.filter((m) => !m.divider).length;
  $('previewInfo').textContent =
    ` — ${data.roomName} · 필터 후 ${shown}개${!previewAll && msgs.length > 120 ? ' (앞 120개만 — [전체 보기]로 전부)' : ''}`;
  const html = B.buildHtml(slice, buildPreviewSettings(), { roomName: data.roomName, singleTab: false });
  setPreviewHtml(html);
}

function queueRender() {
  clearTimeout(renderTimer);
  renderTimer = setTimeout(renderPreview, 150);
}

// 기준 날짜·형식이 바뀌면 표시 시각을 다시 계산한다 (직접 고친 대사는 건드리지 않음)
function relocalize() {
  const keep = new Map();
  for (const m of data.messages) if (m.__tsEdited) keep.set(m.__id, m.ts);
  data.messages = B.localizeTimes(data.messages, collectedAt, tsFormat);
  for (const m of data.messages) if (keep.has(m.__id)) m.ts = keep.get(m.__id);
  assignIds(data.messages);
  updateTsInfo();
  renderPreview();
}

function updateTsInfo() {
  const times = data.messages
    .filter((m) => !m.divider && typeof m.exact === 'number' && m.exact > 1e12)
    .map((m) => m.exact);
  const el = $('tsInfo');
  if (!times.length) {
    el.textContent = '시각을 읽지 못했습니다. 기준 날짜를 직접 골라 주세요.';
    return;
  }
  const min = Math.min(...times);
  const max = Math.max(...times);
  const f = (t) => {
    const d = new Date(t);
    const p = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}.${p(d.getMonth() + 1)}.${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
  };
  const derived = data.messages.some((m) => m.__derived);
  el.textContent =
    `${f(min)} ~ ${f(max)}` +
    (derived ? ' (화면에 보이던 상대 시각에서 계산 — 어긋나면 기준 날짜를 바꿔 주세요)' : ' (코코포리아 내부 시각 그대로)');
}

// ---------- 되돌리기 (Ctrl+Z) ----------
// 대사를 고치거나 지우기 직전 상태를 통째로 담아둔다.
// 스타일 설정은 담지 않는다 — 되돌리기는 "글"에 대한 것이라야 헷갈리지 않는다.
const UNDO_MAX = 40;
let undoStack = [];

function snapshotMsgs() {
  return data.messages.map((m) => ({ ...m }));
}

function pushUndo(label) {
  undoStack.push({ label: label || '편집', msgs: snapshotMsgs() });
  if (undoStack.length > UNDO_MAX) undoStack.shift();
  updateUndoBtn();
}

function updateUndoBtn() {
  const btn = $('undoBtn');
  if (!btn) return;
  const n = undoStack.length;
  btn.disabled = !n;
  btn.title = n ? `되돌리기: ${undoStack[n - 1].label} (Ctrl+Z) · ${n}단계 남음` : '되돌릴 편집이 없습니다';
}

function doUndo() {
  const snap = undoStack.pop();
  if (!snap) return;
  data.messages = snap.msgs;
  assignIds(data.messages);
  closeMsgEditor();
  updateUndoBtn();
  renderCharRows();
  renderFilterRows();
  renderImgFix();
  renderPreview();
  $('srcInfo').textContent = `되돌렸습니다 — ${snap.label}`;
}

function isTypingTarget(t) {
  return !!t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable);
}

function bindUndoKey(doc) {
  doc.addEventListener('keydown', (e) => {
    if (!(e.ctrlKey || e.metaKey) || e.shiftKey || e.key.toLowerCase() !== 'z') return;
    if (isTypingTarget(e.target)) return; // 입력칸 안에서는 브라우저 기본 되돌리기가 맞다
    e.preventDefault();
    doUndo();
  });
}

bindUndoKey(document);
$('undoBtn').addEventListener('click', doUndo);

// ---------- 미리보기에서 대사 편집 ----------
// 미리보기 iframe은 같은 출처라, 스크립트를 넣지 않고도 바깥에서 클릭을 붙일 수 있다
// 여러 개 고르기: 그냥 클릭=하나 / Shift+클릭=여기까지 죽 / Ctrl(⌘)+클릭=하나씩 더하기
let picked = new Set();
let pickAnchor = null;

function previewOrderIds() {
  const doc = $('preview').contentDocument;
  if (!doc) return [];
  return [...doc.querySelectorAll('[data-mid]')].map((el) => el.dataset.mid);
}

function paintPicked() {
  const doc = $('preview').contentDocument;
  if (!doc) return;
  for (const el of doc.querySelectorAll('[data-mid]')) {
    el.classList.toggle('cst-picked', picked.has(el.dataset.mid));
  }
  const n = picked.size;
  $('bulkBar').classList.toggle('hidden', n < 2);
  $('bulkCount').textContent = `${n}개 선택`;
}

function clearPicked() {
  picked.clear();
  pickAnchor = null;
  paintPicked();
}

function bindPreviewEditing() {
  if (!editMode) return;
  const doc = $('preview').contentDocument;
  if (!doc) return;
  paintPicked(); // 다시 그린 뒤에도 골라둔 것이 남아 있게
  bindUndoKey(doc); // 미리보기 안을 클릭한 상태에서도 Ctrl+Z가 먹게
  doc.addEventListener('click', (e) => {
    const row = e.target.closest && e.target.closest('[data-mid]');
    if (!row) return;
    e.preventDefault();
    const id = row.dataset.mid;

    if (e.shiftKey && pickAnchor) {
      const ids = previewOrderIds();
      const a = ids.indexOf(pickAnchor);
      const b = ids.indexOf(id);
      if (a >= 0 && b >= 0) {
        for (const x of ids.slice(Math.min(a, b), Math.max(a, b) + 1)) picked.add(x);
      }
      closeMsgEditor(true);
      paintPicked();
      return;
    }

    if (e.ctrlKey || e.metaKey) {
      if (picked.has(id)) picked.delete(id);
      else picked.add(id);
      pickAnchor = id;
      closeMsgEditor(true);
      paintPicked();
      return;
    }

    picked = new Set([id]);
    pickAnchor = id;
    paintPicked();
    openMsgEditor(id);
  });
}

// ---------- 고른 대사 한꺼번에 ----------
function pickedMsgs() {
  return data.messages.filter((m) => picked.has(m.__id));
}

function afterBulk(msg) {
  renderCharRows();
  renderFilterRows();
  renderImgFix();
  renderPreview();
  if (msg) $('srcInfo').textContent = msg;
}

$('bulkClear').addEventListener('click', clearPicked);

$('bulkDelete').addEventListener('click', () => {
  const list = pickedMsgs();
  if (!list.length) return;
  if (!confirm(`고른 대사 ${list.length}개를 지울까요?`)) return;
  pushUndo(`대사 ${list.length}개 삭제`);
  data.messages = data.messages.filter((m) => !picked.has(m.__id));
  clearPicked();
  afterBulk(`대사 ${list.length}개를 지웠습니다.`);
});

$('bulkName').addEventListener('click', () => {
  const list = pickedMsgs();
  if (!list.length) return;
  const cur = list[0].name || '';
  const name = prompt(`고른 ${list.length}개의 이름 (비우면 이름은 그대로, 색만 바꿉니다)`, cur);
  if (name === null) return;
  const color = prompt('이름 색 (#rrggbb, 비우면 색은 그대로)', normalizeHex(list[0].color) || '');
  if (color === null) return;
  const hex = normalizeHex(color);
  pushUndo(`대사 ${list.length}개 이름·색`);
  for (const m of list) {
    if (name.trim()) m.name = name.trim();
    if (hex) m.color = hex;
  }
  afterBulk(`${list.length}개에 적용했습니다.`);
});

$('bulkReplace').addEventListener('click', () => {
  const list = pickedMsgs();
  if (!list.length) return;
  const from = prompt(`고른 ${list.length}개 안에서 찾을 말`, '');
  if (!from) return;
  const to = prompt(`"${from}" → 바꿀 말 (비우면 지웁니다)`, '');
  if (to === null) return;
  let n = 0;
  pushUndo('찾아 바꾸기');
  for (const m of list) {
    if (!m.text || !m.text.includes(from)) continue;
    m.text = m.text.split(from).join(to);
    m.__edited = true;
    n++;
  }
  afterBulk(`${n}개 대사에서 "${from}"을(를) 바꿨습니다.`);
});

function openMsgEditor(id) {
  const m = findMsg(id);
  if (!m) return;
  editingId = id;
  $('meName').value = m.name || '';
  $('meColor').value = normalizeHex(m.color) || '#888888';
  $('meTs').value = m.ts || '';
  $('meText').value = m.text || '';
  // 어느 대사를 고치는지 한눈에
  const idx = data.messages.findIndex((x) => x.__id === id);
  $('meWho').textContent = `${m.name || '이름 없음'}${m.tab ? ' · ' + m.tab : ''}  (${idx + 1}번째)`;
  $('meBadge').textContent = isDiceLike(m.text) ? '주사위' : '대사';
  $('msgEditor').classList.remove('hidden');
  const ta = $('meText');
  ta.focus();
  ta.setSelectionRange(ta.value.length, ta.value.length);
}

function isDiceLike(t) {
  try {
    return B.isDice(t) || B.isCmd(t);
  } catch (_) {
    return false;
  }
}

function closeMsgEditor(keepPicked) {
  editingId = null;
  $('msgEditor').classList.add('hidden');
  if (keepPicked === true) return;
  clearPicked();
}

$('meClose').addEventListener('click', closeMsgEditor);

$('msgEditor').addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    e.stopPropagation();
    closeMsgEditor();
  } else if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
    e.preventDefault();
    $('meSave').click();
  }
});

$('meSave').addEventListener('click', () => {
  const m = findMsg(editingId);
  if (!m) return closeMsgEditor();
  pushUndo('대사 수정');
  m.name = $('meName').value.trim() || m.name;
  m.color = $('meColor').value;
  // 시각을 직접 고쳤을 때만 잠근다 (형식·기준 날짜를 바꿔도 안 덮이게)
  if ($('meTs').value !== (m.ts || '')) {
    m.ts = $('meTs').value;
    m.__tsEdited = true;
  }
  m.text = $('meText').value;
  m.__edited = true;
  closeMsgEditor();
  renderCharRows();
  renderImgFix();
  renderPreview();
});

$('meDelete').addEventListener('click', () => {
  const m = findMsg(editingId);
  if (!m) return closeMsgEditor();
  if (!confirm(`"${(m.text || '').slice(0, 30)}…" 이 대사를 지울까요?`)) return;
  pushUndo('대사 삭제');
  data.messages = data.messages.filter((x) => x.__id !== editingId);
  closeMsgEditor();
  renderCharRows();
  renderFilterRows();
  renderImgFix();
  renderPreview();
});

$('meApplyAll').addEventListener('click', () => {
  const m = findMsg(editingId);
  if (!m) return;
  const oldName = m.name;
  const newName = $('meName').value.trim() || oldName;
  const color = $('meColor').value;
  pushUndo('이름·색 일괄');
  let n = 0;
  for (const x of data.messages) {
    if (!x.divider && x.name === oldName) {
      x.name = newName;
      x.color = color;
      n++;
    }
  }
  m.text = $('meText').value;
  m.ts = $('meTs').value;
  closeMsgEditor();
  renderCharRows();
  renderImgFix();
  renderPreview();
  $('srcInfo').textContent = `"${oldName}" ${n}개 대사에 이름·색을 적용했습니다.`;
});

$('editModeBtn').addEventListener('click', () => {
  editMode = !editMode;
  $('editModeBtn').classList.toggle('on', editMode);
  $('editModeBtn').textContent = editMode ? '편집 끝내기' : '대사 편집';
  if (!editMode) closeMsgEditor();
  else clearPicked();
  renderPreview();
});

// ---------- 찾기 · 바꾸기 (로그 전체) ----------
function findTargets() {
  const withDice = $('findDice').checked;
  return data.messages.filter((m) => !m.divider && (withDice || !isDiceLike(m.text)));
}

// 대소문자를 가리지 않을 때도 원문의 다른 부분은 손대지 않도록 인덱스로 자른다
function replaceAllIn(str, from, to, caseSensitive) {
  if (!str) return { out: str, n: 0 };
  if (caseSensitive) {
    const parts = str.split(from);
    return { out: parts.join(to), n: parts.length - 1 };
  }
  const hay = str.toLowerCase();
  const needle = from.toLowerCase();
  let out = '';
  let i = 0;
  let n = 0;
  for (;;) {
    const at = hay.indexOf(needle, i);
    if (at < 0) break;
    out += str.slice(i, at) + to;
    i = at + needle.length;
    n++;
  }
  out += str.slice(i);
  return { out, n };
}

function runFind(apply) {
  const from = $('findFrom').value;
  if (!from) {
    $('findInfo').textContent = '찾을 말을 적어 주세요.';
    return;
  }
  const to = $('findTo').value;
  const cs = $('findCase').checked;
  const doNames = $('findNames').checked;
  const list = findTargets();

  let hits = 0;
  let rows = 0;
  for (const m of list) {
    const a = replaceAllIn(m.text || '', from, to, cs);
    const b = doNames ? replaceAllIn(m.name || '', from, to, cs) : { out: m.name, n: 0 };
    if (!a.n && !b.n) continue;
    hits += a.n + b.n;
    rows++;
    if (apply) {
      if (a.n) {
        m.text = a.out;
        m.__edited = true;
      }
      if (b.n) m.name = b.out;
    }
  }

  if (!hits) {
    $('findInfo').textContent = `"${from}" 을(를) 찾지 못했습니다.`;
    return;
  }
  if (!apply) {
    $('findInfo').textContent = `${rows}개 대사에서 ${hits}군데 찾았습니다. [모두 바꾸기]를 누르면 고칩니다.`;
    return;
  }
  $('findInfo').textContent = `${rows}개 대사에서 ${hits}군데 바꿨습니다. (Ctrl+Z로 되돌리기)`;
  renderCharRows();
  renderFilterRows();
  renderImgFix();
  renderPreview();
}

$('findCountBtn').addEventListener('click', () => runFind(false));
$('findApplyBtn').addEventListener('click', () => {
  const from = $('findFrom').value;
  if (!from) return runFind(false);
  pushUndo(`"${from}" 찾아 바꾸기`);
  runFind(true);
});
$('findFrom').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') runFind(false);
});
$('findTo').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') $('findApplyBtn').click();
});

// ---------- 캐릭터 (이름 수정·색 지정) ----------
function renderCharRows() {
  const box = $('charRows');
  box.innerHTML = '';
  const counts = new Map();
  const colors = new Map();
  for (const m of data.messages) {
    if (m.divider) continue;
    counts.set(m.name, (counts.get(m.name) || 0) + 1);
    if (!colors.has(m.name) && /^#[0-9a-f]{6}$/i.test(m.color || '')) colors.set(m.name, m.color.toLowerCase());
  }
  if (!counts.size) {
    box.appendChild(Object.assign(document.createElement('div'), { className: 'st-desc', textContent: '캐릭터가 없습니다.' }));
    return;
  }
  const sorted = [...counts.entries()].sort((a, b) => b[1] - a[1]);
  for (const [name, cnt] of sorted) {
    const row = document.createElement('div');
    row.className = 'char-row';
    const inp = document.createElement('input');
    inp.type = 'text';
    inp.className = 'tname-input';
    inp.value = name;
    inp.title = '이름 수정 (이 캐릭터의 모든 메시지에 적용)';
    inp.addEventListener('change', () => {
      const newName = inp.value.trim();
      if (!newName || newName === name) {
        inp.value = name;
        return;
      }
      for (const m of data.messages) {
        if (!m.divider && m.name === name) m.name = newName;
      }
      renderCharRows();
      renderImgFix();
      renderPreview();
    });
    const cntEl = document.createElement('span');
    cntEl.className = 'st-desc';
    cntEl.textContent = `${cnt}개`;
    const pick = document.createElement('input');
    pick.type = 'color';
    pick.className = 'circle';
    pick.title = '이름 색 (모든 메시지에 적용)';
    pick.value = colors.get(name) || '#888888';
    pick.addEventListener('change', () => {
      for (const m of data.messages) {
        if (!m.divider && m.name === name) m.color = pick.value;
      }
      renderPreview();
    });
    row.append(inp, cntEl, pick);
    box.appendChild(row);
  }
}
