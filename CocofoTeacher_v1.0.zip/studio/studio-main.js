// [main] 저장·내보내기 · 이미지 보강 · 통계 · 파일 열기 · 초기화
// ---------- 저장/내보내기 ----------
$('saveSettingsBtn').addEventListener('click', async () => {
  await saveLogSettings(s);
  $('saveSettingsBtn').textContent = '저장됨 ✓';
  setTimeout(() => ($('saveSettingsBtn').textContent = '설정 저장'), 1200);
});

$('exportBtn').addEventListener('click', async () => {
  const btn = $('exportBtn');
  btn.disabled = true;
  try {
    await saveLogSettings(s); // 원클릭에도 같은 설정이 적용되게 함께 저장
    let msgs = data.messages;
    if ($('sEmbed').checked) {
      msgs = await B.embedImagesInMessages(msgs, {
        onProgress: (d, t) => (btn.textContent = `이미지 내장 중 ${d}/${t}…`),
      });
    }
    btn.textContent = '파일 생성 중…';
    const sExp = { ...s };
    if (s.theme === 'image') sExp.__bgImage = bgImage || '';
    sExp.__headerImage = headerImage || '';
    const result = await B.exportAll(msgs, sExp, data.roomName);
    btn.textContent = `저장됨 ✓ (${result.files}개 파일)`;
    btn.title = (result.names || []).join('\n');
  } catch (e) {
    btn.textContent = '실패: ' + e.message;
  }
  btn.disabled = false;
  setTimeout(() => (btn.textContent = '이 설정으로 로그 저장'), 2500);
});

$('previewAllBtn').addEventListener('click', () => {
  previewAll = !previewAll;
  $('previewAllBtn').textContent = previewAll ? '앞부분만' : '전체 보기';
  renderPreview();
});

// ---------- 이미지 보강 ----------
function isGoodUrl(u) {
  return /^(https?:|data:)/i.test(u || '') && !brokenUrls.has(u);
}

function missingStats() {
  // name -> { empty, broken }
  const by = new Map();
  for (const m of data.messages) {
    if (m.divider) continue;
    const st = by.get(m.name) || { empty: 0, broken: 0 };
    if (!m.imgUrl) st.empty++;
    else if (brokenUrls.has(m.imgUrl)) st.broken++;
    by.set(m.name, st);
  }
  for (const [k, v] of by) if (!v.empty && !v.broken) by.delete(k);
  return by;
}

function needsFill(m) {
  return !m.divider && (!m.imgUrl || brokenUrls.has(m.imgUrl));
}

function applyUrlToChar(name, url) {
  let n = 0;
  for (const m of data.messages) {
    if (needsFill(m) && m.name === name) {
      m.imgUrl = url;
      n++;
    }
  }
  return n;
}

let imgFixCharTarget = ''; // 파일 업로드 대상 캐릭터

function renderImgFix() {
  const box = $('imgFixRows');
  box.innerHTML = '';
  const by = missingStats();
  const totalEmpty = [...by.values()].reduce((a, x) => a + x.empty, 0);
  const totalBroken = [...by.values()].reduce((a, x) => a + x.broken, 0);
  $('imgFixStatus').textContent = by.size
    ? `빈 이미지 ${totalEmpty}개 · 깨진 이미지 ${totalBroken}개 (${by.size}명)`
    : brokenUrls.size || checkedOnce
      ? '비었거나 깨진 이미지가 없습니다.'
      : '이미지가 빈 메시지가 없습니다. URL이 있어도 깨졌을 수 있으니 [깨진 이미지 검사]를 눌러보세요.';
  if (!by.size) return;

  for (const [name, st] of by) {
    const row = document.createElement('div');
    row.className = 'imgfix-row';
    const nm = document.createElement('span');
    nm.className = 'cname';
    nm.textContent = `${name} (${st.empty + st.broken})`;
    nm.title = `${name} — 빈 ${st.empty} · 깨짐 ${st.broken}`;
    const inp = document.createElement('input');
    inp.type = 'text';
    inp.placeholder = '이미지 URL 붙여넣기';
    const apply = document.createElement('button');
    apply.className = 'st-btn ghost st-mini';
    apply.textContent = '적용';
    apply.addEventListener('click', () => {
      const url = inp.value.trim();
      if (!/^(https?:|data:)/i.test(url)) return;
      applyUrlToChar(name, url);
      renderImgFix();
      renderPreview();
    });
    const fileBtn = document.createElement('button');
    fileBtn.className = 'st-btn ghost st-mini';
    fileBtn.textContent = '파일';
    fileBtn.title = '내 PC의 이미지 파일로 채우기 (HTML에 내장됨)';
    fileBtn.addEventListener('click', () => {
      imgFixCharTarget = name;
      $('charImgInput').click();
    });
    row.append(nm, inp, apply, fileBtn);
    box.appendChild(row);
  }
}

$('charImgInput').addEventListener('change', async () => {
  const file = $('charImgInput').files[0];
  $('charImgInput').value = '';
  if (!file || !imgFixCharTarget) return;
  try {
    const dataUrl = await fileToDataUrl(file, 256, 'image/webp', 0.85);
    const n = applyUrlToChar(imgFixCharTarget, dataUrl);
    $('imgFixStatus').textContent = `"${imgFixCharTarget}" ${n}개 채움 ✓`;
    setTimeout(renderImgFix, 1200);
    renderPreview();
  } catch (e) {
    $('imgFixStatus').textContent = '이미지를 읽지 못했습니다: ' + e.message;
  }
});

// 깨진 이미지 검사: 고유 URL을 실제로 로드해봐서 실패하는 것 표시
let checkedOnce = false;
// URL이 살아 있는지 실제로 불러 본다 (onProgress(done, total))
async function checkBrokenImages(onProgress) {
  const urls = [...new Set(data.messages.filter((m) => !m.divider && /^https?:/i.test(m.imgUrl || '')).map((m) => m.imgUrl))];
  brokenUrls.clear();
  let done = 0;
  const test = (url) =>
    new Promise((resolve) => {
      const img = new Image();
      const timer = setTimeout(() => {
        img.src = '';
        resolve(false);
      }, 10000);
      img.onload = () => {
        clearTimeout(timer);
        resolve(true);
      };
      img.onerror = () => {
        clearTimeout(timer);
        resolve(false);
      };
      img.src = url;
    });
  // 6개씩 병렬
  for (let i = 0; i < urls.length; i += 6) {
    const batch = urls.slice(i, i + 6);
    const results = await Promise.all(batch.map(test));
    results.forEach((ok, j) => {
      if (!ok) brokenUrls.add(batch[j]);
    });
    done += batch.length;
    if (onProgress) onProgress(done, urls.length);
  }
  checkedOnce = true;
  return brokenUrls.size;
}

$('imgCheckBtn').addEventListener('click', async () => {
  const btn = $('imgCheckBtn');
  btn.disabled = true;
  const n = await checkBrokenImages((d, t) => (btn.textContent = `검사 중 ${d}/${t}…`));
  btn.textContent = n ? `깨진 URL ${n}개 발견` : '깨진 이미지 없음 ✓';
  btn.disabled = false;
  setTimeout(() => (btn.textContent = '깨진 이미지 검사'), 2600);
  renderImgFix();
});

// 저장된 스탠딩 꾸러미 — 이 방을 먼저 보고, 없으면 다른 방까지 뒤진다
async function standingPools() {
  const { lastLogCollection, rooms } = await getLocal({ lastLogCollection: null, rooms: {} });
  const roomId = lastLogCollection && lastLogCollection.roomId;
  const pools = [];
  if (roomId && rooms[roomId] && rooms[roomId].standings) pools.push(rooms[roomId].standings);
  for (const [rid, r] of Object.entries(rooms || {})) {
    if (rid !== roomId && r.standings && Object.keys(r.standings).length) pools.push(r.standings);
  }
  return pools;
}

// 로그 이름과 저장된 이름이 살짝 달라도 (괄호 주석 등) 찾아준다
function poolLookup(pools, name) {
  const simplify = (n) => String(n || '').trim().replace(/\s*[(（].*?[)）]\s*$/, '');
  for (const pool of pools) {
    for (const k of [name, String(name || '').trim(), simplify(name)]) {
      if (pool[k] && pool[k].length) return pool[k];
    }
    for (const key of Object.keys(pool)) {
      if (key.includes(name) || name.includes(key)) {
        if (pool[key] && pool[key].length) return pool[key];
      }
    }
  }
  return null;
}

// 대사 안의 @표정 표시로 스탠딩을 골라 채운다.
// 코코포리아에서는 @이름으로 표정을 바꾸므로, 마지막으로 부른 표정이 그 캐릭터의 현재 얼굴이다.
function fillByFaceTags(pools) {
  const cur = new Map(); // 캐릭터 -> 마지막으로 부른 표정 이미지
  let filled = 0;
  for (const m of data.messages) {
    if (m.divider) continue;
    const list = poolLookup(pools, m.name);
    if (list && list.length) {
      const tag = (m.text || '').match(/@([^\s@,.·、。]{1,20})/);
      if (tag) {
        const want = tag[1].toLowerCase();
        const hit = list.find((x) => String(x.label || '').replace(/^@/, '').toLowerCase() === want);
        if (hit && /^https?:/i.test(hit.img || '')) cur.set(m.name, hit.img);
      }
    }
    if (!needsFill(m)) continue;
    const img = cur.get(m.name);
    if (img && !brokenUrls.has(img)) {
      m.imgUrl = img;
      filled++;
    }
  }
  return filled;
}

// 캐릭터별 대표 이미지로 채우기
function fillByStandings(pools) {
  let filled = 0;
  for (const name of missingStats().keys()) {
    const list = poolLookup(pools, name);
    if (!list) continue;
    const withImg = list.find((x) => /^https?:/i.test(x.img || '')) || list[0];
    const img = withImg && withImg.img;
    if (img && !brokenUrls.has(img)) filled += applyUrlToChar(name, img);
  }
  return filled;
}

$('fillFromStandingsBtn').addEventListener('click', async () => {
  const { lastLogCollection, rooms } = await getLocal({ lastLogCollection: null, rooms: {} });
  const roomId = lastLogCollection && lastLogCollection.roomId;
  const simplify = (n) => String(n || '').trim().replace(/\s*[(（].*?[)）]\s*$/, '');
  const pools = [];
  if (roomId && rooms[roomId] && rooms[roomId].standings) pools.push(rooms[roomId].standings);
  for (const [rid, r] of Object.entries(rooms || {})) {
    if (rid !== roomId && r.standings && Object.keys(r.standings).length) pools.push(r.standings);
  }
  const findImg = (name) => {
    for (const pool of pools) {
      const keys = [name, name.trim(), simplify(name)];
      for (const k of keys) {
        const list = pool[k];
        if (list && list.length) {
          const withImg = list.find((x) => /^https?:/i.test(x.img || '')) || list[0];
          if (withImg && withImg.img) return withImg.img;
        }
      }
      // 부분 일치 (저장된 이름이 로그 이름을 포함하거나 그 반대)
      for (const key of Object.keys(pool)) {
        if (key.includes(name) || name.includes(key)) {
          const list = pool[key];
          if (list && list.length && list[0].img) return list[0].img;
        }
      }
    }
    return '';
  };
  let filled = 0;
  const by = missingStats();
  for (const name of by.keys()) {
    const img = findImg(name);
    if (img && !brokenUrls.has(img)) filled += applyUrlToChar(name, img);
  }
  $('fillFromStandingsBtn').textContent = filled ? `${filled}개 채움 ✓` : '매칭되는 스탠딩 없음';
  setTimeout(() => ($('fillFromStandingsBtn').textContent = '스탠딩으로 채우기'), 2200);
  renderImgFix();
  renderPreview();
});

// 이웃 대사로 채우기: 같은 캐릭터의 가장 가까운 정상 이미지 재사용
// 같은 캐릭터의 가장 가까운 멀쩡한 이미지를 가져온다
function fillByNeighbor() {
  const msgs = data.messages;
  let filled = 0;
  // 캐릭터별 정상 이미지 위치 인덱스
  const goodIdx = new Map(); // name -> [{i, url}]
  msgs.forEach((m, i) => {
    if (!m.divider && isGoodUrl(m.imgUrl)) {
      if (!goodIdx.has(m.name)) goodIdx.set(m.name, []);
      goodIdx.get(m.name).push({ i, url: m.imgUrl });
    }
  });
  msgs.forEach((m, i) => {
    if (!needsFill(m)) return;
    const list = goodIdx.get(m.name);
    if (!list || !list.length) return;
    let best = list[0];
    for (const g of list) {
      if (Math.abs(g.i - i) < Math.abs(best.i - i)) best = g;
    }
    m.imgUrl = best.url;
    filled++;
  });
  return filled;
}

$('fillNeighborBtn').addEventListener('click', () => {
  const filled = fillByNeighbor();
  $('fillNeighborBtn').textContent = filled ? `${filled}개 채움 ✓` : '채울 이웃 이미지 없음';
  setTimeout(() => ($('fillNeighborBtn').textContent = '이웃 대사로 채우기'), 2200);
  renderImgFix();
  renderPreview();
});

// ---------- 이미지 한 번에 채우기 ----------
// 깨진 것 찾기 → 표정(@) 매칭 → 대표 스탠딩 → 이웃 대사 순으로 훑는다.
// 앞 단계가 정확한 순서라 뒤 단계는 남은 것만 메운다.
$('imgAutoBtn').addEventListener('click', async () => {
  const btn = $('imgAutoBtn');
  const out = $('imgAutoStatus');
  btn.disabled = true;
  const before = [...missingStats().values()].reduce((a, x) => a + x.empty + x.broken, 0);
  try {
    btn.textContent = '깨진 이미지 검사 중…';
    out.textContent = '';
    await checkBrokenImages((d, t) => (btn.textContent = `깨진 이미지 검사 ${d}/${t}…`));

    btn.textContent = '스탠딩 맞추는 중…';
    const pools = await standingPools();
    const steps = [];
    const byFace = pools.length ? fillByFaceTags(pools) : 0;
    if (byFace) steps.push(`표정(@) ${byFace}개`);
    const byStand = pools.length ? fillByStandings(pools) : 0;
    if (byStand) steps.push(`스탠딩 ${byStand}개`);
    const byNear = fillByNeighbor();
    if (byNear) steps.push(`이웃 대사 ${byNear}개`);

    const left = [...missingStats().values()].reduce((a, x) => a + x.empty + x.broken, 0);
    out.textContent = steps.length
      ? `${steps.join(' · ')} 채움 — ${before}개 중 ${left}개 남음` +
        (left ? ' (남은 것은 아래에서 직접 넣거나 캐릭터 JSON을 붙여넣어 주세요)' : ' ✓')
      : pools.length
        ? '채울 수 있는 이미지를 못 찾았습니다. 캐릭터 이름이 저장된 스탠딩 이름과 같은지 확인해 주세요.'
        : '저장된 스탠딩이 없습니다. 방에서 캐릭터 편집창을 열어 스탠딩을 모아 두거나, 캐릭터 JSON을 붙여넣어 주세요.';
    renderImgFix();
    renderPreview();
  } catch (e) {
    out.textContent = '실패: ' + e.message;
  }
  btn.disabled = false;
  btn.textContent = '이미지 한 번에 채우기';
});

// 캐릭터 JSON(코코포리아 코마 출력 / kkul 형식) 붙여넣기로 채우기
function extractJsonObjects(text) {
  const results = [];
  let depth = 0;
  let start = -1;
  let inStr = false;
  let esc = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inStr) {
      if (esc) esc = false;
      else if (c === '\\') esc = true;
      else if (c === '"') inStr = false;
      continue;
    }
    if (c === '"') {
      inStr = true;
      continue;
    }
    if (c === '{') {
      if (depth === 0) start = i;
      depth++;
    } else if (c === '}') {
      depth--;
      if (depth === 0 && start !== -1) {
        results.push(text.slice(start, i + 1));
        start = -1;
      }
    }
  }
  return results;
}

$('charJsonApplyBtn').addEventListener('click', async () => {
  const text = $('charJsonInput').value.trim();
  const out = $('charJsonStatus');
  if (!text) {
    out.textContent = '붙여넣은 내용이 없습니다.';
    return;
  }
  const chars = [];
  for (const block of extractJsonObjects(text)) {
    try {
      const parsed = JSON.parse(block);
      const d = parsed && parsed.kind === 'character' && parsed.data ? parsed.data : parsed;
      if (d && typeof d.name === 'string' && d.name.trim()) chars.push(d);
    } catch (_) {}
  }
  if (!chars.length) {
    out.textContent = '인식 가능한 캐릭터 JSON을 찾지 못했습니다.';
    return;
  }
  let filled = 0;
  const applied = [];
  const { lastLogCollection, rooms } = await getLocal({ lastLogCollection: null, rooms: {} });
  for (const d of chars) {
    const name = d.name.trim();
    const faces = Array.isArray(d.faces) ? d.faces : [];
    const urls = [d.iconUrl, ...faces.map((f) => f && f.iconUrl)].filter((u) => /^https?:/i.test(u || ''));
    if (urls.length) {
      const n = applyUrlToChar(name, urls[0]);
      if (n) {
        filled += n;
        applied.push(`${name}(${n})`);
      }
      // 스탠딩 저장소에도 등록 → 패널·다음 백업에서 재사용
      if (lastLogCollection && lastLogCollection.roomId && rooms[lastLogCollection.roomId]) {
        const room = rooms[lastLogCollection.roomId];
        room.standings = room.standings || {};
        if (!room.standings[name] || !room.standings[name].length) {
          room.standings[name] = faces
            .filter((f) => f && /^https?:/i.test(f.iconUrl || ''))
            .map((f) => ({ label: String(f.label || '').replace(/^@/, '') || '기본', img: f.iconUrl }));
          if (!room.standings[name].length && /^https?:/i.test(d.iconUrl || '')) {
            room.standings[name] = [{ label: '기본', img: d.iconUrl }];
          }
        }
      }
    }
  }
  await setLocal({ rooms });
  out.textContent = filled
    ? `${applied.join(', ')} — 총 ${filled}개 채움 ✓ (스탠딩 저장소에도 등록)`
    : `이름은 인식했지만(${chars.map((c) => c.name).join(', ')}) 메시지와 매칭되거나 채울 것이 없었습니다. 캐릭터 이름과 로그 이름이 같은지 확인해 주세요.`;
  renderImgFix();
  renderPreview();
});

// ---------- 파일 → dataURL 유틸 ----------
function fileToDataUrl(file, maxSize, mime, quality) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      try {
        const scale = Math.min(1, maxSize / Math.max(img.naturalWidth, img.naturalHeight));
        const w = Math.max(1, Math.round(img.naturalWidth * scale));
        const h = Math.max(1, Math.round(img.naturalHeight * scale));
        const cv = document.createElement('canvas');
        cv.width = w;
        cv.height = h;
        cv.getContext('2d').drawImage(img, 0, 0, w, h);
        resolve(cv.toDataURL(mime || 'image/webp', quality || 0.85));
      } catch (e) {
        reject(e);
      } finally {
        URL.revokeObjectURL(url);
      }
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('이미지 로드 실패'));
    };
    img.src = url;
  });
}

// ---------- 통계 ----------
$('statsBtn').addEventListener('click', () => {
  statsMode = !statsMode;
  // 통계 화면일 때는 버튼을 포인트색으로 — 돌아가는 길이 눈에 띄게
  $('statsBtn').textContent = statsMode ? '미리보기로' : '통계 보기';
  $('statsBtn').classList.toggle('on', statsMode);
  renderPreview();
});

$('saveStatsBtn').addEventListener('click', () => {
  B.download(
    B.buildStatsHtml(data.messages, data.roomName, collectedAt),
    `${B.sanitizeFilename(data.roomName)}_통계_${B.fileStamp()}.html`
  );
  $('saveStatsBtn').textContent = '저장됨 ✓';
  setTimeout(() => ($('saveStatsBtn').textContent = '통계 HTML 저장 (플레이타임·발화·주사위)'), 1500);
});

// ---------- 파일 열기 (저장해둔 로그 HTML 다시 보기/재편집) ----------
$('openFileBtn').addEventListener('click', () => $('fileInput').click());
$('fileInput').addEventListener('change', async () => {
  const files = [...$('fileInput').files];
  if (!files.length) return;
  const merged = [];
  let firstRoom = '';
  let okFiles = 0;
  for (let i = 0; i < files.length; i++) {
    const parsed = B.parseLogFile(await files[i].text());
    if (!parsed.messages.length) continue;
    if (!firstRoom) firstRoom = parsed.roomName;
    if (files.length > 1) {
      merged.push({ divider: true, text: `${okFiles + 1}회차 — ${files[i].name.replace(/\.html?$/i, '')}`, tabOrder: 0, seq: merged.length });
    }
    for (const m of parsed.messages) {
      merged.push({ ...m, tabOrder: 0, seq: merged.length });
    }
    okFiles++;
  }
  if (!merged.length) {
    $('srcInfo').textContent = '메시지를 읽지 못했습니다 (지원: 코코포 선생님 로그 / 공식·변환기용 형식)';
    return;
  }
  data = {
    roomName: files.length > 1 ? `${firstRoom} 통합본` : firstRoom,
    messages: merged,
    tabNames: [],
  };
  $('srcInfo').textContent =
    files.length > 1
      ? `${okFiles}개 파일 이어붙임 (${merged.filter((m) => !m.divider).length}개 메시지)`
      : `파일 "${files[0].name}" (${merged.length}개 메시지)`;
  collectedAt = Date.now();
  data.messages = B.localizeTimes(data.messages, collectedAt, tsFormat);
  assignIds(data.messages);
  brokenUrls.clear();
  checkedOnce = false;
  renderTabStyles();
  renderCharRows();
  renderRoundRows();
  renderPreview();
  renderImgFix();
  $('fileInput').value = '';
});

// ---------- 로그 합치기 ----------
// 겹친 대사는 절대 알아서 지우지 않는다. 먼저 몇 건인지 보여주고,
// 사람이 [겹친 것 지우기]를 눌렀을 때만 지운다.
function dupKey(m, ignoreTs) {
  const base = (m.name || '') + '\x1f' + (m.text || '');
  return ignoreTs ? base : base + '\x1f' + (m.exact || m.ts || '');
}

function findDups() {
  const ignoreTs = $('dupIgnoreTs').checked;
  const seen = new Map(); // key -> 첫 번째 메시지
  const extras = []; // 두 번째 이후로 나온 것들
  for (const m of data.messages) {
    if (m.divider) continue;
    const k = dupKey(m, ignoreTs);
    if (seen.has(k)) extras.push(m);
    else seen.set(k, m);
  }
  return extras;
}

function renderDupRows(extras) {
  const box = $('dupRows');
  box.innerHTML = '';
  for (const m of extras.slice(0, 40)) {
    const row = document.createElement('div');
    row.className = 'dup-row';
    const who = document.createElement('b');
    who.textContent = m.name || '이름 없음';
    row.append(who, document.createTextNode(`  ${(m.ts || '').trim()}  ${(m.text || '').slice(0, 60)}`));
    box.appendChild(row);
  }
  if (extras.length > 40) {
    const more = document.createElement('div');
    more.className = 'dup-row';
    more.textContent = `… 그리고 ${extras.length - 40}건 더`;
    box.appendChild(more);
  }
}

$('dupScanBtn').addEventListener('click', () => {
  const extras = findDups();
  renderDupRows(extras);
  $('dupRemoveBtn').disabled = !extras.length;
  $('dupInfo').textContent = extras.length
    ? `겹친 대사 ${extras.length}건 — 아래 목록을 확인하고 [겹친 것 지우기]를 누르세요. (첫 번째 것만 남깁니다)`
    : '겹친 대사가 없습니다.';
});

$('dupRemoveBtn').addEventListener('click', () => {
  const extras = findDups();
  if (!extras.length) return;
  if (!confirm(`겹친 대사 ${extras.length}건을 지울까요? (각각 첫 번째 것만 남습니다 · Ctrl+Z로 되돌릴 수 있습니다)`)) return;
  pushUndo(`겹친 대사 ${extras.length}건 정리`);
  const drop = new Set(extras); // 객체 자체로 골라낸다 (id가 겹쳐도 안전)
  data.messages = data.messages.filter((m) => !drop.has(m));
  $('dupRows').innerHTML = '';
  $('dupRemoveBtn').disabled = true;
  $('dupInfo').textContent = `${extras.length}건을 지웠습니다.`;
  renderCharRows();
  renderFilterRows();
  renderImgFix();
  renderPreview();
  renderRoundRows();
});

// ---- 회차 구분선 이름 ----
function renderRoundRows() {
  const box = $('roundRows');
  box.innerHTML = '';
  const dividers = data.messages.filter((m) => m.divider);
  if (!dividers.length) {
    const d = document.createElement('div');
    d.className = 'st-desc';
    d.textContent = '회차 구분선이 없습니다. 파일을 2개 이상 열거나 붙이면 생깁니다.';
    box.appendChild(d);
    return;
  }
  for (const dv of dividers) {
    const row = document.createElement('div');
    row.className = 'round-row';
    const inp = document.createElement('input');
    inp.type = 'text';
    inp.value = dv.text || '';
    inp.title = '회차 이름 — 로그 가운데 구분선에 그대로 나옵니다';
    inp.addEventListener('change', () => {
      pushUndo('회차 이름');
      dv.text = inp.value;
      renderPreview();
    });
    const x = document.createElement('button');
    x.className = 'rr-x';
    x.type = 'button';
    x.textContent = '✕';
    x.title = '이 구분선 지우기';
    x.addEventListener('click', () => {
      pushUndo('구분선 삭제');
      data.messages = data.messages.filter((m) => m !== dv);
      renderRoundRows();
      renderPreview();
    });
    row.append(inp, x);
    box.appendChild(row);
  }
}

// ---- 파일 더 붙이기 ----
$('mergeAddBtn').addEventListener('click', () => $('mergeFileInput').click());
$('mergeFileInput').addEventListener('change', async () => {
  const files = [...$('mergeFileInput').files];
  $('mergeFileInput').value = '';
  if (!files.length) return;
  pushUndo(`파일 ${files.length}개 붙이기`);
  const round = data.messages.filter((m) => m.divider).length;
  let added = 0;
  let n = 0;
  for (const f of files) {
    const parsed = B.parseLogFile(await f.text());
    if (!parsed.messages.length) continue;
    n++;
    data.messages.push({
      divider: true,
      text: `${round + n}회차 — ${f.name.replace(/\.html?$/i, '')}`,
      tabOrder: 0,
      seq: data.messages.length,
    });
    for (const m of parsed.messages) {
      data.messages.push({ ...m, tabOrder: 0, seq: data.messages.length });
      added++;
    }
  }
  if (!added) {
    $('dupInfo').textContent = '메시지를 읽지 못했습니다 (지원: 코코포 선생님 로그 / 공식·변환기용 형식)';
    return;
  }
  data.messages = B.localizeTimes(data.messages, collectedAt, tsFormat);
  assignIds(data.messages);
  $('srcInfo').textContent = `파일 ${n}개를 뒤에 붙였습니다 (+${added}개 메시지 · 전체 ${data.messages.filter((m) => !m.divider).length}개)`;
  $('dupInfo').textContent = '붙인 뒤에는 [겹친 대사 찾기]로 확인해 보세요.';
  renderTabStyles();
  renderCharRows();
  renderFilterRows();
  renderImgFix();
  renderRoundRows();
  renderPreview();
});

// ---------- 설정 공유 (JSON 내보내기/가져오기) ----------
$('exportSettingsBtn').addEventListener('click', () => {
  const json = JSON.stringify({ kind: 'cst-log-settings', version: 2, settings: s }, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `코코포선생님_로그설정_${B.fileStamp()}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  if (navigator.clipboard) navigator.clipboard.writeText(json).catch(() => {});
  $('shareInfo').textContent = 'JSON 파일 저장 + 클립보드에 복사됨 ✓';
});

$('importSettingsBtn').addEventListener('click', () => $('settingsFileInput').click());
$('settingsFileInput').addEventListener('change', async () => {
  const file = $('settingsFileInput').files[0];
  if (!file) return;
  try {
    const obj = JSON.parse(await file.text());
    const incoming = obj && obj.kind === 'cst-log-settings' ? obj.settings : obj;
    if (!incoming || typeof incoming !== 'object') throw new Error('형식 오류');
    s = B.normalizeSettings(incoming);
    await saveLogSettings(s);
    $('shareInfo').textContent = `"${file.name}" 설정 적용됨 ✓`;
    // 폼 다시 그리기: 값 갱신
    location.reload();
  } catch (_) {
    $('shareInfo').textContent = '가져오기 실패 — 코코포 선생님 로그 설정 JSON이 아닙니다.';
  }
  $('settingsFileInput').value = '';
});

// ---------- 저장한 스타일 (프리셋) ----------
// 설정 한 벌을 이름 붙여 담아둔다. 배경·머리말 이미지까지 같이 담아야
// "그때 그 느낌"이 그대로 돌아온다.
let presets = [];

function presetInfo(msg) {
  $('presetInfo').textContent = msg || '';
}

function renderPresetSel(keepId) {
  const sel = $('presetSel');
  const prev = keepId != null ? String(keepId) : sel.value;
  sel.innerHTML = '';
  if (!presets.length) {
    const o = document.createElement('option');
    o.value = '';
    o.textContent = '— 저장한 스타일 없음 —';
    sel.appendChild(o);
    sel.disabled = true;
    return;
  }
  sel.disabled = false;
  for (const p of presets) {
    const o = document.createElement('option');
    o.value = String(p.id);
    const d = new Date(p.at || 0);
    const pad = (n) => String(n).padStart(2, '0');
    o.textContent = `${p.name}  (${pad(d.getMonth() + 1)}.${pad(d.getDate())})`;
    sel.appendChild(o);
  }
  if (prev && presets.some((p) => String(p.id) === prev)) sel.value = prev;
}

async function savePresets() {
  await setLocal({ logPresets: presets });
}

function currentPresetPayload(name) {
  return {
    id: Date.now() + Math.floor(Math.random() * 1000),
    name,
    at: Date.now(),
    settings: JSON.parse(JSON.stringify(s)),
    bgImage: bgImage || '',
    headerImage: headerImage || '',
  };
}

$('presetSaveBtn').addEventListener('click', async () => {
  const name = (prompt('저장할 이름을 적어주세요.', '스타일 ' + (presets.length + 1)) || '').trim();
  if (!name) return;
  const p = currentPresetPayload(name);
  presets.push(p);
  await savePresets();
  renderPresetSel(p.id);
  presetInfo(`"${name}" 저장됨 ✓`);
});

$('presetOverBtn').addEventListener('click', async () => {
  const id = $('presetSel').value;
  const idx = presets.findIndex((p) => String(p.id) === id);
  if (idx < 0) return presetInfo('덮어쓸 스타일을 먼저 고르세요.');
  if (!confirm(`"${presets[idx].name}"을(를) 지금 설정으로 덮어쓸까요?`)) return;
  const keep = presets[idx];
  presets[idx] = { ...currentPresetPayload(keep.name), id: keep.id };
  await savePresets();
  renderPresetSel(keep.id);
  presetInfo(`"${keep.name}" 덮어씀 ✓`);
});

$('presetRenameBtn').addEventListener('click', async () => {
  const id = $('presetSel').value;
  const p = presets.find((x) => String(x.id) === id);
  if (!p) return presetInfo('이름을 바꿀 스타일을 먼저 고르세요.');
  const name = (prompt('새 이름', p.name) || '').trim();
  if (!name) return;
  p.name = name;
  await savePresets();
  renderPresetSel(p.id);
  presetInfo('이름 바뀜 ✓');
});

$('presetDelBtn').addEventListener('click', async () => {
  const id = $('presetSel').value;
  const p = presets.find((x) => String(x.id) === id);
  if (!p) return presetInfo('삭제할 스타일을 먼저 고르세요.');
  if (!confirm(`"${p.name}"을(를) 삭제할까요?`)) return;
  presets = presets.filter((x) => String(x.id) !== id);
  await savePresets();
  renderPresetSel();
  presetInfo('삭제됨');
});

$('presetApplyBtn').addEventListener('click', async () => {
  const id = $('presetSel').value;
  const p = presets.find((x) => String(x.id) === id);
  if (!p) return presetInfo('불러올 스타일을 먼저 고르세요.');
  // 설정 폼이 워낙 많아 값만 바꿔 끼우면 놓치는 칸이 생긴다.
  // 저장한 뒤 새로 그리는 편이 확실하다 (수집한 로그는 저장소에 있어 그대로 남는다).
  await saveLogSettings(B.normalizeSettings(p.settings));
  await setLocal({ logBgImage: p.bgImage || '', logHeaderImage: p.headerImage || '' });
  presetInfo(`"${p.name}" 적용 중…`);
  location.reload();
});

// ---------- 초기화 ----------
window.__studioState = 'start';
(async () => {
  await applyPageTheme();
  window.__studioState = 'theme-ok';
  const logSettings = await loadLogSettings();
  s = B.normalizeSettings(logSettings);

  const { lastLogCollection, logBgImage, logHeaderImage, logPresets } = await getLocal({
    lastLogCollection: null,
    logBgImage: '',
    logHeaderImage: '',
    logPresets: [],
  });
  presets = Array.isArray(logPresets) ? logPresets : [];
  renderPresetSel();
  bgImage = logBgImage || '';
  headerImage = logHeaderImage || '';
  if (lastLogCollection && Array.isArray(lastLogCollection.messages) && lastLogCollection.messages.length) {
    collectedAt = lastLogCollection.at || Date.now();
    data = {
      roomName: lastLogCollection.roomName || '코코포리아',
      // "先週 木曜日 1:57" 같은 일본어 상대 표기를 실제 날짜로 바꿔 둔다
      messages: B.localizeTimes(lastLogCollection.messages, collectedAt, tsFormat),
      tabNames: lastLogCollection.tabNames || [],
    };
    const d = new Date(lastLogCollection.at || Date.now());
    const pad = (n) => String(n).padStart(2, '0');
    $('srcInfo').textContent =
      `"${data.roomName}" 수집본 (${pad(d.getMonth() + 1)}.${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())} · ${data.messages.length}개 메시지)`;
  } else {
    collectedAt = T0 + 300000;
    data = { roomName: '테스트 방', messages: B.localizeTimes(SAMPLE, collectedAt, tsFormat), tabNames: ['메인', '정보', '잡담'] };
    $('exportBtn').disabled = false; // 예시 데이터도 저장은 가능하지만 안내 유지
  }

  assignIds(data.messages);
  $('sEmbed').checked = !!s.embedImages;
  $('sEmbed').addEventListener('change', () => {
    s.embedImages = $('sEmbed').checked;
  });
  try {
    previewFontCss = await B.resolveKopubCss(false);
  } catch (_) {}
  bindForm();
  bindGroupFolding();
  renderTabStyles();
  renderBadgeOnlyRows();
  renderCharRows();
  renderRoundRows();
  renderImgFix();
  renderPreview();
  window.__studioState = 'ready';
})().catch((e) => {
  window.__studioState = 'error: ' + e.message;
  window.__studioErr = e.stack;
});
