const $ = (id) => document.getElementById(id);

const input = $('input');
const clearBtn = $('clearBtn');
const charCount = $('charCount');
const checkBtn = $('checkBtn');
const spinner = $('spinner');
const btnLabel = checkBtn.querySelector('.btn-label');
const result = $('result');
const resultCount = $('resultCount');
const errorList = $('errorList');
const copyBtn = $('copyBtn');
const tip = $('tip');
const liveToggle = $('liveToggle');
const mainView = $('mainView');
const settingsView = $('settingsView');
const settingsBtn = $('settingsBtn');
const footNote = $('footNote');

const DEFAULTS = {
  engine: 'daum',
  liveCheck: false,
  debounceMs: 1500,
  contextMenu: true,
  excluded: '',
  userDict: [],
  userDictOn: true,
  autoCopy: false,
  underlineOn: true,
  underlineColor: '#e5484d',
  underlineStyle: 'wavy',
};

const ENGINE_LABEL = {
  daum: '다음',
  naver: '네이버',
  saramin: '사람인',
  incruit: '인크루트',
  compare: '비교',
};

let checking = false;
let lastCorrections = [];
let autoCopyOn = false;

// 미리보기(비확장 환경)에서도 레이아웃 확인이 가능하도록 가드
const EXT = typeof chrome !== 'undefined' && chrome.storage && chrome.runtime;

// ---------- 버전 표시 ----------
if (EXT && chrome.runtime.getManifest) {
  $('version').textContent = 'v' + chrome.runtime.getManifest().version;
}

// Daum/Naver/개인사전 오류 유형 → 색상 카테고리
function catOf(errType) {
  if (errType === 'space') return 'space';
  if (errType === 'spell' || errType === 'space_spell') return 'spell';
  if (errType === 'doubt') return 'doubt';
  if (errType === 'user') return 'user';
  return 'stat';
}

// ---------- 입력 ----------
function updateMeta() {
  const len = input.value.length;
  charCount.textContent = `${len.toLocaleString()}자`;
  if (len > 1000) {
    charCount.innerHTML = `${len.toLocaleString()}자 <span class="split-hint">· 자동 분할 검사</span>`;
  }
}

input.addEventListener('input', updateMeta);

clearBtn.addEventListener('click', () => {
  input.value = '';
  updateMeta();
  resetResult();
  input.focus();
});

function resetResult() {
  result.innerHTML = '<span class="result-placeholder">검사 결과가 여기에 표시됩니다.</span>';
  resultCount.classList.add('hidden');
  copyBtn.classList.add('hidden');
  errorList.classList.add('hidden');
  errorList.innerHTML = '';
  mainView.classList.remove('with-list');
  lastCorrections = [];
  hideTip();
}

function showTip(message, kind) {
  tip.textContent = message;
  tip.className = `tip ${kind}`;
}

function hideTip() {
  tip.className = 'tip hidden';
}

// ---------- 검사 ----------
async function runCheck() {
  const text = input.value;
  if (!text.trim() || checking) return;

  checking = true;
  checkBtn.disabled = true;
  spinner.classList.remove('hidden');
  btnLabel.textContent = '검사 중';
  hideTip();

  let res;
  try {
    res = await chrome.runtime.sendMessage({ type: 'CHECK', text, source: 'popup' });
  } catch (_) {
    res = null;
  }

  checking = false;
  checkBtn.disabled = false;
  spinner.classList.add('hidden');
  btnLabel.textContent = '검사하기';

  if (!res || !res.ok) {
    resetResult();
    showTip((res && res.error) || '검사에 실패했습니다.', 'error');
    return;
  }

  renderResult(text, res.corrections);
  saveHistory(text, res.corrections, res.engine || 'daum');
  if (autoCopyOn) {
    doCopy('교정 결과가 자동으로 복사되었습니다 ✓');
  }
}

checkBtn.addEventListener('click', runCheck);
input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) runCheck();
});

// ---------- 교정 결과 렌더링 ----------
function renderResult(text, corrections) {
  result.innerHTML = '';
  errorList.innerHTML = '';
  errorList.classList.add('hidden');
  mainView.classList.remove('with-list');
  copyBtn.classList.remove('hidden');
  resultCount.classList.remove('hidden');
  lastCorrections = corrections;

  if (!corrections.length) {
    result.appendChild(document.createTextNode(text));
    resultCount.textContent = '오류 없음 ✓';
    resultCount.classList.add('ok');
    return;
  }

  resultCount.classList.remove('ok');
  resultCount.textContent = `오류 ${corrections.length}개 ▾`;

  // 토큰의 모든 등장 위치를 찾고, 겹치지 않게 왼쪽부터 선택
  const occs = [];
  for (const c of corrections) {
    if (!c.token || c.token === c.suggestion) continue;
    let idx = 0;
    for (;;) {
      idx = text.indexOf(c.token, idx);
      if (idx === -1) break;
      occs.push({ start: idx, end: idx + c.token.length, c });
      idx += c.token.length;
    }
  }
  occs.sort((a, b) => a.start - b.start || (b.end - b.start) - (a.end - a.start));

  let pos = 0;
  const chosen = [];
  for (const o of occs) {
    if (o.start >= pos) {
      chosen.push(o);
      pos = o.end;
    }
  }

  pos = 0;
  corrections.forEach((c, i) => (c._idx = i));
  for (const o of chosen) {
    if (o.start > pos) {
      result.appendChild(document.createTextNode(text.slice(pos, o.start)));
    }
    const span = document.createElement('span');
    span.className = `tok tok-${catOf(o.c.errType)}`;
    span.textContent = o.c.suggestion;
    span.dataset.original = o.c.token;
    span.dataset.suggestion = o.c.suggestion;
    span.dataset.idx = o.c._idx;
    span.title = `원문: ${o.c.token} (클릭하면 대치어·도움말 보기)`;
    result.appendChild(span);
    pos = o.end;
  }
  if (pos < text.length) {
    result.appendChild(document.createTextNode(text.slice(pos)));
  }

  buildErrorList(corrections);
}

// ---------- 오류 상세 목록 ----------
function buildErrorList(corrections) {
  errorList.innerHTML = '';
  for (const c of corrections) {
    const row = document.createElement('div');
    row.className = 'err-row';

    const dot = document.createElement('span');
    dot.className = `err-dot ${catOf(c.errType)}`;

    const before = document.createElement('span');
    before.className = 'err-before';
    before.textContent = c.token;

    const arrow = document.createElement('span');
    arrow.className = 'err-arrow';
    arrow.textContent = '→';

    const after = document.createElement('span');
    after.className = 'err-after';
    after.textContent = c.suggestion;

    const info = document.createElement('span');
    info.className = 'err-info';
    info.textContent = c.info ? c.info.split('\n')[0] : '';
    if (c.info) row.title = c.info;

    row.append(dot, before, arrow, after, info);
    row.addEventListener('click', () => {
      const span = flashToken(c._idx);
      if (span) openDetail(span);
    });
    errorList.appendChild(row);
  }
}

resultCount.addEventListener('click', () => {
  if (resultCount.classList.contains('ok') || !lastCorrections.length) return;
  const opened = !errorList.classList.toggle('hidden');
  mainView.classList.toggle('with-list', opened);
  resultCount.textContent = `오류 ${lastCorrections.length}개 ${opened ? '▴' : '▾'}`;
});

// 목록 클릭 → 본문에서 해당 토큰 강조
function flashToken(idx) {
  const span = result.querySelector(`.tok[data-idx="${idx}"]`);
  if (!span) return null;
  span.scrollIntoView({ behavior: 'smooth', block: 'center' });
  span.classList.add('flash');
  setTimeout(() => span.classList.remove('flash'), 1200);
  return span;
}

// ---------- 오류 단어 상세 카드 ----------
const detailOverlay = $('detailOverlay');
const detailClose = $('detailClose');
const detailDot = $('detailDot');
const detailToken = $('detailToken');
const candList = $('candList');
const candInput = $('candInput');
const candApply = $('candApply');
const detailInfo = $('detailInfo');
const detailRevert = $('detailRevert');
let detailSpan = null;

function openDetail(span) {
  const c = lastCorrections[Number(span.dataset.idx)];
  if (!c) return;
  detailSpan = span;

  detailDot.className = `err-dot ${catOf(c.errType)}`;
  detailToken.textContent = c.token;
  detailInfo.textContent = c.info || '';
  candInput.value = '';

  candList.innerHTML = '';
  const cands = c.cands && c.cands.length ? c.cands : [c.suggestion];
  const current = span.classList.contains('off') ? null : span.textContent;
  for (const cand of cands) {
    const b = document.createElement('button');
    b.className = 'cand-item' + (cand === current ? ' selected' : '');
    b.textContent = cand;
    b.addEventListener('click', () => applyCand(cand));
    candList.appendChild(b);
  }

  detailOverlay.classList.remove('hidden');
}

function closeDetail() {
  detailOverlay.classList.add('hidden');
  detailSpan = null;
}

function applyCand(text) {
  if (!detailSpan || !text) return;
  detailSpan.classList.remove('off');
  detailSpan.textContent = text;
  detailSpan.dataset.suggestion = text;
  closeDetail();
}

detailClose.addEventListener('click', closeDetail);
detailOverlay.addEventListener('click', (e) => {
  if (e.target === detailOverlay) closeDetail();
});
detailRevert.addEventListener('click', () => {
  if (detailSpan) {
    detailSpan.classList.add('off');
    detailSpan.textContent = detailSpan.dataset.original;
  }
  closeDetail();
});
candApply.addEventListener('click', () => applyCand(candInput.value.trim()));
candInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') applyCand(candInput.value.trim());
});

// 색칠된 단어 클릭 → 상세 카드 (대치어 선택·직접 수정·원문 유지)
result.addEventListener('click', (e) => {
  const span = e.target.closest('.tok');
  if (!span) return;
  openDetail(span);
});

// ---------- 복사 ----------
async function doCopy(message) {
  try {
    await navigator.clipboard.writeText(result.textContent);
  } catch (_) {
    return;
  }
  copyBtn.classList.add('copied');
  const prev = footNote.textContent;
  footNote.textContent = message;
  setTimeout(() => {
    copyBtn.classList.remove('copied');
    footNote.textContent = prev;
  }, 1500);
}

copyBtn.addEventListener('click', () => doCopy('교정 결과가 클립보드에 복사되었습니다 ✓'));

// ---------- 검사 기록 (최근 10건, storage.local) ----------
const HISTORY_MAX = 10;

function saveHistory(text, corrections, engine) {
  if (!EXT) return;
  chrome.storage.local.get({ history: [] }, ({ history }) => {
    history.unshift({
      at: Date.now(),
      engine,
      text: text.slice(0, 3000),
      corrections,
    });
    chrome.storage.local.set({ history: history.slice(0, HISTORY_MAX) });
  });
}

function fmtTime(ts) {
  const d = new Date(ts);
  const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getMonth() + 1)}.${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

function renderHistory() {
  const list = $('historyList');
  list.innerHTML = '';
  if (!EXT) return;
  chrome.storage.local.get({ history: [] }, ({ history }) => {
    if (!history.length) {
      const empty = document.createElement('div');
      empty.className = 'hist-empty';
      empty.textContent = '아직 검사 기록이 없습니다.';
      list.appendChild(empty);
      return;
    }
    history.forEach((h, i) => {
      const row = document.createElement('div');
      row.className = 'hist-row';

      const meta = document.createElement('div');
      meta.className = 'hist-meta';

      const time = document.createElement('span');
      time.textContent = fmtTime(h.at);

      const eng = document.createElement('span');
      eng.className = 'hist-engine';
      eng.textContent = ENGINE_LABEL[h.engine] || h.engine;

      const count = document.createElement('span');
      const n = (h.corrections || []).length;
      count.className = 'hist-count' + (n ? '' : ' ok');
      count.textContent = n ? `오류 ${n}개` : '오류 없음';

      const del = document.createElement('button');
      del.className = 'hist-del';
      del.textContent = '✕';
      del.title = '삭제';
      del.addEventListener('click', (e) => {
        e.stopPropagation();
        chrome.storage.local.get({ history: [] }, ({ history: cur }) => {
          cur.splice(i, 1);
          chrome.storage.local.set({ history: cur }, renderHistory);
        });
      });

      meta.append(time, eng, count, del);

      const preview = document.createElement('div');
      preview.className = 'hist-preview';
      preview.textContent = h.text.slice(0, 60);

      row.append(meta, preview);
      row.addEventListener('click', () => {
        input.value = h.text;
        updateMeta();
        showView('main');
        renderResult(h.text, h.corrections || []);
      });
      list.appendChild(row);
    });
  });
}

$('historyClear').addEventListener('click', () => {
  if (!EXT) return;
  chrome.storage.local.set({ history: [] }, renderHistory);
});

// ---------- 설정 ----------
const setLive = $('setLive');
const setDebounce = $('setDebounce');
const setMenu = $('setMenu');
const setExcluded = $('setExcluded');
const setSaved = $('setSaved');
const engineRadios = [...document.querySelectorAll('input[name="engine"]')];

// 맞춤법 설정은 local을 정본으로 두고 sync에 미러링한다.
// chrome.storage.sync는 분당 120회·시간당 1800회 쓰기 제한이 있고 초과하면 조용히 실패해서,
// "저장되었습니다"가 뜬 뒤에도 값이 되돌아가는 문제가 있었다. local은 그 제한이 없다.
function applySettings(s) {
  liveToggle.checked = s.liveCheck;
  setLive.checked = s.liveCheck;
  setDebounce.value = String(s.debounceMs);
  setMenu.checked = s.contextMenu;
  setExcluded.value = s.excluded;
  for (const r of engineRadios) r.checked = r.value === s.engine;
  setDictOn.checked = s.userDictOn;
  setAutoCopy.checked = s.autoCopy;
  autoCopyOn = s.autoCopy;
  setUnderline.checked = s.underlineOn;
  ulColor = s.underlineColor;
  ulStyle = s.underlineStyle;
  refreshUnderlineUI();
  userDict = Array.isArray(s.userDict) ? s.userDict : [];
  renderDict();
}

function loadSettings() {
  if (!EXT) return;
  chrome.storage.sync.get(DEFAULTS, (sv) => {
    const s = chrome.runtime.lastError || !sv ? { ...DEFAULTS } : { ...DEFAULTS, ...sv };
    chrome.storage.local.get(Object.keys(DEFAULTS), (lc) => {
      // local에 값이 있으면 그것이 이 기기의 확정값
      if (!chrome.runtime.lastError && lc) {
        for (const k of Object.keys(DEFAULTS)) if (lc[k] !== undefined) s[k] = lc[k];
      }
      applySettings(s);
    });
  });
}

function save(partial) {
  if (!EXT) return;
  chrome.storage.local.set(partial, () => {
    const err = chrome.runtime.lastError;
    if (err) {
      setSaved.textContent = '저장 실패: ' + err.message;
      setSaved.classList.add('flash');
      return;
    }
    setSaved.textContent = '저장되었습니다 ✓';
    setSaved.classList.add('flash');
    setTimeout(() => {
      setSaved.textContent = '변경 사항은 즉시 저장됩니다';
      setSaved.classList.remove('flash');
    }, 1200);
    // 다른 기기 동기화는 덤 — 할당량 초과로 실패해도 이 기기 동작에는 영향 없음
    try {
      chrome.storage.sync.set(partial, () => void chrome.runtime.lastError);
    } catch (_) {}
  });
}

liveToggle.addEventListener('change', () => {
  setLive.checked = liveToggle.checked;
  save({ liveCheck: liveToggle.checked });
});

setLive.addEventListener('change', () => {
  liveToggle.checked = setLive.checked;
  save({ liveCheck: setLive.checked });
});

setDebounce.addEventListener('change', () => save({ debounceMs: Number(setDebounce.value) }));
setMenu.addEventListener('change', () => save({ contextMenu: setMenu.checked }));

const setAutoCopy = $('setAutoCopy');
setAutoCopy.addEventListener('change', () => {
  autoCopyOn = setAutoCopy.checked;
  save({ autoCopy: setAutoCopy.checked });
});

// ---------- 오류 밑줄 설정 ----------
const setUnderline = $('setUnderline');
const ulOpts = $('ulOpts');
const ulCustom = $('ulCustom');
const ulPreview = $('ulPreview');
const swatches = [...document.querySelectorAll('.swatch[data-color]')];
const ulStyles = [...document.querySelectorAll('.ul-style')];
let ulColor = DEFAULTS.underlineColor;
let ulStyle = DEFAULTS.underlineStyle;

function refreshUnderlineUI() {
  ulOpts.classList.toggle('disabled', !setUnderline.checked);
  const preset = swatches.some((s) => s.dataset.color === ulColor);
  for (const s of swatches) s.classList.toggle('selected', s.dataset.color === ulColor);
  document.querySelector('.swatch-custom').classList.toggle('selected', !preset);
  if (!preset) ulCustom.value = ulColor;
  for (const b of ulStyles) b.classList.toggle('selected', b.dataset.style === ulStyle);
  ulPreview.style.textDecoration = setUnderline.checked
    ? `underline ${ulStyle} ${ulColor} 2px`
    : 'none';
}

setUnderline.addEventListener('change', () => {
  save({ underlineOn: setUnderline.checked });
  refreshUnderlineUI();
});

for (const s of swatches) {
  s.addEventListener('click', () => {
    ulColor = s.dataset.color;
    save({ underlineColor: ulColor });
    refreshUnderlineUI();
  });
}

ulCustom.addEventListener('input', () => {
  ulColor = ulCustom.value;
  save({ underlineColor: ulColor });
  refreshUnderlineUI();
});

for (const b of ulStyles) {
  b.addEventListener('click', () => {
    ulStyle = b.dataset.style;
    save({ underlineStyle: ulStyle });
    refreshUnderlineUI();
  });
}

let excludedTimer = 0;
setExcluded.addEventListener('input', () => {
  clearTimeout(excludedTimer);
  excludedTimer = setTimeout(() => save({ excluded: setExcluded.value }), 500);
});

for (const r of engineRadios) {
  r.addEventListener('change', () => {
    if (r.checked) save({ engine: r.value });
  });
}

// ---------- 개인 사전 ----------
const setDictOn = $('setDictOn');
const dictList = $('dictList');
const dictFrom = $('dictFrom');
const dictTo = $('dictTo');
const dictAddBtn = $('dictAddBtn');
let userDict = [];

function renderDict() {
  dictList.innerHTML = '';
  if (!userDict.length) {
    const empty = document.createElement('div');
    empty.className = 'dict-empty';
    empty.textContent = '등록된 단어가 없습니다. 아래에서 추가해 보세요.';
    dictList.appendChild(empty);
    return;
  }
  userDict.forEach((entry, i) => {
    const row = document.createElement('div');
    row.className = 'dict-row';

    const from = document.createElement('span');
    from.className = 'dict-from';
    from.textContent = entry.from;

    const arrow = document.createElement('span');
    arrow.className = 'err-arrow';
    arrow.textContent = '→';

    const to = document.createElement('span');
    to.className = 'dict-to';
    to.textContent = entry.to;

    const del = document.createElement('button');
    del.className = 'dict-del';
    del.textContent = '✕';
    del.title = '삭제';
    del.addEventListener('click', () => {
      userDict.splice(i, 1);
      save({ userDict });
      renderDict();
    });

    row.append(from, arrow, to, del);
    dictList.appendChild(row);
  });
}

function addDictEntry() {
  const from = dictFrom.value.trim();
  const to = dictTo.value.trim();
  if (!from || !to || from === to) return;
  // 같은 '틀린 표현'이 이미 있으면 교체
  const existing = userDict.findIndex((e) => e.from === from);
  if (existing !== -1) userDict.splice(existing, 1);
  userDict.unshift({ from, to });
  save({ userDict });
  renderDict();
  dictFrom.value = '';
  dictTo.value = '';
  dictFrom.focus();
}

dictAddBtn.addEventListener('click', addDictEntry);
dictTo.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') addDictEntry();
});
dictFrom.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') dictTo.focus();
});

setDictOn.addEventListener('change', () => save({ userDictOn: setDictOn.checked }));

// 개인 사전 내보내기/가져오기 (JSON)
$('dictExport').addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(userDict, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'textdoctor-dict.json';
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});

$('dictImport').addEventListener('click', () => $('dictFile').click());

$('dictFile').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  try {
    const data = JSON.parse(await file.text());
    if (!Array.isArray(data)) throw new Error('형식 오류');
    let added = 0;
    for (const entry of data) {
      const from = String(entry.from || '').trim();
      const to = String(entry.to || '').trim();
      if (!from || !to || from === to) continue;
      const existing = userDict.findIndex((d) => d.from === from);
      if (existing !== -1) userDict.splice(existing, 1);
      userDict.push({ from, to });
      added++;
    }
    save({ userDict });
    renderDict();
    setSaved.textContent = `${added}개 단어를 가져왔습니다 ✓`;
    setSaved.classList.add('flash');
    setTimeout(() => {
      setSaved.textContent = '변경 사항은 즉시 저장됩니다';
      setSaved.classList.remove('flash');
    }, 2000);
  } catch (_) {
    setSaved.textContent = '가져오기 실패 — JSON 형식을 확인해 주세요 ([{"from":"...","to":"..."}])';
    setTimeout(() => (setSaved.textContent = '변경 사항은 즉시 저장됩니다'), 2500);
  }
});

// ---------- 화면 전환 (검사 / 설정 / 기록) ----------
const historyView = $('historyView');
const historyBtn = $('historyBtn');
let currentView = 'main';

const FOOT_NOTES = {
  main: '색칠된 단어를 누르면 대치어와 도움말을 볼 수 있어요.',
  settings: '설정은 모든 기기에 동기화됩니다.',
  history: '기록을 클릭하면 그 검사 결과를 다시 볼 수 있어요.',
};

function showView(name) {
  if (currentTab !== 'spell') showTab('spell', false);
  currentView = name;
  mainView.classList.toggle('hidden', name !== 'main');
  settingsView.classList.toggle('hidden', name !== 'settings');
  historyView.classList.toggle('hidden', name !== 'history');
  settingsBtn.classList.toggle('active', name === 'settings');
  historyBtn.classList.toggle('active', name === 'history');
  footNote.textContent = FOOT_NOTES[name];
  if (name === 'history') renderHistory();
  // 테마 설정 그룹을 맞춤법 설정에도 표시 (하나뿐인 DOM을 화면 간 이동)
  if (name === 'settings' && typeof placeThemeGroup === 'function') placeThemeGroup('spell');
}

settingsBtn.addEventListener('click', () => {
  // 코코포리아 탭에서는 코코포 설정을, 맞춤법 탭에서는 맞춤법 설정을 연다
  if (currentTab === 'cocofo') {
    toggleCocoSettings();
    return;
  }
  showView(currentTab === 'spell' && currentView === 'settings' ? 'main' : 'settings');
});

historyBtn.addEventListener('click', () => {
  showView(currentTab === 'spell' && currentView === 'history' ? 'main' : 'history');
});

// ---------- 상단 탭 (맞춤법 검사 / 코코포리아) ----------
const cocofoView = $('cocofoView');
const cocoSetView = $('cocoSetView');
const topTabs = [...document.querySelectorAll('.top-tab')];
let currentTab = 'spell';
let cocoSubView = 'main'; // 'main' | 'settings'

const TAB_NOTES = {
  cocofo: '방 카드 클릭 = 새 탭 이동 · 책갈피 = 저장 · 연필 = 메모',
  cocoset: '설정은 저장 즉시 적용됩니다. 코코포리아 탭은 새로고침해 주세요.',
};

function refreshFooterButtons() {
  historyBtn.classList.toggle('hidden', currentTab !== 'spell');
  if (currentTab === 'cocofo') {
    settingsBtn.classList.toggle('active', cocoSubView === 'settings');
  }
}

function showTab(tab, refreshSpellView = true) {
  currentTab = tab;
  for (const b of topTabs) b.classList.toggle('active', b.dataset.tab === tab);
  // 실시간 검사 토글은 맞춤법 탭 전용
  const lt = document.querySelector('.live-toggle');
  if (lt) lt.classList.toggle('hidden', tab !== 'spell');
  if (tab === 'spell') {
    cocofoView.classList.add('hidden');
    cocoSetView.classList.add('hidden');
    if (refreshSpellView) showView('main');
  } else {
    mainView.classList.add('hidden');
    settingsView.classList.add('hidden');
    historyView.classList.add('hidden');
    settingsBtn.classList.remove('active');
    historyBtn.classList.remove('active');
    cocofoView.classList.toggle('hidden', cocoSubView !== 'main');
    cocoSetView.classList.toggle('hidden', cocoSubView !== 'settings');
    footNote.textContent = cocoSubView === 'settings' ? TAB_NOTES.cocoset : TAB_NOTES.cocofo;
    if (cocoSubView === 'main') renderCocofo();
    else loadCocoSettings();
  }
  refreshFooterButtons();
}

function toggleCocoSettings() {
  cocoSubView = cocoSubView === 'settings' ? 'main' : 'settings';
  showTab('cocofo', false);
}

for (const b of topTabs) {
  b.addEventListener('click', () => {
    if (b.dataset.tab === 'cocofo') cocoSubView = 'main';
    showTab(b.dataset.tab);
  });
}

// ---------- 공통: 코코포 데이터/유틸 ----------
const COCO_DEFAULT_CHARS = [
  '「', '」', '『', '』', '【', '】', '〈', '〉', '《', '》', '〔', '〕',
  '…', '‥', '―', '─', '·', '、', '。', '♥', '♡', '☆', '★',
  '※', '○', '●', '◎', '◇', '◆', '□', '■', '△', '▲', '▽', '▼',
  '→', '←', '↑', '↓', '↔', '♪', '♬', '♩', '〓', '§', '¶', '†', '‡',
];
const COCO_DEFAULT_RULES = [
  { from: '...', to: '…' },
  { from: '--', to: '―' },
];

const getLocal = (defs) => new Promise((r) => (EXT ? chrome.storage.local.get(defs, r) : r(defs)));
const setLocalP = (obj) => new Promise((r) => (EXT ? chrome.storage.local.set(obj, r) : r()));
const getSyncP = (defs) => new Promise((r) => (EXT ? chrome.storage.sync.get(defs, r) : r(defs)));

function normalizeHex(v) {
  let s = String(v || '').trim();
  if (!s) return '';
  if (!s.startsWith('#')) s = '#' + s;
  if (/^#[0-9a-fA-F]{3}$/.test(s)) s = '#' + [...s.slice(1)].map((c) => c + c).join('');
  return /^#[0-9a-fA-F]{6}$/.test(s) ? s.toLowerCase() : '';
}

function darkenHex(hex, amt = 0.15) {
  const h = normalizeHex(hex);
  if (!h) return hex;
  const n = parseInt(h.slice(1), 16);
  const f = (v) => Math.max(0, Math.round(v * (1 - amt)));
  return (
    '#' +
    [f((n >> 16) & 255), f((n >> 8) & 255), f(n & 255)]
      .map((v) => v.toString(16).padStart(2, '0'))
      .join('')
  );
}

function hexToSoft(hex, alpha = 0.15) {
  const h = normalizeHex(hex);
  if (!h) return '';
  const n = parseInt(h.slice(1), 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${alpha})`;
}

function fmtDateShort(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  const day0 = new Date();
  day0.setHours(0, 0, 0, 0);
  if (ts >= day0.getTime()) return '오늘';
  if (ts >= day0.getTime() - 86400000) return '어제';
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}.${p(d.getMonth() + 1)}.${p(d.getDate())}`;
}

// ---------- 충돌 확장프로그램 감지 ----------
const KNOWN_CONFLICTS = [
  { re: /국어\s*선생님|textdoctor/i, why: '맞춤법 검사 기능 전부가 이 확장에 이미 들어있어요' },
  { re: /만두/i, why: '채팅 알림·방문 기록·헬퍼 패널이 중복돼요' },
  { re: /클로버/i, why: '스탠딩 패널 기능이 중복돼요' },
  { re: /ccfolia\s*css|css\s*adjuster|스탠딩\s*사이즈|사이즈\s*조절/i, why: '스탠딩 사이즈 조절이 중복돼요 (사이즈 탭에 내장됨)' },
  { re: /할렐|야르미/i, why: '스탠딩/저널 변경 기능이 중복돼요' },
  { re: /특수문자.*팔레트|팔레트.*특수문자/i, why: '특수문자 팔레트가 중복돼요' },
  { re: /text\s*expander|auto\s*text|텍스트\s*대치/i, why: '텍스트 대치가 중복돼요' },
];
const MAYBE_CONFLICT_RE = /ccfolia|cocofo|코코포/i;

async function checkConflicts() {
  if (!EXT || !chrome.management || !chrome.management.getAll) return;
  let all;
  try {
    all = await chrome.management.getAll();
  } catch (_) {
    return;
  }
  const { conflictDismissed } = await getSyncP({ conflictDismissed: [] });
  const dismissed = new Set(conflictDismissed || []);
  const selfId = chrome.runtime.id;

  const must = [];
  const maybe = [];
  for (const ext of all) {
    if (ext.id === selfId || !ext.enabled || ext.type !== 'extension') continue;
    const hay = ext.name + ' ' + (ext.description || '');
    const hit = KNOWN_CONFLICTS.find((k) => k.re.test(hay));
    if (hit) must.push({ ext, why: hit.why });
    else if (MAYBE_CONFLICT_RE.test(hay)) maybe.push({ ext, why: '코코포리아 관련 확장으로 보여요 — 기능이 겹치면 꺼주세요' });
  }

  const visibleMust = must.filter((e) => !dismissed.has(e.ext.id));
  const visibleMaybe = maybe.filter((e) => !dismissed.has(e.ext.id));
  const banner = $('conflictBanner');
  if (!visibleMust.length && !visibleMaybe.length) {
    banner.classList.add('hidden');
    return;
  }

  function fillGroup(groupId, items) {
    const group = $(groupId);
    const rows = group.querySelector('.conflict-rows');
    rows.innerHTML = '';
    group.classList.toggle('hidden', !items.length);
    for (const { ext, why } of items) {
      const row = document.createElement('div');
      row.className = 'conflict-row';
      const name = document.createElement('span');
      name.className = 'conflict-name';
      name.textContent = ext.name;
      name.title = why;
      const off = document.createElement('button');
      off.className = 'conflict-off';
      off.textContent = '끄기';
      off.title = why;
      off.addEventListener('click', async () => {
        try {
          await chrome.management.setEnabled(ext.id, false);
          off.textContent = '꺼짐 ✓';
          off.disabled = true;
          name.style.textDecoration = 'line-through';
          name.style.opacity = '0.6';
        } catch (_) {
          off.textContent = '실패';
        }
      });
      row.append(name, off);
      rows.appendChild(row);
    }
  }

  fillGroup('conflictMust', visibleMust);
  fillGroup('conflictMaybe', visibleMaybe);
  banner.classList.remove('hidden');

  $('conflictDismiss').onclick = () => {
    const ids = [...dismissed, ...visibleMust.map((e) => e.ext.id), ...visibleMaybe.map((e) => e.ext.id)];
    chrome.storage.sync.set({ conflictDismissed: [...new Set(ids)] });
    banner.classList.add('hidden');
  };
}

// ---------- 코코포리아 탭: 섹션 접기 + 순서 ----------
const SEC_NAMES = { tools: '도구', rooms: '방 기록', split: '화면 분할', colors: '캐릭터 색상' };
// 배포본(dist)에는 화면 분할 섹션이 없다 (lib/edition.js)
const SEC_DEFAULT = window.CST_LITE ? ['tools', 'rooms', 'colors'] : ['tools', 'rooms', 'split', 'colors'];
let secOrderState = [...SEC_DEFAULT];
let secCollapsed = {};

// 예전에 저장된 순서에는 '도구'가 없다. 빠진 것은 뒤에 붙이고 모르는 것은 버린다.
function normalizeSecOrder(saved) {
  const out = Array.isArray(saved) ? saved.filter((k) => SEC_DEFAULT.includes(k)) : [];
  for (const k of SEC_DEFAULT) if (!out.includes(k)) out.push(k);
  return out;
}

function applySectionLayout() {
  // 순서
  const secs = {};
  cocofoView.querySelectorAll('.coco-sec').forEach((s) => (secs[s.dataset.sec] = s));
  for (const key of secOrderState) {
    if (secs[key]) cocofoView.appendChild(secs[key]);
  }
  // 접기 상태
  cocofoView.querySelectorAll('.coco-sec').forEach((s) => {
    s.classList.toggle('collapsed', !!secCollapsed[s.dataset.sec]);
  });
}

function toggleSection(sec) {
  const key = sec.dataset.sec;
  secCollapsed[key] = !secCollapsed[key];
  sec.classList.toggle('collapsed', secCollapsed[key]);
  if (EXT) chrome.storage.sync.set({ cocofoCollapsed: secCollapsed });
}

cocofoView.querySelectorAll('.sec-collapse').forEach((btn) => {
  btn.addEventListener('click', () => toggleSection(btn.closest('.coco-sec')));
});

// 섹션 제목 클릭으로도 접기/펼치기
cocofoView.querySelectorAll('.coco-sec .settings-title').forEach((title) => {
  title.classList.add('sec-title-clickable');
  title.addEventListener('click', () => toggleSection(title.closest('.coco-sec')));
});

// ---------- 코코포리아 탭: 방 기록 ----------
let roomSubTab = 'recent'; // 'recent' | 'saved'
let roomView = 'thumb'; // 'thumb' | 'list'

document.querySelectorAll('.room-subtab').forEach((b) => {
  b.addEventListener('click', () => {
    roomSubTab = b.dataset.sub;
    document.querySelectorAll('.room-subtab').forEach((x) => x.classList.toggle('active', x === b));
    renderRooms();
  });
});

$('roomViewToggle').addEventListener('click', () => {
  roomView = roomView === 'thumb' ? 'list' : 'thumb';
  if (EXT) chrome.storage.sync.set({ roomView });
  renderRooms();
});

function openExtPage(path) {
  if (EXT && chrome.tabs) chrome.tabs.create({ url: chrome.runtime.getURL(path) });
}

$('openStudio').addEventListener('click', () => openExtPage('studio/studio.html'));
$('openManager').addEventListener('click', () => openExtPage('manager/manager.html'));
$('openChargen').addEventListener('click', () => openExtPage('chargen/chargen.html'));
// 세션 관리자의 '전체 백업 · 복원' 화면으로 바로 들어간다
$('openBackup').addEventListener('click', () => openExtPage('manager/manager.html#backup'));

// 배포본(dist)에는 캐릭터 생성기 · 전체 백업 · 화면 분할이 없다 (lib/edition.js)
if (window.CST_LITE) {
  $('openChargen').classList.add('hidden');
  $('openBackup').classList.add('hidden');
  const splitSec = document.querySelector('.coco-sec[data-sec="split"]');
  if (splitSec) splitSec.classList.add('hidden');
}

async function toggleBookmark(roomId) {
  const { rooms, savedRoomOrder } = await getLocal({ rooms: {}, savedRoomOrder: [] });
  if (!rooms[roomId]) return;
  const on = !rooms[roomId].favorite;
  rooms[roomId].favorite = on;
  let order = savedRoomOrder.filter((id) => id !== roomId);
  if (on) order.push(roomId);
  await setLocalP({ rooms, savedRoomOrder: order });
  renderRooms();
}

async function renderRooms() {
  const { rooms, savedRoomOrder } = await getLocal({ rooms: {}, savedRoomOrder: [] });
  const grid = $('roomGrid');
  grid.innerHTML = '';
  grid.classList.toggle('list-mode', roomView === 'list');
  $('roomViewToggle').innerHTML =
    roomView === 'thumb' ? faIcon('list') + ' 리스트로' : faIcon('grid') + ' 썸네일로';

  let entries;
  if (roomSubTab === 'recent') {
    entries = Object.entries(rooms || {}).sort((a, b) => (b[1].lastVisit || 0) - (a[1].lastVisit || 0));
  } else {
    const ordered = savedRoomOrder.filter((id) => rooms[id] && rooms[id].favorite);
    for (const [id, r] of Object.entries(rooms || {})) {
      if (r.favorite && !ordered.includes(id)) ordered.push(id);
    }
    entries = ordered.map((id) => [id, rooms[id]]);
  }

  if (!entries.length) {
    const empty = document.createElement('div');
    empty.className = 'room-empty';
    empty.textContent =
      roomSubTab === 'recent'
        ? '아직 방문한 방이 없습니다. 코코포리아 방에 들어가면 자동으로 기록돼요.'
        : '저장된 방이 없습니다. 방의 책갈피 버튼을 누르면 여기 저장돼요.';
    grid.appendChild(empty);
    return;
  }

  entries.forEach(([roomId, room], idx) => {
    grid.appendChild(roomItem(roomId, room, idx, entries));
  });
}

function roomItem(roomId, room, idx, entries) {
  const isList = roomView === 'list';
  const card = document.createElement('div');
  card.className = isList ? 'room-row' : 'room-card';
  card.title = room.name || roomId;

  const thumb = document.createElement('div');
  thumb.className = isList ? 'room-row-thumb' : 'room-thumb';
  if (room.thumb) {
    const img = document.createElement('img');
    img.src = room.thumb;
    img.addEventListener('error', () => {
      img.remove();
      thumb.innerHTML = faIcon('dice');
    });
    thumb.appendChild(img);
  } else {
    thumb.innerHTML = faIcon('dice');
  }

  const name = document.createElement('span');
  name.className = 'room-name';
  name.textContent = room.name || '이름 없는 방';

  const date = document.createElement('span');
  date.className = 'room-date';
  date.textContent = fmtDateShort(room.lastVisit);

  const bk = document.createElement('button');
  bk.className = (isList ? 'room-row-btn' : 'room-fav') + (room.favorite ? ' on' : '');
  bk.innerHTML = faIcon('bookmark');
  bk.title = room.favorite ? '저장 해제' : '저장된 방에 추가 (책갈피)';
  bk.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleBookmark(roomId);
  });

  const del = document.createElement('button');
  del.className = isList ? 'room-row-btn' : 'room-del';
  del.innerHTML = faIcon('xmark');
  del.title = '기록 삭제';
  del.addEventListener('click', async (e) => {
    e.stopPropagation();
    if (!confirm(`"${room.name || roomId}" 기록을 삭제할까요?\n(저장된 스탠딩·메모도 함께 삭제됩니다)`)) return;
    const { rooms: cur, savedRoomOrder } = await getLocal({ rooms: {}, savedRoomOrder: [] });
    delete cur[roomId];
    await setLocalP({ rooms: cur, savedRoomOrder: savedRoomOrder.filter((id) => id !== roomId) });
    renderRooms();
  });

  const memoBtn = document.createElement('button');
  memoBtn.className = (isList ? 'room-row-btn' : 'room-memo-btn') + (room.memo ? ' has-memo' : '');
  memoBtn.innerHTML = faIcon('pen');
  memoBtn.title = '방 메모 편집';
  // 호버하면 읽기용으로 자동 펼침, 클릭(또는 연필 버튼)하면 편집 모드
  const memoView = document.createElement('div');
  memoView.className = 'room-memoview' + (room.memo ? '' : ' memo-none');
  const memoText = document.createElement('div');
  memoText.className = 'room-memotext';
  memoText.textContent = room.memo || '';
  memoView.appendChild(memoText);

  function openMemoEditor() {
    if (card.classList.contains('memo-editing')) return;
    card.classList.add('memo-editing');
    memoView.innerHTML = '';
    const ta = document.createElement('textarea');
    ta.placeholder = '이 방 메모 (자동 저장)';
    ta.value = room.memo || '';
    const saved = document.createElement('div');
    saved.className = 'room-memo-saved';
    let t = 0;
    ta.addEventListener('input', () => {
      clearTimeout(t);
      saved.textContent = '입력 중…';
      t = setTimeout(async () => {
        const { rooms: cur } = await getLocal({ rooms: {} });
        if (cur[roomId]) {
          cur[roomId].memo = ta.value;
          await setLocalP({ rooms: cur });
        }
        room.memo = ta.value;
        memoBtn.classList.toggle('has-memo', !!ta.value);
        saved.textContent = '저장됨 ✓';
      }, 500);
    });
    ta.addEventListener('blur', () => {
      setTimeout(() => {
        card.classList.remove('memo-editing');
        memoView.innerHTML = '';
        memoText.textContent = room.memo || '';
        memoView.appendChild(memoText);
        memoView.classList.toggle('memo-none', !room.memo);
      }, 150);
    });
    ta.addEventListener('click', (ev) => ev.stopPropagation());
    memoView.append(ta, saved);
    ta.focus();
  }

  memoView.addEventListener('click', (ev) => {
    ev.stopPropagation();
    openMemoEditor();
  });
  memoBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    openMemoEditor();
  });
  card.appendChild(memoView);

  if (isList) {
    card.append(thumb, name, date, memoBtn, bk, del);
  } else {
    card.append(thumb, name, date, bk, del, memoBtn);
  }

  card.addEventListener('click', () => {
    const url = room.url || 'https://ccfolia.com/rooms/' + roomId;
    if (EXT && chrome.tabs) chrome.tabs.create({ url });
    else window.open(url);
  });

  // 저장된 방: 드래그로 순서 변경
  if (roomSubTab === 'saved') {
    card.draggable = true;
    card.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('text/plain', String(idx));
      card.classList.add('dragging');
    });
    card.addEventListener('dragend', () => card.classList.remove('dragging'));
    card.addEventListener('dragover', (e) => {
      e.preventDefault();
      card.classList.add('dragover');
    });
    card.addEventListener('dragleave', () => card.classList.remove('dragover'));
    card.addEventListener('drop', async (e) => {
      e.preventDefault();
      card.classList.remove('dragover');
      const fromIdx = Number(e.dataTransfer.getData('text/plain'));
      if (Number.isNaN(fromIdx) || fromIdx === idx) return;
      const order = entries.map(([id]) => id);
      const [moved] = order.splice(fromIdx, 1);
      order.splice(idx, 0, moved);
      await setLocalP({ savedRoomOrder: order });
      renderRooms();
    });
  }

  return card;
}

// ---------- 코코포리아 탭: 화면 분할 (같은 방 멀티 창) ----------
let splitTarget = null; // { tabId } | { url }

async function renderSplitTarget() {
  const box = $('splitTarget');
  box.innerHTML = '';
  splitTarget = null;

  let openTabs = [];
  if (EXT && chrome.tabs) {
    try {
      openTabs = await chrome.tabs.query({
        url: ['https://ccfolia.com/rooms/*', 'https://*.ccfolia.com/rooms/*'],
      });
    } catch (_) {}
  }
  const { rooms } = await getLocal({ rooms: {} });
  const recent = Object.entries(rooms || {})
    .sort((a, b) => (b[1].lastVisit || 0) - (a[1].lastVisit || 0))
    .slice(0, 8);

  function addOption(value, labelText, thumbUrl, checked) {
    const label = document.createElement('label');
    label.className = 'split-room';
    const rb = document.createElement('input');
    rb.type = 'radio';
    rb.name = 'splitTarget';
    rb.checked = !!checked;
    rb.addEventListener('change', () => {
      if (rb.checked) {
        splitTarget = value;
        updateSplitButtons();
      }
    });
    if (checked) splitTarget = value;
    const name = document.createElement('span');
    name.className = 'split-room-name';
    name.textContent = labelText;
    if (thumbUrl) {
      const img = document.createElement('img');
      img.className = 'room-mini-thumb';
      img.src = thumbUrl;
      img.addEventListener('error', () => (img.style.visibility = 'hidden'));
      label.append(rb, img, name);
    } else {
      label.append(rb, name);
    }
    box.appendChild(label);
  }

  let first = true;
  for (const tab of openTabs) {
    addOption({ tabId: tab.id }, '(열린 탭) ' + (tab.title || tab.url), null, first && tab.active);
    first = false;
  }
  for (const [roomId, room] of recent) {
    const url = room.url || 'https://ccfolia.com/rooms/' + roomId;
    // 이미 열린 탭과 같은 방은 중복 표시하지 않음
    if (openTabs.some((t) => (t.url || '').startsWith(url))) continue;
    addOption({ url }, room.name || '이름 없는 방', room.thumb || null, false);
  }

  if (!box.children.length) {
    const empty = document.createElement('div');
    empty.className = 'dict-empty';
    empty.textContent = '분할할 방이 없습니다. 코코포리아 방을 열어두거나 방문 기록을 만들어 주세요.';
    box.appendChild(empty);
  }

  // 라디오 하나라도 선택돼 있지 않으면 첫 항목 선택
  if (!splitTarget && box.querySelector('input[type="radio"]')) {
    const firstRb = box.querySelector('input[type="radio"]');
    firstRb.checked = true;
    firstRb.dispatchEvent(new Event('change'));
  }
  updateSplitButtons();
}

function updateSplitButtons() {
  document.querySelectorAll('.split-count-btn').forEach((b) => (b.disabled = !splitTarget));
}

document.querySelectorAll('.split-count-btn').forEach((b) => {
  b.addEventListener('click', async () => {
    if (!EXT || !splitTarget) return;
    await chrome.runtime.sendMessage({
      type: 'SPLIT_SAME',
      target: splitTarget,
      count: Number(b.dataset.n),
      screen: {
        availLeft: window.screen.availLeft || 0,
        availTop: window.screen.availTop || 0,
        availWidth: window.screen.availWidth,
        availHeight: window.screen.availHeight,
      },
    });
    window.close();
  });
});

// ---------- 코코포리아 탭: 캐릭터 색상 ----------
async function renderColors() {
  const { charColors } = await getLocal({ charColors: {} });
  const rows = $('colorRows');
  rows.innerHTML = '';
  const names = Object.keys(charColors || {});
  if (!names.length) {
    const empty = document.createElement('div');
    empty.className = 'dict-empty';
    empty.textContent = '저장된 색상이 없습니다. 위에서 캐릭터 이름과 색상을 입력해 저장하세요.';
    rows.appendChild(empty);
  }
  for (const n of names) {
    const row = document.createElement('div');
    row.className = 'color-row';
    row.title = '클릭하면 색상 코드를 복사합니다.';
    const chip = document.createElement('span');
    chip.className = 'color-chip';
    chip.style.background = charColors[n];
    const label = document.createElement('span');
    label.className = 'color-name';
    label.textContent = n;
    const hex = document.createElement('span');
    hex.className = 'color-hex';
    hex.textContent = charColors[n];
    const del = document.createElement('button');
    del.className = 'dict-del';
    del.textContent = '✕';
    del.title = '삭제';
    del.addEventListener('click', async (e) => {
      e.stopPropagation();
      const { charColors: cc } = await getLocal({ charColors: {} });
      delete cc[n];
      await setLocalP({ charColors: cc });
      renderColors();
    });
    row.append(chip, label, hex, del);
    row.addEventListener('click', () => {
      navigator.clipboard && navigator.clipboard.writeText(charColors[n]).catch(() => {});
    });
    rows.appendChild(row);
  }
}

$('colorPick').addEventListener('input', () => ($('colorHex').value = $('colorPick').value));
$('colorHex').addEventListener('input', () => {
  const h = normalizeHex($('colorHex').value);
  if (h) $('colorPick').value = h;
});
$('colorAddBtn').addEventListener('click', async () => {
  const nm = $('colorName').value.trim();
  const hx = normalizeHex($('colorHex').value) || normalizeHex($('colorPick').value);
  if (!nm || !hx) return;
  const { charColors: cc } = await getLocal({ charColors: {} });
  cc[nm] = hx;
  await setLocalP({ charColors: cc });
  $('colorName').value = '';
  $('colorHex').value = '';
  renderColors();
});

// ---------- 코코포리아 탭 전체 렌더 ----------
async function renderCocofo() {
  const s = await getSyncP({ roomView: 'thumb', cocofoOrder: SEC_DEFAULT, cocofoCollapsed: {} });
  roomView = s.roomView === 'list' ? 'list' : 'thumb';
  secOrderState = normalizeSecOrder(s.cocofoOrder);
  secCollapsed = s.cocofoCollapsed || {};
  applySectionLayout();
  renderRooms();
  renderSplitTarget();
  renderColors();
}

// ---------- 테마 그룹 DOM 이동 (맞춤법 설정 ↔ 코코포 설정 양쪽에 표시) ----------
const themeGroupEl = $('themeGroup');
const spellThemeMount = $('spellThemeMount');
const themeGroupHome = document.createComment('theme-home');
if (themeGroupEl && themeGroupEl.parentElement) {
  themeGroupEl.parentElement.insertBefore(themeGroupHome, themeGroupEl);
}

function placeThemeGroup(where) {
  if (!themeGroupEl) return;
  if (where === 'spell' && spellThemeMount) {
    spellThemeMount.appendChild(themeGroupEl);
  } else if (themeGroupHome.parentNode) {
    themeGroupHome.parentNode.insertBefore(themeGroupEl, themeGroupHome.nextSibling);
  }
}

// ---------- 테마 (4종 + 포인트색) ----------
const THEMES = ['dark', 'light', 'mono', 'retro'];
const THEME_DEFAULT_ACCENT = {
  dark: '#e05252',
  light: '#d94848',
  mono: '#e8e8ec',
  retro: '#c94434',
};
let curTheme = 'dark';
let curAccent = '';

function applyThemeUI() {
  for (const t of THEMES) document.body.classList.toggle('theme-' + t, curTheme === t && t !== 'dark');
  const a = normalizeHex(curAccent);
  if (a) {
    document.body.style.setProperty('--accent', a);
    document.body.style.setProperty('--accent-dark', darkenHex(a));
    document.body.style.setProperty('--accent-soft', hexToSoft(a));
  } else {
    document.body.style.removeProperty('--accent');
    document.body.style.removeProperty('--accent-dark');
    document.body.style.removeProperty('--accent-soft');
  }
  document
    .querySelectorAll('.theme-btn')
    .forEach((b) => b.classList.toggle('selected', b.dataset.theme === curTheme));
  const pick = $('accentPick');
  if (pick) {
    pick.value = a || THEME_DEFAULT_ACCENT[curTheme] || '#e05252';
    $('accentCode').textContent = a ? a + ' (커스텀)' : '테마 기본색';
  }
}

document.querySelectorAll('.theme-btn').forEach((b) => {
  b.addEventListener('click', () => {
    curTheme = b.dataset.theme;
    applyThemeUI();
    saveCoco({ theme: curTheme });
  });
});

// ---------- 디자인 (기본 / 디자인 2 = 왼쪽 세로 레일) ----------
// 팝업과 방 안 헬퍼 패널이 같은 값을 본다.
const DESIGNS = ['basic', 'rail'];
let curDesign = 'basic';

function applyDesignUI() {
  document.body.classList.toggle('design-rail', curDesign === 'rail');
  document
    .querySelectorAll('.design-btn')
    .forEach((b) => b.classList.toggle('active', b.dataset.design === curDesign));
}

document.querySelectorAll('.design-btn').forEach((b) => {
  b.addEventListener('click', () => {
    curDesign = b.dataset.design;
    applyDesignUI();
    saveCoco({ uiDesign: curDesign });
  });
});

$('accentPick').addEventListener('input', () => {
  curAccent = $('accentPick').value;
  applyThemeUI();
});
$('accentPick').addEventListener('change', () => {
  saveCoco({ accentColor: curAccent });
});
$('accentReset').addEventListener('click', () => {
  curAccent = '';
  applyThemeUI();
  saveCoco({ accentColor: '' });
});

// ---------- 코코포 설정 ----------
const cocoSetSaved = $('cocoSetSaved');
let cocoRules = [];

function cocoFlash(msg) {
  cocoSetSaved.textContent = msg || '저장되었습니다 ✓';
  cocoSetSaved.classList.add('flash');
  setTimeout(() => {
    cocoSetSaved.textContent = '변경 사항은 즉시 저장됩니다';
    cocoSetSaved.classList.remove('flash');
  }, 1200);
}

function saveCoco(partial) {
  if (!EXT) return;
  chrome.storage.sync.set(partial, cocoFlash);
}

function renderSecOrder() {
  const box = $('secOrder');
  box.innerHTML = '';
  secOrderState.forEach((key, i) => {
    const row = document.createElement('div');
    row.className = 'sec-order-row';
    const name = document.createElement('span');
    name.className = 'sec-order-name';
    name.textContent = `${i + 1}. ${SEC_NAMES[key] || key}`;
    const up = document.createElement('button');
    up.textContent = '↑';
    up.disabled = i === 0;
    up.addEventListener('click', () => {
      [secOrderState[i - 1], secOrderState[i]] = [secOrderState[i], secOrderState[i - 1]];
      saveCoco({ cocofoOrder: secOrderState });
      renderSecOrder();
      applySectionLayout();
    });
    const down = document.createElement('button');
    down.textContent = '↓';
    down.disabled = i === secOrderState.length - 1;
    down.addEventListener('click', () => {
      [secOrderState[i + 1], secOrderState[i]] = [secOrderState[i], secOrderState[i + 1]];
      saveCoco({ cocofoOrder: secOrderState });
      renderSecOrder();
      applySectionLayout();
    });
    row.append(name, up, down);
    box.appendChild(row);
  });
}

async function loadCocoSettings() {
  placeThemeGroup('coco'); // 테마 그룹을 코코포 설정 자리로 복귀
  const s = await getSyncP({
    theme: 'dark',
    accentColor: '',
    ccfNotify: true,
    ccfPanel: true,
    ccfHome: true,
    ccfReplaceOn: true,
    replaceRules: COCO_DEFAULT_RULES,
    replaceSites: [],
    specialChars: COCO_DEFAULT_CHARS,
    cocofoOrder: SEC_DEFAULT,
    uiDesign: 'basic',
    noticePos: 'top',
    noticeFont: 12,
  });
  $('setNoticePos').value = s.noticePos === 'bottom' ? 'bottom' : 'top';
  $('setNoticeFont').value = Number(s.noticeFont) || 12;
  $('setNoticeFontOut').textContent = (Number(s.noticeFont) || 12) + 'px';
  curTheme = THEMES.includes(s.theme) ? s.theme : 'dark';
  curAccent = s.accentColor || '';
  curDesign = DESIGNS.includes(s.uiDesign) ? s.uiDesign : 'basic';
  applyThemeUI();
  applyDesignUI();
  secOrderState = normalizeSecOrder(s.cocofoOrder);
  renderSecOrder();
  $('setNotify').checked = s.ccfNotify !== false;
  $('setPanel').checked = s.ccfPanel !== false;
  $('setHome').checked = s.ccfHome !== false;
  $('setReplace').checked = s.ccfReplaceOn !== false;
  $('setReplaceSites').value = (s.replaceSites || []).join('\n');
  $('setChars').value = (s.specialChars || COCO_DEFAULT_CHARS).join(' ');
  cocoRules = Array.isArray(s.replaceRules) ? s.replaceRules : COCO_DEFAULT_RULES;
  renderRules();
}

$('setNotify').addEventListener('change', () => saveCoco({ ccfNotify: $('setNotify').checked }));
$('setPanel').addEventListener('change', () => saveCoco({ ccfPanel: $('setPanel').checked }));
$('setHome').addEventListener('change', () => saveCoco({ ccfHome: $('setHome').checked }));
$('setNoticePos').addEventListener('change', () => saveCoco({ noticePos: $('setNoticePos').value }));
// 슬라이더는 끌 때마다 input이 쏟아진다 — sync 저장은 분당 쓰기 한도가 있어 묶어서 보낸다
let noticeFontTimer = 0;
$('setNoticeFont').addEventListener('input', () => {
  const v = Number($('setNoticeFont').value) || 12;
  $('setNoticeFontOut').textContent = v + 'px';
  clearTimeout(noticeFontTimer);
  noticeFontTimer = setTimeout(() => saveCoco({ noticeFont: v }), 300);
});
$('setReplace').addEventListener('change', () => saveCoco({ ccfReplaceOn: $('setReplace').checked }));

let sitesTimer = 0;
$('setReplaceSites').addEventListener('input', () => {
  clearTimeout(sitesTimer);
  sitesTimer = setTimeout(() => {
    const sites = $('setReplaceSites')
      .value.split('\n')
      .map((s) => s.trim())
      .filter(Boolean);
    saveCoco({ replaceSites: sites });
  }, 500);
});

let charsTimer = 0;
$('setChars').addEventListener('input', () => {
  clearTimeout(charsTimer);
  charsTimer = setTimeout(() => {
    const chars = $('setChars').value.split(/\s+/).filter(Boolean);
    saveCoco({ specialChars: chars });
  }, 500);
});

$('charsReset').addEventListener('click', () => {
  $('setChars').value = COCO_DEFAULT_CHARS.join(' ');
  saveCoco({ specialChars: COCO_DEFAULT_CHARS });
});

function renderRules() {
  const rows = $('ruleRows');
  rows.innerHTML = '';
  if (!cocoRules.length) {
    const empty = document.createElement('div');
    empty.className = 'dict-empty';
    empty.textContent = '규칙이 없습니다. 아래에서 추가해 보세요.';
    rows.appendChild(empty);
    return;
  }
  cocoRules.forEach((r, i) => {
    const row = document.createElement('div');
    row.className = 'dict-row';
    const from = document.createElement('span');
    from.className = 'dict-from';
    from.style.textDecoration = 'none';
    from.textContent = r.from;
    const arrow = document.createElement('span');
    arrow.className = 'err-arrow';
    arrow.textContent = '→';
    const to = document.createElement('span');
    to.className = 'dict-to';
    to.textContent = r.to;
    const del = document.createElement('button');
    del.className = 'dict-del';
    del.textContent = '✕';
    del.title = '삭제';
    del.addEventListener('click', () => {
      cocoRules.splice(i, 1);
      saveCoco({ replaceRules: cocoRules });
      renderRules();
    });
    row.append(from, arrow, to, del);
    rows.appendChild(row);
  });
}

function addRule() {
  const from = $('ruleFrom').value;
  const to = $('ruleTo').value;
  if (!from || !to || from === to) return;
  const existing = cocoRules.findIndex((r) => r.from === from);
  if (existing !== -1) cocoRules.splice(existing, 1);
  cocoRules.unshift({ from, to });
  saveCoco({ replaceRules: cocoRules });
  renderRules();
  $('ruleFrom').value = '';
  $('ruleTo').value = '';
  $('ruleFrom').focus();
}

$('ruleAddBtn').addEventListener('click', addRule);
$('ruleTo').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') addRule();
});
$('ruleFrom').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') $('ruleTo').focus();
});

// ---------- SVG 아이콘 주입 (lib/icons.js) ----------
(function injectStaticIcons() {
  if (typeof faIcon !== 'function') return;
  const THEME_ICONS = { dark: 'moon', light: 'sun', mono: 'half', retro: 'gamepad' };
  document.querySelectorAll('.theme-btn').forEach((b) => {
    const ic = THEME_ICONS[b.dataset.theme];
    if (ic) b.innerHTML = faIcon(ic) + ' ' + b.textContent.trim();
  });
  const warn = document.querySelector('.conflict-title-ic');
  if (warn) warn.innerHTML = faIcon('warning');
  document.querySelectorAll('.io-ic').forEach((sp) => {
    sp.innerHTML = faIcon(sp.dataset.ic === 'up' ? 'up' : 'down');
  });
})();

// ---------- 초기화 ----------
// 팝업을 열 때마다 저장된 맞춤법 설정을 화면에 다시 채운다.
// (이 호출이 빠져 있어서 실시간 검사 토글·엔진·사전이 매번 기본값으로 보였다)
loadSettings();

getSyncP({ theme: 'dark', accentColor: '', uiDesign: 'basic' }).then((s) => {
  curTheme = THEMES.includes(s.theme) ? s.theme : 'dark';
  curAccent = s.accentColor || '';
  curDesign = DESIGNS.includes(s.uiDesign) ? s.uiDesign : 'basic';
  applyThemeUI();
  applyDesignUI();
});
checkConflicts();
