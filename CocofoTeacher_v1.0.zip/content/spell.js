/**
 * 국어 선생님 (TextDoctor) — 콘텐트 스크립트
 * 1) 실시간 검사(토글): textarea / input / contenteditable
 * 2) 우클릭 "맞춤법 검사 후 자동 교정" 처리
 */
(() => {
  'use strict';

  // 선언적 + 프로그램적 주입이 겹쳐도 한 번만 실행
  if (window.__textDoctorLoaded) return;
  window.__textDoctorLoaded = true;

  const HANGUL_RE = /[가-힣]{2,}/;
  const HIGHLIGHT_NAME = 'tcx-typo';
  const MAX_LIVE_CHARS = 3000; // 실시간 검사 상한 (무게 제한)

  let liveEnabled = false;
  let debounceMs = 1500;
  let excludedHere = false; // 이 사이트가 제외 목록에 있는가
  let underlineOn = true;
  let underlineColor = '#e5484d';
  let underlineStyle = 'wavy'; // wavy | solid | dotted

  // 밑줄 스타일을 동적 <style>로 주입 (설정 변경 즉시 반영)
  function updateUnderlineStyle() {
    let el = document.getElementById('tcx-underline-style');
    if (!el) {
      el = document.createElement('style');
      el.id = 'tcx-underline-style';
      (document.head || document.documentElement).appendChild(el);
    }
    el.textContent =
      `::highlight(tcx-typo){` +
      `text-decoration: underline ${underlineStyle} ${underlineColor} 2px;` +
      `text-underline-offset: 3px;}` +
      // textarea용 겹판 — 글자는 투명하고 밑줄만 보인다
      `.tcx-underlay{color:transparent !important;background:none !important;}` +
      `.tcx-underlay .tcx-mark{color:transparent !important;background:none !important;` +
      `text-decoration: underline ${underlineStyle} ${underlineColor} 2px;` +
      `text-underline-offset: 3px;}`;
  }
  let currentField = null;
  let currentTypos = [];
  let debounceTimer = 0;
  // 검사 직전 설정 재확인 주기 (매번 읽으면 검사가 눈에 띄게 늦어진다)
  let lastVerifyAt = 0;
  const VERIFY_INTERVAL_MS = 5000;
  let composing = false;
  let checkSeq = 0;
  const ignored = new Set(); // 세션 내 무시 토큰

  let badgeEl = null;
  let panelEl = null;
  let toastEl = null;
  let toastTimer = 0;
  let applying = false; // 교정 적용 중 (자체 input 이벤트로 UI가 닫히는 것 방지)

  // ---------- 설정 ----------
  function isExcluded(excluded) {
    const host = location.hostname;
    return String(excluded || '')
      .split(/[\n,]+/)
      .map((s) => s.trim().replace(/^https?:\/\//, '').replace(/\/.*$/, ''))
      .filter(Boolean)
      .some((site) => host === site || host.endsWith('.' + site));
  }

  function liveActive() {
    return liveEnabled && !excludedHere;
  }

  // 토글이 켜진 순간 이미 포커스된 입력창이 있으면 바로 검사 시작
  function attachActiveElement() {
    const el = document.activeElement;
    if (!el) return;
    if (isTextInput(el)) attachField(el);
    else {
      const root = editableRoot(el);
      if (root) attachField(root);
    }
  }

  // 저장값을 읽어 로컬 상태와 맞춘다.
  // 읽기가 실패하면(동기화 오류·확장 리로드 등) 기존 상태를 그대로 두고 false로 낙인찍지 않는다
  // — 예전에는 실패를 "꺼짐"으로 처리해서 켜둔 검사가 혼자 꺼지는 일이 있었다.
  const SPELL_DEFAULTS = {
    liveCheck: false,
    debounceMs: 1500,
    excluded: '',
    underlineOn: true,
    underlineColor: '#e5484d',
    underlineStyle: 'wavy',
  };
  const SPELL_KEYS = Object.keys(SPELL_DEFAULTS);

  // 설정 읽기: local이 이 기기의 정본, sync는 다른 기기에서 넘어온 기본값
  // (sync는 쓰기 할당량 초과 시 조용히 실패하므로 단독으로 신뢰하지 않는다)
  function extAlive() {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (_) {
      return false;
    }
  }

  function readSettings(cb) {
    if (!extAlive()) return cb(null);
    try {
      chrome.storage.sync.get(SPELL_DEFAULTS, (sv) => {
        const s = chrome.runtime.lastError || !sv ? { ...SPELL_DEFAULTS } : { ...SPELL_DEFAULTS, ...sv };
        const syncOk = !chrome.runtime.lastError;
        chrome.storage.local.get(SPELL_KEYS, (lc) => {
          const localOk = !chrome.runtime.lastError && !!lc;
          if (localOk) {
            for (const k of SPELL_KEYS) if (lc[k] !== undefined) s[k] = lc[k];
          }
          cb(syncOk || localOk ? s : null);
        });
      });
    } catch (_) {
      cb(null);
    }
  }

  function syncSettings(onDone) {
    readSettings((s) => {
      if (!s) return onDone && onDone(false);
      liveEnabled = !!s.liveCheck; // 켜짐/꺼짐 양방향 동기화 (오래된 탭의 상태 어긋남 교정)
      debounceMs = Number(s.debounceMs) || 1500;
      excludedHere = isExcluded(s.excluded);
      underlineOn = !!s.underlineOn;
      underlineColor = s.underlineColor || '#e5484d';
      underlineStyle = s.underlineStyle || 'wavy';
      updateUnderlineStyle();
      if (onDone) onDone(true);
    });
  }

  syncSettings((ok) => {
    if (ok && liveActive()) attachActiveElement();
  });

  if (extAlive()) chrome.storage.onChanged.addListener((changes, area) => {
    // local(정본)과 sync(미러) 양쪽 다 본다
    if (area !== 'sync' && area !== 'local') return;
    if (!SPELL_KEYS.some((k) => k in changes)) return;
    if (changes.liveCheck) liveEnabled = !!changes.liveCheck.newValue;
    if (changes.debounceMs) debounceMs = Number(changes.debounceMs.newValue) || 1500;
    if (changes.excluded) excludedHere = isExcluded(changes.excluded.newValue);
    if (changes.underlineOn) underlineOn = !!changes.underlineOn.newValue;
    if (changes.underlineColor) underlineColor = changes.underlineColor.newValue || '#e5484d';
    if (changes.underlineStyle) underlineStyle = changes.underlineStyle.newValue || 'wavy';
    if (changes.underlineOn || changes.underlineColor || changes.underlineStyle) {
      updateUnderlineStyle();
      paintHighlights(); // 현재 필드에 즉시 반영
    }
    // 검사 on/off·제외 목록이 실제로 바뀐 경우에만 붙였다 뗀다.
    // (테마·패널 설정 등 다른 sync 쓰기에 반응해 검사가 멋대로 시작되던 문제)
    if (!changes.liveCheck && !changes.excluded) return;
    if (!liveActive()) detachField();
    else attachActiveElement();
  });

  // 탭을 다시 볼 때 저장값과 맞춘다 — 다른 탭/기기에서 토글한 결과를 놓친 탭 교정
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState !== 'visible') return;
    syncSettings((ok) => {
      if (!ok) return;
      if (!liveActive()) detachField();
    });
  });

  // ---------- 필드 판별/읽기/쓰기 ----------
  function isTextInput(el) {
    if (!el || el.closest && el.closest('.tcx-panel')) return false;
    if (el instanceof HTMLTextAreaElement) return true;
    if (el instanceof HTMLInputElement) {
      return ['text', 'search', 'email', 'url'].includes(el.type);
    }
    return false;
  }

  function editableRoot(el) {
    if (!el || !(el instanceof Element)) return null;
    const host = el.closest('[contenteditable=""], [contenteditable="true"], [contenteditable="plaintext-only"]');
    return host;
  }

  function fieldText(field) {
    if (isTextInput(field)) return field.value;
    return field.innerText || '';
  }

  // ---------- 텍스트 노드 매핑 (contenteditable) ----------
  function collectTextNodes(root) {
    const nodes = [];
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let n;
    let total = 0;
    while ((n = walker.nextNode())) {
      nodes.push({ node: n, start: total, end: total + n.data.length });
      total += n.data.length;
    }
    return { nodes, text: nodes.map((x) => x.node.data).join('') };
  }

  function rangeFromOffsets(nodes, start, end) {
    let sNode = null, sOff = 0, eNode = null, eOff = 0;
    for (const item of nodes) {
      if (sNode === null && start >= item.start && start < item.end) {
        sNode = item.node;
        sOff = start - item.start;
      }
      if (end > item.start && end <= item.end) {
        eNode = item.node;
        eOff = end - item.start;
        break;
      }
    }
    if (!sNode || !eNode) return null;
    const range = document.createRange();
    range.setStart(sNode, sOff);
    range.setEnd(eNode, eOff);
    return range;
  }

  // ---------- 하이라이트 ----------
  // contenteditable은 CSS Custom Highlight로 칠하고,
  // textarea/input은 그 API가 안 먹으므로 같은 자리에 투명한 겹판을 얹어 밑줄만 보여준다.
  let underlayEl = null;

  function removeUnderlay() {
    if (underlayEl) {
      underlayEl.remove();
      underlayEl = null;
    }
  }

  function escHtml(t) {
    return String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  // 오탈자 위치를 <mark>로 감싼 HTML (겹판에 넣을 것)
  function underlayHtml(text) {
    const marks = [];
    for (const typo of currentTypos) {
      let idx = 0;
      for (;;) {
        idx = text.indexOf(typo.token, idx);
        if (idx === -1) break;
        marks.push([idx, idx + typo.token.length]);
        idx += typo.token.length;
      }
    }
    if (!marks.length) return '';
    marks.sort((a, b) => a[0] - b[0]);
    // 겹치는 구간 합치기
    const merged = [marks[0]];
    for (const m of marks.slice(1)) {
      const last = merged[merged.length - 1];
      if (m[0] <= last[1]) last[1] = Math.max(last[1], m[1]);
      else merged.push(m);
    }
    let html = '';
    let pos = 0;
    for (const [a, b] of merged) {
      html += escHtml(text.slice(pos, a));
      html += '<mark class="tcx-mark">' + escHtml(text.slice(a, b)) + '</mark>';
      pos = b;
    }
    html += escHtml(text.slice(pos));
    // 마지막 줄바꿈이 잘리지 않게
    return html + '​';
  }

  const UNDERLAY_COPY = [
    'fontFamily', 'fontSize', 'fontWeight', 'fontStyle', 'letterSpacing', 'lineHeight',
    'textTransform', 'textIndent', 'textAlign', 'wordSpacing', 'whiteSpace', 'wordBreak',
    'overflowWrap', 'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft',
    'borderTopWidth', 'borderRightWidth', 'borderBottomWidth', 'borderLeftWidth', 'direction',
  ];

  function paintUnderlay() {
    if (!currentField || !isTextInput(currentField)) return removeUnderlay();
    if (!underlineOn || !currentTypos.length) return removeUnderlay();

    const html = underlayHtml(fieldText(currentField));
    if (!html) return removeUnderlay();

    if (!underlayEl) {
      underlayEl = document.createElement('div');
      underlayEl.className = 'tcx-underlay';
      document.documentElement.appendChild(underlayEl);
    }
    const cs = getComputedStyle(currentField);
    const r = currentField.getBoundingClientRect();
    const st = underlayEl.style;
    st.position = 'fixed';
    st.left = r.left + 'px';
    st.top = r.top + 'px';
    st.width = r.width + 'px';
    st.height = r.height + 'px';
    st.pointerEvents = 'none';
    st.zIndex = '2147483000';
    st.overflow = 'hidden';
    st.boxSizing = 'border-box';
    st.color = 'transparent';
    st.background = 'none';
    st.borderStyle = 'solid';
    st.borderColor = 'transparent';
    st.margin = '0';
    if (cs.whiteSpace === 'normal' || !cs.whiteSpace) st.whiteSpace = 'pre-wrap';
    for (const k of UNDERLAY_COPY) st[k] = cs[k];
    underlayEl.innerHTML = html;
    underlayEl.scrollTop = currentField.scrollTop;
    underlayEl.scrollLeft = currentField.scrollLeft;
  }

  function clearHighlights() {
    if (window.CSS && CSS.highlights) CSS.highlights.delete(HIGHLIGHT_NAME);
    removeUnderlay();
  }

  function paintHighlights() {
    if (window.CSS && CSS.highlights) CSS.highlights.delete(HIGHLIGHT_NAME);
    if (!currentField) return removeUnderlay();
    // textarea/input → 겹판 방식
    if (isTextInput(currentField)) return paintUnderlay();
    removeUnderlay();
    if (!underlineOn) return;
    if (!(window.CSS && CSS.highlights && typeof Highlight !== 'undefined')) return;

    const { nodes, text } = collectTextNodes(currentField);
    const ranges = [];
    for (const typo of currentTypos) {
      let idx = 0;
      for (;;) {
        idx = text.indexOf(typo.token, idx);
        if (idx === -1) break;
        const r = rangeFromOffsets(nodes, idx, idx + typo.token.length);
        if (r) ranges.push(r);
        idx += typo.token.length;
      }
    }
    if (ranges.length) {
      CSS.highlights.set(HIGHLIGHT_NAME, new Highlight(...ranges));
    }
  }

  // ---------- 배지 ----------
  function ensureBadge() {
    if (badgeEl) return badgeEl;
    badgeEl = document.createElement('button');
    badgeEl.className = 'tcx-badge';
    badgeEl.type = 'button';
    badgeEl.addEventListener('mousedown', (e) => e.preventDefault()); // 포커스 유지
    badgeEl.addEventListener('click', () => {
      if (currentTypos.length) togglePanel();
    });
    document.documentElement.appendChild(badgeEl);
    return badgeEl;
  }

  function positionBadge() {
    if (!badgeEl || !currentField) return;
    const rect = currentField.getBoundingClientRect();
    const bw = badgeEl.offsetWidth || 60;
    badgeEl.style.left = `${Math.max(4, rect.right - bw - 6)}px`;
    badgeEl.style.top = `${Math.min(window.innerHeight - 30, rect.bottom - 26)}px`;
  }

  function showBadge() {
    // 오류가 없으면 아무것도 표시하지 않는다 (초록 ✓ 배지 제거)
    if (!currentTypos.length) {
      hideBadge();
      return;
    }
    const b = ensureBadge();
    b.textContent = `맞춤법 ${currentTypos.length}`;
    b.classList.remove('tcx-ok');
    b.style.display = 'inline-flex';
    positionBadge();
  }

  function hideBadge() {
    if (badgeEl) badgeEl.style.display = 'none';
  }

  // ---------- 교정 패널 ----------
  function closePanel() {
    if (panelEl) {
      panelEl.remove();
      panelEl = null;
    }
  }

  function togglePanel() {
    if (panelEl) closePanel();
    else openPanel();
  }

  function openPanel(focusToken) {
    closePanel();
    if (!currentField || !currentTypos.length) return;

    panelEl = document.createElement('div');
    panelEl.className = 'tcx-panel';
    panelEl.addEventListener('mousedown', (e) => e.preventDefault()); // 필드 포커스 유지

    const head = document.createElement('div');
    head.className = 'tcx-panel-head';
    const title = document.createElement('span');
    title.textContent = `교정 제안 ${currentTypos.length}개`;
    const btns = document.createElement('div');
    btns.className = 'tcx-panel-head-btns';

    const fixAll = document.createElement('button');
    fixAll.className = 'tcx-btn tcx-btn-fix';
    fixAll.textContent = '모두 바꾸기';
    fixAll.addEventListener('click', () => {
      applyAll();
    });

    const close = document.createElement('button');
    close.className = 'tcx-btn-x';
    close.textContent = '✕';
    close.setAttribute('aria-label', '닫기');
    close.addEventListener('click', closePanel);

    btns.append(fixAll, close);
    head.append(title, btns);
    panelEl.appendChild(head);

    for (const typo of currentTypos) {
      const item = document.createElement('div');
      item.className = 'tcx-item';

      const line = document.createElement('div');
      line.className = 'tcx-item-line';
      const before = document.createElement('span');
      before.className = 'tcx-before';
      before.textContent = typo.token;
      const arrow = document.createElement('span');
      arrow.className = 'tcx-arrow';
      arrow.textContent = '→';
      const after = document.createElement('span');
      after.className = 'tcx-after';
      after.textContent = typo.suggestion;
      line.append(before, arrow, after);

      const itemBtns = document.createElement('div');
      itemBtns.className = 'tcx-item-btns';

      const fix = document.createElement('button');
      fix.className = 'tcx-btn tcx-btn-fix';
      fix.textContent = '바꾸기';
      fix.addEventListener('click', () => {
        applyOne(typo);
      });

      const ignore = document.createElement('button');
      ignore.className = 'tcx-btn tcx-btn-ghost';
      ignore.textContent = '무시하기';
      ignore.addEventListener('click', () => {
        ignored.add(typo.token);
        currentTypos = currentTypos.filter((t) => t !== typo);
        refreshUI();
      });

      itemBtns.append(fix, ignore);
      item.append(line, itemBtns);
      panelEl.appendChild(item);

      if (focusToken && typo.token === focusToken) {
        setTimeout(() => item.scrollIntoView({ block: 'nearest' }), 0);
      }
    }

    document.documentElement.appendChild(panelEl);
    positionPanel();
  }

  function positionPanel() {
    if (!panelEl || !currentField) return;
    const rect = currentField.getBoundingClientRect();
    const pw = 300;
    const ph = Math.min(320, panelEl.offsetHeight || 320);
    let left = Math.min(rect.right - pw, window.innerWidth - pw - 8);
    left = Math.max(8, left);
    let top = rect.bottom + 6;
    if (top + ph > window.innerHeight - 8) top = Math.max(8, rect.top - ph - 6);
    panelEl.style.left = `${left}px`;
    panelEl.style.top = `${top}px`;
  }

  function refreshUI() {
    paintHighlights();
    showBadge();
    if (panelEl) {
      if (currentTypos.length) openPanel();
      else closePanel();
    }
  }

  // ---------- 교정 적용 ----------
  function replaceInTextInput(field, token, suggestion, all) {
    let from = 0;
    let replacedAny = false;
    for (;;) {
      const idx = field.value.indexOf(token, from);
      if (idx === -1) break;
      field.focus();
      field.setSelectionRange(idx, idx + token.length);
      let ok = false;
      try {
        ok = document.execCommand('insertText', false, suggestion);
      } catch (_) { /* ignore */ }
      if (!ok) {
        field.setRangeText(suggestion, idx, idx + token.length, 'end');
        field.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: suggestion }));
      }
      replacedAny = true;
      from = idx + suggestion.length;
      if (!all) break;
    }
    return replacedAny;
  }

  function replaceInEditable(root, token, suggestion, all) {
    let replacedAny = false;
    for (let guard = 0; guard < 50; guard++) {
      const { nodes, text } = collectTextNodes(root);
      const idx = text.indexOf(token);
      if (idx === -1) break;
      const range = rangeFromOffsets(nodes, idx, idx + token.length);
      if (!range) break;
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      let ok = false;
      try {
        ok = document.execCommand('insertText', false, suggestion);
      } catch (_) { /* ignore */ }
      if (!ok) {
        range.deleteContents();
        range.insertNode(document.createTextNode(suggestion));
      }
      replacedAny = true;
      if (!all) break;
    }
    return replacedAny;
  }

  function applyTypo(typo, all) {
    if (!currentField) return;
    applying = true;
    try {
      if (isTextInput(currentField)) {
        replaceInTextInput(currentField, typo.token, typo.suggestion, all);
      } else {
        replaceInEditable(currentField, typo.token, typo.suggestion, all);
      }
    } finally {
      applying = false;
    }
  }

  function applyOne(typo) {
    applyTypo(typo, true); // 같은 오류는 한 번에 (동일 토큰 전부)
    currentTypos = currentTypos.filter((t) => t !== typo);
    refreshUI();
  }

  function applyAll() {
    const list = currentTypos.slice();
    for (const typo of list) applyTypo(typo, true);
    const n = list.length;
    currentTypos = [];
    refreshUI();
    closePanel();
    showToast(`${n}곳 교정 완료`);
  }

  // ---------- 실시간 검사 ----------
  async function runLiveCheck() {
    if (!liveActive() || !currentField) return;
    // 설정 변경 알림을 놓친 경우에 대비해 저장값을 재확인한다.
    // 읽기 자체가 실패하면(동기화 오류 등) 판단을 보류하고 기존 상태로 진행 —
    // 실패를 "꺼짐"으로 오인해 검사가 혼자 꺼지지 않게 한다.
    // 단, 매 검사마다 sync+local을 직렬로 읽으면 그만큼 검사가 늦어진다.
    // storage.onChanged가 이미 상태를 따라가고 있으니 확인은 드물게만 한다.
    if (Date.now() - lastVerifyAt > VERIFY_INTERVAL_MS) {
      lastVerifyAt = Date.now();
      const fresh = await new Promise((r) => readSettings((st) => r(st ? !!st.liveCheck : null)));
      if (fresh === false) {
        liveEnabled = false;
        detachField();
        return;
      }
      if (fresh === true) liveEnabled = true;
      if (!liveActive() || !currentField) return;
    }
    const text = fieldText(currentField);
    if (!HANGUL_RE.test(text) || text.length > MAX_LIVE_CHARS) {
      currentTypos = [];
      clearHighlights();
      hideBadge();
      return;
    }

    const seq = ++checkSeq;
    let res;
    try {
      res = await chrome.runtime.sendMessage({ type: 'CHECK', text });
    } catch (_) {
      return; // 확장 리로드 등
    }
    if (seq !== checkSeq || !currentField) return; // 오래된 응답 무시
    if (!res || !res.ok) return;

    currentTypos = res.corrections.filter((c) => !ignored.has(c.token));
    paintHighlights();
    showBadge();
    if (panelEl) refreshUI();
  }

  // 한글은 마지막 글자가 조합 중(composing)으로 남아 있는 일이 흔하다.
  // 예전에는 타이머가 터질 때 조합 중이면 검사를 그냥 버리고 다시 예약하지도 않아서,
  // 다음 입력이 올 때까지 밑줄이 안 떴다 — 0.5초로 맞춰놔도 몇 초씩 기다리는 느낌의 원인.
  // 이제는 조합이 끝나기를 잠깐만 기다리고, 그래도 안 끝나면 그대로 검사한다.
  const COMPOSE_STEP_MS = 120;
  const COMPOSE_MAX_MS = 600;

  function waitComposeThenCheck(waited) {
    if (composing && waited < COMPOSE_MAX_MS) {
      debounceTimer = setTimeout(() => waitComposeThenCheck(waited + COMPOSE_STEP_MS), COMPOSE_STEP_MS);
      return;
    }
    runLiveCheck();
  }

  function scheduleCheck() {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => waitComposeThenCheck(0), debounceMs);
  }

  function attachField(field) {
    if (currentField === field) return;
    detachField();
    currentField = field;
    scheduleCheck();
  }

  function detachField() {
    clearTimeout(debounceTimer);
    checkSeq++;
    currentField = null;
    currentTypos = [];
    clearHighlights();
    hideBadge();
    closePanel();
  }

  document.addEventListener('focusin', (e) => {
    if (!liveActive()) return;
    const t = e.target;
    if (isTextInput(t)) {
      attachField(t);
    } else {
      const root = editableRoot(t);
      if (root) attachField(root);
    }
  });

  document.addEventListener('focusout', (e) => {
    if (!currentField) return;
    const next = e.relatedTarget;
    if (next && (panelEl && panelEl.contains(next))) return;
    if (next && (currentField === next || currentField.contains && currentField.contains(next))) return;
    // 패널 조작 중일 수 있으므로 약간 지연 후 실제 포커스 확인
    setTimeout(() => {
      const active = document.activeElement;
      if (
        currentField &&
        active !== currentField &&
        !(currentField.contains && currentField.contains(active)) &&
        !(panelEl && panelEl.contains(active))
      ) {
        detachField();
      }
    }, 120);
  });

  document.addEventListener('input', (e) => {
    if (!liveActive() || !currentField) return;
    const t = e.target;
    if (t === currentField || (currentField.contains && currentField.contains(t))) {
      if (applying) return; // 교정 적용으로 발생한 이벤트
      clearHighlights(); // 편집 중 어긋난 밑줄 제거
      hideBadge();
      closePanel();
      scheduleCheck();
    }
  });

  document.addEventListener('compositionstart', () => (composing = true));
  document.addEventListener('compositionend', () => {
    composing = false;
    if (liveActive() && currentField) scheduleCheck();
  });

  // 밑줄 클릭 → 해당 오류의 교정 패널 열기 (contenteditable)
  document.addEventListener('click', (e) => {
    if (!currentField || isTextInput(currentField) || !currentTypos.length) return;
    if (!(currentField.contains && currentField.contains(e.target))) return;
    let range = null;
    if (document.caretRangeFromPoint) {
      range = document.caretRangeFromPoint(e.clientX, e.clientY);
    }
    if (!range) return;
    const { nodes, text } = collectTextNodes(currentField);
    let caret = -1;
    for (const item of nodes) {
      if (item.node === range.startContainer) {
        caret = item.start + range.startOffset;
        break;
      }
    }
    if (caret === -1) return;
    for (const typo of currentTypos) {
      let idx = 0;
      for (;;) {
        idx = text.indexOf(typo.token, idx);
        if (idx === -1) break;
        if (caret >= idx && caret <= idx + typo.token.length) {
          openPanel(typo.token);
          return;
        }
        idx += typo.token.length;
      }
    }
  });

  window.addEventListener('scroll', () => {
    positionBadge();
    positionPanel();
    paintUnderlay();
  }, { passive: true, capture: true });

  // 입력창 자체를 스크롤하면 밑줄도 같이 움직여야 한다
  document.addEventListener('scroll', (e) => {
    if (underlayEl && e.target === currentField) {
      underlayEl.scrollTop = currentField.scrollTop;
      underlayEl.scrollLeft = currentField.scrollLeft;
    }
  }, true);
  window.addEventListener('resize', () => {
    positionBadge();
    positionPanel();
    paintUnderlay();
  }, { passive: true });

  // ---------- 토스트 ----------
  function showToast(message) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.className = 'tcx-toast';
      document.documentElement.appendChild(toastEl);
    }
    toastEl.textContent = message;
    toastEl.classList.add('tcx-show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('tcx-show'), 2500);
  }

  // ---------- 우클릭 즉시 교정 ----------
  function getSelectionContext() {
    const active = document.activeElement;
    if (isTextInput(active) && active.selectionStart < active.selectionEnd) {
      return {
        kind: 'input',
        field: active,
        start: active.selectionStart,
        end: active.selectionEnd,
        text: active.value.substring(active.selectionStart, active.selectionEnd),
      };
    }
    const sel = window.getSelection();
    if (sel && !sel.isCollapsed && sel.rangeCount > 0) {
      const range = sel.getRangeAt(0);
      const root = editableRoot(
        range.commonAncestorContainer instanceof Element
          ? range.commonAncestorContainer
          : range.commonAncestorContainer.parentElement
      );
      return { kind: root ? 'editable' : 'readonly', range, text: sel.toString() };
    }
    return null;
  }

  async function contextCorrect() {
    const ctx = getSelectionContext();
    if (!ctx || !ctx.text.trim()) {
      showToast('선택된 텍스트가 없습니다');
      return;
    }

    showToast('맞춤법 검사 중…');

    let res;
    try {
      res = await chrome.runtime.sendMessage({ type: 'CHECK', text: ctx.text });
    } catch (_) {
      showToast('검사에 실패했습니다');
      return;
    }
    if (!res || !res.ok) {
      showToast(res && res.error ? res.error : '검사에 실패했습니다');
      return;
    }

    let corrected = ctx.text;
    let count = 0;
    for (const c of res.corrections) {
      if (c.token && c.token !== c.suggestion && corrected.includes(c.token)) {
        corrected = corrected.split(c.token).join(c.suggestion);
        count++;
      }
    }

    if (count === 0) {
      showToast('맞춤법 오류가 없습니다 ✓');
      return;
    }

    if (ctx.kind === 'input') {
      const f = ctx.field;
      f.focus();
      f.setSelectionRange(ctx.start, ctx.end);
      let ok = false;
      try {
        ok = document.execCommand('insertText', false, corrected);
      } catch (_) { /* ignore */ }
      if (!ok) {
        f.setRangeText(corrected, ctx.start, ctx.end, 'end');
        f.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: corrected }));
      }
      showToast(`${count}곳 교정 완료`);
    } else if (ctx.kind === 'editable') {
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(ctx.range);
      let ok = false;
      try {
        ok = document.execCommand('insertText', false, corrected);
      } catch (_) { /* ignore */ }
      if (!ok) {
        ctx.range.deleteContents();
        ctx.range.insertNode(document.createTextNode(corrected));
      }
      showToast(`${count}곳 교정 완료`);
    } else {
      // 편집 불가 영역 → 교정문을 클립보드로
      try {
        await navigator.clipboard.writeText(corrected);
        showToast(`${count}곳 교정 → 클립보드에 복사됨`);
      } catch (_) {
        showToast('편집할 수 없는 영역입니다');
      }
    }
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === 'CONTEXT_CORRECT') {
      contextCorrect();
      sendResponse({ ok: true });
    }
    return false;
  });
})();
