// 코코포리아 선생님 — 통합 헬퍼 패널 (스탠딩 / 색상 / 메모 / 문자 / 사이즈)
(() => {
  if (window.__cstPanelLoaded) return;
  window.__cstPanelLoaded = true;

  const EXT = typeof chrome !== 'undefined' && chrome.storage && chrome.runtime;
  if (!EXT) return;

  const m = location.pathname.match(/^\/rooms\/([^/]+)/);
  if (!m) return;
  const roomId = m[1];

  const DEFAULT_CHARS = [
    '「', '」', '『', '』', '【', '】', '〈', '〉', '《', '》', '〔', '〕',
    '…', '‥', '―', '─', '·', '、', '。', '♥', '♡', '☆', '★',
    '※', '○', '●', '◎', '◇', '◆', '□', '■', '△', '▲', '▽', '▼',
    '→', '←', '↑', '↓', '↔', '♪', '♬', '♩', '〓', '§', '¶', '†', '‡',
  ];

  const THEMES = ['dark', 'light', 'mono', 'retro'];
  const LITE = !!window.CST_LITE; // 배포본: 캡처 탭·로그 자동 백업 없음 (lib/edition.js)

  // 켜기/끄기 스위치 — 팝업 설정의 토글과 같은 모양. 패널의 모든 켜기/끄기는 이걸 쓴다.
  // 반환: { wrap, input }  (wrap 을 줄에 붙이고, input 으로 checked 를 읽는다)
  // 글자 라벨은 <label for=input.id> 로 연결한다 — 줄 자체를 label 로 감싸 중첩시키면
  // 글자를 눌렀을 때 토글이 안 된다 (안쪽 label 이 상호작용 요소라 바깥 label 이 비켜감).
  let swSeq = 0;
  function mkSwitch(checked, onChange) {
    // <label> 이어야 손잡이를 눌렀을 때 안쪽 숨은 체크박스가 토글된다 (div 줄 안에 놓여도 동작)
    const wrap = document.createElement('label');
    wrap.className = 'cst-switch';
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.id = 'cst-sw-' + ++swSeq;
    input.checked = !!checked;
    if (onChange) input.addEventListener('change', () => onChange(input.checked));
    const knob = document.createElement('span');
    knob.className = 'cst-switch-knob';
    wrap.append(input, knob);
    return { wrap, input };
  }

  const state = {
    theme: 'dark',
    accent: '',
    panelOn: true,
    specialChars: DEFAULT_CHARS,
    thumb: { zoom: 100, posX: 50, posY: 15 },
    cols: 3,
    standingCss: {},
    noticePos: 'top', // 고정 메모 바 위치: top | bottom(좌하단)
    noticeFont: 12, // 고정 메모 글자 크기(px)
    activeTab: 'standing',
    currentChar: '',
    lastStanding: '',
    atPrefix: true, // 스탠딩 클릭 시 맨 앞에 @ 추가
    adjustMode: false, // 썸네일을 마우스로 직접 조정하는 중
    detected: null, // { name, standings, sheet }
    sheetChar: '', // 시트 백업에서 보고 있는 캐릭터
  };

  let suppressThumbEcho = false;
  let suppressColsEcho = false;
  let suppressCssEcho = false;

  // ---------------- 스토리지 ----------------
  // 확장을 새로고침하면 페이지에 남아 있던 이 스크립트의 chrome.* 연결이 끊긴다
  // ("Extension context invalidated"). 그 상태에서 호출하면 예외가 나므로,
  // 매번 살아 있는지 확인하고 죽었으면 조용히 기본값으로 넘어간 뒤 UI를 정리한다.
  let extDead = false;

  function extAlive() {
    if (extDead) return false;
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (_) {
      return false;
    }
  }

  function handleContextLost() {
    if (extDead) return;
    extDead = true;
    try {
      clearInterval(fabGuardTimer);
      clearTimeout(detectTimer);
      if (domObserver) domObserver.disconnect();
      if (panel) panel.remove();
      if (fab) fab.remove();
      if (noticeBar) noticeBar.remove();
      if (toastEl) toastEl.remove();
    } catch (_) {}
    // 확장이 업데이트/재로드된 상황 — 새로고침하면 다시 붙는다
    try {
      const note = document.createElement('div');
      note.style.cssText =
        'position:fixed;left:50%;bottom:22px;transform:translateX(-50%);z-index:2147483600;' +
        'background:#2a2a2f;color:#ececef;border:1px solid #46464f;border-radius:10px;' +
        'padding:8px 14px;font:12px/1.5 sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.4);cursor:pointer;';
      note.textContent = '코코포리아 선생님이 업데이트됐어요. 새로고침하면 다시 켜집니다. (클릭하면 새로고침)';
      note.addEventListener('click', () => location.reload());
      document.body.appendChild(note);
      setTimeout(() => note.remove(), 12000);
    } catch (_) {}
  }

  // chrome.storage 호출을 감싼다 — 컨텍스트가 죽었으면 예외 대신 기본값 반환
  function safeStorage(area, method, arg, defs) {
    return new Promise((resolve) => {
      if (!extAlive()) {
        handleContextLost();
        return resolve(defs);
      }
      try {
        chrome.storage[area][method](arg, (d) => {
          if (chrome.runtime.lastError) return resolve(defs);
          resolve(method === 'get' ? d : undefined);
        });
      } catch (_) {
        handleContextLost();
        resolve(defs);
      }
    });
  }

  function extUrl(path) {
    try {
      return extAlive() ? chrome.runtime.getURL(path) : '';
    } catch (_) {
      return '';
    }
  }

  function sendMsg(payload) {
    if (!extAlive()) {
      handleContextLost();
      return;
    }
    try {
      chrome.runtime.sendMessage(payload, () => void chrome.runtime.lastError);
    } catch (_) {
      handleContextLost();
    }
  }

  const getLocal = (defs) => safeStorage('local', 'get', defs, defs);
  const setLocal = (obj) => safeStorage('local', 'set', obj, undefined);
  const getSync = (defs) => safeStorage('sync', 'get', defs, defs);
  const setSync = (obj) => safeStorage('sync', 'set', obj, undefined);

  async function getRoom() {
    const { rooms } = await getLocal({ rooms: {} });
    return (
      rooms[roomId] || {
        name: '이름 없는 방',
        url: location.origin + '/rooms/' + roomId,
        thumb: '',
        favorite: false,
        memo: '',
        standings: {},
        standingOrder: {},
        lastVisit: Date.now(),
      }
    );
  }

  async function patchRoom(patchFn) {
    const { rooms } = await getLocal({ rooms: {} });
    const cur = rooms[roomId] || (await getRoom());
    patchFn(cur);
    rooms[roomId] = cur;
    await setLocal({ rooms });
  }

  // ---------------- 색상 유틸 ----------------
  function normalizeHex(v) {
    let s = String(v || '').trim();
    if (!s) return '';
    if (!s.startsWith('#')) s = '#' + s;
    if (/^#[0-9a-fA-F]{3}$/.test(s)) s = '#' + [...s.slice(1)].map((c) => c + c).join('');
    return /^#[0-9a-fA-F]{6}$/.test(s) ? s.toLowerCase() : '';
  }

  function darken(hex, amt = 0.15) {
    const h = normalizeHex(hex);
    if (!h) return hex;
    const n = parseInt(h.slice(1), 16);
    const f = (v) => Math.max(0, Math.round(v * (1 - amt)));
    return (
      '#' +
      [f((n >> 16) & 255), f((n >> 8) & 255), f(n & 255)]
        .map((v) => v.toString(16).padStart(2, '0'))
        .join('')
    );
  }

  function hexToSoft(hex, alpha = 0.15) {
    const h = normalizeHex(hex);
    if (!h) return '';
    const n = parseInt(h.slice(1), 16);
    return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${alpha})`;
  }

  // ---------------- 코코포리아 DOM 헬퍼 ----------------
  function findChatInput() {
    return document.querySelector('div[class*="MuiInputBase-root"] textarea');
  }

  function setNativeValue(el, text) {
    const proto =
      el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(el, text);
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }

  function insertAtCursor(text) {
    const input = findChatInput();
    if (!input) return;
    const start = input.selectionStart ?? input.value.length;
    const end = input.selectionEnd ?? input.value.length;
    const val = input.value;
    setNativeValue(input, val.slice(0, start) + text + val.slice(end));
    const pos = start + text.length;
    input.focus();
    input.setSelectionRange(pos, pos);
  }

  // 발화 캐릭터 전환: 채팅 입력창 옆의 캐릭터 선택 버튼을 눌러 메뉴에서 이름 매칭 클릭
  async function switchCharacter(name) {
    const input = findChatInput();
    if (!input) {
      toast('채팅 입력창을 찾을 수 없어요.');
      return;
    }
    // 입력창에서 위로 올라가며 캐릭터 선택 버튼(텍스트가 있는 button/[role="button"]) 탐색
    let opener = null;
    let p = input.parentElement;
    for (let i = 0; i < 6 && p && !opener; i++) {
      for (const b of p.querySelectorAll('button, [role="button"]')) {
        const t = (b.textContent || '').trim();
        if (t && t.length <= 30 && !/^[0-9]+$/.test(t)) {
          opener = b;
          break;
        }
      }
      p = p.parentElement;
    }
    if (!opener) {
      toast('캐릭터 선택 버튼을 찾지 못했어요.');
      return;
    }
    opener.click();
    await new Promise((r) => setTimeout(r, 350));
    const items = document.querySelectorAll(
      '[role="menu"] [role="menuitem"], [role="listbox"] [role="option"], .MuiMenu-list li, .MuiPopover-root li'
    );
    saveMyCharsFromMenu(items); // 메뉴에 뜬 목록 = 내가 발화 권한 있는 캐릭터
    let hit = null;
    for (const it of items) {
      const t = (it.textContent || '').trim();
      if (t === name) {
        hit = it;
        break;
      }
      if (!hit && t.includes(name)) hit = it;
    }
    if (hit) {
      hit.click();
      toast(`"${name}"(으)로 전환`);
    } else {
      document.body.click(); // 메뉴 닫기
      toast(`메뉴에서 "${name}"을(를) 찾지 못했어요. 캐릭터가 방에 등록돼 있어야 해요.`);
    }
  }

  // 캐릭터 선택 메뉴에 뜨는 이름들 = 내 권한 캐릭터 → room.myChars 저장
  // (백업용으로 편집창만 연 캐릭터는 여기 안 뜨므로 NPC 픽커에서 걸러진다)
  function saveMyCharsFromMenu(items) {
    const names = [];
    for (const it of items) {
      const t = (it.textContent || '').trim();
      if (t && t.length <= 40 && !names.includes(t)) names.push(t);
    }
    if (names.length) {
      patchRoom((r) => {
        r.myChars = names;
      }).catch(() => {});
    }
    return names;
  }

  // 메뉴를 잠깐 열었다 닫으며 내 캐릭터 목록만 갱신
  async function scanMyChars() {
    const input = findChatInput();
    if (!input) {
      toast('채팅 입력창을 찾을 수 없어요.');
      return [];
    }
    let opener = null;
    let p = input.parentElement;
    for (let i = 0; i < 6 && p && !opener; i++) {
      for (const b of p.querySelectorAll('button, [role="button"]')) {
        const t = (b.textContent || '').trim();
        if (t && t.length <= 30 && !/^[0-9]+$/.test(t)) {
          opener = b;
          break;
        }
      }
      p = p.parentElement;
    }
    if (!opener) {
      toast('캐릭터 선택 버튼을 찾지 못했어요.');
      return [];
    }
    opener.click();
    await new Promise((r) => setTimeout(r, 400));
    const items = document.querySelectorAll(
      '[role="menu"] [role="menuitem"], [role="listbox"] [role="option"], .MuiMenu-list li, .MuiPopover-root li'
    );
    const names = saveMyCharsFromMenu(items);
    // 메뉴 닫기 (ESC → 폴백 body 클릭)
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    await new Promise((r) => setTimeout(r, 150));
    document.body.click();
    return names;
  }

  function appendStandingTag(label) {
    const input = findChatInput();
    if (!input) return;
    // @ 추가 토글: 켜져 있으면 정확히 하나의 @만 붙인다 (라벨에 이미 @가 있으면 중복 방지)
    const tag = state.atPrefix ? '@' + String(label).replace(/^@+/, '') : String(label);
    const stripped = input.value.replace(/\s*@[^@\s]*$/, '');
    setNativeValue(input, stripped + tag);
    input.focus();
  }

  // ---------------- 캐릭터 편집창 감지 (스탠딩 자동 저장용) ----------------
  function detectDialog() {
    const dialogs = document.querySelectorAll('.MuiDialog-root, [role="dialog"]');
    for (const dialog of dialogs) {
      const nameInput = dialog.querySelector('input[name="name"]');
      if (!nameInput) continue;
      const name = (nameInput.value || '').trim();
      if (!name) continue;

      const standings = [];
      const labelInputs = dialog.querySelectorAll('input[name^="faces."][name$=".label"]');
      for (const li of labelInputs) {
        const label = (li.value || '').trim();
        if (!label) continue;
        const idx = (li.getAttribute('name').match(/faces\.(\d+)\.label/) || [])[1];
        let img = '';
        if (idx !== undefined) {
          const imgInput = dialog.querySelector(`input[name="faces.${idx}.image"]`);
          if (imgInput && imgInput.value) img = imgInput.value;
        }
        if (!img) {
          let p = li.parentElement;
          while (p && p !== dialog) {
            const el2 = p.querySelector('img');
            if (el2 && el2.src) {
              img = el2.src;
              break;
            }
            p = p.parentElement;
          }
        }
        standings.push({ label, img });
      }

      // 스탠딩만이 아니라 시트 내용도 함께 담아둔다 (능력치·파라미터·채팅 팔레트·메모)
      const sheet = readSheet(dialog);
      return { name, standings, sheet };
    }
    return null;
  }

  // 캐릭터 편집창에서 시트 값을 읽어온다.
  // 코코포리아 폼은 status.0.label / status.0.value / status.0.max, params.0.label / params.0.value 꼴이다.
  function readSheet(dialog) {
    const rows = (prefix, keys) => {
      const out = [];
      const seen = new Set();
      const pre = prefix + '.';
      for (const inp of dialog.querySelectorAll(`input[name^="${pre}"]`)) {
        // "status.0.label" 에서 0을 뽑는다
        const idx = (inp.getAttribute('name').slice(pre.length).match(/^(\d+)\./) || [])[1];
        if (idx === undefined || seen.has(idx)) continue;
        seen.add(idx);
        const get = (k) => {
          const e = dialog.querySelector(`input[name="${prefix}.${idx}.${k}"]`);
          return e ? (e.value || '').trim() : '';
        };
        const rec = {};
        for (const k of keys) rec[k] = get(k);
        if (rec.label) out.push(rec);
      }
      return out;
    };

    const text = (sel) => {
      const e = dialog.querySelector(sel);
      return e ? e.value || '' : '';
    };

    return {
      status: rows('status', ['label', 'value', 'max']),
      params: rows('params', ['label', 'value']),
      commands: text('textarea[name="commands"]'),
      memo: text('textarea[name="memo"]'),
      initiative: text('input[name="initiative"]'),
      externalUrl: text('input[name="externalUrl"]'),
    };
  }

  // 시트에 담을 내용이 하나라도 있는지
  function sheetHasContent(sh) {
    if (!sh) return false;
    return !!(
      (sh.status && sh.status.length) ||
      (sh.params && sh.params.length) ||
      (sh.commands || '').trim() ||
      (sh.memo || '').trim()
    );
  }

  let detectTimer = 0;
  let syncThumbSliders = () => {};
  function scheduleDetect() {
    clearTimeout(detectTimer);
    detectTimer = setTimeout(async () => {
      const d = detectDialog();
      if (!d) {
        state.detected = null;
        return;
      }
      const changed =
        !state.detected ||
        state.detected.name !== d.name ||
        JSON.stringify(state.detected.standings) !== JSON.stringify(d.standings);
      state.detected = d;

      if (d.standings.length || sheetHasContent(d.sheet)) {
        await patchRoom((room) => {
          room.standings = room.standings || {};
          room.standingOrder = room.standingOrder || {};
          if (sheetHasContent(d.sheet)) {
            room.sheets = room.sheets || {};
            // 편집창이 아직 다 그려지지 않아 빈 칸으로 읽힐 수 있다.
            // 새로 읽은 값이 비어 있으면 전에 담아둔 것을 지우지 않는다.
            const prev = room.sheets[d.name] || {};
            const keep = (a, b) => (a && (Array.isArray(a) ? a.length : String(a).trim()) ? a : b);
            room.sheets[d.name] = {
              status: keep(d.sheet.status, prev.status) || [],
              params: keep(d.sheet.params, prev.params) || [],
              commands: keep(d.sheet.commands, prev.commands) || '',
              memo: keep(d.sheet.memo, prev.memo) || '',
              initiative: keep(d.sheet.initiative, prev.initiative) || '',
              externalUrl: keep(d.sheet.externalUrl, prev.externalUrl) || '',
              at: Date.now(),
            };
          }
          if (!d.standings.length) return; // 스탠딩이 없으면 시트만 갱신하고 끝
          room.standings[d.name] = d.standings;
          const known = d.standings.map((s) => s.label);
          const order = (room.standingOrder[d.name] || []).filter((l) => known.includes(l));
          for (const l of known) if (!order.includes(l)) order.push(l);
          room.standingOrder[d.name] = order;
        });
        if (!state.currentChar) state.currentChar = d.name;
      }
      if (changed && state.activeTab === 'standing') renderBody();
    }, 400);
  }

  const domObserver = new MutationObserver(scheduleDetect);
  domObserver.observe(document.body, { childList: true, subtree: true });
  document.addEventListener('input', (e) => {
    if (e.target && e.target.closest && e.target.closest('.MuiDialog-root, [role="dialog"]'))
      scheduleDetect();
  });

  // ---------------- 디자인 (기본 / 디자인 2 = 왼쪽 세로 레일) ----------------
  // 확장 팝업 설정에서 고른 값을 그대로 따라간다.
  let uiDesign = 'basic';

  function applyDesign() {
    if (panel) panel.classList.toggle('cst-rail', uiDesign === 'rail');
  }

  getSync({ uiDesign: 'basic' }).then((d) => {
    uiDesign = d.uiDesign === 'rail' ? 'rail' : 'basic';
    applyDesign();
  });

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'sync' || !changes.uiDesign) return;
      uiDesign = changes.uiDesign.newValue === 'rail' ? 'rail' : 'basic';
      applyDesign();
    });
  } catch (_) {}

  // ---------------- 패널 UI ----------------
  let panel = null;
  let fab = null;
  let body = null;
  let sizeSaveTimer = 0;

  // 코코포리아 채팅 헤더의 톱니(설정) 버튼을 찾아 그 왼쪽에 토글 버튼을 넣는다.
  // MUI SettingsIcon의 path("M19.14…")로 톱니 아이콘을 정확히 식별하고,
  // 여러 개(하단 HO 탭 등)면 화면에서 가장 위에 있는 것(채팅 헤더)을 고른다.
  function findCcfoliaSettingsButton() {
    let best = null;
    let bestTop = Infinity;
    for (const path of document.querySelectorAll('button svg path, [role="button"] svg path')) {
      const d = path.getAttribute('d') || '';
      if (!/^M19[.,]14/.test(d)) continue;
      const btn = path.closest('button, [role="button"]');
      if (!btn) continue;
      const r = btn.getBoundingClientRect();
      if (!r.width || !r.height) continue;
      if (r.top < bestTop) {
        bestTop = r.top;
        best = btn;
      }
    }
    if (best) return best;
    // 백업: aria-label/title 텍스트
    const LABELS = /設定|설정|settings/i;
    for (const b of document.querySelectorAll('button[aria-label], [role="button"][aria-label]')) {
      if (LABELS.test(b.getAttribute('aria-label') || '')) return b;
    }
    for (const b of document.querySelectorAll('button[title]')) {
      if (LABELS.test(b.getAttribute('title') || '')) return b;
    }
    return null;
  }

  let fabPlaced = false;

  function placeFab() {
    if (!fab) return;
    const target = findCcfoliaSettingsButton();
    if (target && target.parentElement) {
      fab.classList.add('cst-fab-inline');
      fab.classList.remove('cst-fab-float');
      target.parentElement.insertBefore(fab, target);
      fabPlaced = true;
      fab.classList.remove('cst-fab-hidden');
    } else {
      fab.classList.add('cst-fab-float');
      fab.classList.remove('cst-fab-inline');
      document.body.appendChild(fab);
      // 코코포리아 UI가 아직 안 그려졌을 수 있다 — 잠깐 숨겨 두고 기다린다.
      // (예전에는 좌하단에 잠깐 떴다가 제자리로 튀어 거슬렸다)
      if (!fabPlaced) fab.classList.add('cst-fab-hidden');
    }
  }

  // 방 화면이 준비될 때까지 짧게 재시도하다가, 끝내 못 찾으면 폴백 위치로 보여준다
  function settleFab() {
    const t0 = Date.now();
    const tick = () => {
      if (!fab || fabPlaced) return;
      placeFab();
      if (fabPlaced) return;
      if (Date.now() - t0 > 4000) {
        fab.classList.remove('cst-fab-hidden'); // 폴백 위치로 확정
        return;
      }
      setTimeout(tick, 200);
    };
    tick();
  }

  // 코코포리아가 툴바를 다시 그려 버튼이 사라지면 재삽입
  let fabGuardTimer = 0;
  function startFabGuard() {
    clearInterval(fabGuardTimer);
    fabGuardTimer = setInterval(() => {
      if (fab && !document.contains(fab)) placeFab();
      else if (fab && fab.classList.contains('cst-fab-float')) {
        // 플로팅 폴백 상태면 설정 버튼이 나타났는지 주기적으로 재시도
        const t = findCcfoliaSettingsButton();
        if (t) placeFab();
      }
    }, 2000);
  }

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }

  function titleWithIcon(text) {
    const wrap = el('span', 'cst-title');
    const icon = document.createElement('img');
    icon.src = extUrl('icons/icon16.png');
    icon.className = 'cst-title-icon';
    icon.alt = '';
    wrap.append(icon, document.createTextNode(text));
    return wrap;
  }

  function buildUI() {
    if (panel) return;

    fab = el('button', 'cst-root');
    fab.id = 'cst-fab';
    const fabIcon = document.createElement('img');
    fabIcon.src = extUrl('icons/icon32.png');
    fabIcon.alt = '코코포리아 선생님';
    fab.appendChild(fabIcon);
    fab.title = '코코포리아 선생님 패널 열기/닫기';
    fab.classList.add('cst-fab-hidden');
    placeFab();
    settleFab();

    panel = el('div', 'cst-root');
    panel.id = 'cst-panel';
    panel.style.display = 'none';

    const head = el('div', 'cst-head');
    const title = titleWithIcon('코코포리아 선생님');
    const minBtn = el('button', 'cst-iconbtn', '－');
    minBtn.title = '최소화';
    const closeBtn = el('button', 'cst-iconbtn', '✕');
    closeBtn.title = '닫기';
    head.append(title, minBtn, closeBtn);

    const tabs = el('div', 'cst-tabs');
    const TABS = [
      ['standing', '캐릭터'],
      ['color', '색상'],
      ['memo', '메모'],
      ['chars', '문자'],
      ['size', '사이즈'],
      ['capture', '캡처'],
      ['log', '로그'],
    ].filter(([key]) => !(LITE && key === 'capture'));
    for (const [key, label] of TABS) {
      const b = el('button', 'cst-tab', label);
      b.dataset.tab = key;
      b.addEventListener('click', () => {
        state.activeTab = key;
        for (const t of tabs.children) t.classList.toggle('on', t.dataset.tab === key);
        renderBody();
      });
      tabs.appendChild(b);
    }
    tabs.children[0].classList.add('on');

    body = el('div', 'cst-body');

    // 기본은 탭이 위, '디자인 2'에서는 왼쪽 세로 레일이 되는 껍데기
    const shell = el('div', 'cst-shell');
    shell.append(tabs, body);
    panel.append(head, shell);
    document.body.appendChild(panel);
    applyDesign();

    // 위치·크기 복원
    getLocal({ panelPos: null, panelSize: null }).then(({ panelPos, panelSize }) => {
      if (panelPos && panelPos.left != null) {
        panel.style.left = panelPos.left + 'px';
        panel.style.top = panelPos.top + 'px';
        clampIntoView();
      } else {
        panel.style.right = '14px';
        panel.style.bottom = '124px';
      }
      if (panelSize && panelSize.w) {
        panel.style.width = panelSize.w + 'px';
        panel.style.height = panelSize.h + 'px';
      }
    });

    // 크기 조절(우하단 그립): 크기 저장 + 썸네일 확대 상태 재계산 (칸이 커져도 잘라둔 위치 유지)
    const ro = new ResizeObserver(() => {
      if (panel.style.display === 'none') return;
      refreshThumbStyles();
      clearTimeout(sizeSaveTimer);
      sizeSaveTimer = setTimeout(() => {
        const r = panel.getBoundingClientRect();
        if (r.width > 100 && r.height > 100) setLocal({ panelSize: { w: Math.round(r.width), h: Math.round(r.height) } });
      }, 400);
    });
    ro.observe(panel);

    let drag = null;
    head.addEventListener('pointerdown', (e) => {
      if (e.target.closest('.cst-iconbtn')) return;
      const r = panel.getBoundingClientRect();
      drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
      head.setPointerCapture(e.pointerId);
    });
    head.addEventListener('pointermove', (e) => {
      if (!drag) return;
      panel.style.right = 'auto';
      panel.style.bottom = 'auto';
      panel.style.left = Math.max(0, e.clientX - drag.dx) + 'px';
      panel.style.top = Math.max(0, e.clientY - drag.dy) + 'px';
    });
    head.addEventListener('pointerup', () => {
      if (!drag) return;
      drag = null;
      clampIntoView();
      const r = panel.getBoundingClientRect();
      setLocal({ panelPos: { left: r.left, top: r.top } });
    });

    minBtn.addEventListener('click', () => {
      panel.classList.toggle('cst-min');
      // 접었다 펴도 크기 저장이 꼬이지 않게 현재 가로폭을 유지한다
      if (panel.classList.contains('cst-min')) {
        const r = panel.getBoundingClientRect();
        panel.dataset.openH = String(Math.round(r.height));
      }
    });
    closeBtn.addEventListener('click', () => (panel.style.display = 'none'));
    fab.addEventListener('click', () => {
      const show = panel.style.display === 'none';
      panel.style.display = show ? 'flex' : 'none';
      if (show) {
        clampIntoView();
        renderBody();
      }
    });

    startFabGuard();
    applyTheme();
  }

  function clampIntoView() {
    if (!panel) return;
    const r = panel.getBoundingClientRect();
    let left = r.left;
    let top = r.top;
    if (left + 60 > innerWidth) left = innerWidth - 80;
    if (top + 40 > innerHeight) top = innerHeight - 60;
    if (left < 0) left = 8;
    if (top < 0) top = 8;
    if (panel.style.left !== 'auto' && panel.style.left !== '') {
      panel.style.left = left + 'px';
      panel.style.top = top + 'px';
    }
  }

  function applyTheme() {
    for (const root of [panel, fab, toastEl]) {
      if (!root) continue;
      for (const t of THEMES) root.classList.remove('cst-theme-' + t);
      if (state.theme !== 'dark') root.classList.add('cst-theme-' + state.theme);
      const accent = normalizeHex(state.accent);
      if (accent) {
        root.style.setProperty('--cst-accent', accent);
        root.style.setProperty('--cst-accent-dark', darken(accent));
        root.style.setProperty('--cst-accent-soft', hexToSoft(accent));
      } else {
        root.style.removeProperty('--cst-accent');
        root.style.removeProperty('--cst-accent-dark');
        root.style.removeProperty('--cst-accent-soft');
      }
    }
  }

  // ---------------- 탭 렌더링 ----------------
  function renderBody() {
    if (!body || panel.style.display === 'none') return;
    body.innerHTML = '';
    if (state.activeTab === 'standing') renderStanding();
    else if (state.activeTab === 'color') renderColor();
    else if (state.activeTab === 'memo') renderMemo();
    else if (state.activeTab === 'chars') renderChars();
    else if (state.activeTab === 'size') renderSize();
    else if (state.activeTab === 'capture') renderCapture();
    else renderLog();
  }

  // ----- 로그 백업 (kkul-log 자동화) -----
  let logBusy = false;
  let lastMessages = null;

  let abStatHandler = null;

  async function renderLog() {
    body.innerHTML = '';
    if (!window.CSTLog) {
      body.appendChild(el('div', 'cst-hint', '로그 모듈을 불러오지 못했습니다. 페이지를 새로고침해 주세요.'));
      return;
    }
    // 로그 설정은 local이 정본 (sync는 다른 기기용 미러)
    const lc = await getLocal({ logSettings: null });
    const logSettings = lc.logSettings || (await getSync({ logSettings: null })).logSettings;
    const s = window.CSTLogBuild
      ? window.CSTLogBuild.normalizeSettings(logSettings)
      : { ...window.CSTLog.DEFAULT_SETTINGS, ...(logSettings || {}) };

    body.appendChild(
      el('div', 'cst-hint', '채팅 로그를 자동 스크롤로 수집해서 HTML로 저장합니다.\n버튼을 누르고 끝날 때까지 기다려 주세요 (창을 건드리지 마세요!).')
    );

    // ---- 원클릭 버튼 ----
    const goBtn = el('button', 'cst-btn cst-log-go', logBusy ? '수집 중…' : '원클릭 로그 백업');
    goBtn.disabled = logBusy;
    const stopBtn = el('button', 'cst-btn ghost', '수집 중지');
    stopBtn.style.width = '100%';
    stopBtn.classList.add('cst-hide');
    stopBtn.addEventListener('click', () => {
      window.dispatchEvent(new CustomEvent('cst-log-abort'));
      stopBtn.textContent = '중지하는 중…';
      stopBtn.disabled = true;
    });
    const progress = el('div', 'cst-log-progress', '');
    goBtn.addEventListener('click', async () => {
      if (logBusy) return;
      logBusy = true;
      goBtn.disabled = true;
      goBtn.textContent = '수집 중…';
      stopBtn.classList.remove('cst-hide');
      stopBtn.disabled = false;
      stopBtn.textContent = '수집 중지';
      try {
        const r = await window.CSTLog.collect({ allTabs: s.allTabs }, (p) => {
          const tabLabel = p.tab ? `[${p.tab}] ` : '';
          const line =
            p.phase === 'tab'
              ? `${tabLabel}탭 이동 중… (수집됨 ${p.count}개)`
              : p.phase === 'up'
                ? `${tabLabel}과거 로그 로딩 중 — 불러온 메시지 ${p.count}개`
                : p.phase === 'down'
                  ? `${tabLabel}수집 중 — ${p.count}개`
                  : p.phase === 'noscroll'
                    ? `스크롤 영역 없음 — 보이는 부분만 수집 (${p.count}개)`
                    : p.phase === 'onetab'
                      ? '채팅 탭을 못 찾아 현재 탭만 수집'
                      : p.phase === 'tabfail'
                        ? `${tabLabel}탭 전환 실패!`
                        : `완료 — ${p.count}개`;
          progress.textContent = line;
        });
        lastMessages = r.messages;
        const room = await getRoom();
        // 수집본 저장 → 로그 스튜디오에서 미리보기·상세 설정 가능
        try {
          await window.CSTLog.saveCollection(roomId, room.name || '코코포리아', r.messages, r.tabNames);
        } catch (_) {}
        // 방별 누적 통계 기록 (세션 관리자에서 표시)
        try {
          const exacts = r.messages.map((m) => m.exact).filter((v) => typeof v === 'number' && v > 1e12);
          // 첫 대사~마지막 대사를 통째로 재면 쉬는 시간까지 들어간다.
          // 대화가 1시간 넘게 끊긴 곳을 경계로 잘라 실제 구간만 더한다.
          let durationMs = 0;
          if (exacts.length >= 2) {
            const sorted = [...exacts].sort((x, y) => x - y);
            const GAP = 60 * 60 * 1000;
            let start = sorted[0];
            let prev = sorted[0];
            for (const t of sorted.slice(1)) {
              if (t - prev > GAP) {
                durationMs += prev - start;
                start = t;
              }
              prev = t;
            }
            durationMs += prev - start;
          }
          await patchRoom((rm) => {
            rm.sessions = rm.sessions || [];
            rm.sessions.push({ at: Date.now(), count: r.messages.length, durationMs, tabs: r.tabNames.length, netTime: true });
            if (rm.sessions.length > 100) rm.sessions = rm.sessions.slice(-100);
          });
        } catch (_) {}
        if (s.previewBeforeSave) {
          // 저장 전 미리보기: 파일을 바로 만들지 않고 스튜디오에서 확인 후 저장
          progress.textContent = `수집 완료 — ${r.messages.length}개. 로그 스튜디오에서 확인 후 저장하세요.`;
          sendMsg({ type: 'OPEN_STUDIO' });
          toast('수집 완료! 로그 스튜디오에서 미리보고 저장하세요.');
          logBusy = false;
          goBtn.disabled = false;
          goBtn.textContent = '원클릭 로그 백업';
          return;
        }
        const result = await window.CSTLog.exportHtml(r.messages, s, room.name || '코코포리아');
        const tabInfo = r.tabSwitchFailed
          ? ' 주의: 탭 전환 실패 — 현재 탭만 수집됨'
          : r.tabNames.length > 1
            ? ` (탭 ${r.tabNames.length}개: ${r.tabNames.join('/')})`
            : '';
        progress.textContent = `완료! 메시지 ${result.count}개 → 파일 ${result.files}개 저장됨${tabInfo}`;
        progress.title = (result.names || []).join('\n');
        toast(
          r.tabSwitchFailed
            ? '탭 전환에 실패해서 현재 탭만 백업했어요. 다른 탭은 탭을 직접 켠 뒤 "탭 전부 수집"을 끄고 다시 실행해 주세요.'
            : `로그 백업 완료 — ${result.count}개 메시지 저장`
        );
      } catch (err) {
        const m = friendlyError(err);
        progress.textContent = m;
        toast(m);
      }
      logBusy = false;
      goBtn.disabled = false;
      goBtn.textContent = '원클릭 로그 백업';
      stopBtn.classList.add('cst-hide');
    });
    body.append(goBtn, stopBtn, progress);

    // 로그 스튜디오 (미리보기 + 상세 설정)
    const studioRow = el('div', 'cst-row');
    const studioBtn = el('button', 'cst-btn ghost', '로그 스튜디오 열기 (미리보기·상세 설정)');
    studioBtn.style.flex = '1';
    studioBtn.addEventListener('click', () => {
      sendMsg({ type: 'OPEN_STUDIO' });
    });
    studioRow.appendChild(studioBtn);
    body.appendChild(studioRow);

    // ---- 수집 옵션 (수집할 때만 쓰는 것 2개는 여기서 바로 토글) ----
    const optWrap = el('div', 'cst-sliders');
    optWrap.appendChild(el('div', 'cst-slider-row', '수집 옵션'));

    function mkQuickToggle(labelText, key) {
      const r = el('div', 'cst-size-row');
      const sw = mkSwitch(!!s[key], (on) => {
        s[key] = on;
        setLocal({ logSettings: s });
        try {
          setSync({ logSettings: s });
        } catch (_) {}
      });
      const lab = el('label', '', labelText);
      lab.htmlFor = sw.input.id;
      lab.style.cursor = 'pointer';
      r.append(lab, sw.wrap);
      return r;
    }

    optWrap.append(
      mkQuickToggle('채팅 탭 전부 수집 (전환 검증하며 순회)', 'allTabs'),
      mkQuickToggle('저장 전 미리보기 (수집 후 로그 스튜디오에서 확인하고 저장)', 'previewBeforeSave')
    );
    body.appendChild(optWrap);

    // ---- 자동 백업 (배포본에는 없음: LITE) ----
    if (!LITE) {
      // ---- 자동 백업 ----
      // 전체 수집과 달리 화면을 건드리지 않는다. 보이는 대사만 조용히 주워 담아
      // 브라우저가 죽어도 그날 로그가 남게 하는 안전망이다.
      const autoWrap = el('div', 'cst-sliders');
      autoWrap.appendChild(el('div', 'cst-slider-row', '자동 백업 (안전망)'));
      autoWrap.appendChild(
        el('div', 'cst-hint', '화면에 보이는 대사만 조용히 주워 담습니다. 스크롤을 건드리지 않으니\n플레이 중에 켜 두어도 방해되지 않아요. 읽으며 진행하면 자연히 다 모입니다.')
      );

      const abCfg = (await getLocal({ autoBackup: { on: false, minutes: 5 } })).autoBackup || { on: false, minutes: 5 };

      const abToggleRow = el('div', 'cst-size-row');
      const abSw = mkSwitch(!!abCfg.on);
      const abCb = abSw.input;
      const abLab = el('label', '', '자동 백업 켜기');
      abLab.htmlFor = abCb.id;
      abLab.style.cursor = 'pointer';
      abToggleRow.append(abLab, abSw.wrap);

      const abEveryRow = el('label', 'cst-size-row');
      const abEveryLab = el('label', '', '간격');
      const abSel = document.createElement('select');
      abSel.className = 'cst-select';
      for (const v of [1, 3, 5, 10, 15, 30]) {
        const o = document.createElement('option');
        o.value = String(v);
        o.textContent = v + '분마다';
        abSel.appendChild(o);
      }
      abSel.value = String(abCfg.minutes || 5);
      abEveryRow.append(abEveryLab, abSel);

      const abStat = el('div', 'cst-log-progress', '');

      async function refreshAbStat() {
        const { autoBackupData } = await getLocal({ autoBackupData: {} });
        const rec = (autoBackupData || {})[roomId];
        if (!rec || !rec.messages || !rec.messages.length) {
          abStat.textContent = '모아둔 대사 없음';
          abOpenBtn.disabled = true;
          abClearBtn.disabled = true;
          return;
        }
        const d = new Date(rec.at || 0);
        const pad = (n) => String(n).padStart(2, '0');
        abStat.textContent = `모아둔 대사 ${rec.messages.length.toLocaleString()}개 · 마지막 ${pad(d.getHours())}:${pad(d.getMinutes())}`;
        abOpenBtn.disabled = false;
        abClearBtn.disabled = false;
      }

      const abBtnRow = el('div', 'cst-row');
      const abOpenBtn = el('button', 'cst-btn ghost', '스튜디오에서 열기');
      abOpenBtn.style.flex = '1';
      abOpenBtn.addEventListener('click', async () => {
        const { autoBackupData } = await getLocal({ autoBackupData: {} });
        const rec = (autoBackupData || {})[roomId];
        if (!rec || !rec.messages || !rec.messages.length) return toast('모아둔 대사가 없습니다.');
        const room = await getRoom();
        const tabNames = [...new Set(rec.messages.map((m) => m.tab).filter(Boolean))];
        await window.CSTLog.saveCollection(roomId, room.name || '코코포리아', rec.messages, tabNames);
        sendMsg({ type: 'OPEN_STUDIO' });
        toast(`자동 백업본 ${rec.messages.length}개를 스튜디오로 보냈습니다.`);
      });
      const abClearBtn = el('button', 'cst-btn ghost', '모아둔 것 비우기');
      abClearBtn.style.flex = '1';
      abClearBtn.addEventListener('click', async () => {
        const { autoBackupData } = await getLocal({ autoBackupData: {} });
        const all = autoBackupData || {};
        delete all[roomId];
        await setLocal({ autoBackupData: all });
        refreshAbStat();
        toast('자동 백업본을 비웠습니다.');
      });
      abBtnRow.append(abOpenBtn, abClearBtn);

      const saveAb = () => setLocal({ autoBackup: { on: abCb.checked, minutes: Number(abSel.value) || 5 } });
      abCb.addEventListener('change', saveAb);
      abSel.addEventListener('change', saveAb);

      autoWrap.append(abToggleRow, abEveryRow, abStat, abBtnRow);
      body.appendChild(autoWrap);
      refreshAbStat();
      // 백업이 돌 때마다 숫자를 갱신 (탭을 다시 그릴 때 옛 핸들러는 떼어낸다)
      if (abStatHandler) window.removeEventListener('cst-autobackup', abStatHandler);
      abStatHandler = refreshAbStat;
      window.addEventListener('cst-autobackup', abStatHandler);

    }

    // ---- 설정 요약 (스타일 설정은 로그 스튜디오가 원본 — 여기서는 읽기 전용) ----
    const FONT_LABEL = {
      noto: 'Noto Sans KR', myeongjo: '나눔명조', gothic: '나눔고딕',
      pretendard: 'Pretendard', dot42: '42dot Sans', kopub: 'KoPub돋움',
    };
    const THEME_LABEL = { dark: '다크', gray: '그레이', white: '화이트', custom: '직접 지정' };
    const SHAPE_LABEL = { square: '네모', rounded: '둥근 네모', circle: '원형' };
    const MODE_LABEL = { merged: '합본', perTab: '탭별', both: '합본+탭별' };

    const sumWrap = el('div', 'cst-sliders');
    sumWrap.appendChild(el('div', 'cst-slider-row', '현재 저장 설정 (로그 스튜디오에서 변경)'));
    const rf = s.rowFilters || {};
    const RF_LABEL = { hide: '비표시', del: '삭제' };
    const filters = [];
    if (RF_LABEL[rf.empty]) filters.push('빈 대사 ' + RF_LABEL[rf.empty]);
    if (RF_LABEL[rf.dice]) filters.push('주사위 ' + RF_LABEL[rf.dice]);
    if (RF_LABEL[rf.cmd]) filters.push('명령어 ' + RF_LABEL[rf.cmd]);
    if (RF_LABEL[rf.edited]) filters.push('[편집 완료] ' + RF_LABEL[rf.edited]);
    if (s.groupSame) filters.push('연속 대사 묶기');
    const tabStyleCount = Object.values(s.tabStyles || {}).filter((t) => t.mode && t.mode !== 'normal').length;
    const lines = [
      `${FONT_LABEL[s.font] || s.font} ${s.fontSize}px · 행간 ${s.lineHeight} · 이미지 ${s.imgSize}px ${SHAPE_LABEL[s.imgShape] || ''}`,
      `테마 ${THEME_LABEL[s.theme] || s.theme}${s.theme === 'custom' ? ' (' + (s.customBg || '') + ')' : ''} · 저장 ${MODE_LABEL[s.saveMode] || s.saveMode}${s.split > 0 ? ' · ' + s.split + '개씩 분할' : ''}`,
      `필터: ${filters.length ? filters.join(', ') : '없음'}`,
      `탭 스타일 지정 ${tabStyleCount}개 · 변환기용 파일 ${s.ccfoliaCompat ? 'O' : 'X'}`,
    ];
    const sumBox = el('div', 'cst-log-summary');
    for (const line of lines) sumBox.appendChild(el('div', 'cst-log-summary-line', line));
    sumWrap.appendChild(sumBox);
    body.appendChild(sumWrap);


    // ---- kkul-log 연동 (세부 편집용) ----
    const kkul = el('div', 'cst-sliders');
    kkul.appendChild(el('div', 'cst-slider-row', 'kkul-log 사이트에서 세부 편집'));
    kkul.appendChild(
      el(
        'div',
        'cst-hint',
        '더 세세한 편집(티스토리·PDF 등)은 kkul-log 사이트에서.\n① 백업할 때 저장된 "…_변환기용.html" 파일을 사이트 왼쪽에 업로드\n② 아래 JSON을 복사해 "불러오기" 칸에 붙여넣기 (표정 매칭·이미지)'
      )
    );

    // 한 번에: 메시지 + 이 방의 모든 캐릭터 이미지를 하나로 이어 복사
    const rowAll = el('div', 'cst-row');
    const copyAllBtn = el('button', 'cst-btn', '한 번에 복사 (로그 + 캐릭터 전부)');
    copyAllBtn.style.flex = '1';
    copyAllBtn.title = '메시지 JSON과 이 방의 캐릭터 이미지 JSON을 한 덩어리로 복사합니다';
    copyAllBtn.addEventListener('click', async () => {
      if (!lastMessages || !lastMessages.length) {
        toast('먼저 "원클릭 로그 백업"으로 수집해 주세요.');
        return;
      }
      const rm = await getRoom();
      const names = Object.keys(rm.standings || {});
      const parts = [window.CSTLog.kkulMessagesJson(lastMessages)];
      for (const n of names) parts.push(window.CSTLog.kkulCharacterJson(n, rm.standings[n]));
      try {
        await navigator.clipboard.writeText(parts.join('\n'));
        toast(`메시지 ${lastMessages.length}개 + 캐릭터 ${names.length}명 복사됨`);
      } catch (_) {
        toast('복사 실패 — 창을 한 번 클릭한 뒤 다시 눌러 주세요.');
      }
    });
    rowAll.appendChild(copyAllBtn);
    kkul.appendChild(rowAll);

    const row1 = el('div', 'cst-row');
    const copyMsgBtn = el('button', 'cst-btn ghost', '수집한 로그 JSON 복사');
    copyMsgBtn.title = '원클릭 백업을 먼저 실행해야 합니다';
    copyMsgBtn.addEventListener('click', () => {
      if (!lastMessages || !lastMessages.length) {
        toast('먼저 "원클릭 로그 백업"으로 수집해 주세요.');
        return;
      }
      navigator.clipboard
        .writeText(window.CSTLog.kkulMessagesJson(lastMessages))
        .then(() => toast(`메시지 ${lastMessages.length}개 JSON 복사됨 — kkul-log에 붙여넣으세요.`))
        .catch(() => toast('복사 실패'));
    });
    row1.appendChild(copyMsgBtn);
    kkul.appendChild(row1);

    const room = await getRoom();
    const charNames = Object.keys(room.standings || {});
    if (charNames.length) {
      const row2 = el('div', 'cst-row');
      const sel = el('select', 'cst-select');
      for (const c of charNames) {
        const o = el('option', '', c);
        o.value = c;
        sel.appendChild(o);
      }
      const copyCharBtn = el('button', 'cst-btn ghost', '캐릭터 이미지 JSON 복사');
      copyCharBtn.addEventListener('click', () => {
        const name = sel.value;
        navigator.clipboard
          .writeText(window.CSTLog.kkulCharacterJson(name, room.standings[name]))
          .then(() => toast(`"${name}" 이미지 URL JSON 복사됨`))
          .catch(() => toast('복사 실패'));
      });
      const copyAllCharBtn = el('button', 'cst-btn ghost', '전부');
      copyAllCharBtn.title = '이 방의 캐릭터 이미지 JSON을 모두 이어서 복사';
      copyAllCharBtn.addEventListener('click', () => {
        const all = charNames.map((n) => window.CSTLog.kkulCharacterJson(n, room.standings[n])).join('\n');
        navigator.clipboard
          .writeText(all)
          .then(() => toast(`캐릭터 ${charNames.length}명 이미지 JSON 복사됨`))
          .catch(() => toast('복사 실패'));
      });
      row2.append(sel, copyCharBtn, copyAllCharBtn);
      kkul.appendChild(row2);
    } else {
      kkul.appendChild(
        el('div', 'cst-hint', '캐릭터 편집창을 열어두면 스탠딩 이미지 URL도 자동 수집되어\n캐릭터별 JSON 복사 버튼이 생깁니다.')
      );
    }

    const row3 = el('div', 'cst-row');
    const siteBtn = el('button', 'cst-btn ghost', 'kkul-log 사이트 열기');
    siteBtn.addEventListener('click', () => window.open('https://kkul-log.netlify.app/'));
    row3.appendChild(siteBtn);
    kkul.appendChild(row3);

    body.appendChild(kkul);
  }

  // 탭 안이 여러 덩어리로 나뉘는 곳에서 쓰는 구역 머리.
  // 붙어 있으면 뭐가 뭔지 알기 어려워서 번호·제목·설명을 붙여 갈라 놓는다.
  function secBlock(no, title, desc) {
    const wrap = el('div', 'cst-sec');
    const head = el('div', 'cst-sec-head');
    head.append(el('span', 'cst-sec-no', no), el('span', 'cst-sec-title', title));
    wrap.appendChild(head);
    if (desc) wrap.appendChild(el('div', 'cst-sec-desc', desc));
    return wrap;
  }

  // ----- 캐릭터 (NPC 픽커 · 스탠딩 · 시트 백업) -----
  // 확대/이동: 원본 비율 기준으로 이미지를 통째로 배치 → 그림의 모든 부분을 훑을 수 있음
  //  base = cover 배율 (zoom 100% = 꽉 채움)
  //  disp = 원본비율 × base × zoom
  //  left/top = (박스 - disp) × pos%  → pos 0%=이미지 왼쪽/위 끝, 100%=오른쪽/아래 끝
  function applyThumbStyle(img) {
    const box = img.parentElement;
    if (!box) return;
    const doLayout = () => {
      const bw = box.clientWidth;
      const bh = box.clientHeight;
      const nw = img.naturalWidth;
      const nh = img.naturalHeight;
      if (!bw || !bh || !nw || !nh) return;
      const t = state.thumb;
      const zoom = Math.max(100, Number(t.zoom) || 100) / 100;
      const posX = Math.min(100, Math.max(0, Number(t.posX) || 0)) / 100;
      const posY = Math.min(100, Math.max(0, Number(t.posY) || 0)) / 100;
      const base = Math.max(bw / nw, bh / nh);
      const dw = nw * base * zoom;
      const dh = nh * base * zoom;
      img.style.width = dw + 'px';
      img.style.height = dh + 'px';
      img.style.left = (bw - dw) * posX + 'px';
      img.style.top = (bh - dh) * posY + 'px';
    };
    if (img.complete && img.naturalWidth) {
      // 박스가 아직 레이아웃 전이면 다음 프레임에
      if (!box.clientWidth) requestAnimationFrame(doLayout);
      else doLayout();
    } else {
      img.addEventListener('load', doLayout, { once: true });
    }
  }

  function refreshThumbStyles() {
    if (!body) return;
    for (const img of body.querySelectorAll('.cst-thumb img')) applyThumbStyle(img);
  }

  async function renderStanding() {
    const room = await getRoom();
    const chars = Object.keys(room.standings || {});
    body.innerHTML = '';

    if (!chars.length) {
      body.appendChild(
        el('div', 'cst-hint', '저장된 스탠딩이 없습니다.\n캐릭터 편집창을 열면 스탠딩이 자동으로 저장됩니다.')
      );
      return;
    }

    if (!state.currentChar || !chars.includes(state.currentChar)) state.currentChar = chars[0];

    // NPC 픽커: 칩 클릭 한 번으로 발화 캐릭터 전환 (GM용)
    // 내 권한 캐릭터(myChars)가 파악돼 있으면 그것만 표시 — 백업용으로 편집창만 연 캐릭터는 제외
    const myChars = Array.isArray(room.myChars) ? room.myChars : null;
    const pickWrap = el('div', 'cst-npc-picker');
    const pickHead = el('div', 'cst-slider-row', '');
    const refreshBtn = el('button', 'cst-btn ghost cst-mini-btn', '내 캐릭터 새로고침');
    refreshBtn.title = '캐릭터 선택 메뉴를 잠깐 열어 내 권한 캐릭터 목록을 갱신합니다';
    refreshBtn.addEventListener('click', async () => {
      refreshBtn.disabled = true;
      refreshBtn.textContent = '확인 중…';
      const names = await scanMyChars();
      toast(names.length ? `내 캐릭터 ${names.length}명 확인` : '캐릭터 메뉴를 읽지 못했어요.');
      renderBody();
    });
    pickHead.appendChild(refreshBtn);
    pickWrap.appendChild(pickHead);
    const pickNames = myChars && myChars.length ? myChars : chars;
    if (myChars === null) {
      pickWrap.appendChild(
        el('div', 'cst-hint', '[내 캐릭터 새로고침]을 누르면 발화 권한 있는 캐릭터만 남습니다.')
      );
    }
    const chipRow = el('div', 'cst-npc-chips');
    for (const c of pickNames) {
      const chip = el('button', 'cst-npc-chip', c);
      chip.title = `"${c}"(으)로 발화 캐릭터 전환`;
      chip.addEventListener('click', () => switchCharacter(c));
      chipRow.appendChild(chip);
    }
    if (!pickNames.length) chipRow.appendChild(el('div', 'cst-hint', '내 권한 캐릭터가 없습니다.'));
    pickWrap.appendChild(chipRow);
    const sec1 = secBlock('1', '발화 캐릭터 고르기', '');
    sec1.appendChild(pickWrap);
    body.appendChild(sec1);

    const row = el('div', 'cst-row');
    const sel = el('select', 'cst-select');
    for (const c of chars) {
      const isMine = !myChars || myChars.some((n) => n === c || n.includes(c) || c.includes(n));
      const o = el('option', '', isMine ? c : c + ' (백업)');
      o.value = c;
      if (c === state.currentChar) o.selected = true;
      sel.appendChild(o);
    }
    sel.addEventListener('change', () => {
      state.currentChar = sel.value;
      renderBody();
    });
    const delBtn = el('button', 'cst-btn ghost', '삭제');
    delBtn.title = '이 캐릭터의 저장된 스탠딩 삭제';
    delBtn.addEventListener('click', async () => {
      await patchRoom((r) => {
        delete r.standings[state.currentChar];
        delete r.standingOrder[state.currentChar];
      });
      state.currentChar = '';
      renderBody();
    });
    row.append(sel, delBtn);
    const sec2 = secBlock('2', '스탠딩 보기 · 크기 조절', '카드를 누르면 채팅창에 표정 이름이 들어갑니다 · 드래그로 순서 변경');
    sec2.appendChild(row);
    body.appendChild(sec2);

    const list = room.standings[state.currentChar] || [];
    const order = room.standingOrder?.[state.currentChar] || list.map((s) => s.label);
    const byLabel = new Map(list.map((s) => [s.label, s]));
    const ordered = order.map((l) => byLabel.get(l)).filter(Boolean);

    const grid = el('div', 'cst-standing-grid');
    grid.style.setProperty('--cst-cols', state.cols);
    ordered.forEach((s, i) => {
      const card = el('div', 'cst-standing');
      card.draggable = true;
      card.dataset.label = s.label;
      if (s.label === state.lastStanding) card.classList.add('cst-standing-last');

      const thumb = el('div', 'cst-thumb');
      if (s.img) {
        const img = document.createElement('img');
        img.src = s.img;
        applyThumbStyle(img);
        thumb.appendChild(img);
      } else {
        const noimg = el('span', 'cst-noimg');
        noimg.innerHTML = window.faIcon ? window.faIcon('image') : '?';
        thumb.appendChild(noimg);
      }
      const label = el('span', 'cst-standing-label', s.label);
      label.title = s.label;
      card.append(thumb, label);

      card.addEventListener('click', () => {
        if (state.adjustMode) return; // 조정 중에는 전송하지 않는다
        appendStandingTag(s.label);
        state.lastStanding = s.label;
        for (const c of grid.children) c.classList.remove('cst-standing-last');
        card.classList.add('cst-standing-last');
      });

      if (state.adjustMode) {
        card.classList.add('cst-standing-adjust');
        card.draggable = false;
        card.addEventListener(
          'wheel',
          (e) => {
            e.preventDefault();
            const next = Math.round(Math.min(400, Math.max(100, state.thumb.zoom - Math.sign(e.deltaY) * 8)));
            state.thumb.zoom = next;
            refreshThumbStyles();
            syncThumbSliders();
          },
          { passive: false }
        );
        let drag = null;
        card.addEventListener('pointerdown', (e) => {
          drag = { x: e.clientX, y: e.clientY, px: state.thumb.posX, py: state.thumb.posY };
          card.setPointerCapture(e.pointerId);
        });
        card.addEventListener('pointermove', (e) => {
          if (!drag) return;
          const box = card.querySelector('.cst-thumb');
          const w = (box && box.clientWidth) || 100;
          const h = (box && box.clientHeight) || 100;
          // 이미지를 잡아끄는 방향으로 움직이게 (드래그 반대편으로 잘린 곳이 보인다)
          state.thumb.posX = Math.round(Math.min(100, Math.max(0, drag.px - ((e.clientX - drag.x) / w) * 100)));
          state.thumb.posY = Math.round(Math.min(100, Math.max(0, drag.py - ((e.clientY - drag.y) / h) * 100)));
          refreshThumbStyles();
          syncThumbSliders();
        });
        const endDrag = () => (drag = null);
        card.addEventListener('pointerup', endDrag);
        card.addEventListener('pointercancel', endDrag);
      }

      card.addEventListener('dragstart', (e) => {
        if (state.adjustMode) {
          e.preventDefault();
          return;
        }
        e.dataTransfer.setData('text/plain', String(i));
        card.classList.add('cst-dragging');
      });
      card.addEventListener('dragend', () => card.classList.remove('cst-dragging'));
      card.addEventListener('dragover', (e) => {
        e.preventDefault();
        card.classList.add('cst-dragover');
      });
      card.addEventListener('dragleave', () => card.classList.remove('cst-dragover'));
      card.addEventListener('drop', async (e) => {
        e.preventDefault();
        card.classList.remove('cst-dragover');
        const fromIdx = Number(e.dataTransfer.getData('text/plain'));
        if (Number.isNaN(fromIdx) || fromIdx === i) return;
        const newOrder = ordered.map((x) => x.label);
        const [moved] = newOrder.splice(fromIdx, 1);
        newOrder.splice(i, 0, moved);
        await patchRoom((r) => {
          r.standingOrder[state.currentChar] = newOrder;
        });
        renderBody();
      });

      grid.appendChild(card);
    });
    sec2.appendChild(grid);

    // 격자가 레이아웃된 뒤 썸네일 크기 계산
    requestAnimationFrame(refreshThumbStyles);

    const sliders = el('div', 'cst-sliders');

    // 직접 조정 모드: 켜면 클릭 전송·순서 변경 대신 휠(확대)·드래그(위치)만 먹는다
    const adjRow = el('div', 'cst-slider-row');
    adjRow.append(el('label', '', '직접 조정'));
    const adjBtn = el('button', 'cst-btn ghost cst-mini-btn', state.adjustMode ? '조정 끝내기 (저장)' : '마우스로 조정');
    adjBtn.title = '휠로 확대, 드래그로 위치. 켜는 동안에는 클릭 전송·순서 변경이 잠깁니다.';
    adjBtn.addEventListener('click', () => {
      state.adjustMode = !state.adjustMode;
      if (!state.adjustMode) {
        suppressThumbEcho = true;
        setSync({ standingThumb: state.thumb }); // 끝낼 때 저장
        toast('썸네일 표시 설정을 저장했어요.');
      } else {
        toast('휠=확대, 드래그=위치. 끝나면 [조정 끝내기]를 눌러 주세요.');
      }
      renderBody();
    });
    adjRow.appendChild(adjBtn);
    sliders.appendChild(adjRow);

    const colRow = el('div', 'cst-slider-row');
    colRow.append(el('label', '', '열 수'));
    const colBtns = el('div', 'cst-colbtns');
    for (const n of [1, 2, 3, 4]) {
      const b = el('button', 'cst-colbtn' + (n === state.cols ? ' on' : ''), n + '열');
      b.addEventListener('click', () => {
        state.cols = n;
        grid.style.setProperty('--cst-cols', n);
        for (const c of colBtns.children) c.classList.toggle('on', Number(c.textContent) === n);
        suppressColsEcho = true;
        setSync({ standingCols: n });
        requestAnimationFrame(refreshThumbStyles); // 칸 크기가 바뀌므로 재계산
      });
      colBtns.appendChild(b);
    }
    colRow.appendChild(colBtns);

    const thumbInputs = [];
    // 마우스로 조정한 값을 슬라이더에도 즉시 반영 (서로 덮어써서 튀지 않게)
    syncThumbSliders = () => {
      for (const [key, range, out, unit] of thumbInputs) {
        range.value = state.thumb[key];
        out.textContent = Math.round(state.thumb[key]) + unit;
      }
    };

    const mk = (labelText, key, min, max, unit) => {
      const r = el('div', 'cst-slider-row');
      const lab = el('label', '', labelText);
      const range = document.createElement('input');
      range.type = 'range';
      range.min = min;
      range.max = max;
      range.value = state.thumb[key];
      const out = el('output', '', state.thumb[key] + unit);
      thumbInputs.push([key, range, out, unit]);
      range.addEventListener('input', () => {
        state.thumb[key] = Number(range.value);
        out.textContent = range.value + unit;
        refreshThumbStyles();
      });
      range.addEventListener('change', () => {
        suppressThumbEcho = true;
        setSync({ standingThumb: state.thumb });
      });
      r.append(lab, range, out);
      return r;
    };

    // 맨 앞에 @ 추가 토글
    const atRow = el('div', 'cst-slider-row');
    const atSw = mkSwitch(state.atPrefix, (on) => {
      state.atPrefix = on;
      setSync({ standingAtPrefix: state.atPrefix });
    });
    const atText = el('label', 'cst-at-lab', '클릭 시 맨 앞에 @ 추가 (라벨에 @가 이미 있으면 중복으로 붙지 않아요)');
    atText.htmlFor = atSw.input.id;
    atText.style.cursor = 'pointer';
    atRow.append(atSw.wrap, atText);

    sliders.append(
      el('div', 'cst-slider-row', '썸네일 표시 조절 (모든 스탠딩 공통)'),
      colRow,
      mk('확대', 'zoom', 100, 400, '%'),
      mk('가로 위치', 'posX', 0, 100, '%'),
      mk('세로 위치', 'posY', 0, 100, '%'),
      atRow
    );
    sec2.appendChild(sliders);

    renderSheetBackup(room);
  }

  // ----- 캐릭터 시트 백업 (능력치·파라미터·채팅 팔레트·메모) -----
  // 캐릭터 편집창을 열어두면 스탠딩과 함께 자동으로 담긴다.
  function renderSheetBackup(room) {
    const sheets = room.sheets || {};
    const names = Object.keys(sheets);

    const sec3 = secBlock('3', '캐릭터 시트 백업', '편집창을 열면 능력치·채팅 팔레트·메모가 자동으로 담깁니다.');
    const wrap = el('div', 'cst-sliders');
    sec3.appendChild(wrap);

    if (!names.length) {
      wrap.appendChild(el('div', 'cst-hint', '아직 담아둔 시트가 없습니다.'));
      body.appendChild(sec3);
      return;
    }

    wrap.appendChild(el('div', 'cst-hint', `${names.length}명 시트 저장됨 — 편집창을 열 때마다 최신으로 갱신됩니다.`));

    const pickRow = el('div', 'cst-row');
    const sel = el('select', 'cst-select');
    for (const n of names) {
      const o = el('option', '', n);
      o.value = n;
      if (n === state.sheetChar) o.selected = true;
      sel.appendChild(o);
    }
    if (!state.sheetChar || !names.includes(state.sheetChar)) state.sheetChar = names[0];
    sel.value = state.sheetChar;
    const delBtn = el('button', 'cst-btn ghost', '삭제');
    delBtn.title = '이 캐릭터의 저장된 시트만 지웁니다 (스탠딩은 그대로)';
    pickRow.append(sel, delBtn);
    wrap.appendChild(pickRow);

    const view = el('div', 'cst-hint');
    view.style.whiteSpace = 'pre-wrap';
    wrap.appendChild(view);

    const btnRow = el('div', 'cst-row');
    const palBtn = el('button', 'cst-btn ghost', '채팅 팔레트 복사');
    palBtn.style.flex = '1';
    const jsonBtn = el('button', 'cst-btn ghost', '이 시트 JSON 복사');
    jsonBtn.style.flex = '1';
    btnRow.append(palBtn, jsonBtn);
    wrap.appendChild(btnRow);

    const fileRow = el('div', 'cst-row');
    const saveAllBtn = el('button', 'cst-btn ghost', '이 방 시트 전부 파일로 저장');
    saveAllBtn.style.flex = '1';
    fileRow.appendChild(saveAllBtn);
    wrap.appendChild(fileRow);

    function draw() {
      const sh = sheets[state.sheetChar] || {};
      const lines = [];
      if (sh.status && sh.status.length) {
        lines.push('능력치  ' + sh.status.map((x) => `${x.label} ${x.value}${x.max ? '/' + x.max : ''}`).join('  ·  '));
      }
      if (sh.params && sh.params.length) {
        lines.push('파라미터  ' + sh.params.map((x) => `${x.label} ${x.value}`).join('  ·  '));
      }
      const pal = (sh.commands || '').trim();
      lines.push(pal ? `채팅 팔레트  ${pal.split('\n').length}줄` : '채팅 팔레트  없음');
      if ((sh.memo || '').trim()) lines.push('메모  ' + sh.memo.trim().slice(0, 60) + (sh.memo.length > 60 ? '…' : ''));
      if (sh.at) {
        const d = new Date(sh.at);
        const pad = (n) => String(n).padStart(2, '0');
        lines.push(`담은 때  ${d.getFullYear()}.${pad(d.getMonth() + 1)}.${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`);
      }
      view.textContent = lines.join('\n');
      palBtn.disabled = !pal;
    }

    sel.addEventListener('change', () => {
      state.sheetChar = sel.value;
      draw();
    });

    palBtn.addEventListener('click', () => {
      const sh = sheets[state.sheetChar] || {};
      navigator.clipboard
        .writeText(sh.commands || '')
        .then(() => toast(`"${state.sheetChar}" 채팅 팔레트 복사됨`))
        .catch(() => toast('복사 실패'));
    });

    jsonBtn.addEventListener('click', () => {
      const payload = { kind: 'cst-character-sheet', name: state.sheetChar, sheet: sheets[state.sheetChar] };
      navigator.clipboard
        .writeText(JSON.stringify(payload, null, 2))
        .then(() => toast(`"${state.sheetChar}" 시트 JSON 복사됨`))
        .catch(() => toast('복사 실패'));
    });

    saveAllBtn.addEventListener('click', () => {
      const payload = {
        kind: 'cst-character-sheets',
        version: 1,
        roomName: room.name || '코코포리아',
        at: Date.now(),
        sheets,
        standings: room.standings || {},
      };
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const safe = (room.name || '코코포리아').replace(/[\/:*?"<>|]/g, '_').slice(0, 40);
      a.href = url;
      a.download = `${safe}_캐릭터시트.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
      toast(`시트 ${names.length}명 분을 파일로 저장했습니다.`);
    });

    delBtn.addEventListener('click', async () => {
      const gone = state.sheetChar;
      await patchRoom((r) => {
        if (r.sheets) delete r.sheets[gone];
      });
      state.sheetChar = '';
      toast(`"${gone}" 시트를 지웠습니다.`);
      renderBody();
    });

    draw();
    body.appendChild(sec3);
  }

  // ----- 색상 (직접 입력 저장 전용, 전역/이 방 전용 선택) -----
  async function renderColor() {
    const { charColors } = await getLocal({ charColors: {} });
    const room = await getRoom();
    const roomColors = room.charColors || {};
    body.innerHTML = '';

    body.appendChild(
      el('div', 'cst-hint', '캐릭터 이름과 색상 코드를 입력해 저장하세요.\n목록 클릭 시 색상 코드가 복사됩니다.')
    );

    const manual = el('div', 'cst-row');
    const nameIn = el('input', 'cst-input');
    nameIn.placeholder = '캐릭터 이름';
    if (state.detected && state.detected.name) nameIn.value = state.detected.name;
    const hexIn = el('input', 'cst-input');
    hexIn.placeholder = '#ff5555';
    hexIn.style.maxWidth = '76px';
    const pick = document.createElement('input');
    pick.type = 'color';
    pick.className = 'cst-color-pick';
    pick.value = '#e05252';
    pick.addEventListener('input', () => (hexIn.value = pick.value));
    hexIn.addEventListener('input', () => {
      const h = normalizeHex(hexIn.value);
      if (h) pick.value = h;
    });
    const addBtn = el('button', 'cst-btn', '저장');
    manual.append(nameIn, hexIn, pick, addBtn);
    body.appendChild(manual);

    addBtn.addEventListener('click', async () => {
      const nm = nameIn.value.trim();
      const hx = normalizeHex(hexIn.value) || normalizeHex(pick.value);
      if (!nm) return toast('캐릭터 이름을 입력해 주세요.');
      if (!hx) return toast('색상 코드가 올바르지 않아요. 예: #ff5555');
      const { charColors: cc } = await getLocal({ charColors: {} });
      cc[nm] = hx;
      await setLocal({ charColors: cc });
      toast(`"${nm}" → ${hx} 저장됨 (목록에서 '이 방' O/X 전환 가능)`);
      renderBody();
    });

    // 캐릭터별 "이 방에서만" O/X 전환: O = 이 방 전용, X = 모든 방 공통
    function colorItem(name, value, roomOnly) {
      const item = el('div', 'cst-color-item');
      item.title = '클릭하면 색상 코드를 복사합니다.';
      const chip = el('span', 'cst-color-chip');
      chip.style.background = value;
      const label = el('span', 'cst-color-name', name);

      const scopeBtn = el('button', 'cst-scope-btn' + (roomOnly ? ' on' : ''), '이 방 ' + (roomOnly ? 'O' : 'X'));
      scopeBtn.title = roomOnly
        ? '이 방 전용 색상 — 클릭하면 모든 방 공통으로 전환'
        : '모든 방 공통 색상 — 클릭하면 이 방 전용으로 전환';
      scopeBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        if (roomOnly) {
          // 이 방 전용 → 공통
          const { charColors: cc } = await getLocal({ charColors: {} });
          cc[name] = value;
          await setLocal({ charColors: cc });
          await patchRoom((r) => {
            if (r.charColors) delete r.charColors[name];
          });
        } else {
          // 공통 → 이 방 전용
          await patchRoom((r) => {
            r.charColors = r.charColors || {};
            r.charColors[name] = value;
          });
          const { charColors: cc } = await getLocal({ charColors: {} });
          delete cc[name];
          await setLocal({ charColors: cc });
        }
        renderBody();
      });

      const code = el('span', '', value);
      code.style.cssText = 'font-size:11px;color:var(--cst-sub);flex-shrink:0;';
      const del = el('button', 'cst-del');
      del.innerHTML = window.faIcon ? window.faIcon('xmark') : '✕';
      del.title = '삭제';
      del.addEventListener('click', async (e) => {
        e.stopPropagation();
        if (roomOnly) {
          await patchRoom((r) => {
            if (r.charColors) delete r.charColors[name];
          });
        } else {
          const { charColors: cc } = await getLocal({ charColors: {} });
          delete cc[name];
          await setLocal({ charColors: cc });
        }
        renderBody();
      });

      item.append(chip, label, scopeBtn, code, del);
      item.addEventListener('click', () => {
        if (navigator.clipboard) {
          navigator.clipboard
            .writeText(value)
            .then(() => toast(`${value} 복사됨 — 캐릭터 편집창 색상 칸에 붙여넣으세요.`))
            .catch(() => toast(value));
        } else toast(value);
      });
      return item;
    }

    const roomNames = Object.keys(roomColors);
    const globalNames = Object.keys(charColors).filter((n) => !roomNames.includes(n));
    if (!roomNames.length && !globalNames.length) {
      body.appendChild(el('div', 'cst-hint', '저장된 색상이 없습니다.'));
      return;
    }

    const list = el('div', 'cst-color-list');
    for (const name of roomNames) list.appendChild(colorItem(name, roomColors[name], true));
    for (const name of globalNames) list.appendChild(colorItem(name, charColors[name], false));
    body.appendChild(list);
  }

  // ----- 메모 (방 공지 + 세션 메모 여러 개, 상단 고정은 선택) -----
  // 공지는 memos 배열에서 id '__notice__' 인 항목으로 다룬다 (기존 room.memo와 호환 유지).
  const NOTICE_ID = '__notice__';

  function memoList(room) {
    const out = [];
    out.push({
      id: NOTICE_ID,
      text: room.memo || '',
      pinned: !!room.memoPinned,
      collapsed: room.noticeCollapsed !== false,
      isNotice: true,
    });
    for (const mo of Array.isArray(room.memos) ? room.memos : []) {
      out.push({ ...mo, pinned: !!mo.pinned, collapsed: mo.collapsed !== false, isNotice: false });
    }
    return out;
  }

  function patchMemo(id, fn) {
    return patchRoom((r) => {
      if (id === NOTICE_ID) {
        const view = { text: r.memo || '', pinned: !!r.memoPinned, collapsed: r.noticeCollapsed !== false };
        fn(view);
        r.memo = view.text;
        r.memoPinned = view.pinned;
        r.noticeCollapsed = view.collapsed;
        return;
      }
      const hit = (r.memos || []).find((x) => x.id === id);
      if (hit) fn(hit);
    });
  }

  // ----- 세션 준비 체크리스트 (방마다) -----
  // 가운데에 딱 맞는 체크 표시.
  // Font Awesome 체크는 획이 오른쪽 위로 길게 뻗어 눈으로 보면 오른쪽에 쏠려 보인다.
  // 잉크의 가로·세로 중심이 뷰박스 중심(8,8)에 정확히 오도록 직접 그렸다.
  const CHECK_MARK =
    '<svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="3.5,8.4 6.4,11.3 12.5,4.7"/></svg>';

  function renderChecklist(room) {
    const list = Array.isArray(room.checklist) ? room.checklist : [];
    const wrap = el('div', 'cst-check');

    // ---- 머리: 제목 + 진행 + 상단 표시 핀 ----
    const head = el('div', 'cst-check-head');
    head.appendChild(el('span', 'cst-check-title', '세션 준비'));
    const count = el('span', 'cst-check-count', '');
    head.appendChild(count);
    const pinned = !!room.checklistPinned;
    const pin = el('button', 'cst-pin-btn cst-check-pin' + (pinned ? ' on' : ''), pinned ? '방에 표시 중' : '방에 표시');
    pin.type = 'button';
    pin.title = pinned ? '방 화면에서 내리기' : '방 화면에 메모들과 함께 띄우기 (위치는 팝업 설정에서)';
    pin.addEventListener('click', async () => {
      await patchRoom((r) => (r.checklistPinned = !pinned));
      refreshNoticeBar();
      renderBody();
    });
    head.appendChild(pin);
    wrap.appendChild(head);

    const bar = el('div', 'cst-check-bar');
    const fill = el('div', 'cst-check-fill');
    bar.appendChild(fill);
    wrap.appendChild(bar);

    const rows = el('div', 'cst-check-rows');
    wrap.appendChild(rows);

    function refreshCount() {
      const all = rows.querySelectorAll('.cst-check-row').length;
      const on = rows.querySelectorAll('.cst-check-row.done').length;
      count.textContent = all ? `${on} / ${all}` : '';
      fill.style.width = all ? (on / all) * 100 + '%' : '0%';
      bar.classList.toggle('cst-hide', !all);
      wrap.classList.toggle('all-done', all > 0 && on === all);
      footRow.classList.toggle('cst-hide', !all);
    }

    // ---- 항목 한 줄 ----
    function mkRow(it) {
      const row = el('div', 'cst-check-row' + (it.done ? ' done' : ''));

      const box = el('button', 'cst-check-box');
      box.type = 'button';
      box.title = '했음/안 했음';
      box.innerHTML = CHECK_MARK;
      box.addEventListener('click', async () => {
        const on = !row.classList.contains('done');
        row.classList.toggle('done', on);
        refreshCount();
        await patchRoom((r) => {
          const hit = (r.checklist || []).find((x) => x.id === it.id);
          if (hit) hit.done = on;
        });
      });

      const txt = el('input', 'cst-check-text');
      txt.value = it.text || '';
      txt.placeholder = '내용';
      txt.addEventListener('change', () => {
        patchRoom((r) => {
          const hit = (r.checklist || []).find((x) => x.id === it.id);
          if (hit) hit.text = txt.value;
        });
      });
      // 항목 안에서 엔터를 누르면 바로 아래에 새 항목을 만들어 이어서 적는다
      txt.addEventListener('keydown', (e) => {
        if (e.key !== 'Enter') return;
        e.preventDefault();
        txt.blur();
        addItem('', row);
      });

      const del = el('button', 'cst-check-del');
      del.type = 'button';
      del.innerHTML = window.faIcon ? window.faIcon('xmark') : '✕';
      del.title = '이 항목 지우기';
      del.addEventListener('click', async () => {
        row.remove();
        refreshCount();
        await patchRoom((r) => {
          r.checklist = (r.checklist || []).filter((x) => x.id !== it.id);
        });
      });

      row.append(box, txt, del);
      return row;
    }

    for (const it of list) rows.appendChild(mkRow(it));

    // ---- 항목 추가 ----
    // 화면을 다시 그리지 않고 줄만 덧붙인다 — 그래야 엔터로 계속 이어 적을 수 있다.
    async function addItem(text, afterRow) {
      const it = { id: 'c' + Date.now() + Math.floor(Math.random() * 100), text: text || '', done: false };
      const row = mkRow(it);
      if (afterRow && afterRow.parentElement === rows) afterRow.insertAdjacentElement('afterend', row);
      else rows.appendChild(row);
      refreshCount();
      const input = row.querySelector('.cst-check-text');
      input.focus();
      await patchRoom((r) => {
        r.checklist = Array.isArray(r.checklist) ? r.checklist : [];
        const at = afterRow ? [...rows.children].indexOf(row) : r.checklist.length;
        r.checklist.splice(at, 0, it);
      });
    }

    const addBtn = el('button', 'cst-check-add', '');
    addBtn.type = 'button';
    addBtn.innerHTML = (window.faIcon ? window.faIcon('plus') : '+') + '<span>항목 추가</span>';
    addBtn.title = '엔터로 계속 이어서 적을 수 있어요';
    addBtn.addEventListener('click', () => addItem(''));
    wrap.appendChild(addBtn);

    // ---- 발: 전부 해제 / 비우기 ----
    const footRow = el('div', 'cst-check-foot');
    const resetBtn = el('button', 'cst-check-foot-btn', '체크 전부 해제');
    resetBtn.type = 'button';
    resetBtn.title = '항목은 그대로 두고 체크만 풉니다 (다음 회차용)';
    resetBtn.addEventListener('click', async () => {
      for (const r of rows.querySelectorAll('.cst-check-row')) r.classList.remove('done');
      refreshCount();
      await patchRoom((r) => {
        for (const x of r.checklist || []) x.done = false;
      });
    });
    const clearBtn = el('button', 'cst-check-foot-btn', '목록 비우기');
    clearBtn.type = 'button';
    clearBtn.addEventListener('click', async () => {
      if (!confirm('체크리스트 항목을 전부 지울까요?')) return;
      rows.innerHTML = '';
      refreshCount();
      await patchRoom((r) => {
        r.checklist = [];
      });
    });
    footRow.append(resetBtn, clearBtn);
    wrap.appendChild(footRow);

    refreshCount();
    return wrap;
  }

  async function renderMemo() {
    const room = await getRoom();
    body.innerHTML = '';

    body.appendChild(renderChecklist(room));

    body.appendChild(
      el('div', 'cst-hint', '[방에 표시]를 누른 메모만 방 화면에 뜹니다. 위치(상단/하단)와 글자 크기는 팝업 설정에서. (기본은 표시 안 함)')
    );

    const items = memoList(room);
    const wrap = el('div', 'cst-sliders');
    wrap.appendChild(el('div', 'cst-slider-row', '메모'));

    for (const mo of items) {
      const card = el('div', 'cst-memo-card');
      const top = el('div', 'cst-memo-card-top');

      if (mo.isNotice) {
        top.appendChild(el('span', 'cst-memo-date', '방 공지'));
      } else {
        const dt = new Date(mo.at || Date.now());
        const pad = (n) => String(n).padStart(2, '0');
        top.appendChild(
          el('span', 'cst-memo-date', `${pad(dt.getMonth() + 1)}.${pad(dt.getDate())} ${pad(dt.getHours())}:${pad(dt.getMinutes())}`)
        );
      }

      const btns = el('span', 'cst-memo-card-btns');
      const pin = el('button', 'cst-pin-btn' + (mo.pinned ? ' on' : ''), mo.pinned ? '방에 표시 중' : '방에 표시');
      pin.title = mo.pinned ? '방 화면에서 내리기' : '방 화면에 표시 (위치는 팝업 설정에서)';
      pin.addEventListener('click', async () => {
        await patchMemo(mo.id, (x) => (x.pinned = !mo.pinned));
        refreshNoticeBar();
        renderBody();
      });
      btns.appendChild(pin);

      if (!mo.isNotice) {
        const del = el('button', 'cst-del');
        del.innerHTML = window.faIcon ? window.faIcon('xmark') : '✕';
        del.title = '이 메모 삭제';
        del.addEventListener('click', async () => {
          await patchRoom((r) => {
            r.memos = (r.memos || []).filter((x) => x.id !== mo.id);
          });
          refreshNoticeBar();
          renderBody();
        });
        btns.appendChild(del);
      }
      top.appendChild(btns);

      const ta = el('textarea', 'cst-memo cst-memo-mini');
      ta.value = mo.text || '';
      ta.placeholder = mo.isNotice ? '방 공지 (자동 저장)' : '메모 내용 (자동 저장)';
      const sv = el('div', 'cst-memo-saved', '');
      let t2 = 0;
      ta.addEventListener('input', () => {
        clearTimeout(t2);
        sv.textContent = '입력 중…';
        t2 = setTimeout(async () => {
          await patchMemo(mo.id, (x) => (x.text = ta.value));
          sv.textContent = '저장됨 ✓';
          refreshNoticeBar();
        }, 500);
      });
      card.append(top, ta, sv);
      wrap.appendChild(card);
    }

    const addBtn = el('button', 'cst-btn ghost', '+ 새 메모');
    addBtn.style.width = '100%';
    addBtn.addEventListener('click', async () => {
      await patchRoom((r) => {
        r.memos = r.memos || [];
        // 적은 순서대로 아래로 쌓인다 (전에는 맨 위에 끼어들어 헷갈렸음)
        r.memos.push({
          id: Date.now() + '_' + Math.random().toString(36).slice(2, 7),
          text: '',
          at: Date.now(),
          pinned: false,
        });
      });
      renderBody();
    });
    wrap.appendChild(addBtn);
    body.appendChild(wrap);
  }

  // ----- 상단 고정 메모 바 (핀한 메모만, 드래그 정렬, 클릭 접기 — 편집은 패널 메모 탭에서) -----
  let noticeBar = null;

  const CHECK_NOTICE_ID = '__checklist__';

  // 채팅 별창(/rooms/ID/chat 등 하위 경로)에는 띄우지 않는다 — 메인 방 화면에서만
  const isMainRoomPage = /^\/rooms\/[^/]+\/?$/.test(location.pathname) && !/chat/i.test(location.search);

  async function refreshNoticeBar() {
    if (!isMainRoomPage) {
      if (noticeBar) noticeBar.style.display = 'none';
      return;
    }
    const room = await getRoom();
    const pinned = memoList(room).filter((m) => m.pinned && (m.text || '').trim());
    // 세션 준비도 핀하면 메모들과 같은 줄에 놓인다
    const showCheck = !!room.checklistPinned && (room.checklist || []).length > 0;
    if (showCheck) pinned.push({ id: CHECK_NOTICE_ID, isCheck: true, collapsed: room.checklistCollapsed !== false });

    if (!pinned.length) {
      if (noticeBar) noticeBar.style.display = 'none';
      return;
    }
    if (!noticeBar) {
      noticeBar = el('div', 'cst-root');
      noticeBar.id = 'cst-notice';
      document.body.appendChild(noticeBar);
      applyTheme();
    }
    noticeBar.style.display = 'flex';
    noticeBar.style.setProperty('--cst-notice-fs', (Number(state.noticeFont) || 12) + 'px');
    noticeBar.innerHTML = '';
    placeNoticeBar();

    // 저장된 순서대로 나열 (드래그로 바꾼 순서)
    const order = Array.isArray(room.noticeOrder) ? room.noticeOrder : [];
    pinned.sort((a, b) => {
      const ia = order.indexOf(a.id);
      const ib = order.indexOf(b.id);
      return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib);
    });

    pinned.forEach((mo, i) =>
      noticeBar.appendChild(mo.isCheck ? checkNoticeCard(room, i, pinned) : noticeCard(mo, i, pinned))
    );
  }

  // 화면의 가로 띠(bandTop~bandBottom) 안에서 코코포리아 요소들이 차지한 구간을 빼고 남는 빈 구간들.
  // 상단 바(메모 위쪽 배치)와 하단 띠(좌하단 배치)가 같은 계산을 쓴다.
  function freeGaps(bandTop, bandBottom, leftLimit, rightLimit) {
    const spans = [];
    for (const elx of document.querySelectorAll('button, [role="button"], h6, a, input, textarea, svg, img')) {
      if (elx.closest && elx.closest('.cst-root')) continue;
      const r = elx.getBoundingClientRect();
      if (!r.width || !r.height) continue;
      if (r.bottom < bandTop || r.top > bandBottom) continue;
      if (r.right < leftLimit || r.left > rightLimit) continue;
      spans.push([Math.max(leftLimit, r.left - 6), Math.min(rightLimit, r.right + 6)]);
    }
    spans.sort((a, b) => a[0] - b[0]);
    const merged = [];
    for (const sp of spans) {
      const last = merged[merged.length - 1];
      if (last && sp[0] <= last[1]) last[1] = Math.max(last[1], sp[1]);
      else merged.push(sp.slice());
    }
    const gaps = [];
    let cur = leftLimit;
    for (const m of merged) {
      if (m[0] - cur > 0) gaps.push({ left: cur, width: m[0] - cur });
      cur = Math.max(cur, m[1]);
    }
    if (rightLimit - cur > 0) gaps.push({ left: cur, width: rightLimit - cur });
    return { gaps, occupied: merged.length > 0 };
  }

  // 상단 바 아래로 내려 전체 폭을 쓰는 자리
  function belowSlot() {
    return { left: 12, width: Math.min(560, innerWidth - 24), below: true };
  }

  // 상단: 코코포리아 상단 바(0~64px)에서 방 이름·아이콘 버튼 "사이"의 가장 넓은 틈.
  // minWidth보다 좁으면 상단 바 아래로 내려 전체 폭을 쓴다 (말줄임으로라도 보이게).
  function noticeSlot(minWidth) {
    const { gaps, occupied } = freeGaps(2, 64, 0, innerWidth);
    if (!occupied) return { left: 12, width: Math.min(560, innerWidth - 24) };
    const inner = gaps.filter((g) => g.left > 0 && g.left + g.width < innerWidth);
    const best = inner.reduce((a, b) => (!a || b.width > a.width ? b : a), null);
    if (!best || best.width < minWidth) return belowSlot();
    return { left: best.left + 4, width: Math.max(120, best.width - 8) };
  }

  // 하단(좌하단): 화면 아래 띠(72px)에서 버튼들과 채팅창을 피해 왼쪽부터 빈 구간을 찾는다.
  // 공간이 넓어 창을 줄여도 웬만하면 살아남는다.
  function bottomSlot() {
    let leftLimit = 8;
    let rightLimit = innerWidth - 8;
    // 채팅창(드로어)은 통째로 피한다 — 메모가 채팅창 위로 넘어가면 안 된다.
    // 전체 폭 레이아웃 컨테이너를 드로어로 오인하지 않게 MuiDrawer-paper만 본다.
    const log = document.querySelector('[role="log"]');
    const drawer = log && log.closest('.MuiDrawer-paper');
    if (drawer) {
      const d = drawer.getBoundingClientRect();
      if (d.width && d.height) {
        if (d.width >= innerWidth - 40) return null; // 채팅창이 화면을 다 덮은 상태
        if (d.left > innerWidth / 2) rightLimit = Math.min(rightLimit, d.left - 8);
        else if (d.right < innerWidth / 2) leftLimit = Math.max(leftLimit, d.right + 8);
      }
    }
    const { gaps } = freeGaps(innerHeight - 72, innerHeight, leftLimit, rightLimit);
    if (!gaps.length) return null;
    // 왼쪽부터 160px 이상 되는 첫 빈 구간, 없으면 가장 넓은 것
    const pick = gaps.find((g) => g.width >= 160) || gaps.reduce((a, b) => (b.width > a.width ? b : a));
    if (pick.width < 120) return null;
    return { left: pick.left + 4, width: Math.min(560, pick.width - 8) };
  }

  function placeNoticeBar() {
    if (!noticeBar || noticeBar.style.display === 'none') return;
    const bottom = state.noticePos === 'bottom';
    noticeBar.classList.toggle('cst-notice-bottom', bottom);
    const slot = bottom ? bottomSlot() : noticeSlot(160);
    // 정말 넣을 자리가 없을 때만 숨긴다
    if (!slot || innerWidth < 300 || slot.width < 120) {
      noticeBar.style.visibility = 'hidden';
      return;
    }
    noticeBar.style.visibility = '';
    noticeBar.style.left = Math.round(slot.left) + 'px';
    noticeBar.style.width = Math.round(slot.width) + 'px';
    noticeBar.style.maxWidth = Math.round(slot.width) + 'px';
    if (bottom) {
      noticeBar.style.top = 'auto';
      noticeBar.style.bottom = '8px';
    } else {
      noticeBar.style.bottom = 'auto';
      noticeBar.style.top = (slot.below ? 68 : 8) + 'px';
    }
  }

  let placeTimer = 0;
  addEventListener('resize', () => {
    placeNoticeBar();
    // 코코포리아 레이아웃이 늦게 따라오는 경우를 위해 한 번 더
    clearTimeout(placeTimer);
    placeTimer = setTimeout(placeNoticeBar, 300);
  });

  // 상단 바에 뜨는 세션 준비 카드. 여기서도 바로 체크할 수 있다.
  function checkNoticeCard(room, index, siblings) {
    const list = room.checklist || [];
    const done = list.filter((x) => x.done).length;
    const collapsed = room.checklistCollapsed !== false;

    const card = el('div', 'cst-notice-card cst-notice-check' + (collapsed ? ' cst-notice-collapsed' : ''));
    attachNoticeDrag(card, index, siblings);

    const chev = el('button', 'cst-notice-chev', collapsed ? '▸' : '▾');
    chev.title = collapsed ? '펼치기' : '접기';
    chev.addEventListener('click', async (e) => {
      e.stopPropagation();
      await patchRoom((r) => (r.checklistCollapsed = !collapsed));
      refreshNoticeBar();
    });
    card.appendChild(chev);

    const body2 = el('div', 'cst-notice-check-body');
    const title = el('div', 'cst-notice-check-head');
    title.append(
      el('span', 'cst-notice-check-t', '세션 준비'),
      el('span', 'cst-notice-check-n', `${done} / ${list.length}`)
    );
    body2.appendChild(title);

    if (!collapsed) {
      const ul = el('div', 'cst-notice-check-list');
      for (const it of list) {
        const row = el('div', 'cst-notice-check-row' + (it.done ? ' done' : ''));
        const box = el('button', 'cst-notice-check-box');
        box.type = 'button';
        box.innerHTML = CHECK_MARK;
        box.addEventListener('click', async (e) => {
          e.stopPropagation();
          await patchRoom((r) => {
            const hit = (r.checklist || []).find((x) => x.id === it.id);
            if (hit) hit.done = !it.done;
          });
          refreshNoticeBar();
          if (state.activeTab === 'memo' && panel && panel.style.display !== 'none') renderBody();
        });
        row.append(box, el('span', '', it.text || ''));
        ul.appendChild(row);
      }
      body2.appendChild(ul);
    }
    card.appendChild(body2);
    return card;
  }

  // 상단 카드 공통 드래그 순서 바꾸기
  function attachNoticeDrag(card, index, siblings) {
    card.draggable = true;
    card.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('text/plain', String(index));
      card.classList.add('cst-notice-dragging');
    });
    card.addEventListener('dragend', () => card.classList.remove('cst-notice-dragging'));
    card.addEventListener('dragover', (e) => {
      e.preventDefault();
      card.classList.add('cst-notice-dragover');
    });
    card.addEventListener('dragleave', () => card.classList.remove('cst-notice-dragover'));
    card.addEventListener('drop', async (e) => {
      e.preventDefault();
      card.classList.remove('cst-notice-dragover');
      const from = Number(e.dataTransfer.getData('text/plain'));
      if (Number.isNaN(from) || from === index) return;
      const ids = siblings.map((x) => x.id);
      const [moved] = ids.splice(from, 1);
      ids.splice(index, 0, moved);
      await patchRoom((r) => (r.noticeOrder = ids));
      refreshNoticeBar();
    });
  }

  function noticeCard(mo, index, siblings) {
    const card = el('div', 'cst-notice-card');
    card.draggable = true;
    card.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('text/plain', String(index));
      card.classList.add('cst-notice-dragging');
    });
    card.addEventListener('dragend', () => card.classList.remove('cst-notice-dragging'));
    card.addEventListener('dragover', (e) => {
      e.preventDefault();
      card.classList.add('cst-notice-dragover');
    });
    card.addEventListener('dragleave', () => card.classList.remove('cst-notice-dragover'));
    card.addEventListener('drop', async (e) => {
      e.preventDefault();
      card.classList.remove('cst-notice-dragover');
      const from = Number(e.dataTransfer.getData('text/plain'));
      if (Number.isNaN(from) || from === index) return;
      const ids = siblings.map((x) => x.id);
      const [moved] = ids.splice(from, 1);
      ids.splice(index, 0, moved);
      await patchRoom((r) => (r.noticeOrder = ids));
      refreshNoticeBar();
    });
    const text = (mo.text || '').trim();

    // 한 줄로 다 보이는 짧은 메모는 접을 필요가 없다 → 화살표를 안 만든다
    const multiline = /\n/.test(text);
    card.classList.toggle('cst-notice-collapsed', mo.collapsed && multiline);

    const textEl = el('div', 'cst-notice-text');
    textEl.textContent = mo.collapsed && multiline ? text.split('\n')[0] : text;
    textEl.title = multiline ? '클릭하면 접기/펼치기 · 편집은 패널의 메모 탭에서' : '편집은 패널의 메모 탭에서';
    if (multiline) {
      textEl.addEventListener('click', async () => {
        await patchMemo(mo.id, (x) => (x.collapsed = !mo.collapsed));
        refreshNoticeBar();
      });
    }

    if (multiline) {
      const chev = el('button', 'cst-notice-chev', mo.collapsed ? '▸' : '▾');
      chev.title = mo.collapsed ? '펼치기' : '접기';
      chev.addEventListener('click', async (e) => {
        e.stopPropagation();
        await patchMemo(mo.id, (x) => (x.collapsed = !mo.collapsed));
        refreshNoticeBar();
      });
      card.appendChild(chev);
    }
    card.appendChild(textEl);
    return card;
  }

  // ----- 특수문자 -----
  function renderChars() {
    body.innerHTML = '';
    const wrap = el('div', 'cst-chars');
    for (const ch of state.specialChars) {
      const b = el('button', 'cst-char', ch);
      b.addEventListener('click', () => insertAtCursor(ch));
      wrap.appendChild(b);
    }
    body.appendChild(wrap);
    body.appendChild(
      el('div', 'cst-hint', '클릭하면 채팅 입력창 커서 위치에 삽입됩니다.\n목록은 팝업 → 설정에서 편집할 수 있어요.')
    );
  }

  // ----- 사이즈 -----
  function renderSize() {
    body.innerHTML = '';
    const css = { ...(state.standingCss || {}) };

    body.appendChild(el('div', 'cst-hint', '방 중앙에 뜨는 스탠딩·대화창의 크기를 조절합니다. 빈 칸은 코코포리아 기본값.'));

    let saveTimer = 0;
    function queueSave() {
      clearTimeout(saveTimer);
      saveTimer = setTimeout(() => {
        state.standingCss = { ...css };
        suppressCssEcho = true;
        setSync({ standingCss: state.standingCss });
      }, 400);
    }

    // 묶음 카드: 제목 + 줄들
    function mkSec(title, rows) {
      const sec = el('div', 'cst-size-sec');
      sec.appendChild(el('div', 'cst-size-sec-t', title));
      for (const r of rows) if (r) sec.appendChild(r);
      return sec;
    }

    // 한 줄 = 라벨 + 값. 설명은 줄 밑에 깔지 않고 툴팁으로만.
    function mkCheck(labelText, desc, key) {
      const r = el('div', 'cst-size-row');
      if (desc) r.title = desc;
      const sw = mkSwitch(!!css[key], (on) => {
        css[key] = on;
        queueSave();
      });
      const lab = el('label', '', labelText);
      lab.htmlFor = sw.input.id;
      lab.style.cursor = 'pointer';
      r.append(lab, sw.wrap);
      return r;
    }

    // 숫자 칸 + px 단위 — 라벨·칸·단위가 한 줄에 (빈 칸 = '기본').
    // type=number 는 크롬이 e · + · . 같은 글자도 받아서, 텍스트 칸에 숫자만 남기는 방식으로.
    // 입력 직후 한 번 정리한다 — 타이핑·붙여넣기("600px" → 600)·드롭 전부 같은 길.
    // allowNeg 면 맨 앞의 '-' 하나만 허용 (좌우·세로 위치).
    function mkNum(labelText, desc, key, allowNeg) {
      const r = el('div', 'cst-size-row');
      if (desc) r.title = desc;
      const lab = el('label', '', labelText);
      const inp = document.createElement('input');
      inp.type = 'text';
      inp.inputMode = allowNeg ? 'text' : 'numeric';
      inp.autocomplete = 'off';
      inp.className = 'cst-size-num';
      inp.placeholder = '기본';
      lab.htmlFor = inp.id = 'cst-num-' + key;
      if (css[key] !== undefined && css[key] !== null && css[key] !== '') inp.value = css[key];
      const clean = (v) => {
        let s2 = String(v).replace(/[^\d-]/g, '');
        const neg = allowNeg && s2.startsWith('-');
        s2 = s2.replace(/-/g, '');
        return (neg ? '-' : '') + s2;
      };
      inp.addEventListener('input', () => {
        const v = clean(inp.value);
        if (v !== inp.value) {
          const pos = inp.selectionStart;
          inp.value = v; // 잡글자 제거 (커서는 제거된 만큼만 당겨 둔다)
          try { inp.setSelectionRange(Math.min(pos, v.length), Math.min(pos, v.length)); } catch (_) {}
        }
        css[key] = v === '' || v === '-' ? '' : Number(v);
        queueSave();
      });
      r.append(lab, inp, el('span', 'cst-size-unit', 'px'));
      return r;
    }

    body.append(
      mkSec('스탠딩', [
        mkCheck('이미지 원본 크기', '켜면 가로 크기를 무시합니다', 'originalSize'),
        mkNum('가로 크기', '', 'width'),
        mkNum('좌우 위치', '왼쪽 기준 · 마이너스 가능', 'left', true),
      ]),
      mkSec('대화창', [
        mkNum('세로 위치', '아래 기준 · 마이너스 가능', 'bottom', true),
        // 배포본(dist)에는 대화창 가로·높이 조절이 없다 (lib/edition.js)
        LITE ? null : mkNum('가로 크기', '', 'dialogWidth'),
        LITE ? null : mkNum('높이', '', 'dialogHeight'),
      ]),
      mkSec('글자', [mkNum('캐릭터명', '', 'nameSize'), mkNum('대사', '', 'dialogueSize')])
    );

    const resetRow = el('div', 'cst-size-reset');
    const resetBtn = el('button', 'cst-btn ghost cst-sm', '전부 기본값으로');
    resetBtn.addEventListener('click', () => {
      state.standingCss = {};
      suppressCssEcho = true;
      setSync({ standingCss: {} });
      renderBody();
    });
    resetRow.appendChild(resetBtn);
    body.appendChild(resetRow);
  }

  // ----- 맵시트 캡처 -----
  const capState = { format: 'png', scale: 1, gifSec: 4, gifWidth: 720, gifSpeed: 1, gifSmooth: false, gifFps: 15 };

  function renderCapture() {
    body.innerHTML = '';
    body.appendChild(el('div', 'cst-hint', '맵시트를 이미지로 저장합니다.'));

    // 저장 형식
    const fmtRow = el('div', 'cst-slider-row');
    fmtRow.appendChild(el('label', '', '저장 형식'));
    const fmtWrap = el('div', 'cst-colbtns');
    for (const [v, label, tip] of [
      ['png', 'PNG', '투명 유지 · 무손실'],
      ['jpg', 'JPG', '파일이 가벼움'],
      ['gif', 'GIF', '움직이는 맵시트 기록용 (색이 256개로 줄어듭니다)'],
    ]) {
      const b = el('button', 'cst-colbtn' + (v === capState.format ? ' on' : ''), label);
      b.title = tip;
      b.addEventListener('click', () => {
        capState.format = v;
        for (const c of fmtWrap.children) c.classList.toggle('on', c === b);
        applyFmtRows();
      });
      fmtWrap.appendChild(b);
    }

    // 형식에 따라 어떤 줄을 보일지
    function applyFmtRows() {
      const isGif = capState.format === 'gif';
      gifRow.classList.toggle('cst-hide', !isGif);
      scaleRow.classList.toggle('cst-hide', isGif); // 배율은 정지 이미지 전용
      gifModeRow.classList.toggle('cst-hide', !isGif);
      gifFpsRow.classList.toggle('cst-hide', !isGif || !capState.gifSmooth);
    }
    fmtRow.appendChild(fmtWrap);

    // 배율
    const scaleRow = el('div', 'cst-slider-row');
    scaleRow.appendChild(el('label', '', '배율'));
    const scaleWrap = el('div', 'cst-colbtns');
    for (const v of [1, 2, 4]) {
      const b = el('button', 'cst-colbtn' + (v === capState.scale ? ' on' : ''), v + 'x');
      b.title = v === 1 ? '지금 화면 그대로' : '브라우저를 잠깐 확대해서 더 큰 해상도로 찍습니다';
      b.addEventListener('click', () => {
        capState.scale = v;
        for (const c of scaleWrap.children) c.classList.toggle('on', c === b);
      });
      scaleWrap.appendChild(b);
    }
    scaleRow.appendChild(scaleWrap);

    // GIF 길이
    const gifRow = el('div', 'cst-slider-row');
    gifRow.appendChild(el('label', '', '길이'));
    const gifRange = document.createElement('input');
    gifRange.type = 'range';
    gifRange.min = 2;
    gifRange.max = 10;
    gifRange.value = capState.gifSec;
    const gifOut = el('output', '', capState.gifSec + '초');
    gifRange.addEventListener('input', () => {
      capState.gifSec = Number(gifRange.value);
      gifOut.textContent = capState.gifSec + '초';
    });
    gifRow.append(gifRange, gifOut);


    // 찍는 방식 — 화면 찍기는 초당 2컷이 한계, 탭 영상은 더 잘게 딸 수 있다
    const gifModeRow = el('div', 'cst-slider-row');
    gifModeRow.appendChild(el('label', '', '찍는 방식'));
    const gifModeWrap = el('div', 'cst-colbtns');
    for (const [v, label] of [[false, '화면 찍기'], [true, '매끄럽게']]) {
      const b = el('button', 'cst-colbtn' + (v === capState.gifSmooth ? ' on' : ''), label);
      b.title = v
        ? '탭 영상을 받아 초당 10~30컷으로 찍습니다 (쓸 수 없으면 화면 찍기로 넘어갑니다)'
        : '초당 2컷 — 어디서나 되지만 뚝뚝 끊깁니다';
      b.addEventListener('click', () => {
        capState.gifSmooth = v;
        for (const c of gifModeWrap.children) c.classList.toggle('on', c === b);
        gifFpsRow.classList.toggle('cst-hide', !v || capState.format !== 'gif');
      });
      gifModeWrap.appendChild(b);
    }
    gifModeRow.appendChild(gifModeWrap);

    // 초당 컷 수 (매끄럽게 모드에서만)
    const gifFpsRow = el('div', 'cst-slider-row');
    gifFpsRow.appendChild(el('label', '', '초당 컷'));
    const gifFpsWrap = el('div', 'cst-colbtns');
    for (const v of [10, 15, 20, 30]) {
      const b = el('button', 'cst-colbtn' + (v === capState.gifFps ? ' on' : ''), v + '컷');
      b.title =
        v >= 30
          ? '가장 매끄럽지만 파일이 아주 커집니다 (담는 폭도 480px로 줄어듭니다)'
          : v >= 20
            ? '매끄럽습니다 (담는 폭 600px)'
            : '적당합니다 (담는 폭 720px)';
      b.addEventListener('click', () => {
        capState.gifFps = v;
        for (const c of gifFpsWrap.children) c.classList.toggle('on', c === b);
      });
      gifFpsWrap.appendChild(b);
    }
    gifFpsRow.appendChild(gifFpsWrap);



    const gifRows = [gifRow, gifModeRow, gifFpsRow];

    const opts = el('div', 'cst-sliders');
    opts.append(fmtRow, scaleRow, gifRow, gifModeRow, gifFpsRow);
    body.appendChild(opts);
    applyFmtRows();

    // 캡처 버튼들
    const autoBtn = el('button', 'cst-btn', '맵시트 자동 인식');
    autoBtn.style.width = '100%';
    autoBtn.title = '맵시트(격자판 또는 배경 이미지)를 찾아 그 부분만 잘라 저장합니다';
    autoBtn.addEventListener('click', () => runCapture('auto'));
    body.appendChild(autoBtn);

    const row1 = el('div', 'cst-row');
    const dragBtn = el('button', 'cst-btn ghost', '영역 드래그');
    dragBtn.style.flex = '1';
    dragBtn.title = '드래그한 범위 안에서 맵시트 경계를 자동으로 다듬어 저장합니다';
    dragBtn.addEventListener('click', () => runCapture('drag'));
    const dragRawBtn = el('button', 'cst-btn ghost', '드래그(그대로)');
    dragRawBtn.style.flex = '1';
    dragRawBtn.title = '드래그한 범위를 다듬지 않고 그대로 저장';
    dragRawBtn.addEventListener('click', () => runCapture('dragRaw'));
    row1.append(dragBtn, dragRawBtn);
    body.appendChild(row1);

    const row2 = el('div', 'cst-row');
    const boardBtn = el('button', 'cst-btn ghost', '맵 전체 (채팅 제외)');
    boardBtn.style.flex = '1';
    boardBtn.addEventListener('click', () => runCapture('board'));
    const fullBtn = el('button', 'cst-btn ghost', '화면 전체');
    fullBtn.addEventListener('click', () => runCapture('full'));
    row2.append(boardBtn, fullBtn);
    body.appendChild(row2);

    // 이 방에서 전에 드래그한 영역 — 매번 다시 그리지 않아도 되게
    const savedRow = el('div', 'cst-row');
    savedRow.classList.add('cst-hide');
    const savedBtn = el('button', 'cst-btn ghost', '저장한 영역으로 찍기');
    savedBtn.style.flex = '1';
    const savedClearBtn = el('button', 'cst-btn ghost', '영역 잊기');
    savedRow.append(savedBtn, savedClearBtn);
    body.appendChild(savedRow);

    getRoom().then((room) => {
      const v = room && room.capRect;
      if (!v || !v.rw || !v.rh) return;
      const r = ratioToRect(v);
      savedRow.classList.remove('cst-hide');
      savedBtn.title = `${r.w}×${r.h}px 자리 — ${v.mode === 'dragRaw' ? '다듬지 않고 그대로' : '경계를 다듬어서'} 찍습니다`;
      savedBtn.addEventListener('click', () => runCapture(v.mode || 'drag', ratioToRect(v)));
      savedClearBtn.addEventListener('click', async () => {
        await patchRoom((rm) => {
          delete rm.capRect;
        });
        renderCapture();
        toast('저장한 캡처 영역을 지웠습니다.');
      });
    });

    const row3 = el('div', 'cst-row');
    const origBtn = el('button', 'cst-btn ghost', '맵시트 원본 파일만 받기');
    origBtn.style.flex = '1';
    origBtn.title = '맵시트가 이미지 한 장일 때 그 원본을 그대로 내려받습니다 (캐릭터·말은 안 나옴)';
    origBtn.addEventListener('click', () => runCapture('original'));
    row3.appendChild(origBtn);
    body.appendChild(row3);

    capProgress = el('div', 'cst-log-progress', '');
    body.appendChild(capProgress);

    body.appendChild(
      el(
        'div',
        'cst-hint',
        '자동 인식이 빗나가면 [영역 드래그]로 맵시트를 적당히 감싸주세요. 그 안에서 실제 경계를 찾아 잘라냅니다.\n' +
          '한 번 드래그한 영역은 이 방에 기억해 두어, 다음부터는 [저장한 영역으로 찍기]로 바로 찍을 수 있습니다.\n' +
          'GIF는 브라우저 제한 때문에 초당 2컷으로만 찍힙니다. 실제 속도로 재생하면 끊겨 보이니\n' +
          '[재생 속도]를 2~3배로 두면 훨씬 매끄럽습니다 (컷 수는 그대로).'
      )
    );
  }

  // ---------- 방마다 캡처 영역 기억 ----------
  // 창 크기가 달라져도 쓸 수 있게 화면 비율로 담아둔다.
  function rectToRatio(r) {
    return {
      rx: r.x / innerWidth,
      ry: r.y / innerHeight,
      rw: r.w / innerWidth,
      rh: r.h / innerHeight,
    };
  }

  function ratioToRect(v) {
    return {
      x: Math.round(v.rx * innerWidth),
      y: Math.round(v.ry * innerHeight),
      w: Math.round(v.rw * innerWidth),
      h: Math.round(v.rh * innerHeight),
    };
  }

  async function saveCapRect(rect, mode) {
    try {
      await patchRoom((rm) => {
        rm.capRect = { ...rectToRatio(rect), mode, at: Date.now() };
      });
    } catch (_) {}
  }

  let capProgress = null;
  function capSay(msg) {
    if (capProgress) capProgress.textContent = msg;
  }

  // ---------- 맵시트 영역 찾기 ----------
  // 채팅 패널(오른쪽)의 위치 — 맵 영역의 오른쪽 경계로 쓴다
  function findChatPanelRect() {
    const starts = [
      document.querySelector('[data-virtuoso-scroller="true"]'),
      document.querySelector('div[class*="MuiInputBase-root"] textarea'),
    ].filter(Boolean);
    let best = null;
    for (const start of starts) {
      let elx = start;
      for (let i = 0; i < 10 && elx && elx !== document.body; i++) {
        const r = elx.getBoundingClientRect();
        if (r.height > innerHeight * 0.5 && r.width > 180 && r.width < innerWidth * 0.6) {
          if (!best || r.width > best.width) best = r;
        }
        elx = elx.parentElement;
      }
    }
    return best;
  }

  function boardRect() {
    const chat = findChatPanelRect();
    const right = chat && chat.left > innerWidth * 0.4 ? chat.left : innerWidth;
    return { x: 0, y: 0, w: Math.max(1, right), h: innerHeight };
  }

  // DOM에서 맵시트로 보이는 요소 찾기.
  // 코코포리아 맵시트는 ① 격자 배경이 깔린 보드 ② 배경 이미지 한 장 두 형태다.
  // 흐림(blur) 처리된 뒤쪽 배경은 제외해야 진짜 맵시트만 남는다.
  function findMapSheet() {
    const board = boardRect();
    const boardArea = board.w * board.h;
    let best = null;

    const consider = (elx, url) => {
      if (elx.closest && elx.closest('.cst-root')) return;
      const cs = getComputedStyle(elx);
      if (cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) < 0.15) return;
      if (/blur\(/.test(cs.filter || '')) return; // 흐린 배경막은 맵시트가 아니다
      const r = elx.getBoundingClientRect();
      const x = Math.max(board.x, r.left);
      const y = Math.max(board.y, r.top);
      const x2 = Math.min(board.x + board.w, r.right);
      const y2 = Math.min(board.y + board.h, r.bottom);
      const w = x2 - x;
      const h = y2 - y;
      if (w < 80 || h < 80) return;
      const area = w * h;
      if (area < boardArea * 0.06) return;
      if (area > boardArea * 0.99) return; // 화면 전체를 덮는 배경막은 제외
      if (!best || area > best.area) best = { rect: { x, y, w, h }, area, el: elx, url: url || '' };
    };

    for (const elx of document.querySelectorAll('img')) {
      consider(elx, elx.currentSrc || elx.src || '');
    }
    for (const elx of document.querySelectorAll('canvas, video')) consider(elx, '');
    for (const elx of document.querySelectorAll('div, section, main, span')) {
      const cs = getComputedStyle(elx);
      const bg = cs.backgroundImage;
      if (!bg || bg === 'none') continue;
      const m = bg.match(/url\(["']?([^"')]+)["']?\)/);
      // 격자(repeating-gradient)도 맵시트 후보
      consider(elx, m ? m[1] : '');
    }
    return best;
  }

  // ---------- 픽셀 기반 경계 다듬기 ----------
  // 캡처 이미지에서 "내용이 있는" 영역만 남긴다.
  // 격자판은 선이, 맵시트 이미지는 또렷한 무늬가 변화량을 만들고,
  // 빈 검은 보드나 흐릿한 배경은 변화량이 거의 없다 → 그 차이로 경계를 찾는다.
  function trimByContent(canvas, rect, tight) {
    const W = Math.round(rect.w);
    const H = Math.round(rect.h);
    if (W < 20 || H < 20) return rect;
    const AW = Math.min(480, W);
    const AH = Math.max(1, Math.round((H * AW) / W));
    const small = document.createElement('canvas');
    small.width = AW;
    small.height = AH;
    const sc = small.getContext('2d', { willReadFrequently: true });
    sc.drawImage(canvas, Math.round(rect.x), Math.round(rect.y), W, H, 0, 0, AW, AH);
    let px;
    try {
      px = sc.getImageData(0, 0, AW, AH).data;
    } catch (_) {
      return rect;
    }

    const lum = new Float32Array(AW * AH);
    for (let i = 0, p = 0; p < lum.length; i += 4, p++) {
      lum[p] = 0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2];
    }
    const rowE = new Float32Array(AH);
    const colE = new Float32Array(AW);
    for (let y = 1; y < AH; y++) {
      for (let x = 1; x < AW; x++) {
        const p = y * AW + x;
        const g = Math.abs(lum[p] - lum[p - 1]) + Math.abs(lum[p] - lum[p - AW]);
        rowE[y] += g;
        colE[x] += g;
      }
    }
    const cut = (arr, len) => {
      let max = 0;
      for (let i = 0; i < len; i++) if (arr[i] > max) max = arr[i];
      if (max <= 0) return null;
      // 직접 드래그한 경우엔 더 바짝 조인다 (주변 여백이 남는다는 피드백 반영)
      const th = max * (tight ? 0.3 : 0.14);
      let a = 0;
      let b = len - 1;
      while (a < len && arr[a] < th) a++;
      while (b > a && arr[b] < th) b--;
      return a >= b ? null : [a, b];
    };
    const rc = cut(rowE, AH);
    const cc = cut(colE, AW);
    if (!rc || !cc) return rect;

    const sx = W / AW;
    const sy = H / AH;
    const pad = tight ? 0 : 2;
    const nx = rect.x + Math.max(0, (cc[0] - pad) * sx);
    const ny = rect.y + Math.max(0, (rc[0] - pad) * sy);
    const nw = Math.min(W - (nx - rect.x), (cc[1] - cc[0] + 1 + pad * 2) * sx);
    const nh = Math.min(H - (ny - rect.y), (rc[1] - rc[0] + 1 + pad * 2) * sy);
    if (nw < 40 || nh < 40) return rect;
    return { x: nx, y: ny, w: nw, h: nh };
  }

  // ---------- 캡처 실행 ----------
  // 캡처 순간 마우스가 올라가 있어 생긴 hover 강조가 같이 찍히는 것을 막는다
  function suppressHover() {
    const st = document.createElement('style');
    st.id = 'cst-nohover';
    st.textContent =
      '*, *::before, *::after { transition: none !important; animation: none !important; }' +
      'body * { cursor: none !important; }';
    document.documentElement.appendChild(st);
    // 포인터를 화면 밖으로 보낸 것처럼 이벤트를 흘려 hover 상태를 푼다
    try {
      const ev = (t) => document.elementFromPoint(2, 2) &&
        document.elementFromPoint(2, 2).dispatchEvent(new PointerEvent(t, { bubbles: true, clientX: -50, clientY: -50 }));
      ev('pointerout');
      ev('pointerleave');
      ev('mouseout');
    } catch (_) {}
    return () => st.remove();
  }

  function hideOurUi() {
    const hidden = [];
    for (const elx of [panel, fab, noticeBar, toastEl]) {
      if (elx && elx.style.display !== 'none') {
        hidden.push([elx, elx.style.display]);
        elx.style.display = 'none';
      }
    }
    return () => {
      for (const [elx, disp] of hidden) elx.style.display = disp;
    };
  }

  function msg(type, payload) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type, ...(payload || {}) }, (r) =>
          resolve(chrome.runtime.lastError ? { ok: false, error: chrome.runtime.lastError.message } : r)
        );
      } catch (err) {
        resolve({ ok: false, error: String(err && err.message) });
      }
    });
  }

  function loadImg(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error('이미지를 읽지 못했어요.'));
      img.src = src;
    });
  }

  async function shoot() {
    const res = await msg('CAPTURE_VISIBLE');
    if (!res || !res.ok || !res.dataUrl) throw new Error((res && res.error) || '캡처 응답 없음');
    const img = await loadImg(res.dataUrl);
    const cv = document.createElement('canvas');
    cv.width = img.width;
    cv.height = img.height;
    cv.getContext('2d').drawImage(img, 0, 0);
    return { canvas: cv, scale: img.width / innerWidth };
  }

  // 사람이 읽는 파일 크기
  function fmtSize(bytes) {
    if (bytes < 1024) return bytes + 'B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + 'KB';
    return (bytes / 1048576).toFixed(2) + 'MB';
  }

  function saveBlob(blob, ext) {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    const stamp = `${String(d.getFullYear()).slice(2)}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${capName}_맵시트_${stamp}.${ext}`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 20000);
  }

  let capName = '코코포리아';

  // 원본 이미지 그대로 저장 (맵시트가 이미지 한 장일 때 — 화면 캡처보다 훨씬 고화질)
  async function saveOriginal(url) {
    const res = await fetch(url, { mode: 'cors' });
    if (!res.ok) throw new Error('원본 이미지를 받지 못했어요.');
    const blob = await res.blob();
    const bmp = await createImageBitmap(blob).catch(() => null);
    const ext = (blob.type.split('/')[1] || 'png').replace('jpeg', 'jpg');
    saveBlob(blob, ext);
    return bmp ? `${bmp.width}×${bmp.height}` : '원본';
  }

  async function runCapture(mode, reuseRect) {
    if (capBusy) return;
    capBusy = true;
    capStop = false;
    try {
      const room = await getRoom();
      capName = (room.name || '코코포리아').replace(/[\\/:*?"<>|]/g, '_').slice(0, 40);

      // 드래그 모드는 먼저 범위를 받는다
      let dragRect = reuseRect || null;
      if ((mode === 'drag' || mode === 'dragRaw') && !dragRect) {
        panel.style.display = 'none';
        dragRect = await new Promise((r) => startAreaSelect(r));
        panel.style.display = 'flex';
        if (!dragRect) {
          capBusy = false;
          return;
        }
        // 다음에 또 쓸 수 있게 이 방의 영역으로 기억해 둔다
        await saveCapRect(dragRect, mode);
        if (state.activeTab === 'capture') renderCapture();
      }

      // '원본 파일' 모드일 때만 맵시트 이미지 원본을 그대로 받는다.
      // (자동 인식은 전경·배경·캐릭터가 다 보이는 화면 그대로를 찍어야 한다)
      if (mode === 'original') {
        const sheet = findMapSheet();
        if (!sheet || !/^https?:/i.test(sheet.url)) {
          capSay('맵시트가 이미지 파일이 아니라 원본을 받을 수 없어요. [맵시트 자동 인식]을 써 주세요.');
          capBusy = false;
          return;
        }
        capSay('원본 이미지 받는 중…');
        const size = await saveOriginal(sheet.url);
        capSay(`원본 이미지 그대로 저장됨 (${size}) — 캐릭터 말은 포함되지 않습니다`);
        toast(`맵시트 원본 저장됨 (${size})`);
        capBusy = false;
        return;
      }

      if (capState.format === 'gif') {
        await captureGif(mode, dragRect);
      } else {
        await captureStill(mode, dragRect);
      }
    } catch (err) {
      const msgText = friendlyError(err);
      capSay(msgText);
      toast(msgText);
    }
    capBusy = false;
  }

  let capBusy = false;
  let capStop = false;

  // 개발자 오류 문구를 사용자가 이해할 수 있는 말로 바꾼다
  function friendlyError(err) {
    const raw = String((err && err.message) || err || '');
    if (/Extension context invalidated|context invalidated/i.test(raw)) {
      return '확장이 방금 업데이트돼서 연결이 끊겼어요. 페이지를 새로고침(F5)한 뒤 다시 시도해 주세요.';
    }
    if (/MAX_CAPTURE|quota|too many/i.test(raw)) {
      return '캡처를 너무 빠르게 반복했어요. 몇 초 뒤에 다시 눌러 주세요.';
    }
    if (/activeTab|permission|not allowed/i.test(raw)) {
      return '이 탭을 캡처할 권한이 없어요. 코코포리아 방 화면에서 실행했는지 확인해 주세요.';
    }
    if (/응답 없음|no tab|Receiving end does not exist/i.test(raw)) {
      return '확장 백그라운드가 응답하지 않아요. 페이지를 새로고침하거나 브라우저를 다시 켜 주세요.';
    }
    if (/원본 이미지를 받지 못했|Failed to fetch|NetworkError/i.test(raw)) {
      return '이미지를 내려받지 못했어요. 인터넷 연결을 확인하거나 [맵시트 자동 인식]으로 화면을 찍어 주세요.';
    }
    if (/변환 실패|toBlob/i.test(raw)) {
      return '이미지를 파일로 만드는 데 실패했어요. 캡처 영역이 너무 크지 않은지 확인해 주세요.';
    }
    return '캡처에 실패했어요: ' + raw;
  }

  // 배율 적용: 브라우저를 확대해 실제로 더 큰 픽셀로 렌더링시킨다.
  // 확대해도 캡처 해상도가 늘지 않는 화면(뷰포트에 꽉 맞춘 레이아웃)이면 원래대로 되돌린다.
  // ---------- 배율 캡처 ----------
  // 배율을 올리는 방법은 크롬 확대율을 올려 같은 영역에 픽셀을 더 담는 것뿐이다.
  // 그런데 확대하면 화면이 다시 배치돼서, 맵시트가 잘리거나
  // 엉뚱한 요소(넓어진 채팅창)가 제일 큰 후보로 잡히는 일이 있었다.
  // 그래서 확대 전 "화면에서 차지하던 비율"을 기억해 두고,
  // 확대 후에도 배치가 그대로인지 확인한 다음에만 그 배율로 찍는다.
  // 어긋나면 배율을 한 단계 낮춰 다시 보고, 끝까지 안 맞으면 1배율로 찍는다.
  function viewportFrac(r) {
    return {
      fx: r.x / innerWidth,
      fy: r.y / innerHeight,
      fw: r.w / innerWidth,
      fh: r.h / innerHeight,
    };
  }

  function fracToRect(f) {
    return {
      x: f.fx * innerWidth,
      y: f.fy * innerHeight,
      w: f.fw * innerWidth,
      h: f.fh * innerHeight,
    };
  }

  function fracClose(a, b, tol) {
    const t = tol || 0.04;
    return (
      Math.abs(a.fx - b.fx) < t &&
      Math.abs(a.fy - b.fy) < t &&
      Math.abs(a.fw - b.fw) < t &&
      Math.abs(a.fh - b.fh) < t
    );
  }

  // 찍을 영역을 1배율에서 먼저 정하고, 배율을 낮춰가며 배치가 유지되는 지점을 찾는다.
  // 반환: { s, r, scale, asked } — r은 그때 화면 좌표(CSS px)
  async function shootAtBestScale(mode, dragRect) {
    const base0 = rectFor(mode, dragRect);
    if (!base0 || base0.w < 4 || base0.h < 4) return null;
    const want = viewportFrac(base0);
    const boardBefore = viewportFrac(boardRect());
    const asked = capState.scale;

    const steps = asked === 4 ? [4, 2, 1] : asked === 2 ? [2, 1] : [1];
    const z = asked > 1 ? await msg('GET_ZOOM') : null;
    const base = z && z.ok ? z.factor : 1;
    const unzoom = async () => {
      await msg('SET_ZOOM', { factor: base });
      await new Promise((r) => setTimeout(r, 250));
    };

    for (const k of steps) {
      if (k > 1) {
        const set = await msg('SET_ZOOM', { factor: base * k });
        if (!set || !set.ok) continue;
        await new Promise((r) => setTimeout(r, 700));
        // 확대해도 화면 배치가 비율 그대로인지 확인 — 아니면 이 배율은 쓸 수 없다
        if (!fracClose(boardBefore, viewportFrac(boardRect()))) {
          await unzoom();
          continue;
        }
      }
      await new Promise((r) => requestAnimationFrame(() => setTimeout(r, 80)));
      const s = await shoot();
      const r = fracToRect(want);
      if (k > 1) await unzoom();
      return { s, r, scale: k, asked };
    }
    return null;
  }

  function rectFor(mode, dragRect) {
    if (mode === 'full') return { x: 0, y: 0, w: innerWidth, h: innerHeight };
    if (mode === 'board') return boardRect();
    if (mode === 'drag' || mode === 'dragRaw') return dragRect;
    const sheet = findMapSheet();
    return sheet ? sheet.rect : boardRect();
  }

  async function captureStill(mode, dragRect) {
    capSay('캡처 중…');
    const restore = hideOurUi();
    const unhover = suppressHover();
    let shot;
    try {
      shot = await shootAtBestScale(mode, dragRect);
    } finally {
      unhover();
      restore();
    }
    if (!shot) {
      capSay('찍을 영역을 찾지 못했어요. [영역 드래그]로 직접 감싸 주세요.');
      return;
    }

    const { s, r } = shot;
    let rect = { x: r.x * s.scale, y: r.y * s.scale, w: r.w * s.scale, h: r.h * s.scale };
    // 자동 인식/드래그(다듬기)는 픽셀 경계로 한 번 더 조인다
    if (mode === 'auto' || mode === 'drag' || mode === 'board') {
      rect = trimByContent(s.canvas, rect, mode === 'drag');
    }

    const cv = document.createElement('canvas');
    cv.width = Math.max(1, Math.round(rect.w));
    cv.height = Math.max(1, Math.round(rect.h));
    cv.getContext('2d').drawImage(
      s.canvas,
      Math.round(rect.x),
      Math.round(rect.y),
      cv.width,
      cv.height,
      0,
      0,
      cv.width,
      cv.height
    );

    const scaleNote =
      shot.scale === shot.asked
        ? shot.scale > 1
          ? ` · ${shot.scale}배율`
          : ''
        : ` · ${shot.asked}배율을 요청했지만 확대하면 화면 배치가 바뀌어 맵시트가 잘리므로 ${shot.scale}배율로 찍었어요`;
    capSay(`찍었어요 — ${cv.width}×${cv.height}px${scaleNote}. 미리보기에서 확인 후 저장하세요.`);
    showCapturePreview(cv, mode, dragRect);
  }

  // ---------- 캡처 미리보기 (저장 전에 확인하고 배율 바꿔 다시 찍기) ----------
  let previewOverlay = null;

  let previewObjUrl = '';

  function closeCapturePreview() {
    if (previewObjUrl) {
      URL.revokeObjectURL(previewObjUrl);
      previewObjUrl = '';
    }
    if (previewOverlay) {
      previewOverlay.remove();
      previewOverlay = null;
    }
  }

  // gif를 넘기면 캔버스 대신 그 GIF를 움직이는 채로 보여준다.
  //   gif = { blob, bytes, w, h, delayMs, count, src }
  // src(원본 프레임)가 함께 오면 미리보기에서 재생 속도·가로 크기를 바로 바꿀 수 있다 — 다시 찍지 않는다.
  function showCapturePreview(canvas, mode, dragRect, gif) {
    closeCapturePreview();
    const ov = el('div', 'cst-root');
    ov.id = 'cst-cap-preview';
    previewOverlay = ov;

    let cur = gif || null; // 지금 보고 있는 GIF
    const box = el('div', 'cst-cap-box');
    const head = el('div', 'cst-cap-head');
    const title = el('span', 'cst-cap-title', '');
    const closeBtn = el('button', 'cst-iconbtn', '✕');
    closeBtn.addEventListener('click', closeCapturePreview);
    head.append(title, closeBtn);

    const imgWrap = el('div', 'cst-cap-imgwrap');
    const img = document.createElement('img');
    imgWrap.appendChild(img);
    function paint() {
      if (cur) {
        if (previewObjUrl) URL.revokeObjectURL(previewObjUrl);
        previewObjUrl = URL.createObjectURL(cur.blob);
        img.src = previewObjUrl;
        title.textContent =
          `GIF 미리보기 — ${cur.w}×${cur.h}px · ${cur.count}컷 · ` +
          `컷당 ${(cur.delayMs / 1000).toFixed(2)}초 · ${fmtSize(cur.blob.size)}`;
      } else {
        img.src = canvas.toDataURL('image/png');
        title.textContent = `캡처 미리보기 — ${canvas.width}×${canvas.height}px`;
      }
    }

    const foot = el('div', 'cst-cap-foot');

    if (cur && cur.src) {
      // ---- GIF: 속도·크기를 슬라이더로 그 자리에서 바꾼다 ----
      let speed = capState.gifSpeed;
      let width = cur.w;
      const busy = el('span', 'cst-cap-lab', '');

      // 재생 속도 — 파일 안의 지연 값만 고쳐 쓰면 되므로 즉시 끝난다.
      // 0.25배(느리게)부터 8배까지 0.05 단위.
      const spBox = el('label', 'cst-cap-slider');
      const spLab = el('span', 'cst-cap-lab', '');
      const spRange = document.createElement('input');
      spRange.type = 'range';
      spRange.min = '0.25';
      spRange.max = '8';
      spRange.step = '0.05';
      spRange.value = String(speed);
      const showSpeed = () => {
        const ms = Math.max(20, Math.round(cur.src.realGap / speed));
        spLab.textContent = `재생 ${speed.toFixed(2)}배 · 컷당 ${(ms / 1000).toFixed(2)}초`;
      };
      const applySpeed = () => {
        const ms = Math.max(20, Math.round(cur.src.realGap / speed));
        const patched = window.CSTGif.setDelay(cur.bytes, ms);
        cur = { ...cur, bytes: patched.bytes, blob: new Blob([patched.bytes], { type: 'image/gif' }), delayMs: ms };
        paint();
      };
      spRange.addEventListener('input', () => {
        speed = Number(spRange.value) || 1;
        capState.gifSpeed = speed;
        showSpeed();
        applySpeed(); // 1ms면 끝나니 끄는 대로 바로 반영
      });
      spBox.append(spLab, spRange);

      // 가로 크기 — 프레임을 줄여 다시 만들어야 하므로 놓았을 때만 반영한다
      const wBox = el('label', 'cst-cap-slider');
      const wLab = el('span', 'cst-cap-lab', '');
      const wRange = document.createElement('input');
      wRange.type = 'range';
      wRange.min = String(Math.min(240, cur.src.w));
      wRange.max = String(cur.src.w);
      wRange.step = '8';
      wRange.value = String(width);
      const showWidth = (v) => {
        const h = Math.round((cur.src.h * v) / cur.src.w);
        wLab.textContent = `가로 ${v}px (${v}×${h})` + (v >= cur.src.w ? ' 최대' : '');
      };
      wRange.addEventListener('input', () => showWidth(Number(wRange.value)));
      wRange.addEventListener('change', async () => {
        const v = Number(wRange.value);
        if (v === width) return;
        width = v;
        capState.gifWidth = v;
        busy.textContent = '다시 만드는 중…';
        await new Promise((r) => setTimeout(r, 20));
        cur = { ...buildGif(cur.src, v, speed), src: cur.src };
        busy.textContent = '';
        showWidth(v);
        paint();
      });
      wBox.append(wLab, wRange);

      showSpeed();
      showWidth(width);
      foot.append(spBox, wBox, busy);

    } else {
      // ---- 정지 이미지: 배율은 실제 픽셀을 더 받아와야 하므로 다시 찍어야 한다 ----
      const scaleWrap = el('div', 'cst-colbtns');
      for (const v of [1, 2, 4]) {
        const b = el('button', 'cst-colbtn' + (v === capState.scale ? ' on' : ''), v + 'x');
        b.title = v === 1 ? '지금 화면 그대로' : '더 큰 해상도로 다시 찍습니다 (픽셀을 새로 받아와야 해서 재촬영)';
        b.addEventListener('click', async () => {
          capState.scale = v;
          for (const c of scaleWrap.children) c.classList.toggle('on', c === b);
          closeCapturePreview();
          await runCapture(mode, dragRect);
        });
        scaleWrap.appendChild(b);
      }
      foot.append(el('span', 'cst-cap-lab', '배율'), scaleWrap);
    }

    const saveBtn = el('button', 'cst-btn', '저장');
    saveBtn.addEventListener('click', async () => {
      if (cur) {
        saveBlob(cur.blob, 'gif');
        const sz = fmtSize(cur.blob.size);
        capSay(`GIF 저장됨 — ${cur.w}×${cur.h}px · ${cur.count}컷 · 컷당 ${(cur.delayMs / 1000).toFixed(2)}초 · ${sz}`);
        toast(`GIF 저장됨 (${cur.count}컷 · ${sz})`);
        closeCapturePreview();
        return;
      }
      const isJpg = capState.format === 'jpg';
      try {
        const blob = await new Promise((resolve, reject) =>
          canvas.toBlob(
            (b) => (b ? resolve(b) : reject(new Error('이미지 변환 실패'))),
            isJpg ? 'image/jpeg' : 'image/png',
            isJpg ? 0.94 : undefined
          )
        );
        saveBlob(blob, isJpg ? 'jpg' : 'png');
        const sz = fmtSize(blob.size);
        capSay(`저장됨 — ${canvas.width}×${canvas.height}px · ${sz}`);
        toast(`맵시트 저장됨 (${canvas.width}×${canvas.height}px · ${sz})`);
      } catch (err) {
        toast(friendlyError(err));
      }
      closeCapturePreview();
    });

    foot.append(saveBtn);
    box.append(head, imgWrap, foot);
    ov.appendChild(box);
    ov.addEventListener('click', (e) => {
      if (e.target === ov) closeCapturePreview();
    });
    document.body.appendChild(ov);
    applyTheme();
    paint();
  }

  // ---------- 매끄러운 GIF (탭 영상 스트림) ----------
  // 화면 찍기(captureVisibleTab)는 초당 2번으로 묶여 있어 프레임을 잘게 딸 수 없다.
  // 탭 영상 스트림을 받으면 초당 10~30컷까지 뽑을 수 있다.
  // 쓸 수 없는 환경이면 화면 찍기 방식으로 조용히 되돌아간다.
  // 탭 영상 스트림을 얻는다. 두 가지 길을 차례로 시도한다.
  //  ① chrome.tabCapture — 대화상자가 없어 편하지만, 확장이 이 탭에 대해
  //     "사용자 조작으로 불려온" 상태여야 해서 막히는 경우가 있다.
  //  ② getDisplayMedia — 공유할 화면을 고르는 대화상자가 뜨지만 확실히 된다.
  //     preferCurrentTab으로 지금 탭이 먼저 뜨게 해 둔다.
  const streamErrors = [];

  async function grabTabStream(maxFps) {
    streamErrors.length = 0;

    // ① tabCapture
    try {
      const res = await msg('GET_STREAM_ID');
      if (!res || !res.ok) throw new Error((res && res.error) || '스트림 ID 발급 실패');
      // 크기를 안 주면 크롬이 기본 해상도로 내보내며 비율이 다르면 위아래 검은 띠를 넣는다.
      // 뷰포트의 실제 픽셀 크기를 그대로 요구해 영상 좌표 = 화면 좌표가 되게 한다.
      const dpr = window.devicePixelRatio || 1;
      const vw = Math.max(2, Math.round(innerWidth * dpr));
      const vh = Math.max(2, Math.round(innerHeight * dpr));
      const ask = (size) =>
        navigator.mediaDevices.getUserMedia({
          audio: false,
          video: {
            mandatory: {
              chromeMediaSource: 'tab',
              chromeMediaSourceId: res.streamId,
              maxFrameRate: maxFps || 30,
              ...(size ? { minWidth: vw, maxWidth: vw, minHeight: vh, maxHeight: vh } : {}),
            },
          },
        });
      let st;
      try {
        st = await ask(true);
      } catch (_) {
        // 정확한 크기를 못 맞추는 환경이면 크기 조건 없이 다시 (검은 띠는 뒤에서 보정한다)
        st = await ask(false);
      }
      return { stream: st, how: 'tab' };
    } catch (err) {
      streamErrors.push('탭 캡처: ' + ((err && err.message) || (err && err.name) || 'error'));
    }

    // ② getDisplayMedia (대화상자)
    if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
      throw new Error(streamErrors.join(' / ') + ' / 이 브라우저는 화면 공유를 지원하지 않습니다');
    }
    try {
      const st = await navigator.mediaDevices.getDisplayMedia({
        audio: false,
        video: { frameRate: { ideal: maxFps || 30 } },
        preferCurrentTab: true,
      });
      return { stream: st, how: 'display' };
    } catch (err) {
      streamErrors.push('화면 공유: ' + ((err && err.message) || (err && err.name) || 'error'));
      throw new Error(streamErrors.join(' / '));
    }
  }

  async function grabSmoothFrames(mode, dragRect, hud) {
    hud.set('영상 스트림 준비 중… (화면 공유 창이 뜨면 이 탭을 골라 주세요)');
    const got = await grabTabStream(capState.gifFps);
    const stream = got.stream;

    const video = document.createElement('video');
    video.muted = true;
    video.playsInline = true;
    video.srcObject = stream;
    const stop = () => {
      try {
        for (const t of stream.getTracks()) t.stop();
      } catch (_) {}
      video.srcObject = null;
    };

    try {
      await video.play();
      // 첫 프레임이 들어올 때까지
      for (let i = 0; i < 60 && !video.videoWidth; i++) await new Promise((r) => setTimeout(r, 50));
      if (!video.videoWidth) throw new Error('탭 영상이 시작되지 않았습니다.');

      // 영상 비율이 뷰포트와 다르면 크롬이 검은 띠를 넣어 맞춘다 (레터박스/필러박스).
      // 그 띠 두께만큼 원점을 옮겨야 화면 찍기 방식과 같은 자리가 잘린다.
      const vwAspect = innerWidth / innerHeight;
      const vAspect = video.videoWidth / video.videoHeight;
      let contentW = video.videoWidth;
      let contentH = video.videoHeight;
      let offX = 0;
      let offY = 0;
      if (Math.abs(vAspect - vwAspect) > 0.005) {
        if (vAspect > vwAspect) {
          contentW = video.videoHeight * vwAspect; // 좌우 띠
          offX = (video.videoWidth - contentW) / 2;
        } else {
          contentH = video.videoWidth / vwAspect; // 위아래 띠
          offY = (video.videoHeight - contentH) / 2;
        }
      }
      const vScale = contentW / innerWidth;
      const r0 = mode === 'drag' || mode === 'dragRaw' ? dragRect : rectFor(mode, null);
      let px = { x: offX + r0.x * vScale, y: offY + r0.y * vScale, w: r0.w * vScale, h: r0.h * vScale };

      // 경계 다듬기는 한 프레임을 캔버스에 올려놓고 판단한다
      const probe = document.createElement('canvas');
      probe.width = video.videoWidth;
      probe.height = video.videoHeight;
      probe.getContext('2d', { willReadFrequently: true }).drawImage(video, 0, 0);
      if (mode === 'auto' || mode === 'drag' || mode === 'board') px = trimByContent(probe, px, mode === 'drag');
      // 영상은 계속 흘러 들어오므로 표시기를 촬영 영역 밖으로 치워 둔다
      hud.avoid({ x: (px.x - offX) / vScale, y: (px.y - offY) / vScale, w: px.w / vScale, h: px.h / vScale });

      // 컷이 많아지므로 담아두는 폭을 줄인다 (프레임 수 × 픽셀이 메모리를 잡아먹는다)
      const capW = keepWidthFor(Math.min(GIF_MAX_FRAMES, Math.round(capState.gifSec * capState.gifFps)), px.w, px.h);
      const k = px.w > capW ? capW / px.w : 1;
      const W = Math.max(1, Math.round(px.w * k));
      const H = Math.max(1, Math.round(px.h * k));

      const cv = document.createElement('canvas');
      cv.width = W;
      cv.height = H;
      const ctx = cv.getContext('2d', { willReadFrequently: true });

      const fps = capState.gifFps;
      const step = 1000 / fps;
      const total = Math.min(GIF_MAX_FRAMES, Math.max(2, Math.round(capState.gifSec * fps)));
      const frames = [];
      const t0 = Date.now();
      for (let i = 0; i < total; i++) {
        if (capStop) break;
        hud.set(`매끄러운 GIF 촬영 중 ${i + 1}/${total} (초당 ${fps}컷)`);
        ctx.drawImage(video, Math.round(px.x), Math.round(px.y), Math.round(px.w), Math.round(px.h), 0, 0, W, H);
        frames.push(ctx.getImageData(0, 0, W, H).data);
        const due = t0 + (i + 1) * step - Date.now();
        if (due > 0) await new Promise((r) => setTimeout(r, due));
      }
      const elapsed = Date.now() - t0;
      // 실제로 걸린 시간을 컷 수로 나눈 값이 진짜 간격이다
      const realGap = frames.length > 1 ? elapsed / frames.length : step;
      return { frames, w: W, h: H, realGap, fps };
    } finally {
      stop();
    }
  }

  const GIF_MAX_FRAMES = 150;
  const GIF_MAX_W = 2560; // 사람이 고를 수 있는 최대 폭
  // 담아두는 프레임 전체 픽셀 수 상한. RGBA 4바이트니까 약 160MB.
  // 컷이 적으면 크게, 많으면 작게 — 알아서 균형이 잡힌다.
  const GIF_PIXEL_BUDGET = 40e6;

  function keepWidthFor(frameCount, w, h) {
    const aspect = Math.max(0.1, w / Math.max(1, h));
    const byBudget = Math.floor(Math.sqrt((GIF_PIXEL_BUDGET / Math.max(1, frameCount)) * aspect));
    return Math.max(240, Math.min(GIF_MAX_W, byBudget, Math.round(w)));
  }

  async function captureGif(mode, dragRect) {
    if (!window.CSTGif) {
      toast('GIF 인코더를 불러오지 못했어요. 페이지를 새로고침해 주세요.');
      return;
    }

    // 매끄럽게 모드 — 실패하면 아래 화면 찍기 방식으로 내려간다
    if (capState.gifSmooth) {
      const restore0 = hideOurUi();
      const unhover0 = suppressHover();
      const hud0 = showCaptureHud();
      let src = null;
      let why = '';
      try {
        src = await grabSmoothFrames(mode, dragRect, hud0);
      } catch (err) {
        why = (err && err.message) || '실패';
      } finally {
        unhover0();
        restore0();
        hud0.done();
      }
      if (src && src.frames.length) {
        capSay('GIF 만드는 중… (잠시 걸립니다)');
        await new Promise((r) => setTimeout(r, 30));
        const out = buildGif(src, Math.min(capState.gifWidth, src.w), capState.gifSpeed);
        capSay(
          `GIF 완성 — ${out.w}×${out.h}px · ${src.frames.length}컷 (초당 ${src.fps}컷) · ${fmtSize(out.blob.size)}.`
        );
        showCapturePreview(null, mode, dragRect, { ...out, src });
        return;
      }
      capSay(`매끄럽게 찍지 못해 화면 찍기(초당 2컷)로 진행합니다 — ${why}`);
      await new Promise((r) => setTimeout(r, 600));
    }

    const FPS = 2; // 브라우저가 탭 캡처를 초당 2회로 제한한다
    const total = Math.max(2, capState.gifSec * FPS);
    const restore = hideOurUi();
    const unhover = suppressHover();
    const hud = showCaptureHud();
    const frames = [];
    const gaps = []; // 컷 사이 실제로 걸린 시간
    let W = 0;
    let H = 0;
    try {
      await new Promise((r) => requestAnimationFrame(() => setTimeout(r, 80)));
      let rect = null;
      let prevAt = 0;
      for (let i = 0; i < total; i++) {
        if (capStop) break;
        const t0 = Date.now();
        hud.set(`GIF 촬영 중 ${i + 1}/${total}`);
        // 표시기가 컷에 찍히지 않게 찍는 순간만 숨긴다 (숨김이 그려질 한 프레임을 기다린 뒤 촬영)
        hud.hide();
        await new Promise((r) => requestAnimationFrame(() => setTimeout(r, 0)));
        let s;
        try {
          s = await shoot();
        } finally {
          hud.show();
        }
        if (prevAt) gaps.push(t0 - prevAt);
        prevAt = t0;
        if (!rect) {
          const r0 = mode === 'drag' || mode === 'dragRaw' ? dragRect : rectFor(mode, null);
          let px = { x: r0.x * s.scale, y: r0.y * s.scale, w: r0.w * s.scale, h: r0.h * s.scale };
          if (mode === 'auto' || mode === 'drag' || mode === 'board') px = trimByContent(s.canvas, px, mode === 'drag');
          // 프레임은 담을 수 있는 가장 큰 폭으로 담아둔다.
          // 그래야 미리보기에서 가로 크기를 바꿀 때 다시 찍지 않고 줄여서 다시 만들 수 있다.
          const keep = keepWidthFor(total, px.w, px.h);
          const k = px.w > keep ? keep / px.w : 1;
          rect = px;
          W = Math.max(1, Math.round(px.w * k));
          H = Math.max(1, Math.round(px.h * k));
        }
        const cv = document.createElement('canvas');
        cv.width = W;
        cv.height = H;
        const ctx = cv.getContext('2d', { willReadFrequently: true });
        ctx.drawImage(s.canvas, Math.round(rect.x), Math.round(rect.y), Math.round(rect.w), Math.round(rect.h), 0, 0, W, H);
        frames.push(ctx.getImageData(0, 0, W, H).data);
        capSay(`GIF 촬영 중 ${i + 1}/${total}…`);
        const wait = 1000 / FPS - (Date.now() - t0);
        if (wait > 0) await new Promise((r) => setTimeout(r, wait));
      }
    } finally {
      unhover();
      restore();
      hud.done();
    }

    if (!frames.length) {
      capSay('GIF 촬영이 중단됐어요.');
      return;
    }
    capSay('GIF 만드는 중… (잠시 걸립니다)');
    await new Promise((r) => setTimeout(r, 30));

    // 실제로 찍힌 간격의 중앙값. 브라우저 제한 때문에 500ms보다 늘어지는 일이 흔한데,
    // 예전에는 무조건 500ms로 적어서 실제보다 빠르게 재생됐다.
    const realGap = gaps.length
      ? [...gaps].sort((a, b) => a - b)[Math.floor(gaps.length / 2)]
      : 1000 / FPS;
    // 재생 속도: 실제 속도(1) / 조금 빠르게(2) / 빠르게(3)
    const delayMs = Math.max(20, Math.round(realGap / capState.gifSpeed));

    // 담아둔 프레임(원본 폭 W)과 실제 간격을 들고 미리보기로 넘긴다.
    // 미리보기에서 가로 크기·재생 속도를 바꿀 때 다시 찍지 않고 여기서 다시 만든다.
    const src = { frames, w: W, h: H, realGap };
    const out = buildGif(src, Math.min(capState.gifWidth, W), capState.gifSpeed);
    capSay(`GIF 완성 — ${out.w}×${out.h}px · ${frames.length}컷 · ${fmtSize(out.blob.size)}. 미리보기에서 속도·크기를 바꿔볼 수 있어요.`);
    showCapturePreview(null, mode, dragRect, { ...out, src });
  }

  // 담아둔 프레임으로 GIF를 만든다. 폭을 줄이는 것만 한다 (없는 픽셀을 늘리지는 않는다).

  function buildGif(src, targetW, speed) {
    const w = Math.max(16, Math.min(targetW || src.w, src.w));
    const h = Math.max(1, Math.round((src.h * w) / src.w));
    let frames = src.frames;
    if (w !== src.w) {
      // 프레임마다 줄여 다시 그린다
      const from = document.createElement('canvas');
      from.width = src.w;
      from.height = src.h;
      const fctx = from.getContext('2d', { willReadFrequently: true });
      const to = document.createElement('canvas');
      to.width = w;
      to.height = h;
      const tctx = to.getContext('2d', { willReadFrequently: true });
      tctx.imageSmoothingEnabled = true;
      tctx.imageSmoothingQuality = 'high';
      frames = src.frames.map((data) => {
        fctx.putImageData(new ImageData(new Uint8ClampedArray(data), src.w, src.h), 0, 0);
        tctx.clearRect(0, 0, w, h);
        tctx.drawImage(from, 0, 0, w, h);
        return tctx.getImageData(0, 0, w, h).data;
      });
    }
    const delayMs = Math.max(20, Math.round(src.realGap / (speed || 1)));
    const bytes = window.CSTGif.encode(frames, w, h, { delayMs, maxColors: 255 });
    return { blob: new Blob([bytes], { type: 'image/gif' }), bytes, w, h, delayMs, count: frames.length };
  }

  // 패널을 숨긴 동안에도 진행 상황이 보이도록 화면에 띄우는 표시기 (중지 버튼 포함)
  function showCaptureHud() {
    const hud = el('div', 'cst-root');
    hud.id = 'cst-cap-hud';
    const txt = el('span', 'cst-cap-hud-text', '준비 중…');
    const stop = el('button', 'cst-btn ghost', '중지');
    stop.addEventListener('click', () => {
      capStop = true;
      txt.textContent = '중지하는 중…';
    });
    hud.append(txt, stop);
    document.body.appendChild(hud);
    applyTheme();
    // 촬영 영역(CSS px)과 겹치지 않는 자리로 옮긴다 — 겹치지 않는 자리가 없으면 숨긴다.
    // (탭 캡처에는 이 표시기도 같이 찍히므로, 크게 찍을 때 "촬영 중 8/8"이 GIF에 남던 문제)
    const avoid = (rc) => {
      if (!rc) return;
      hud.style.visibility = '';
      const w = hud.offsetWidth || 240;
      const h = hud.offsetHeight || 40;
      const M = 10;
      const spots = [
        { left: innerWidth / 2 - w / 2, top: innerHeight - 26 - h },
        { left: innerWidth / 2 - w / 2, top: 26 },
        { left: innerWidth - 16 - w, top: innerHeight / 2 - h / 2 },
        { left: 16, top: innerHeight / 2 - h / 2 },
        { left: innerWidth - 16 - w, top: 26 },
        { left: 16, top: 26 },
        { left: innerWidth - 16 - w, top: innerHeight - 26 - h },
        { left: 16, top: innerHeight - 26 - h },
      ];
      const overlaps = (p) =>
        !(p.left + w + M < rc.x || p.left - M > rc.x + rc.w || p.top + h + M < rc.y || p.top - M > rc.y + rc.h);
      const ok = spots.find((p) => !overlaps(p));
      if (!ok) {
        hud.style.visibility = 'hidden';
        return;
      }
      hud.style.left = Math.round(ok.left) + 'px';
      hud.style.top = Math.round(ok.top) + 'px';
      hud.style.bottom = 'auto';
      hud.style.transform = 'none';
    };
    return {
      set: (m) => (txt.textContent = m),
      hide: () => (hud.style.visibility = 'hidden'),
      show: () => (hud.style.visibility = ''),
      avoid,
      done: () => hud.remove(),
    };
  }

  // 드래그로 영역 선택 → cb(rect | null)
  function startAreaSelect(cb) {
    const ov = el('div', 'cst-root');
    ov.style.cssText = 'position:fixed;inset:0;z-index:2147483100;cursor:crosshair;background:rgba(0,0,0,.25);';
    const tip = el('div', '', '맵시트를 대충 감싸도록 드래그하세요 — ESC 취소');
    tip.style.cssText =
      'position:absolute;top:14px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,.75);color:#fff;' +
      'padding:6px 14px;border-radius:99px;font-size:12px;font-family:sans-serif;pointer-events:none;';
    const box = el('div');
    box.style.cssText =
      'position:absolute;border:2px solid #e05252;background:rgba(224,82,82,.12);display:none;pointer-events:none;';
    ov.append(tip, box);
    document.body.appendChild(ov);

    let sx = 0;
    let sy = 0;
    let dragging = false;
    const done = (rect) => {
      ov.remove();
      document.removeEventListener('keydown', onKey, true);
      cb(rect);
    };
    const onKey = (e) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        done(null);
      }
    };
    document.addEventListener('keydown', onKey, true);
    ov.addEventListener('pointerdown', (e) => {
      dragging = true;
      sx = e.clientX;
      sy = e.clientY;
      box.style.display = 'block';
      ov.setPointerCapture(e.pointerId);
    });
    ov.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      box.style.left = Math.min(sx, e.clientX) + 'px';
      box.style.top = Math.min(sy, e.clientY) + 'px';
      box.style.width = Math.abs(e.clientX - sx) + 'px';
      box.style.height = Math.abs(e.clientY - sy) + 'px';
    });
    ov.addEventListener('pointerup', (e) => {
      if (!dragging) return;
      const rect = {
        x: Math.min(sx, e.clientX),
        y: Math.min(sy, e.clientY),
        w: Math.abs(e.clientX - sx),
        h: Math.abs(e.clientY - sy),
      };
      done(rect.w > 8 && rect.h > 8 ? rect : null);
    });
  }

  // ----- 토스트 -----
  let toastEl = null;
  function toast(msg) {
    if (!toastEl) {
      toastEl = el('div', 'cst-root');
      toastEl.style.cssText =
        'position:fixed;left:50%;bottom:90px;transform:translateX(-50%);z-index:2147483001;' +
        'background:var(--cst-card);color:var(--cst-text);border:1px solid var(--cst-border);' +
        'border-radius:10px;padding:8px 14px;font-size:12px;box-shadow:var(--cst-shadow);display:none;max-width:70vw;';
      document.body.appendChild(toastEl);
      applyTheme();
    }
    toastEl.textContent = msg;
    toastEl.style.display = 'block';
    clearTimeout(toastEl._t);
    toastEl._t = setTimeout(() => (toastEl.style.display = 'none'), 2200);
  }

  // ---------------- 초기화 ----------------
  async function init() {
    const s = await getSync({
      theme: 'dark',
      accentColor: '',
      ccfPanel: true,
      specialChars: DEFAULT_CHARS,
      standingThumb: { zoom: 100, posX: 50, posY: 15 },
      standingCols: 3,
      standingCss: {},
      standingAtPrefix: true,
      noticePos: 'top',
      noticeFont: 12,
    });
    state.theme = THEMES.includes(s.theme) ? s.theme : 'dark';
    state.accent = s.accentColor || '';
    state.noticePos = s.noticePos === 'bottom' ? 'bottom' : 'top';
    state.noticeFont = Number(s.noticeFont) || 12;
    state.atPrefix = s.standingAtPrefix !== false;
    state.panelOn = s.ccfPanel !== false;
    state.specialChars =
      Array.isArray(s.specialChars) && s.specialChars.length ? s.specialChars : DEFAULT_CHARS;
    state.thumb = { zoom: 100, posX: 50, posY: 15, ...(s.standingThumb || {}) };
    state.cols = [1, 2, 3, 4].includes(s.standingCols) ? s.standingCols : 3;
    state.standingCss = s.standingCss || {};
    if (!state.panelOn) return;
    buildUI();
    refreshNoticeBar();
  }

  if (extAlive()) chrome.storage.onChanged.addListener((changes, area) => {
    // 세션 관리자 등 다른 화면에서 공지를 고치면 방 화면 공지 바도 갱신
    if (area === 'local' && changes.rooms) {
      refreshNoticeBar();
      return;
    }
    if (area !== 'sync') return;
    if (changes.theme || changes.accentColor) {
      if (changes.theme) state.theme = THEMES.includes(changes.theme.newValue) ? changes.theme.newValue : 'dark';
      if (changes.accentColor) state.accent = changes.accentColor.newValue || '';
      applyTheme();
    }
    if (changes.noticePos || changes.noticeFont) {
      if (changes.noticePos) state.noticePos = changes.noticePos.newValue === 'bottom' ? 'bottom' : 'top';
      if (changes.noticeFont) state.noticeFont = Number(changes.noticeFont.newValue) || 12;
      refreshNoticeBar();
    }
    if (changes.specialChars) {
      state.specialChars = changes.specialChars.newValue || DEFAULT_CHARS;
      if (state.activeTab === 'chars') renderBody();
    }
    if (changes.standingThumb) {
      if (suppressThumbEcho) {
        suppressThumbEcho = false;
      } else {
        state.thumb = { zoom: 100, posX: 50, posY: 15, ...(changes.standingThumb.newValue || {}) };
        refreshThumbStyles();
      }
    }
    if (changes.standingCols) {
      if (suppressColsEcho) {
        suppressColsEcho = false;
      } else {
        state.cols = changes.standingCols.newValue || 3;
        if (state.activeTab === 'standing') renderBody();
      }
    }
    if (changes.standingCss) {
      if (suppressCssEcho) suppressCssEcho = false;
      else state.standingCss = changes.standingCss.newValue || {};
    }
    if (changes.standingAtPrefix) {
      state.atPrefix = changes.standingAtPrefix.newValue !== false;
    }
    if (changes.ccfPanel) {
      const on = changes.ccfPanel.newValue !== false;
      if (on && !panel) buildUI();
      if (panel) panel.style.display = on ? panel.style.display : 'none';
      if (fab) fab.style.display = on ? 'flex' : 'none';
    }
  });

  if (document.readyState === 'loading') {
    window.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
