// 코코포리아 선생님 — 채팅 알림음
// 만두 확장의 <title> 감지 방식 + 스크롤 오탐 방지 가드:
//  1) 이 창에서 최근 2초 안에 스크롤/휠/포인터 조작이 있었으면 알림 억제
//     (창을 클릭하지 않고 휠로 과거 로그를 올릴 때 발생하던 오탐 수정)
//  2) 알림은 1.5초에 1회로 제한
//  3) 탭·창이 포커스 상태면 알림 없음
(() => {
  if (window.__cstNotifyLoaded) return;
  window.__cstNotifyLoaded = true;

  const EXT = typeof chrome !== 'undefined' && chrome.storage && chrome.runtime;
  if (!EXT) return;

  const sound = new Audio(chrome.runtime.getURL('sounds/notify.mp3'));
  sound.volume = 1;

  let enabled = true;

  // 확장을 새로고침하면 남아 있던 이 스크립트의 chrome.* 연결이 끊긴다
  // ("Extension context invalidated"). 호출 전에 살아 있는지 확인한다.
  function extAlive() {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (_) {
      return false;
    }
  }

  if (extAlive()) chrome.storage.sync.get({ ccfNotify: true }, (s) => (enabled = !chrome.runtime.lastError && s.ccfNotify !== false));
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync' && changes.ccfNotify) enabled = changes.ccfNotify.newValue !== false;
  });

  // ---- 사용자 조작 감지 (스크롤 오탐 가드) ----
  let lastUserAction = 0;
  const markAction = () => (lastUserAction = Date.now());
  window.addEventListener('wheel', markAction, { passive: true, capture: true });
  window.addEventListener('scroll', markAction, { passive: true, capture: true });
  window.addEventListener('pointerdown', markAction, { passive: true, capture: true });
  window.addEventListener('keydown', markAction, { passive: true, capture: true });

  let lastPlay = 0;
  function notify() {
    if (!enabled) return;
    if (document.hasFocus()) return;
    const now = Date.now();
    if (now - lastUserAction < 2000) return; // 사용자가 직접 조작 중 → 신규 채팅 아님
    if (now - lastPlay < 1500) return; // 연타 방지
    lastPlay = now;
    sound.play().catch(() => {});
  }

  // ---- <title> 변경 감지 ----
  function observeTitle() {
    const head = document.head;
    if (!head) return;

    let titleObserver = null;
    let lastTitle = document.title;

    function watch(titleElem) {
      if (titleObserver) titleObserver.disconnect();
      if (!titleElem) return;
      titleObserver = new MutationObserver(() => {
        const cur = titleElem.textContent.trim();
        if (cur !== lastTitle) {
          lastTitle = cur;
          notify();
        }
      });
      titleObserver.observe(titleElem, { characterData: true, childList: true, subtree: true });
    }

    new MutationObserver((muts) => {
      for (const mu of muts) {
        for (const node of mu.addedNodes) {
          if (node.nodeType === Node.ELEMENT_NODE && node.tagName === 'TITLE') watch(node);
        }
      }
    }).observe(head, { childList: true });

    watch(document.querySelector('head > title'));
  }

  if (document.readyState === 'loading') {
    window.addEventListener('DOMContentLoaded', observeTitle);
  } else {
    observeTitle();
  }
})();
