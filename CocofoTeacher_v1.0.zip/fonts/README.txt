KoPub돋움 폰트를 넣는 곳입니다.

지금 들어 있는 파일 (이대로 두면 됩니다)
  KoPubWorldDotumMedium.woff2
  KoPubWorldDotumBold.woff2

woff2는 원본 otf(각 3.5MB)의 절반 크기(각 1.9MB)라 확장 용량도, 로그를 저장할 때
파일에 폰트를 내장하는 용량도 훨씬 가볍습니다. 화면에 보이는 모양은 완전히 같습니다.

otf를 그대로 쓰고 싶으면 아래 이름 중 하나로 넣어도 인식합니다 (woff2가 있으면 그쪽 우선).
  KoPubWorld Dotum Medium.otf / KoPubWorldDotumMedium.otf / KoPubWorld Dotum_Pro Medium.otf
  KoPubWorld Dotum Bold.otf   / KoPubWorldDotumBold.otf   / KoPubWorld Dotum_Pro Bold.otf

파일이 하나도 없으면 CDN 웹폰트로 자동 대체됩니다(인터넷 필요).
KoPub 바탕(Batang)은 로그에서 쓰지 않으므로 넣을 필요 없습니다.
